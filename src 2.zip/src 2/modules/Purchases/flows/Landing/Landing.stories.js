import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Landing from './index';

storiesOf('Modules|Purchases/Landing', module).add('Landing screen', () => (
  <Landing />
));

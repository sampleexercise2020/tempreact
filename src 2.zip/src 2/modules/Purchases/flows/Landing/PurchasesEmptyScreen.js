import React from 'react';
import styled from 'styled-components/native';

const icon = require('../../../../../assets/images/purchases_empty_icon.png');

const PurchasesEmptyScreen = (props) => {
  return (
    <Container>
      <Icon source={icon} />
      <Title>No purchase yet</Title>
      <Subtitle>
        When you purchase or order something it will appear here.
      </Subtitle>
    </Container>
  );
};

export default PurchasesEmptyScreen;

const Container = styled.View`
  flex: 1;
  margin: 50px 60px 0 60px;
  align-items: center;
  justify-content: center;
`;

const Title = styled.Text`
  color: #0d1943;
  font-size: 16px;
  font-weight: bold;
  font-family: 'OpenSans-Bold';
  text-align: center;
  margin-bottom: 5px;
  margin-top: 40px;
`;

const Subtitle = styled.Text`
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  line-height: 18px;
  text-align: center;
  color: #0d1943;
`;

const Icon = styled.Image`
  height: 121px;
  width: 108px;
`;

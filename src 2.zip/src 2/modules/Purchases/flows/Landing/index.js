import React, { useEffect, useState } from 'react';
import { Animated } from 'react-native';
import { navigateTo } from 'navigation';
import styled from 'styled-components/native';
import TabHeader from 'components/common/Header/TabHeader';
import SinglePurchase from './components/SinglePurchase';
import CollapsibleHeader from 'components/common/Header/CollapsibleHeader';
import { useActions, useStore } from 'easy-peasy';
import selectedCopy from '../../../../i18n/copy';
import convertDate from 'src/../helpers/convertDate';
import PurchasesEmptyScreen from './PurchasesEmptyScreen';
import { testProperties } from '../../../../helpers/testProperties';

const TitleIcon = require('../../../../../assets/images/purchases_empty_icon.png');

const copy = selectedCopy.components.modules.Purchases.flows.Landing.index;

const Landing = (props) => {
  const accessToken = useStore((state) => state.session.token);
  const receipts = useStore((state) => state.receipts.results);
  const fetchReceipts = useActions((actions) => {
    return actions.receipts.fetch;
  });

  useEffect(() => {
    if (accessToken) {
      fetchReceipts();
    }
  }, [accessToken]);

  return (
    <CollapsibleHeader
      extendedHeight={134}
      collapsedHeight={0}
      isCurved={true}
      bigContent={
        <TabHeader
          text={copy.title}
          testId={'purchases-header'}
          icon={TitleIcon}
        />
      }
      positionFromLeft={20}
      positionFromBottom={44}
      alignBigContentLeft
    >
      <Container
        as={Animated.ScrollView}
        {...testProperties('purchases-container-id')}
      >
        <ScrollContent>
          {receipts && receipts.length > 0 ? (
            receipts.map((receipt) => {
              return (
                <SinglePurchase
                  schoolName={receipt.merchantName}
                  date={convertDate(receipt.timestamp)}
                  refNumber={receipt.ref}
                  onPress={() =>
                    navigateTo('Skiply.Purchases.Receipt', props.componentId, {
                      receipt
                    })
                  }
                  key={receipt.ref}
                  {...testProperties(`purchases-${receipt.refNumber}`)}
                />
              );
            })
          ) : (
            <EmptyScreenContainer>
              <PurchasesEmptyScreen />
            </EmptyScreenContainer>
          )}
        </ScrollContent>
      </Container>
    </CollapsibleHeader>
  );
};

export default Landing;

const Container = styled.View`
  height: 100%;
`;

const ScrollContent = styled.View`
  padding-horizontal: 20px;
`;

const EmptyScreenContainer = styled.View`
  flex: 1;
`;

import React from 'react';
import styled from 'styled-components/native';
import Avatar from '../../../components/common/Avatar/Avatar';
import { testProperties } from '../../../helpers/testProperties';

const CompleteProfileBtn = ({ btnText, image, onPress, componentId }) => {
  return (
    <Container
      componentId={componentId}
      onPress={onPress}
      {...testProperties('home-complete-profile-btn-container-id')}
    >
      <Avatar
        innerBorder
        innerColor='#fff'
        image={image}
        {...testProperties('home-complete-profile-btn-avatar-id')}
      />
      <BtnText {...testProperties('home-complete-profile-btn-buttontitle-id')}>
        {btnText}
      </BtnText>
      <RightArrow
        resizeMode='contain'
        source={require('../../../../assets/icons/common/right-arrow.png')}
      />
    </Container>
  );
};

export default CompleteProfileBtn;

const Container = styled.TouchableOpacity`
  margin: 0 20px 10px 20px;
  align-items: center;
  flex-direction: row;
  height: 60px;
  padding-left: 10px;
  border-radius: 30px;
  box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.08);
  background-color: white;
`;
const BtnText = styled.Text`
  margin-left: 15px;
  color: rgb(13, 25, 67);
  font-family: OpenSans-Regular;
  font-size: 16px;
`;

const RightArrow = styled.Image`
  position: absolute;
  height: 15px;
  right: 10px;
`;

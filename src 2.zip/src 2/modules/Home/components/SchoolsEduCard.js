import React from 'react';
import { Alert, Platform } from 'react-native';
import styled, { css } from 'styled-components/native';
import SchoolHeader from '../../Discover/School/flows/AddStudent/components/SchoolHeader';
import AddStudentBtn from '../../Discover/School/flows/AddStudent/components/AddStudentBtn';
import { dismissOverlay } from 'navigation';
import { useStore, useActions } from 'easy-peasy';
import { Navigation } from 'react-native-navigation';
import { navigateTo, popToRoot } from 'navigation';
import R from 'ramda';
import { testProperties } from 'helpers/testProperties';

const background = require('../../../../assets/backgrounds/school.png');
const SchoolsEduCard = ({ cardBg, pending, componentId }) => {
  const cart = useStore((state) => state.cart);
  const savedStudents = useStore((state) => state.student.lists.saved);

  const fetchMerchant = useActions((actions) => actions.merchant.fetch);
  const setIsFloatingCart = useActions(
    (actions) => actions.cart.setIsFloatingCart
  );
  const merchantIsLoading = useStore((state) => state.merchant.isLoading);
  const updateBeneficiaryId = useActions(
    (actions) => actions.student.updateBeneficiary
  );
  const beneficiaryId =
    cart.carts && cart.carts[0] && cart.carts[0].cartItems[0].beneficiaryId;

  const setCurrentStudent = useActions((actions) => actions.student.setCurrent);

  const carts = useStore((state) => state.cart.carts);
  const deleteCart = useActions((actions) => actions.cart.deleteCart);

  console.log('savedStudents', savedStudents);

  const selectStudent = (student) => {
    // Check if cart should be deleted.
    if (!beneficiaryId) {
      navigateToSchool(student);
    } else if (student.mcBeneficiaryId == beneficiaryId) {
      navigateToSchool(student);
    } else if (carts.length > 0) {
      Alert.alert(
        'Clear cart?',
        'You can only have one cart active at a time. One cart may only include one student. If you want to navigate to a new student, you must clear the cart.',
        [
          {
            text: 'Clear cart',
            onPress: async () => {
              navigateToSchool(student);

              if (carts[0] && carts[0].cartId) {
                const response = await deleteCart(carts[0].cartId);
                if (response.status !== 200) {
                  Navigation.popToRoot(componentId);
                  Alert.alert('Error', response.message);
                }
              }
            }
          },
          { text: 'Cancel', onPress: () => console.log('CANCELLED ACTION') }
        ]
      );
    } else {
      navigateToSchool(student);
    }
  };

  const navigateToTakeATour = () => {
    navigateTo('Skiply.Onboarding.Slider', componentId);
  };

  const navigateToSchool = async (student) => {
    updateBeneficiaryId(student.mcBeneficiaryId);
    setCurrentStudent(student);
    navigateTo('Skiply.Store.Categories', componentId, {
      studentId: student.id,
      merchantId: student.merchantId
    });
  };

  const navigateToSchoolSearch = () => {
    navigateTo('Skiply.Discover.School.SearchSchool', componentId);
  };

  return (
    <>
      <InnerContainer
        cardBg
        {...testProperties('home-schools-edu-card-container-id')}
      >
        <Background resizeMode='cover' source={background} />
        <TopContainer>
          <SubHeader {...testProperties('home-schools-edu-card-sub-title-id')}>
            Education & Schools
          </SubHeader>
        </TopContainer>
        {savedStudents.map((student) => {
          return (
            <Button
              onPress={() => {
                if (!merchantIsLoading) {
                  selectStudent(student);
                }
              }}
              key={student.id}
              {...testProperties('home-schools-edu-card-button-id')}
            >
              <SchoolHeader
                {...testProperties('home-schools-edu-card-header-id')}
                cardBg
                isBig
                isLight
                cover={true}
                innerColor='rgb(247, 247, 247);'
                pending={pending}
                schoolName={`${student.firstName} ${student.lastName}`}
                schoolAddress={student.schoolName || 'Undefined school'}
                schoolImageUrl={student.image}
                arrowOnPress={() => {
                  if (!merchantIsLoading) {
                    selectStudent(student);
                  }
                }}
              />
            </Button>
          );
        })}
        <BottomInfo
          onPress={navigateToTakeATour}
          {...testProperties('home-schoolpayment-card-link-id')}
        >
          <BottomText
            {...testProperties('home-schoolpayment-card-subtitle-id')}
          >
            Take a tour!
          </BottomText>
        </BottomInfo>
      </InnerContainer>
      <AddStudentBtn
        onPress={navigateToSchoolSearch}
        {...testProperties('home-schools-edu-card-search-button-id')}
      />
    </>
  );
};

export default SchoolsEduCard;

const InnerContainer = styled.View`
  overflow: hidden;
  margin: 15px 20px;
  background-color: #3980f7;
  border-top-left-radius: 40px;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 40px;
  border-bottom-left-radius: 4px;
`;
const TopContainer = styled.View``;
const Margin = styled.View`
  margin-bottom: 30px;
`;

const Button = styled.TouchableOpacity`
  width: 100%;
`;

const SubHeader = styled.Text`
  color: rgb(255, 255, 255);
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 20px;
  font-weight: 900;
  padding: 25px 0 25px 25px;
`;

const Background = styled.Image`
  position: absolute;
  width: 100%;
  top: 0;
  left: 0;
  height: 75px;
  overflow: hidden;
`;

const BottomInfo = styled.TouchableOpacity`
  background-color: #1e549a;
  position: relative;
`;
const BottomText = styled.Text`
  color: rgb(255, 255, 255);
  font-size: 14px;
  font-family: 'OpenSans-SemiBold';
  font-weight: 600;
  text-align: center;
  margin-top: 16px;
  margin-bottom: 20px;
`;

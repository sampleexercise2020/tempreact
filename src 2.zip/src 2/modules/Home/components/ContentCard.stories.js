import React from 'react';
import { storiesOf } from '@storybook/react-native';
import ContentCard from './ContentCard';

// TODO: Get notes working.

storiesOf('Modules|Home/Content Cards', module).add('Content Card', () => (
  <ContentCard />
));

import React, { useState, useEffect } from 'react';
import styled from 'styled-components/native';
import { useStoreActions, useStoreState } from 'easy-peasy';
import Carousel from './components/Carousel';
import Button from 'components/common/Button/Button';
import LoginFlowFooter from 'components/common/Footers/LoginFlowFooter';
import LoaderWithOverlay from 'components/common/LoaderWithOverlay';
import selectedCopy from '../../../../i18n/copy';
import { root } from 'navigation/root';
import { Navigation } from 'react-native-navigation';
import { navigateTo } from 'navigation';
import { Alert, View } from 'react-native';
import { testProperties } from '../../../../helpers/testProperties';
import BiometricManager from '../../../../biometric/BiometricManager';
import SplashScreen from 'react-native-splash-screen';
import JailMonkey from 'jail-monkey';

const copy = selectedCopy.components.modules.LoginAndSignup.flows.Landing.index;

const Landing = ({ componentId }) => {
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const isBiometricLoading = useStoreState(
    ({ session }) => session.isBiometricLoading
  );
  const login = useStoreActions((actions) => actions.session.login);
  const fetchProfile = useStoreActions(({ profile }) => profile.fetch);
  const setAccessToken = useStoreActions((actions) => actions.session.setToken);
  const setAuthorization = useStoreActions(
    (actions) => actions.session.setAuthorization
  );
  const handleBiometricLoading = useStoreActions(
    ({ session }) => session.handleBiometricLoading
  );

  const showLoginForm = () => {
    navigateTo('Skiply.LoginForm', componentId);
  };

  const showSignupForm = () => {
    navigateTo('Skiply.SignupForm', componentId);
  };

  useEffect(() => {
    if (!JailMonkey.trustFall() || __DEV__) {
      const bm = BiometricManager.showBiometricLogin();

      bm.then(
        (params) => {
          handleBiometricLoading(true);
          // Try auto login here only once.
          // console.log("Bio Login Parameters: ", params);
          handleLogin(params.email, params.password);
        },
        (error) => {
          // alert("error: ", error);
          // Nothing to do here simply show login popup
          handleBiometricLoading(false);
        }
      );
    }
  }, []);

  const handleLogin = async (email, password) => {
    setIsLoggingIn(true);

    const response = await login({ emailAddress: email, password });
    if (response.success) {
      setAccessToken(response.data.userAccessToken);
      setAuthorization(response.data.authorization);
      fetchProfileAndMoveToHome();
    } else {
      alert(response.message);
    }

    setIsLoggingIn(false);
  };

  const fetchProfileAndMoveToHome = async () => {
    const profileResponse = await fetchProfile();
    if (profileResponse.status == 200) {
      navigateToHome();
    } else {
      alert(profileResponse.message);
    }
  };

  const navigateToHome = async () => {
    Navigation.setRoot({ root });
  };

  const JailBrokenDevice = () => {
    useEffect(() => {
      Alert.alert(
        'Rooted or Jailbroken device',
        'You cannot use a rooted or jailbroken device with this application. Please reset your device in order to continue.'
      );
    });

    return <View />;
  };

  return JailMonkey.trustFall() && !__DEV__ ? (
    <JailBrokenDevice />
  ) : (
    <Container {...testProperties('landing-carousel-container-id')}>
      <InnerContainer>
        <Carousel {...testProperties('landing-carousel-id')} />
        {isBiometricLoading && <LoaderWithOverlay />}
        <ButtonsContainer>
          <Button
            testProperties={testProperties('landing-buttonsignup-id')}
            onPress={() => showSignupForm()}
            debounce
          >
            {copy.signUp}
          </Button>
          <Button
            testProperties={testProperties('landing-buttonlogin-id')}
            transparent
            onPress={() => showLoginForm()}
            debounce
          >
            {copy.login}
          </Button>
        </ButtonsContainer>
        <QkrLoginButton
          testProperties={testProperties('landing-QkrLoginButton-id')}
          onPress={() => showLoginForm()}
        >
          <QkrButtonText>{copy.qkrLogin}</QkrButtonText>
        </QkrLoginButton>
      </InnerContainer>
      <LoginFlowFooter />
    </Container>
  );
};

class Wrapper extends React.Component {
  componentDidMount() {
    console.log('DID MOUNT');
    SplashScreen.hide();
  }

  render() {
    return <Landing componentId={this.props.componentId} />;
  }
}

export default Wrapper;

const Container = styled.View`
  flex: 1;
  background-color: #402ca8;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const ButtonsContainer = styled.View`
  height: 110px;
  justify-content: space-between;
  margin: 30px 20px 0 20px;
`;

const QkrLoginButton = styled.TouchableOpacity`
  margin-bottom: 30px;
`;

const QkrButtonText = styled.Text`
  font-family: 'TeshrinAR-Regular';
  color: #ffffff;
  font-size: 12px;
  line-height: 16px;
  font-weight: 600;
  text-align: center;
  margin-top: 15px;
`;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Onboarding from './screens/Slider';

storiesOf('Modules|LoginAndSignup/Onboarding', module).add(
  'App tutorial',
  () => <Onboarding />
);

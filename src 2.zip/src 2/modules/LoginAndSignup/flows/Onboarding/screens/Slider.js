import React, { useState } from 'react';
import { View, Dimensions, Platform } from 'react-native';
import styled from 'styled-components/native';
import SingleSlide from '../components/SingleSlide';
import CircleIndicator from 'components/common/CircleIndicator/index';
import { Navigation } from 'react-native-navigation';
import { navigateTo } from 'navigation';
import { testProperties } from '../../../../../helpers/testProperties';

const screenWidth = Dimensions.get('window').width;
const closeIcon = require('../../../../../../assets/icons/common/close.png');

const array = [
  {
    id: 1,
    backgroundColor: '#13b9ab',
    title: 'Add 1 or more children',
    subtitle:
      'Search for schools and setup student profiles. You need your school registration confirmation handy, but it only takes a minute.',
    image: require('../../../../../../assets/images/onboarding3.png')
  },
  {
    id: 2,
    backgroundColor: '#f15b60',
    title: 'Keep tabs',
    subtitle:
      'All your payments are collected in one convenient place so you will never have to get busy over what you paid.',
    image: require('../../../../../../assets/images/onboarding2.png')
  },
  {
    id: 3,
    backgroundColor: '#2c79de',
    title: 'All your profile needs, in one place',
    subtitle:
      'All your profile options and app settings in one page. Access your profile at your convenience.',
    image: require('../../../../../../assets/images/onboarding1.png')
  },
  {
    id: 4,
    backgroundColor: '#ffc157',
    title: 'Browse fees, books and more',
    subtitle:
      'Skiply let you pay much more than just school fee, check your field trips, purchase uniforms, books and much more.',
    image: require('../../../../../../assets/images/onboarding4.png')
  }
];

const Slider = ({ backgroundColor, props }) => {
  const [scrollIndex, setScrollIndex] = useState(0);

  const handleScroll = (e) => {
    const offset = e.nativeEvent.contentOffset.x;
    const index = Math.ceil(offset / screenWidth);

    setScrollIndex(index);
  };

  return (
    <Container {...testProperties('onboarding-carousel-container-id')}>
      <ScrollContainer
        horizontal
        showsHorizontalScrollIndicator={false}
        snapToInterval={screenWidth}
        snapToAlignment='center'
        decelerationRate='fast'
        onMomentumScrollEnd={handleScroll}
      >
        {array.map((item) => (
          <SingleSlide
            key={item.id}
            backgroundColor={item.backgroundColor}
            title={item.title}
            subtitle={item.subtitle}
            image={item.image}
          />
        ))}
      </ScrollContainer>
      <Footer backgroundColor={backgroundColor}>
        <CircleContainer>
          {array.map((item, i) => (
            <CircleIndicator key={item.id} active={i === scrollIndex} />
          ))}
        </CircleContainer>
      </Footer>
    </Container>
  );
};

export default Slider;

const Container = styled.View`
  flex: 1;
  background-color: #402ca8;
  position: relative;
  align-items: center;
`;

const ScrollContainer = styled.ScrollView`
  flex: 1;
`;

const Footer = styled.View`
  background-color: #0000004c;
  height: 64px;
  border-top-right-radius: 40px;
  width: 100%;
  align-items: center;
  justify-content: center;
  position: absolute;
  bottom: 0;
`;

const CircleContainer = styled.View`
  flex-direction: row;
  position: absolute;
  z-index: 5;
`;

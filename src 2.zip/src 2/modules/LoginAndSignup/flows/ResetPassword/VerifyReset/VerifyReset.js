import React, { useState, useEffect } from 'react';
import { Alert } from 'react-native';
import { useStoreActions, useStoreState } from 'easy-peasy';
import { navigateTo } from 'navigation';
import styled from 'styled-components/native';
import Button from 'components/common/Button/Button';
import CheckListItem from '../../../../../components/common/ListItem/CheckListItem';
import { testProperties } from '../../../../../helpers/testProperties';

const VerifyReset = ({ title, componentId, email }) => {
  const [selected, setSelected] = useState(null);
  const isLoading = useStoreState((state) => state.session.isLoading);
  const errorMessage = useStoreState((state) => state.session.errorMessage);
  const fetchedDetails = useStoreState(
    (state) => state.session.resetPasswordFetchDetails
  );
  const forgotPasswordCustom = useStoreActions(
    (actions) => actions.session.forgotPasswordCustom
  );

  const forgotPassword = useStoreActions(
    (actions) => actions.session.forgotPassword
  );

  const [array, setArray] = useState(() => {
    if (!fetchedDetails.existingQkrUser) {
      return [
        { phoneNumber: fetchedDetails.phoneNumber },
        { emailAddress: fetchedDetails.userEmailAddress }
      ];
    } else {
      return [{ emailAddress: fetchedDetails.userEmailAddress }];
    }
  });

  useEffect(() => {
    setSelected(array[0]);
  }, []);

  const handleTypeSubmit = async () => {
    if (!fetchedDetails.existingQkrUser) {
      let phoneEmail = null;
      let payload = null;
      if (selected.phoneNumber !== undefined) {
        phoneEmail = { phoneEmail: 'P' };
      } else {
        phoneEmail = { phoneEmail: 'E' };
      }
      payload = { ...phoneEmail, emailAddress: email };
      //console.log('Selected Itemmmmmm: ', payload);

      const response = await forgotPasswordCustom(payload);
      if (response == 200) {
        navigateTo('Skiply.VerificationCode', componentId, {
          email: email,
          existingQkrUser: fetchedDetails.existingQkrUser,
          phoneEmail: phoneEmail
        });
      } else {
        Alert.alert('Error', 'Something went wrong. Please try again.', [
          { text: 'OK', onPress: () => console.log('Ok pressed') }
        ]);
      }
    } else {
      const response = await forgotPassword(selected);
      if (response == 200) {
        navigateTo('Skiply.VerificationCode', componentId);
      } else {
        Alert.alert('Error', 'Something went wrong. Please try again.', [
          { text: 'OK', onPress: () => console.log('Ok pressed') }
        ]);
      }
    }
  };

  const checkSelected = (item) => {
    return item === selected ? true : false;
  };

  return (
    <Container {...testProperties('verifyreset-verifyresetlist-container-id')}>
      <InnerContainer>
        <Title {...testProperties('verifyreset-title-id')}>
          How do you want to verify and reset your password?
        </Title>
        <ListContainer
          data={array}
          renderItem={({ item }) => {
            return (
              <CheckListItem
                {...testProperties('verifyreset-listitem-id')}
                onPress={() => setSelected(item)}
                selected={checkSelected(item)}
                itemName={
                  item[Object.keys(item)[0]] === item.phoneNumber
                    ? `+${item[Object.keys(item)[0]]}`
                    : item[Object.keys(item)[0]]
                }
              />
            );
          }}
        />
      </InnerContainer>
      <Button
        testProperties={testProperties('verifyreset-nextstep-button-id')}
        primary
        onPress={handleTypeSubmit}
        disabled={isLoading ? true : false}
      >
        Next
      </Button>
    </Container>
  );
};

export default VerifyReset;

const Container = styled.View`
  flex: 1;
  margin: 0 20px 20px 20px;
`;

const InnerContainer = styled.View`
  flex: 1;
`;
const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  line-height: 22px;
  padding: 40px;
  text-align: center;
  color: #0d1943;
`;

const ListContainer = styled.FlatList``;

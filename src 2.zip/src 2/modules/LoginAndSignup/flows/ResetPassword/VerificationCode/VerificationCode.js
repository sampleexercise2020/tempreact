import React, { useState, useEffect, useRef } from 'react';
import { Alert, Platform } from 'react-native';
import styled from 'styled-components';
import { useStoreActions, useStoreState } from 'easy-peasy';
import { Navigation } from 'react-native-navigation';
import { navigateTo } from 'navigation';
import VerificationDots from 'components/common/VerificationDots/VerificationDots';
import Button from 'components/common/Button/Button';
import CodeVerifier from 'components/common/CodeVerifier/CodeVerifier';
import { testProperties } from '../../../../../helpers/testProperties';

const VerificationCode = ({
  componentId,
  email,
  existingQkrUser,
  phoneEmail
}) => {
  const [code, setCode] = useState('');
  const otpToken = useStoreState((state) => state.session.otpToken);
  const verifyOtpCustom = useStoreActions(
    (actions) => actions.session.verifyOtpCustom
  );
  const resendOtp = useStoreActions((actions) => actions.session.resendOtp);

  async function handleResendOtpPress() {
    const response = await resendOtp(phoneEmail);

    if (response == 'Y') {
      Alert.alert('Code sent', `A new OTP has been sent to you.`);
      console.log('Success when sending resending OTP!');
    } else {
      Alert.alert('Error.', response);
    }
  }

  const handleSubmit = async () => {
    const response = await verifyOtpCustom({
      otp: code,
      otpToken: otpToken
    });
    if (response == true) {
      navigateTo(
        'Skiply.Account.Profile.MyProfile.ChangePassword',
        componentId,
        {
          oldPasswordRequired: false,
          email: email,
          existingQkrUser: existingQkrUser
        }
      );
    } else {
      Alert.alert(
        'Incorrect verification code',
        'The verification code you have entered is incorrect.',
        [{ text: 'OK', onPress: () => {} }]
      );
    }
  };

  return (
    <>
      <CodeVerifier
        {...testProperties('resetpassword-verificationcode-input-id')}
        length={6}
        onPress={handleSubmit}
        passDataToParent={setCode}
        buttonText='Next'
        resend={true}
        resendOnPress={handleResendOtpPress}
      >
        <Title {...testProperties('resetpassword-verificationcode-title-id')}>
          Enter verification code
        </Title>
      </CodeVerifier>
    </>
  );
};

export default VerificationCode;

const Container = styled.View`
  position: relative;
  padding-bottom: 20px;
  flex: 1;
  align-items: center;
  justify-content: center;
`;

const Title = styled.Text`
  width: 200px;
  color: rgb(13, 25, 67);
  font-size: 20px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  text-align: center;
  letter-spacing: 0px;
  line-height: 28px;
`;

const PayNowContainer = styled.View`
  padding: 20px;
`;

const VerificationContainer = styled.View`
  padding-top: 50px;
`;
const HiddenInputField = styled.TextInput`
  position: absolute;
  top: -1000px;
`;

const InputFieldActivator = styled.TouchableOpacity`
  position: absolute;
  height: 100%;
  width: 100%;
  opacity: 0;
`;

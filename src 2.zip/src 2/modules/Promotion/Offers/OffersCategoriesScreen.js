import React, { useState, useEffect } from 'react';
import { Alert } from 'react-native';
import { useStoreActions } from 'easy-peasy';
import styled from 'styled-components/native';
import { navigateTo, options } from 'navigation';
import LoaderContainer from 'components/common/LoaderContainer';
import OffersCategoryCard from './components/OffersCategoryCard';

const OffersCategoriesScreen = (props) => {
  const getOffersCategoriesAction = useStoreActions(
    ({ promotion }) => promotion.getOffersCategories
  );

  const [offersCategories, setOffersCategories] = useState([]);
  const [isFetching, setIsFetching] = useState([]);

  useEffect(function componentDidMount() {
    getOffersCategories();
  }, []);

  async function getOffersCategories() {
    setIsFetching(true);

    const response = await getOffersCategoriesAction();

    if (response.status == 200) {
      setOffersCategories(response.data.contentListMap.OFFERS.Categories);
    } else {
      Alert.alert(response.message);
    }

    setIsFetching(false);
  }

  function navigateToOffersCategory(category) {
    navigateTo(
      'Skiply.Promotion.Offers.OffersScreen',
      props.componentId,
      {
        category
      },
      {
        topBar: options.topBarWithTitle(category.title)
      }
    );
  }

  return (
    <Container showsVerticalScrollIndicator={false}>
      <LoaderContainer isLoading={isFetching}>
        <Categories>
          {offersCategories.map(({ Category, Title, onThumbNail }) => (
            <OffersCategoryCard
              key={Category}
              title={Title}
              id={Category}
              categoryImage={onThumbNail}
              onPress={navigateToOffersCategory}
            />
          ))}
        </Categories>
      </LoaderContainer>
    </Container>
  );
};

export default OffersCategoriesScreen;

const Container = styled.View`
  padding-bottom: 20px;
  flex: 1;
`;

const Categories = styled.ScrollView`
  padding: 20px 20px 0;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR-Bold';
  font-size: 32px;
  font-weight: 900;
  line-height: 40;
  margin: 30px 20px 25px 0px;
  color: #0d1943;
`;

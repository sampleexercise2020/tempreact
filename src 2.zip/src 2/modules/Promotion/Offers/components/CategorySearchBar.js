import React from 'react';
import styled from 'styled-components/native';
import CategoryInputField from './CategoryInputField';

const CategorySearchBar = ({ onPress }) => {
  return (
    <Container>
      <CategoryInputField onPress={onPress} />
    </Container>
  );
};

export default CategorySearchBar;

const Container = styled.View`
  background-color: #f5f5f7;
  border-radius: 4px;
  margin: 0 20px;
  height: 81px;
  justify-content: center;
`;

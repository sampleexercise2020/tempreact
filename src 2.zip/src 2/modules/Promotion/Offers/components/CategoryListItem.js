import React from 'react';
import styled from 'styled-components/native';

const CategoryListItem = ({
  companyName,
  offer,
  location,
  image,
  onPress,
  thumbnail
}) => {
  return (
    <Container onPress={onPress}>
      <ThumbNailContainer>
        <ThumbNail source={{ uri: thumbnail }} resizeMode='cover' />
      </ThumbNailContainer>
      <TextContent>
        <CompanyName numberOfLines={1}>{companyName}</CompanyName>
        <Offer numberOfLines={1}>{offer}</Offer>
        <Location numberOfLines={1}>{location}</Location>
      </TextContent>
      {image ? (
        <ImageContainer>
          <Border>
            <Img source={{ uri: image }} />
          </Border>
        </ImageContainer>
      ) : null}
    </Container>
  );
};

export default CategoryListItem;

const Container = styled.TouchableOpacity`
  margin: 0 20px;
  padding: 20px 0;
  position: relative;
  flex-direction: row;
  align-items: center;
`;

const TextContent = styled.View`
  flex: 1;
  height: 80px;
`;

const CompanyName = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 18px;
  line-height: 26px;
  font-weight: 900;
  color: #0d1943;
`;

const ThumbNail = styled.Image`
  height: 80px;
  width: 80px;
`;

const ThumbNailContainer = styled.View`
  border-bottom-left-radius: 2px;
  border-bottom-right-radius: 20px;
  border-top-left-radius: 20px;
  border-top-right-radius: 2px;
  margin-right: 15px;
  overflow: hidden;
`;

const Offer = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  line-height: 20px;
  color: #6d758e;
`;

const Location = styled.Text`
  margin-top: 14px;
  font-family: 'OpenSans-SemiBold';
  font-size: 12px;
  font-weight: 600;
  line-height: 16px;
  color: #0d8177;
`;

const Border = styled.View`
  border-top-left-radius: 11px;
  border-bottom-right-radius: 11px;
  overflow: hidden;
`;

const ImageContainer = styled.View`
  margin-left: 10px;
`;

const Img = styled.Image`
  width: 80px;
  height: 80px;
  background: rebeccapurple;
  border-top-left-radius: 11px;
  border-bottom-right-radius: 11px;
  overflow: hidden;
`;

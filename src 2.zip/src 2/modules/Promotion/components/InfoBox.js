import React from 'react';
import styled from 'styled-components/native';

const InfoBox = ({ boxText }) => {
  return (
    <Container>
      <BoxText>{boxText}</BoxText>
    </Container>
  );
};

export default InfoBox;

const Container = styled.View`
  background-color: #eaf1fb;
  margin: 30px 0;
  padding: 15px;
  border-radius: 4px;
`;

const BoxText = styled.Text`
  font-family: 'OpenSans-Regular';
  text-align: center;
  font-size: 12px;
  line-height: 16px;
  color: #2c79de;
`;

import React from 'react';
import styled from 'styled-components/native';

const AboutSP = (props) => {
  return (
    <Container>
      <Title>About Skiply Points</Title>
      <Description>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur sed
        laoreet felis, id vulputate odio. Vestibulum imperdiet odio malesuada
        dui dapibus venenatis. In lobortis sit amet nulla id interdum.
      </Description>
    </Container>
  );
};

export default AboutSP;

const Container = styled.View`
  padding: 30px 20px;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  line-height: 22px;
  font-weight: bold;
  color: #0d1943;
  margin-bottom: 8px;
`;

const Description = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
`;

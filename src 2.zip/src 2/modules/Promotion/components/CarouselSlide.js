import React from 'react';
import { Dimensions } from 'react-native';
import styled from 'styled-components/native';
import { testProperties } from '../../../helpers/testProperties';

const screenWidth = Dimensions.get('window').width;

const RakBankCardCarousel = ({
  screenWidth,
  cardImg,
  cardType,
  cardDesc,
  key
}) => {
  return (
    <CardContainer
      key={key}
      screenWidth={screenWidth}
      {...testProperties('rakbank-carousel-slide-container-id')}
    >
      <CardImg source={cardImg} resizeMode='contain' />
      <CardType {...testProperties('rakbank-carousel-slide-card-type-id')}>
        {cardType}
      </CardType>
      <CardDesc {...testProperties('rakbank-carousel-slide-card-desc-id')}>
        {cardDesc.map((item) => {
          return (
            <BPWrapper key={item.id}>
              <Cirle />
              <BulletPoint>{item.text}</BulletPoint>
            </BPWrapper>
          );
        })}
      </CardDesc>
    </CardContainer>
  );
};

export default RakBankCardCarousel;

const CardContainer = styled.View`
  width: ${() => screenWidth};
`;

const CardType = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 14px;
  text-align: center;
  line-height: 18px;
  font-weight: bold;
  margin: 30px 40px 10px 40px;
  text-align: center;
  border-radius: 10px;
`;

const CardImg = styled.Image`
  height: 180px;
  width: 100%;
`;

const CardDesc = styled.View`
  margin: 0 40px;
  justify-content: center;
  align-items: center;
`;

const BulletPoint = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  line-height: 18px;
  text-align: center;
  color: #0d1943;
`;

const Cirle = styled.View`
  height: 4px;
  width: 4px;
  border-radius: 2px;
  background-color: #0d1943;
  margin-top: 7px;
  margin-right: 7px;
`;

const BPWrapper = styled.View`
  flex-direction: row;
  margin-bottom: 3px;
`;

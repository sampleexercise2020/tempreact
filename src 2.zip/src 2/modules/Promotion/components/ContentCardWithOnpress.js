import React from 'react';
import styled, { css } from 'styled-components/native';
import TextLink from '../../../components/common/Link/TextLink';
import { testProperties } from '../../../helpers/testProperties';
import { Dimensions } from 'react-native';

const screenWidth = Dimensions.get('window').width;

const ContentCardWithOnpress = ({
  backgroundLinkColor,
  linktext,
  imageBackgroundImg,
  screenWidth,
  title,
  categoryTitle,
  footerLinkVisible,
  cardBackgroundColor,
  secondSubtitle,
  contentCardIcon,
  onPressActivated,
  containerHeight,
  onPress,
  linkOnPress,
  componentId,
  smallIcon
}) => {
  renderContent = () => {
    return (
      <>
        {imageBackgroundImg && (
          <ImageContainer
            footerLinkVisible={footerLinkVisible}
            source={imageBackgroundImg}
            {...testProperties(
              'promo-content-card-imagebackground-container-id'
            )}
          >
            <CategoryTitle
              {...testProperties('promo-content-card-category-id')}
            >
              {categoryTitle}
            </CategoryTitle>
            <Title {...testProperties('promo-content-card-title-id')}>
              {title}
            </Title>
            <SecondSubtitle
              {...testProperties('promo-content-card-second-subtitle-id')}
            >
              {secondSubtitle}
            </SecondSubtitle>
          </ImageContainer>
        )}
        {cardBackgroundColor && (
          <CardBackgroundColor
            cardBackgroundColor={cardBackgroundColor}
            containerHeight={containerHeight}
            footerLinkVisible={footerLinkVisible}
            {...testProperties(
              'promo-content-card-colorbackground-container-id'
            )}
          >
            <InnerWrapper>
              <CategoryTitle
                {...testProperties('promo-content-card-category-id')}
              >
                {categoryTitle}
              </CategoryTitle>
              <SmallerTitle
                {...testProperties('promo-content-card-small-title-id')}
              >
                {title}
              </SmallerTitle>
              <SecondSubtitle
                {...testProperties('promo-content-card-second-subtitle-id')}
              >
                {secondSubtitle}
              </SecondSubtitle>
            </InnerWrapper>
            <ContentCardIconWrapper
              {...testProperties('promo-content-card-icon-wrapper-id')}
            >
              <ContentCardIcon
                smallIcon={smallIcon}
                source={contentCardIcon}
                resizeMode='contain'
                {...testProperties('promo-content-card-icon-id')}
              />
            </ContentCardIconWrapper>
          </CardBackgroundColor>
        )}
        {footerLinkVisible && (
          <OnPressContainer
            backgroundLinkColor={backgroundLinkColor}
            onPress={() => linkOnPress(componentId)}
            {...testProperties('promo-content-card-link-container-id')}
          >
            <TextLink
              marginLeft={20}
              linktext={linktext}
              onPress={() => linkOnPress(componentId)}
              white
              {...testProperties('promo-content-card-link-id')}
            />
          </OnPressContainer>
        )}
      </>
    );
  };

  return (
    <>
      {onPressActivated ? (
        <ContainerOnPress
          {...testProperties('promo-content-card-container-id')}
          screenWidth={screenWidth}
          onPress={onPress}
        >
          {renderContent()}
        </ContainerOnPress>
      ) : (
        <Container containerHeight={containerHeight}>
          {renderContent()}
        </Container>
      )}
    </>
  );
};

export default ContentCardWithOnpress;

const ContainerOnPress = styled.TouchableOpacity`
  height: 260px;
  overflow: hidden;
  width: ${() => screenWidth};
  position: relative;
  padding: 0 20px;
  border: 1px solid yellow;
`;

const Container = styled.View`
  height: ${(props) =>
    props.containerHeight ? props.containerHeight : '260px'};
  overflow: hidden;
  width: ${() => screenWidth};
  position: relative;
  padding: 0 20px;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 32px;
  font-weight: 900;
  line-height: 40px;
  max-height: 80px;
  color: #ffffff;
  margin: 2px 20px 5px 20px;
  text-shadow: 1px 1px 6px #000;
`;

const CategoryTitle = styled.Text`
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  color: #ffffff;
  font-size: 12px;
  line-height: 16px;
  margin: 0 20px;
  text-shadow: 1px 1px 6px #000;
`;

const ImageContainer = styled.ImageBackground`
  height: 260px;
  justify-content: center;
  ${(props) =>
    props.footerLinkVisible &&
    css`
      padding-bottom: 20px;
    `}
  border-top-left-radius: 40px;
  border-bottom-right-radius: 40px;
  border-top-right-radius: 4px;
  border-bottom-left-radius: 4px;
  overflow: hidden;
`;

const OnPressContainer = styled.TouchableOpacity`
  height: 50px;
  background-color: ${(props) => props.backgroundLinkColor};
  flex-direction: row;
  align-items: center;
  position: absolute;
  bottom: 0;
  width: 100%;
  margin-left: 20px;
  border-bottom-right-radius: 40px;
  border-bottom-left-radius: 4px;
  overflow: hidden;
`;

const CardBackgroundColor = styled.View`
  background-color: ${(props) => props.cardBackgroundColor};
  height: ${(props) =>
    props.containerHeight ? props.containerHeight : '260px'};
  flex-direction: row;
  border-top-left-radius: 40px;
  border-bottom-right-radius: 40px;
  border-top-right-radius: 4px;
  border-bottom-left-radius: 4px;
  overflow: hidden;
  ${(props) =>
    props.footerLinkVisible &&
    css`
      padding-bottom: 40px;
    `}
`;

const SecondSubtitle = styled.Text`
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  text-shadow: 1px 1px 6px #000;
  font-size: 14px;
  line-height: 18px;
  color: #ffffff;
  margin: 0 20px;
`;

const InnerWrapper = styled.View`
  flex: 2;
  justify-content: center;
  margin-right: 15px;
`;

const ContentCardIcon = styled.Image`
  height: 152px;
  width: 118px;
  ${(props) =>
    props.smallIcon &&
    css`
      height: 132px;
      width: 98px;
      margin-right: 20px;
    `}
`;

const ContentCardIconWrapper = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
  margin-left: 10px;
`;

const SmallerTitle = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  text-shadow: 1px 1px 6px #000;
  font-size: 20px;
  font-weight: 900;
  line-height: 28px;
  color: #ffffff;
  margin-left: 20px;
  margin-top: 5px;
  margin: 5px 0 20px 20px;
`;

import React from 'react';
import { Animated } from 'react-native';
import styled from 'styled-components/native';
import SchoolsEduCard from '../Home/components/SchoolsEduCard';
import { useStore } from 'easy-peasy';
import TabHeader from 'components/common/Header/TabHeader';
import EmptyDiscover from './EmptyDiscover';
import CollapsibleHeader from 'components/common/Header/CollapsibleHeader';
import selectedCopy from 'src/../i18n/copy';
import { testProperties } from '../../helpers/testProperties';
import ContentCardWithOnpress from '../Promotion/components/ContentCardWithOnpress';

const copy = selectedCopy.components.modules.Discover.Index;

const titleIcon = require('../../../assets/images/discover_rocket.png');

const comingSoonCard = {
  imageBackgroundImg: require('../../../assets/images/coming_soon_bg.png'),
  title: 'The Coca Cola Arena',
  categoryTitle: 'Coming Soon',
  onPressActivated: false,
  secondSubtitle: 'Watch this space for more updates...'
};

const Discover = ({ componentId }) => {
  const savedStudents = useStore((state) => state.student.lists.saved);

  return (
    <CollapsibleHeader
      extendedHeight={134}
      collapsedHeight={0}
      isCurved={true}
      bigContent={
        <TabHeader
          text={copy.title}
          testId={'discover-store-start'}
          icon={titleIcon}
        />
      }
      positionFromLeft={20}
      positionFromBottom={44}
      alignBigContentLeft
    >
      <Container as={Animated.ScrollView}>
        <ContentCardWithOnpress
          key={comingSoonCard.id}
          backgroundLinkColor={comingSoonCard.backgroundLinkColor}
          linktext={comingSoonCard.linktext}
          imageBackgroundImg={comingSoonCard.imageBackgroundImg}
          title={comingSoonCard.title}
          categoryTitle={comingSoonCard.categoryTitle}
          footerLinkVisible={comingSoonCard.footerLinkVisible}
          cardBackgroundColor={comingSoonCard.cardBackgroundColor}
          secondSubtitle={comingSoonCard.secondSubtitle}
          contentCardIcon={comingSoonCard.contentCardIcon}
          componentId={componentId}
        />
      </Container>
      {/* Maybe used in the future? Not sure 
      {savedStudents && savedStudents.length > 0 ? (
        <Container {...testProperties('discover-store-start-container-id')}>
          <SchoolsEduCard
            {...testProperties('discover-store-start-schoolseducard-id')}
            componentId={componentId}
          />
        </Container>
      ) : (
        <EmptyScreenContainer>
          <EmptyDiscover />
        </EmptyScreenContainer>
      )} */}
    </CollapsibleHeader>
  );
};

const Container = styled.ScrollView`
  height: 100%;
`;

export default Discover;

import React from 'react';
import styled from 'styled-components/native';
import { addCommaSeparator } from 'helpers/addCommaSeparator';
import { useStoreState } from 'easy-peasy';

const SignProductView = ({ productName, shortDesc, price, productImg }) => {
  const currency = useStoreState((state) => state.merchant.currency);

  return (
    <ProductInfoContainer>
      <TextContainer>
        <Name numberOfLines={1}>{productName}</Name>
        <ShortDesc numberOfLines={1}>{shortDesc}</ShortDesc>
        <Price>
          {currency} {addCommaSeparator(price)}
        </Price>
      </TextContainer>
      <CurvedEdges>
        <ProductImg source={{ uri: productImg }} />
      </CurvedEdges>
    </ProductInfoContainer>
  );
};

export default SignProductView;

const ProductInfoContainer = styled.View`
  height: 150px;
  justify-content: center;
  align-items: center;
  flex-direction: row;
`;

const TextContainer = styled.View`
  flex-direction: column;
`;

const Name = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 20px;
  font-weight: 900;
  line-height: 28px;
  color: #0d1943;
  width: 230px;
`;

const ShortDesc = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #6d758e;
  width: 230px;
`;

const Price = styled.Text`
  font-family: 'OpenSans-Semibold';
  color: #0d8177;
  font-size: 12px;
  font-weight: 600;
  line-height: 16px;
  margin-top: 14px;
`;

const CurvedEdges = styled.View`
  border-top-left-radius: 11px;
  border-bottom-right-radius: 11px;
  overflow: hidden;
  height: 80px;
  width: 80px;
  margin-left: 20px;
`;

const ProductImg = styled.Image`
  height: 80px;
  width: 80px;
`;

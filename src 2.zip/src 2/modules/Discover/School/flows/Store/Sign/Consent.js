import React, { useState, useEffect } from 'react';
import { Formik } from 'formik';
import styled from 'styled-components/native';
import TopIndicationBar from './components/TopIndicationBar';
import SignProductView from './components/SignProductView';
import FormInput from 'components/common/Input/FormInput';
import { navigateTo, popTo } from 'navigation';
import { useStoreState, useStoreActions, useActions } from 'easy-peasy';
import { testProperties } from 'helpers/testProperties';
import LoaderContainer from 'components/common/LoaderContainer';
import Button from 'components/common/Button/Button';

const store = {
  currentProduct: ({ currentProduct }) => currentProduct.data,
  fetchFields: ({ currentProduct }) => currentProduct.fetchFields,
  totalPrice: ({ currentProduct }) => currentProduct.totalPrice,
  saveConsentForm: ({ currentProduct }) => currentProduct.saveConsentForm,
  addToCart: ({ currentProduct }) => currentProduct.addToCart,
  productListComponentId: ({ currentProduct }) =>
    currentProduct.productListComponentId
};

const Consent = ({ componentId, student, isPayNow }) => {
  const [errorMessage, setErrorMessage] = useState('');
  const [isSavingConsentForm, setIsSavingConsentForm] = useState(false);
  const [isFetchingFormFields, setIsFetchingFormFields] = useState(false);
  const [formFields, setFormFields] = useState([]);

  const currentProduct = useStoreState(store.currentProduct);
  const totalPrice = useStoreState(store.totalPrice);
  const fetchFields = useStoreActions(store.fetchFields);
  const saveConsentFormAction = useStoreActions(store.saveConsentForm);
  const productListComponentId = useStoreState(store.productListComponentId);
  const addToCartAction = useStoreActions(store.addToCart);

  const sessionExpire = useActions((actions) => actions.session.expire);

  /**
   * Fetch all form fields on mount
   */
  useEffect(function componentDidMount() {
    fetchFormFields();
  }, []);

  /**
   * Initializer, fetches all form fields for the provided form id
   */
  async function fetchFormFields() {
    setErrorMessage('');
    setIsFetchingFormFields(true);

    const response = await fetchFields({
      formId: currentProduct.form.id,
      beneficiaryId: student.mcBeneficiaryId
    });

    if (response.status == 200) {
      setFormFields(response.data.formElements);
    } else if (response.status === 401 || response.status === 403) {
      sessionExpire();
    } else {
      setErrorMessage(`Server error: ${response.message}`);
    }

    setIsFetchingFormFields(false);
  }

  /**
   * Takes an object with form data and returns a list of form elements
   *
   * @param {Object} formData { id: value }
   * @return {[{id: value}]}
   */
  function convertToFormElements(formData) {
    const valueArray = Object.values(formData);
    const idArray = Object.keys(formData);

    const formElements = idArray.map((id, i) => ({
      id: id,
      value: valueArray[i]
    }));

    return formElements;
  }

  async function addToCart() {
    const response = await addToCartAction();

    if (response.status === 200 && isPayNow) {
      navigateToCheckout();
    } else if (response.status == 200) {
      popToList();
    } else if (response.status === 401 || response.status == 403) {
      sessionExpire();
    } else {
      setErrorMessage(response.message);
    }
  }

  const navigateToCheckout = () => {
    return navigateTo('Skiply.Store.Checkout', componentId, { student });
  };

  function popToList() {
    popTo(productListComponentId);
  }

  /**
   * Set loading flag state and save consent form
   * Called when: consent form doesn't require a signature
   *
   * @param {Object} formData {id: value}
   */
  async function saveConsentForm(formData, isPayNow) {
    setErrorMessage('');
    setIsSavingConsentForm(true);

    const formElements = convertToFormElements(formData);

    const payload = {
      beneficiaryId: student.mcBeneficiaryId,
      formId: currentProduct.form.id,
      formElements
    };

    const response = await saveConsentFormAction(payload);

    if (response.status == 200) {
      await addToCart(isPayNow);
    } else if (response.status === 401 || response.status === 403) {
      sessionExpire();
    } else {
      setErrorMessage(response.message);
    }

    setIsSavingConsentForm(false);
  }

  /**
   * Navigates to the signing screen with the passed form data
   *
   * @param {Object} formData {id: value}
   */
  async function navigateToSign(formData, isPayNow) {
    const formElements = convertToFormElements(formData);
    const signatureField = formFields.find(({ type }) => type == 'Signature');

    navigateTo('Skiply.Store.Consent.Sign', componentId, {
      formElements: signatureField
        ? [...formElements, signatureField]
        : formElements,
      beneficiaryId: student.mcBeneficiaryId,
      formId: currentProduct.form.id,
      product: currentProduct,
      ...isPayNow,
      student,
      componentId
    });
  }

  function handleSubmit(formData) {
    if (currentProduct.form.formRequiresSignature) {
      navigateToSign(formData, isPayNow);
    } else {
      saveConsentForm(formData, isPayNow);
    }
  }

  function invalidateMaxLengthExceeded(value, label, maxLength) {
    const isMaxLengthExceeded = value.length > maxLength;

    return {
      isValid: !isMaxLengthExceeded,
      errorMessage: `${label} max length is ${maxLength}`
    };
  }

  function invalidateEmpty(value, label) {
    const isEmpty = !value;

    return {
      isValid: !isEmpty,
      errorMessage: `${label} is required`
    };
  }

  function validateField(key, value, errors) {
    const formField = formFields.find(({ id }) => id == key);
    const label = formField.label;
    const validators = [];

    validators.push(invalidateMaxLengthExceeded(value, label, 40));

    if (formField.required) {
      validators.push(invalidateEmpty(value, label));
    }

    delete errors[key];

    validators
      .filter(({ isValid }) => !isValid)
      .forEach(({ errorMessage }) => {
        errors[key] = errorMessage;
      });
  }

  function validateForm(values) {
    let errors = {};

    for (let key in values) {
      validateField(key, values[key], errors);
    }

    const fieldKeys = Object.keys(values);
    const areAllRequiredFieldsFilled = formFields
      .filter(({ required }) => required)
      .filter(({ type }) => type !== 'Signature')
      .every(({ id }) => fieldKeys.includes(id));

    if (!areAllRequiredFieldsFilled) {
      errors.areAllRequiredFieldsFilled = 'All fields are required';
    }

    return errors;
  }

  function renderErrors(errors, touched) {
    delete errors.areAllRequiredFieldsFilled;

    const touchedFields = Object.keys(touched);
    const errorFields = Object.keys(errors);

    return errorFields
      .filter((error) => !touchedFields.includes(error))
      .map((key) => <ErrorContainer>{errors[key]}</ErrorContainer>);
  }

  return (
    <Formik
      onSubmit={handleSubmit}
      enableReinitialize={true}
      validateOnBlur
      validate={validateForm}
      initialValues={{}}
    >
      {(props) => {
        // console.log('FORM FIELDS', formFields);
        return (
          <>
            {currentProduct.form.formRequiresSignature && (
              <TopIndicationBar steps={2} activeStep={1} />
            )}
            <Container
              {...testProperties('discover-store-sign-consent-container-id')}
            >
              <Content>
                <TextContainer>
                  <SignProductView
                    productName={currentProduct.name}
                    shortDesc={currentProduct.smallDescription}
                    price={totalPrice}
                    productImg={currentProduct.mediumImageUrl}
                    {...testProperties(
                      'discover-store-sign-consent-signproductview-id'
                    )}
                  />
                </TextContainer>
                <Border />
                <LoaderContainer
                  isLoading={isFetchingFormFields}
                  errorMessage={errorMessage}
                >
                  <InputContainer>
                    <FormList
                      data={formFields}
                      keyExtractor={(item) => item.id}
                      renderItem={({ item }) => {
                        return item.type != 'Signature' ? (
                          <FormInput
                            numberOfLines={1}
                            label={`${item.label}${item.required ? '*' : ''}`}
                            keyboardType='default'
                            returnKeyType='go'
                            type={item.type}
                            onChangeText={props.handleChange(item.id)}
                            onBlur={props.handleBlur(item.id)}
                            {...testProperties(
                              `discover-store-sign-consent-form-field-${
                                item.id
                              }`
                            )}
                            value={props.values[item.id]}
                          />
                        ) : null;
                      }}
                    />
                  </InputContainer>
                </LoaderContainer>
              </Content>
              <BtnWrapper
                elevation={5}
                style={{
                  shadowColor: '#000',
                  shadowOffset: {
                    width: 0,
                    height: 7
                  },
                  shadowOpacity: 0.43,
                  shadowRadius: 9.51,

                  elevation: 15
                }}
              >
                {renderErrors(props.errors, props.touched)}
                {errorMessage ? (
                  <ErrorContainer>{errorMessage}</ErrorContainer>
                ) : null}
                <Button
                  {...testProperties(
                    'discover-store-sign-consent-next-button-id'
                  )}
                  primary={!isSavingConsentForm}
                  disabled={!props.isValid || isSavingConsentForm}
                  isLoading={isSavingConsentForm}
                  onPress={props.handleSubmit}
                >
                  {currentProduct.form.formRequiresSignature ? 'Next' : 'Save'}
                </Button>
              </BtnWrapper>
            </Container>
          </>
        );
      }}
    </Formik>
  );
};

export default Consent;

const Container = styled.View`
  flex: 1;
`;

const Content = styled.ScrollView`
  flex-grow: 1;
`;

const TextContainer = styled.View`
  margin: 0 20px 20px 20px;
`;

const Border = styled.View`
  border-bottom-width: 1px;
  border-bottom-color: #edeef1;
`;

const BtnWrapper = styled.View`
  padding: 10px 20px 20px 20px;
  background-color: white;
`;

const InputContainer = styled.View`
  background-color: #f5f5f7;
  border-radius: 4px;
  padding: 15px 15px 5px 15px;
  margin: 20px;
`;

const ErrorContainer = styled.Text`
  color: red;
  text-align: center;
  margin-bottom: 10px;
`;

const FormList = styled.FlatList``;

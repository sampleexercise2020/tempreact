import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

import Button from 'components/common/Button/Button';
import { addCommaSeparator } from 'helpers/addCommaSeparator';
import selectedCopy from '../../../../../../i18n/copy';

const copy =
  selectedCopy.components.modules.Discover.School.flows.Store.components
    .CartControls;

// TODO: Add icons.

const CartControls = ({
  price,
  currency,
  vat,
  addToCartAction,
  payNowAction,
  buttonTitle,
  disabled
}) => {
  return (
    <Container>
      <TextContainer>
        <Total>{copy.total}: </Total>
        <Price>
          {currency} {addCommaSeparator(price)}
        </Price>
      </TextContainer>
      {vat === !0 ? (
        <TextContainer>
          <VatTotal>{copy.vat}: </VatTotal>
          <Vat>
            {currency} {vat}
          </Vat>
        </TextContainer>
      ) : null}
      <Actions>
        <Pay>
          <Button primary bold onPress={payNowAction} disabled={disabled}>
            {buttonTitle || copy.goToPayment}
          </Button>
        </Pay>
      </Actions>
    </Container>
  );
};

CartControls.propTypes = {};

const Container = styled.View`
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding: 0px 3px;
`;
const TextContainer = styled.View`
  flex-direction: row;
  margin-bottom: 12px;
`;

const Total = styled.Text`
  color: rgb(13, 133, 123);
  font-size: 16px;
  font-family: 'TeshrinAR+LT-Regular';
  font-weight: normal;
  text-align: center;
  letter-spacing: 0px;
`;
const VatTotal = styled.Text`
  color: rgb(109, 117, 142);
  font-size: 12px;
  font-family: 'TeshrinAR+LT-Regular';
  font-weight: normal;
  text-align: center;
  letter-spacing: 0px;
`;
const Price = styled.Text`
  color: rgb(13, 133, 123);
  font-size: 16px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: bold;
  text-align: center;
  letter-spacing: 0px;
`;
const Vat = styled.Text`
  color: rgb(109, 117, 142);
  font-size: 12px;
  font-family: 'OpenSans-Regular';
  font-weight: bold;
  text-align: center;
  letter-spacing: 0px;
  line-height: 16px;
`;

const Actions = styled.View`
  flex-direction: row;
`;
const AddToCart = styled.View`
  flex-grow: 1;
  padding: 0px 3px;
`;
const Pay = styled.View`
  flex-grow: 1;
  padding: 0px 3px;
`;

export default CartControls;

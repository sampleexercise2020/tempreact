import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action, configureActions } from '@storybook/addon-actions';

import ProductText from './ProductText';

const mockData = {
  name: 'School Uniform',
  price: 322,
  category: 'Supplies',
  shortDesc: 'Short Description',
  longDesc:
    'Long description. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.'
};

// ProductText takes 4 props: name, category, shortDesc, longDesc

storiesOf('Modules|Discover/School/Store/Components/Product/Text', module)
  .add('Both Long and Short Description', () => (
    <ProductText
      name={mockData.name}
      price={mockData.price}
      category={mockData.category}
      shortDesc={mockData.shortDesc}
      longDesc={mockData.longDesc}
    />
  ))
  .add('Only Long Description', () => (
    <ProductText
      name={mockData.name}
      price={mockData.price}
      category={mockData.category}
      longDesc={mockData.longDesc}
    />
  ))
  .add('Only Short Description', () => (
    <ProductText
      name={mockData.name}
      price={mockData.price}
      category={mockData.category}
      shortDesc={mockData.shortDesc}
    />
  ))
  .add('With Signature', () => (
    <ProductText
      name={mockData.name}
      price={mockData.price}
      category={mockData.category}
      shortDesc={mockData.shortDesc}
      signature={true}
    />
  ))
  .add('With everything', () => (
    <ProductText
      name={mockData.name}
      price={mockData.price}
      category={mockData.category}
      shortDesc={mockData.shortDesc}
      longDesc={mockData.longDesc}
      signature={true}
    />
  ))
  .add('Long name', () => (
    <ProductText
      name='This is a super duper duper long product name.'
      price={mockData.price}
      category={mockData.category}
      shortDesc={mockData.shortDesc}
      signature={true}
    />
  ));

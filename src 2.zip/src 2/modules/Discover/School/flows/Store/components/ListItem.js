import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components/native';
import { addCommaSeparator } from 'helpers/addCommaSeparator';
import OptionButton from './OptionButton';

const ListItem = ({
  buttonType,
  type,
  checked,
  title,
  price,
  currency,
  setCustomPrice,
  editable
}) => {
  const [customAmount, setCustomAmount] = useState('');

  useEffect(() => {
    if (setCustomPrice) {
      setCustomPrice(parseInt(customAmount * 100));
    }
  }, [customAmount]);

  return (
    <Container type={type} checked={checked}>
      <Type>
        <OptionButton buttonType={buttonType} checked={checked} />
      </Type>
      <Content>
        <Title>{title}</Title>
        {title === 'Enter Amount' ? (
          <CustomContainer>
            <AmountInputCurrency>{currency}</AmountInputCurrency>
            <AmountInput
              onChangeText={(text) =>
                setCustomAmount(text.replace(/[^0-9]/g, ''))
              }
              value={`${customAmount}`}
              keyboardType='number-pad'
              maxLength={5}
              editable={editable}
              returnKeyType={'done'}
            />
          </CustomContainer>
        ) : (
          <Price>
            {currency} {addCommaSeparator(price)}
          </Price>
        )}
      </Content>
    </Container>
  );
};

const Container = styled.View`
  flex-direction: row;
  height: 56px;
  width: 100%;
  /* TODO: Fix correct conditions to only show when selected*/
  background-color: ${(props) =>
    props.type === 'single' && props.checked ? 'rgb(255, 245, 245);' : 'white'};
  border-radius: 5px;
`;
const Type = styled.View`
  justify-content: center;
  align-items: center;
  padding-right: 15px;
  padding-left: 18px;
`;

const Content = styled.View`
  flex-direction: row;
  flex: 1;
  justify-content: space-between;
  align-items: center;
`;

const Title = styled.Text`
  color: #36235e;
  font-size: 16px;
  font-family: OpenSans-Bold;
  font-weight: bold;
  letter-spacing: -0.2px;
  line-height: 20px;
  width: 68%;
`;

const Price = styled.Text`
  color: #36235e;
  font-size: 16px;
  font-family: OpenSans-Semibold;
  font-weight: 600;
  letter-spacing: 0;
  padding-bottom: 2px;
  padding-right: 18px;
`;

const CustomContainer = styled.View`
  padding: 5px;
  width: 103px;
  height: 40px;
  border-radius: 4px;
  flex-direction: row;
`;

const AmountInput = styled.TextInput`
  height: 30px;
  padding-left: 9.5px;
  padding-bottom: 7px;
  background: rgb(255, 255, 255);
  border: 1px solid rgb(237, 238, 241);
  border-radius: 4px;
  color: #36235e;
  font-size: 14px;
  padding-top: 7px;
  font-family: OpenSans-Semibold;
  font-weight: 600;
  width: 80%;
`;

const AmountInputCurrency = styled.Text`
  color: #36235e;
  font-size: 16px;
  font-family: OpenSans-Semibold;
  font-weight: 600;
  letter-spacing: 0;
  padding-bottom: 2px;
  padding-right: 4px;
  margin-left: -20;
`;

export default ListItem;

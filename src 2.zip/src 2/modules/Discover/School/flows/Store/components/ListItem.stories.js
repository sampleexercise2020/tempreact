import React from 'react';
import { storiesOf } from '@storybook/react-native';

import ListItem from './ListItem';

const mockData = {
  radioChecked: {
    type: 'radio',
    buttonType: 'radio',
    checked: true,
    title: 'Term 5',
    price: 4000
  },
  radioUnchecked: {
    type: 'radio',
    buttonType: 'radio',
    checked: false,
    title: 'Term 5',
    price: 4000
  },
  checkChecked: {
    type: 'check',
    buttonType: 'checkbox',
    checked: true,
    title: 'Term 5',
    price: 4000
  },
  checkUnchecked: {
    type: 'checkbox',
    buttonType: 'radio',
    checked: false,
    title: 'Term 5',
    price: 4000
  }
};

storiesOf('Modules|Discover/School/Store/Components/Product/List Item', module)
  .add('Radio', () => (
    <ListItem
      type={mockData.radioChecked.type}
      buttonType='checkbox'
      title={mockData.radioChecked.title}
      price={mockData.radioChecked.price}
      checked={mockData.radioChecked.checked}
    />
  ))
  .add('Check', () => (
    <ListItem
      type={mockData.checkChecked.type}
      buttonType='checkbox'
      title={mockData.checkChecked.title}
      price={mockData.checkChecked.price}
      checked={mockData.checkChecked.checked}
    />
  ));

/*import React from 'react';
import { storiesOf } from '@storybook/react-native';
import StudentInfoHeader from './StudentInfoHeader';

storiesOf('Temp', module)
  .add('Standard', () => (
    <StudentInfoHeader
      name='Sarah'
      grade='Kindergarten . A'
      schoolName='Brilliant Int Private School'
      schoolAddress='343 &amp; 132 40 B St - Dubai'
      profileImage={true}
    />
  ))
  .add('Short names', () => (
    <StudentInfoHeader
      name='Ex'
      grade='Grade 1'
      schoolName='Brilliant'
      schoolAddress='343 &amp;'
      profileImage={true}
    />
  ))
  .add('Long names', () => (
    <StudentInfoHeader
      name='ExamplEEEAfkdhaksfadfadsfsdaf'
      grade='Grade adfafsadfsfsffsfasdffasdfsdffafdafsdfsf'
      schoolName='Brilliant Int Private Schoooooool'
      schoolAddress='343 &amp; 132DF 40 B7YT6444 St - Dubai'
      profileImage={true}
    />
  ))
  .add('Empty', () => (
    <StudentInfoHeader
      name=''
      grade=''
      schoolName=''
      schoolAddress=''
      profileImage={false}
    />
  ));*/

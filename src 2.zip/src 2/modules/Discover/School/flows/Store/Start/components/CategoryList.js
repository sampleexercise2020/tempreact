import React, { useEffect, useState } from 'react';
import { Text, Animated, StyleSheet, Platform } from 'react-native';
import { Navigation } from 'react-native-navigation';
import styled from 'styled-components/native';
import { Alert } from 'react-native';
import { useStoreState, useStoreActions } from 'easy-peasy';
import { navigateTo } from 'navigation';
import { debounce } from 'underscore';
import R from 'ramda';
import CollapsibleHeader from 'components/common/Header/CollapsibleHeader';
import NavigationButton from 'components/common/TopBar/NavigationButton';
import SimpleArrowListItem from 'components/common/ListItem/SimpleArrowListItem';
import LoaderContainer from 'components/common/LoaderContainer';
import Avatar from 'components/common/Avatar/Avatar';
import SchoolHeader from './SchoolHeader';
import StudentInfoHeader from './StudentInfoHeader';
import ListItemProduct from './ListItemProduct';

const backArrowButton = require('../../../../../../../../assets/icons/common/back_arrow_big.png');
const editButton = require('../../../../../../../../assets/icons/common/edit-white.png');
const backgroundImage = require('../../../../../../../../assets/backgrounds/school-header.png');
const threeDotIcon = require('../../../../../../../../assets/icons/common/three-dots.png');

const CategoryList = ({
  studentId,
  merchantId,
  beneficiaryId,
  componentId
}) => {
  const [isFetchingMerchant, setIsFetchingMerchant] = useState(false);
  const merchant = useStoreState((state) => state.merchant);
  const cart = useStoreState((state) => state.cart);

  const storeFetchMerchant = useStoreActions((actions, payload) => {
    return actions.merchant.fetch;
  });
  const savedStudents = useStoreState((state) => state.student.lists.saved);

  const student = savedStudents.find((student) => {
    return studentId === student.id;
  });
  const fetchProducts = useStoreActions((actions, payload) => {
    return actions.products.fetch;
  });
  const setCategory = useStoreActions((actions, payload) => {
    return actions.products.setCategory;
  });
  const setLocatedScanId = useStoreActions((actions, payload) => {
    return actions.currentProduct.setLocatedScanId;
  });
  const deleteCart = useStoreActions((actions) => actions.cart.deleteCart);

  const sessionExpire = useStoreActions((actions) => actions.session.expire);

  useEffect(() => {
    fetchMerchant(merchantId);
    console.log('Student: ', student);
  }, []);

  const fetchMerchant = async (id) => {
    setIsFetchingMerchant(true);
    const response = await storeFetchMerchant(id);

    if (response.status === 401 || response.status === 403) {
      sessionExpire();
    } else {
      if (response.status !== 200) {
        Alert.alert('Fetching merchant fail', response.message);
      }
    }

    setIsFetchingMerchant(false);
  };

  const shouldBeDebounced = async (item, student, departmentId) => {
    // TODO: Check if items added so far is in the same department as the menu clicked now.
    /**
     * department.id == cart.merchantLocId <- check if matching, otherwise ask user to clear cart.
     *
     * */

    function goToProductList() {
      fetchProducts({ menuId: item.id, gradeText: student.grade });
      // fetchProducts(item.id);

      setCategory({
        category: item.id,
        title: item.name,
        locatedScanId: item.locatedScanId
      });

      setLocatedScanId(item.locatedScanId);

      navigateTo('Skiply.Store.Category', componentId, {
        beneficiaryId,
        studentId,
        category: item.name
      });
    }

    if (cart && cart.carts[0] && cart.carts[0].merchantLocId !== departmentId) {
      Alert.alert(
        'Clear cart?',
        'You can only have one cart active at a time. One cart may only include one student. If you want to navigate to a new student, you must clear the cart.',
        [
          {
            text: 'Clear cart',
            onPress: async () => {
              goToProductList();

              if (cart.carts[0] && cart.carts[0].cartId) {
                const response = await deleteCart(cart.carts[0].cartId);
                if (response.status !== 200) {
                  Navigation.popToRoot(componentId);
                  Alert.alert('Error', response.message);
                }
              }
            }
          },
          { text: 'Cancel', onPress: () => console.log('CANCELLED ACTION') }
        ]
      );
    } else {
      goToProductList();
    }
  };
  const selectProductCategory = debounce(shouldBeDebounced, 300, true);

  const editStudentHandlerNavigate = () => {
    console.log('RAMDA LOL');
    R.ifElse(
      R.complement(R.isEmpty),
      () => Alert.alert('Please clear cart'),
      () =>
        navigateTo('Skiply.Account.StudentProfile.ViewProfile', componentId, {
          studentId
        })
    )(cart.carts);
  };

  const items =
    merchant && merchant.data
      ? merchant.data.departments.map((department, index) =>
          department.prodGroupSummaries.map((product, index) =>
            product ? (
              <SimpleArrowListItem
                text={product.name}
                key={product.id}
                onPress={() => {
                  selectProductCategory(product, student, department.id);
                }}
              />
            ) : null
          )
        )
      : null;

  return (
    <CollapsibleHeader
      title='All Categories'
      alignBigContentLeft
      extendedHeight={215}
      collapsedHeight={40}
      opacity={true}
      backgroundImage={backgroundImage}
      bigContent={
        <>
          <SchoolHeader
            merchant={merchant}
            componentId={componentId}
            schoolName={student && student.schoolName}
            schoolAddress={merchant.data && merchant.data.outlets[0].address}
          />
          <StudentInfoHeader
            hasButton
            student={student}
            onPress={editStudentHandlerNavigate}
          />
        </>
      }
      background
      positionFromLeft={30}
      smallContent={
        <SmallContentContainer>
          <Avatar
            small
            isRemote={true}
            image={student && student.image}
            name={student && `${student.firstName} ${student.lastName}`}
          />
        </SmallContentContainer>
      }
      hasTitleBar={true}
      titleBarIconLeft={
        <NavigationButton
          icon={backArrowButton}
          onPress={() => Navigation.pop(componentId)}
        />
      }
      titleBarIconRight={
        <NavigationButton
          icon={threeDotIcon}
          onPress={() =>
            navigateTo('Skiply.Discover.School.SchoolInfoPage', componentId, {
              merchant
            })
          }
        />
      }
    >
      <Container as={Animated.ScrollView}>
        <LoaderContainer isLoading={isFetchingMerchant}>
          {merchant.errorMessage ? (
            <ErrorMessage>{merchant.errorMessage}</ErrorMessage>
          ) : (
            items
          )}
        </LoaderContainer>
      </Container>
    </CollapsibleHeader>
  );
};

const Container = styled.ScrollView`
  height: 100%;
  ${Platform.select({ ios: `padding-top: 0;`, android: `padding-top: 16;` })};
`;

const SmallContentContainer = styled.View`
  align-items: center;
`;
const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  line-height: 22px;
  font-weight: normal;
`;

export default CategoryList;

import React, { useState, useEffect } from 'react';
import { Animated, Alert } from 'react-native';
import { Navigation } from 'react-native-navigation';
import { TouchableOpacity, Platform, ActivityIndicator } from 'react-native';
import styled from 'styled-components/native';
import { useStore, useActions, useStoreActions } from 'easy-peasy';
import { navigateTo } from 'navigation';
import NavigationButton from 'components/common/TopBar/NavigationButton';

import CollapsibleHeader from 'components/common/Header/CollapsibleHeader';

import LoaderContainer from 'components/common/LoaderContainer';
import Avatar from 'components/common/Avatar/Avatar';
import SchoolHeader from './SchoolHeader';
import StudentInfoHeader from './StudentInfoHeader';
import ListItemProduct from './ListItemProduct';
import { ThinLine } from 'components/common/Dividers/Dividers';
import { options } from '../../../../../../../navigation';

const backArrowButton = require('../../../../../../../../assets/icons/common/back_arrow_big.png');
const backgroundImage = require('../../../../../../../../assets/backgrounds/school-header.png');

let isNavigating = false;
const ProductList = ({
  passDataToParent,
  componentId,
  studentId,
  category
}) => {
  const setProductListComponentId = useStoreActions(
    ({ currentProduct }) => currentProduct.setProductListComponentId
  );
  const products = useStore((state) => state.products);
  const merchant = useStore((state) => state.merchant);

  const selectCurrentProduct = useActions((actions, payload) => {
    return actions.currentProduct.selectCurrentProduct;
  });

  const savedStudents = useStore((state) => state.student.lists.saved);

  const student = savedStudents.find((student) => {
    return studentId === student.id;
  });

  useEffect(function componentDidMount() {
    setProductListComponentId(componentId);
  }, []);

  const navigateToProduct = function(index) {
    if (!isNavigating) {
      isNavigating = true;
      setTimeout(() => {
        isNavigating = false;
      }, 300);
      selectCurrentProduct({ index });
      navigateTo(
        'Skiply.Store.Product',
        componentId,
        {
          student
        },
        {
          topBar: options.topBarWithTitle(products.data.products[index].name)
        }
      );
    }
  };

  useEffect(() => {
    passDataToParent ? passDataToParent(products.title) : null;
    console.log('products', products);
  }, [products]);

  const items =
    products &&
    products.list &&
    products.list.map((item, index) => (
      <React.Fragment key={item.id}>
        <TouchableOpacity
          onPress={() => {
            navigateToProduct(index);
          }}
        >
          <ListItemProduct
            title={item.name}
            shortDesc={item.smallDescription}
            image={item.mediumImageUrl}
            requiresSignature={
              item.form ? item.form.formRequiresSignature : false
            }
            inCart={item.inCart}
          />
        </TouchableOpacity>
        <ThinLine />
      </React.Fragment>
    ));

  return (
    <CollapsibleHeader
      title={category}
      alignBigContentLeft
      extendedHeight={215}
      collapsedHeight={40}
      opacity={true}
      backgroundImage={backgroundImage}
      smallContent={
        <SmallContentContainer>
          <Avatar small isRemote={true} image={student && student.image} />
        </SmallContentContainer>
      }
      bigContent={
        <>
          <SchoolHeader
            merchant={merchant}
            componentId={componentId}
            schoolName={student && student.schoolName}
            schoolAddress={merchant.data && merchant.data.outlets[0].address}
          />
          <StudentInfoHeader student={student} />
        </>
      }
      positionFromLeft={30}
      hasTitleBar={true}
      titleBarIconLeft={
        <NavigationButton
          icon={backArrowButton}
          onPress={() => Navigation.pop(componentId)}
        />
      }
    >
      <Container as={Animated.ScrollView}>
        <LoaderContainer isLoading={products.isLoading}>
          {products.errorMessage ? (
            <ErrorMessage>{products.errorMessage}</ErrorMessage>
          ) : (
            <List>{items}</List>
          )}
        </LoaderContainer>
      </Container>
    </CollapsibleHeader>
  );
};

const Container = styled.ScrollView`
  height: 100%;
  ${Platform.select({ ios: `padding-top: 0;`, android: `padding-top: 16;` })};
`;

const List = styled.View`
  flex-grow: 1;
`;

export const PlaceAtBottom = styled.View`
  padding: 0px 20px 30px;
  background: white;
`;

const SmallContentContainer = styled.View`
  align-items: center;
`;
const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  line-height: 22px;
  font-weight: normal;
`;

export default ProductList;

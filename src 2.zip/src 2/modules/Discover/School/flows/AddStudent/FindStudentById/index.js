import React, { useState, useCallback } from 'react';
import { Formik } from 'formik';
import { useStore, useStoreState, useActions } from 'easy-peasy';
import styled from 'styled-components/native';
import SchoolInfo from '../components/SchoolInfo';
import { navigateTo } from 'navigation';
import { testProperties } from '../../../../../../helpers/testProperties';
import Button from 'components/common/Button/Button';
import FormInput from 'components/common/Input/FormInput';
import * as yup from 'yup';
import R from 'ramda';

const FloatingBottomControls = ({
  handleSubmit,
  serverErrorMessage,
  formErrors,
  isValid,
  isActive
}) => {
  const isLoading = useStore((state) => state.student.isLoading);

  return (
    <FloatingBottom
      elevation={5}
      style={{
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 7
        },
        shadowOpacity: 0.43,
        shadowRadius: 9.51,

        elevation: 15
      }}
    >
      {serverErrorMessage ? (
        <ErrorContainer>{serverErrorMessage}</ErrorContainer>
      ) : null}
      {formErrors.firstName ? (
        <ErrorContainer>{formErrors.firstName}</ErrorContainer>
      ) : null}
      {formErrors.lastName ? (
        <ErrorContainer>{formErrors.lastName}</ErrorContainer>
      ) : null}
      {formErrors.phoneNumber ? (
        <ErrorContainer>{formErrors.phoneNumber}</ErrorContainer>
      ) : null}
      {formErrors.parentID ? (
        <ErrorContainer>{formErrors.parentID}</ErrorContainer>
      ) : null}
      {formErrors.studentID ? (
        <ErrorContainer>{formErrors.studentID}</ErrorContainer>
      ) : null}
      {formErrors.emailID1 ? (
        <ErrorContainer>{formErrors.emailID1}</ErrorContainer>
      ) : null}
      <Button
        {...testProperties('discover-addstudentmanually-nextstep-button-id')}
        primary
        disabled={!R.isEmpty(formErrors) || isLoading || !isActive}
        error={serverErrorMessage && !isLoading}
        onPress={handleSubmit}
      >
        Search
      </Button>
    </FloatingBottom>
  );
};

const FindStudentById = (props) => {
  const [searchType, setSearchType] = useState('');
  const [errorMessage, setErrorMessage] = useState(null);
  const merchant = useStoreState(({ merchant }) => merchant.data);
  const resetStudentResults = useActions(
    ({ student }) => student.resetStudentResults
  );

  const searchStudents = useActions(
    (actions) => actions.student.searchStudents
  );

  const sessionExpire = useActions((actions) => actions.session.expire);

  const validateSearch = yup.object().shape({
    firstName: yup
      .string()
      .matches(
        /^[a-zA-Z\s]+$/,
        'Invalid first name due to the number or special character used.'
      )
      .max(40, 'First name is too long'),
    lastName: yup
      .string()
      .matches(
        /^[a-zA-Z\s]+$/,
        'Invalid last name due to the number or special character used.'
      )
      .max(40, 'Last name is too long'),
    phoneNumber: yup
      .string()
      .matches(/^[\+\(\)0-9\-\s]+$/, 'Please enter phone number to continue.')
      .max(20, 'Phone number is too long'),
    parentID: yup
      .string()
      .matches(
        /^[0-9a-zA-Z]+$/,
        'Invalid parent ID due to the special character used.'
      )
      .max(10, 'Parent ID is too long'),
    studentID: yup
      .string()
      .matches(
        /^[0-9a-zA-Z]+$/,
        'Invalid student ID due to the special character used.'
      )
      .max(10, 'Student ID is too long'),
    emailID1: yup.string().email('Please enter a valid email id.')
  });

  const handleSearch = useCallback(
    async (searchData) => {
      setErrorMessage(null);
      resetStudentResults();

      const data = {
        autoDetect: false,
        [searchData.searchType]: searchData[searchData.searchType],
        merchantId: merchant.id
      };

      const response = await searchStudents(data);

      if (response.status == 200) {
        if (!R.isEmpty(response.data)) {
          navigateTo(
            'Skiply.Discover.School.StudentResults',
            props.componentId,
            {
              title: `${response.data.length} results`
            }
          );
        } else {
          setErrorMessage('No students found');
        }
      } else if (response.status == 401 || response.status == 403) {
        sessionExpire();
      } else {
        setErrorMessage(response.message);
      }
    },
    [searchType]
  );

  const searchOptions = [
    {
      label: 'First Name',
      value: 'firstName'
    },
    {
      label: 'Last Name',
      value: 'lastName'
    },
    {
      label: 'Phone Number',
      value: 'phoneNumber'
    },
    {
      label: 'Parent ID',
      value: 'parentID'
    },
    {
      label: 'Student ID',
      value: 'studentID'
    },
    {
      label: 'Email ID',
      value: 'emailID1'
    }
  ];

  const getCurrentSearchOptionLabel = useCallback((searchType) => {
    const option = searchOptions.find(({ value }) => value == searchType);

    return (option && option.label) || '';
  }, []);

  return (
    <Formik
      initialValues={{
        searchType: '',
        firstName: '',
        lastName: '',
        phoneNumber: '',
        parentId: '',
        studentId: '',
        emailID1: ''
      }}
      validationSchema={validateSearch}
      onSubmit={handleSearch}
      enableReinitialize
    >
      {(props) => (
        <Container {...testProperties('discover-searchstudent-container-id')}>
          <Content>
            <FormContainer>
              <BoxHead {...testProperties('discover-searchstudent-boxhed-id')}>
                <SchoolInfo
                  {...testProperties(
                    'discover-addstudentmanually-schoolinfo-id'
                  )}
                />
              </BoxHead>
              <Form>
                <FormInput
                  {...testProperties(
                    'discover-addstudentmanually-gender-input-id'
                  )}
                  numberOfLines={1}
                  logo={false}
                  label='Search by...'
                  type='DROPDOWN'
                  options={searchOptions}
                  keyboardType='default'
                  returnKeyType='go'
                  value={props.values.searchType}
                  onChangeText={(value) => {
                    console.log(props);
                    props.resetForm({ searchType: value });
                  }}
                />
                {props.values.searchType ? (
                  <FormInput
                    {...testProperties(
                      'discover-addstudentmanually-default-input-id'
                    )}
                    numberOfLines={1}
                    logo={false}
                    label={`Enter ${getCurrentSearchOptionLabel(
                      props.values.searchType
                    )}`}
                    keyboardType='default'
                    returnKeyType='go'
                    value={props.values[props.values.searchType] || ''}
                    onChangeText={props.handleChange(props.values.searchType)}
                  />
                ) : null}
              </Form>
            </FormContainer>
          </Content>
          <FloatingBottomControls
            componentId={props.componentId}
            handleSubmit={props.handleSubmit}
            formErrors={props.errors}
            serverErrorMessage={errorMessage}
            isActive={
              props.values.searchType && props.values[props.values.searchType]
            }
          />
        </Container>
      )}
    </Formik>
  );
};

const Container = styled.View`
  flex: 1;
  padding-top: 20px;
`;

const Content = styled.ScrollView`
  flex: 1;
`;

const FormContainer = styled.View`
  background: #f5f5f7;
  margin: 0px 20px;
  border-radius: 4px;
  overflow: hidden;
`;

const Form = styled.View`
  padding: 10px 15px 0px;
  padding-bottom: 2px;
`;

const HeaderText = styled.Text`
  height: 22px;
  color: rgb(13, 25, 67);
  font-size: 16px;
  font-family: OpenSans-Bold;
  font-weight: bold;
  letter-spacing: 0px;
  line-height: 22px;
  margin-top: 30px;
  margin-bottom: 20px;
  padding: 0px 20px;
`;

const BoxHead = styled.View`
  background: #edeef1;
  padding: 15px 20px;
`;

const FloatingBottom = styled.View`
  background-color: white;
  padding: 20px 20px 30px;
`;
const ErrorContainer = styled.Text`
  color: red;
  text-align: center;
  margin-bottom: 10px;
`;

export default FindStudentById;

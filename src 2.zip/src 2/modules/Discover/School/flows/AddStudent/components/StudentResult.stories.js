import React from 'react';
import { storiesOf } from '@storybook/react-native';
import StudentResult from './StudentResult';
import R from 'ramda';
import StudentAdded from './StudentAdded';

const testStudent = {
  firstName: 'Sarah',
  middleName: 'K',
  lastName: 'Andersson',
  gender: 'F',
  grade: 'Kindergarden',
  class: '3A',
  age: '6',
  beneficiaryId: '',
  schoolName: 'Skiply School of Excellence',
  image:
    'https://testmssbucket.s3-eu-west-1.amazonaws.com/SkiplySchoolofExcellence/56ad1935-bbc8-4741-aafd-8c76a201d776.png'
};

const testSchool = {
  name: 'Skiply School of Excellence',
  address: 'Silicon Oasis, Dubai, UAE',
  imageUrl:
    'https://testmssbucket.s3-eu-west-1.amazonaws.com/SkiplySchoolofExcellence/56ad1935-bbc8-4741-aafd-8c76a201d776.png'
};

storiesOf('Modules|Discover/School/AddStudent/Student Result', module)
  .add('Student Result', () => (
    <StudentResult
      student={testStudent}
      school={testSchool}
      btnText='Add'
      AddBtn={true}
    />
  ))
  .add('No profile photo', () => (
    <StudentResult
      student={R.dissoc('image', testStudent)}
      school={testSchool}
      btnText='Add'
      AddBtn={true}
    />
  ))
  .add('Not the correct student', () => (
    <StudentResult
      student={testStudent}
      school={testSchool}
      btnText='Verify & Add'
      notCorrect={true}
      AddBtn={true}
    />
  ))
  .add('Loading', () => (
    <StudentResult
      student={testStudent}
      school={testSchool}
      btnText='Verify & Add'
      isLoading={true}
      AddBtn={true}
    />
  ))
  .add('Dismiss profile', () => (
    <StudentResult
      student={testStudent}
      school={testSchool}
      btnText='Verify & Add'
      dismissBtnText='Dismiss this Profile'
      dismissBtn={true}
      AddBtn={true}
    />
  ))
  .add('Change profile photo', () => (
    <StudentResult
      student={testStudent}
      school={testSchool}
      btnText='Change profile photo'
      dismissBtnText='Dismiss this Profile'
      AddBtn={true}
      changeProfile={true}
    />
  ))
  .add('Student Added', () => (
    <StudentResult student={testStudent} school={testSchool} />
  ));

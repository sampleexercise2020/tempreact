import React from 'react';
import styled from 'styled-components/native';

const StudentLoader = (props) => {
  return (
    <Container>
      <Loader source={require('src/../../assets/images/loader.gif')} />
    </Container>
  );
};

export default StudentLoader;

const Loader = styled.Image`
  width:30px
  height: 30px;
`;
const Container = styled.View`
  justify-content: center;
  align-items: center;
  margin: 5px 0 25px 0;
`;

import React from 'react';
import styled from 'styled-components/native';
import AddStudentBtn from '../components/AddStudentBtn';
import { Headline } from 'components/common/Typography';
import selectedCopy from '../../../../../../i18n/copy';

const Checkmark = require('src/../../assets/images/checkmark.png');

const copy =
  selectedCopy.components.modules.Discover.School.flows.AddStudent.StudentAdded;

const StudentAdded = ({ studentFirstname }) => {
  return (
    <>
      <Container>
        <Inner>
          <Image source={Checkmark} />
        </Inner>
        <Title>
          {studentFirstname} {copy.added}
        </Title>
      </Container>
      <AddStudentBtn />
    </>
  );
};

export default StudentAdded;

const Container = styled.View`
  flex-direction: column;
  align-items: center;
  background-color: #f5f5f7;
  margin: 10px 20px;
  border-radius: 4px;
`;

const Inner = styled.View`
  align-items: center;
  justify-content: center;
  width: 60px;
  height: 60px;
  border-radius: 30px;
  background-color: #ffffff;
  margin: 25px 0 10px 0;
`;

const Image = styled.Image`
  height: 22px;
  width: 28px;
`;

const Title = styled(Headline)`
  color: rgb(13, 25, 67);
  font-family: OpenSans-Bold;
  font-size: 16px;
  letter-spacing: 0px;
  line-height: 22px;
  margin-bottom: 25px;
`;

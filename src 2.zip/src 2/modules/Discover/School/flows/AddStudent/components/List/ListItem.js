import React from 'react';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components/native';
import UserAvatar from 'react-native-user-avatar';

import Avatar from 'components/common/Avatar/Avatar';
import OptionButton from './OptionButton';

const ListItem = ({ checked, title, address, imageUrl }) => {
  const toggleButton = () => {};

  return (
    <Container checked={checked}>
      <Avatar
        isRemote={true}
        image={imageUrl}
        smallIcon
        light
        name={title ? title.toUpperCase() : 'Test Placeholder'}
      />
      <Content>
        <Title>{title}</Title>
        <Address>{address}</Address>
      </Content>
      <Type>
        <OptionButton checked={checked} />
      </Type>
    </Container>
  );
};

ListItem.propTypes = {
  checked: PropTypes.bool.isRequired,
  title: PropTypes.string.isRequired,
  address: PropTypes.string.isRequired
};

const Container = styled.View`
  flex-direction: row;
  width: 100%;
  min-height: 60px;
  /* TODO: Fix correct conditions to only show when selected*/
  background-color: ${(props) =>
    props.type == 'single' && props.checked ? 'rgb(255, 245, 245);' : 'white'};
  justify-content: center;
  align-items: center;
  padding: 10px 20px;
`;
const Type = styled.View`
  justify-content: center;
  align-items: center;
  padding-left: 18px;
`;

const Content = styled.View`
  flex-direction: column;
  flex: 1;
  justify-content: center;
  padding-left: 16px;
`;

const Title = styled.Text`
  color: rgb(13, 25, 67);
  font-size: 16px;
  font-family: OpenSans-Regular;
  letter-spacing: -0.2px;
  line-height: 20px;
`;

const Address = styled.Text`
  color: rgb(109, 117, 142);
  font-size: 14px;
  font-family: OpenSans-Regular;
  letter-spacing: 0;
  padding-right: 18px;
`;

export default ListItem;

import React, { useEffect } from 'react';
import { ActivityIndicator, Alert } from 'react-native';
import { useStore, useActions } from 'easy-peasy';
import styled from 'styled-components';
import CheckoutTotal from '../components/CheckoutTotal';
import ReceiptTimeStamp from '../components/ReceiptTimeStamp';
import CheckoutItem from '../components/CheckoutItem';
import Button from 'components/common/Button/Button';
import IconAndTextListItem from '../../../../../../components/common/ListItem/IconAndTextListItem';
import selectedCopy from '../../../../../../i18n/copy';
import Avatar from 'modules/Discover/School/flows/Store/Start/components/Avatar';
import convertDate from 'src/../helpers/convertDate';
import { testProperties } from '../../../../../../helpers/testProperties';
import LoaderContainer from 'components/common/LoaderContainer';
import { navigateTo } from 'navigation';
import R from 'ramda';
import { Navigation } from 'react-native-navigation';

const copy =
  selectedCopy.components.modules.Discover.School.flows.Checkout.Receipt
    .Receipt;

const iconVisa = require('../../../../../../../assets/icons/payment/Mobile-VISA.png');

const Receipt = (props) => {
  console.log('Props: ', props);
  const receipt = useStore((state) => state.receipts.singleReceipt);
  const isLoading = useStore((state) => state.receipts.isLoading);
  const isLoadingSendingReceipt = useStore(
    (state) => state.receipts.isLoadingSendingReceipt
  );
  const fetchSingleReceipt = useActions((actions) => {
    return actions.receipts.fetchSingleReceipt;
  });

  const sendReceipt = async () => {
    navigateTo('Skiply.Purchases.EmailReceipt', props.componentId);
  };

  useEffect(() => {
    fetchSingleReceipt(props.receipt.transactionId);
  }, []);

  return (
    <LoaderContainer isLoading={isLoading}>
      <Container {...testProperties('discover-checkout-receipt-containte-id')}>
        <Margin />
        <ReceiptTimeStamp
          {...testProperties('discover-checkout-receipt-receiptbar-id')}
          timestamp={convertDate(receipt.orderDate)}
          orderRef={`REF #${receipt.ref}`}
        />
        {receipt.beneficiaries &&
          receipt.beneficiaries.map((beneficiary) => {
            return beneficiary.items.length > 0 ? (
              <React.Fragment key={beneficiary.id}>
                <AvatarContainer>
                  <Border>
                    <Avatar
                      {...testProperties('discover-checkout-receipt-avatar-id')}
                      source={{
                        uri: beneficiary.image
                      }}
                      name={beneficiary.firstName + ' ' + beneficiary.lastName}
                    />
                  </Border>
                  <TextContainer>
                    <Title
                      {...testProperties(
                        'discover-checkout-receipt-textcontainer-title-id'
                      )}
                    >
                      {beneficiary.firstName + ' ' + beneficiary.lastName}
                    </Title>
                    {/* *
                     * TODO School name is not available in api response. */}
                    <Subtitle
                      {...testProperties(
                        'discover-checkout-receipt-textcontainer-subtitle-id'
                      )}
                    >
                      {props && props.receipt && props.receipt.merchantName}
                    </Subtitle>
                  </TextContainer>
                </AvatarContainer>
                {beneficiary.items.map((item) => {
                  return (
                    <CheckoutItem
                      key={item.id}
                      {...testProperties(
                        'discover-checkout-receipt-checkoutitem-id'
                      )}
                      productTitle={item.historicalPurchaseData.productName}
                      amount={item.amount.amountMinorUnits / 100}
                      currency={item.amount.currency}
                      quantity={item.quantity > 1 ? `x ${item.quantity}` : ''}
                    />
                  );
                })}
              </React.Fragment>
            ) : null;
          })}
        <CheckoutTotal
          {...testProperties('discover-checkout-receipt-checkouttotal-id')}
          total={receipt.totalOrderAmount / 100}
          vat={receipt.taxAmount == 0 ? 0 : receipt.taxAmount / 100}
          currency={`${receipt.currency} `}
        />
        <Separator />
        <LowerContainer>
          <PaymentMethodTitle
            {...testProperties('discover-checkout-receipt-payment-title-id')}
          >
            {copy.cardUsed}
          </PaymentMethodTitle>
          <IconAndTextListItem
            {...testProperties(
              'discover-checkout-receipt-iconandtextlistitem-id'
            )}
            noIcon={true}
            listItemText={props && props.receipt && props.receipt.cardAlias}
            maskedPan={receipt.maskedPan}
            hideArrow={true}
          />
        </LowerContainer>
      </Container>
      <ButtonContainer>
        <Button
          testProperties={testProperties(
            'discover-checkout-receipt-sendreceipt-button-id'
          )}
          secondary
          onPress={() => sendReceipt()}
        >
          {copy.sendReceipt}
        </Button>
      </ButtonContainer>
    </LoaderContainer>
  );
};

export default Receipt;

const TopBar = styled.View`
  height: 64px;
  justify-content: center;
  align-items: center;
  background-color: #2c1e75;
  margin-bottom: 30px;
`;

const TopTitle = styled.Text`
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  font-size: 16px;
  text-align: center;
  color: #ffffff;
  line-height: 22px;
`;

const AvatarContainer = styled.View`
  flex-direction: row;
  margin: 30px 0 10px 20px;
  align-items: center;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  font-size: 12px;
  line-height: 16px;
  color: #0d1943;
`;

const Border = styled.View`
  background-color: rgba(0, 0, 0, 0.3);
  height: 32px;
  width: 32px;
  border-radius: 17px;
  justify-content: center;
  align-items: center;
  overflow: hidden;
`;

const Subtitle = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  line-height: 16px;
  color: #6d758e;
`;

const TextContainer = styled.View`
  flex-direction: column;
  margin-left: 10px;
`;

const Container = styled.ScrollView`
  flex: 1;
`;

const Separator = styled.View`
  margin-top: 10px;
`;

const PaymentMethodTitle = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  line-height: 22px;
  font-weight: bold;
  color: #36235e;
  margin-left: 20px;
  margin-top: 30px;
`;

const LowerContainer = styled.View`
  flex: 1;
`;

const ButtonContainer = styled.View`
  margin: 20px;
`;

const Margin = styled.View`
  margin-top: 20px;
`;

import React from 'react';
import styled from 'styled-components';
import { Headline } from 'components/common/Typography/';
import RadioButton from 'components/common/RadioButton/RadioButton';
import AddCardButton from '../../components/AddCardButton';

const CheckMarkIcon = require('src/../../assets/images/checkmark.png');
const forwardArrow = require('src/../../assets/icons/common/right-arrow.png');

const IconAndTextListItem = ({
  listItemText,
  imageUrl,
  icon,
  maskedPan,
  isDefault,
  selected,
  check,
  onPress,
  iconWidth
}) => {
  return (
    <Container onPress={onPress}>
      {icon ? (
        <IconContainer>
          {imageUrl && (
            <Icon
              iconWidth={iconWidth}
              resizeMode='contain'
              source={{ uri: imageUrl }}
            />
          )}
          {icon && (
            <Icon iconWidth={iconWidth} resizeMode='contain' source={icon} />
          )}
        </IconContainer>
      ) : null}
      <TextContainer>
        <Title>{listItemText ? listItemText : 'Unknown'}</Title>
        {maskedPan ? <MaskedPan>{maskedPan}</MaskedPan> : null}
      </TextContainer>
    </Container>
  );
};

export default IconAndTextListItem;

const Container = styled.View`
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 14px 0;
  ${(props) =>
    props.border &&
    css`
      border-top-width: 1px;
      border-bottom-width: 1px;
      border-color: ${(props) => props.theme.color.misc.listItemDivider};
    `}
`;

const Title = styled(Headline)`
  color: #0d1943;
  font-size: 16px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
`;

const MaskedPan = styled(Headline)`
  color: #6d758e;
  font-size: 12px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
`;

const IconContainer = styled.View`
  height: 28px;
  width: 35px;
  justify-content: center;
  align-items: center;
`;

const Icon = styled.Image`
  flex: 1;
  height: undefined;
  width: ${(props) => (props.iconWidth ? props.iconWidth : '35px')};
`;

const TextContainer = styled.View`
  flex-direction: column;
`;

import React from 'react';
import styled from 'styled-components';

const Receipt = ({ timestamp, orderRef }) => {
  return (
    <Container>
      <Timestamp>{timestamp}</Timestamp>
      <OrderRef>{orderRef}</OrderRef>
    </Container>
  );
};

export default Receipt;

const Container = styled.View`
  background-color: #f5f5f7;
  flex-direction: row;
  border-radius: 4px;
  height: 40px;
  align-items: center;
  margin: 0 20px;
  justify-content: space-between;
`;

const Timestamp = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  line-height: 17px;
  color: #6d758e;
  margin-left: 20px;
`;

const OrderRef = styled.Text`
  color: #0d1943;
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  margin-right: 20px;
`;

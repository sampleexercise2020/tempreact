import React from 'react';
import { storiesOf } from '@storybook/react-native';
import AvailableCardsCO from './AvailableCardsCO';

storiesOf('Modules|Discover/School/Checkout/components', module).add(
  'Available cards at CO',
  () => <AvailableCardsCO title='Choose card' />
);

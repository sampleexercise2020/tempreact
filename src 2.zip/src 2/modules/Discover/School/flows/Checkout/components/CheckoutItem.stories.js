import React from 'react';
import { storiesOf } from '@storybook/react-native';
import CheckoutItem from './CheckoutItem';

storiesOf('Modules|Discover/School/Checkout/components', module).add(
  'Checkout list item',
  () => <CheckoutItem productTitle='Grade 1' amount='AED 4 400' />
);

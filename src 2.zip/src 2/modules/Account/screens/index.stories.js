import React from 'react';
import { storiesOf } from '@storybook/react-native';
import AccountStartingPage from './';

// TODO: Get notes working.

storiesOf('Modules|Account', module).add('Start', () => (
  <AccountStartingPage />
));

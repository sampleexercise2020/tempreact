import React, { useState } from 'react';
import { Animated, Alert } from 'react-native';
import styled from 'styled-components/native';
import { Navigation } from 'react-native-navigation';
import { useStore, useActions } from 'easy-peasy';
import { navigateTo, popToRoot } from 'navigation';
import NavigationButton from 'components/common/TopBar/NavigationButton';
import ProfileImage from 'components/common/ProfileImage/ProfileImage';
import CollapsibleHeader from 'components/common/Header/CollapsibleHeader';
import ProfileInfoListItem from 'components/common/ListItem/ProfileInfoListItem';
import Button from 'components/common/Button/Button';
import selectedCopy from '../../../../../i18n/copy';
import { testProperties } from '../../../../../helpers/testProperties';

const backArrowButton = require('../../../../../../assets/icons/common/back_arrow_big.png');
const editButton = require('../../../../../../assets/icons/common/edit-white.png');

const copy =
  selectedCopy.components.modules.Account.flows.Profile.Profile.index;

const StudentProfile = ({ studentId, componentId }) => {
  const username = useStore((state) => state.profile.data.emailAddress);
  const savedStudents = useStore((state) => state.student.lists.saved);

  const student = savedStudents.find((student) => {
    return studentId === student.id;
  });
  const deleteBeneficiary = useActions(
    (actions) => actions.profile.deleteBeneficiary
  );
  const sessionExpire = useActions((actions) => actions.session.expire);

  const handleRemoveStudent = async () => {
    Alert.alert('Confirm', 'Do you want to remove the student ?', [
      {
        text: 'Yes',
        onPress: async () => {
          popToRoot(componentId);

          const response = await deleteBeneficiary({
            studentId: student.id
          });
          if (response.status == 200) {
            Alert.alert(
              'Remove Student',
              'The selected student has now been removed from your profile.',
              [{ text: 'OK', onPress: () => console.log('Ok pressed') }]
            );
          } else {
            if (response.status == 401 || response.status == 403) {
              sessionExpire();
            } else {
              Alert.alert(
                'Error',
                'Something went wrong when trying to delete this student. Please try again later.',
                [{ text: 'OK', onPress: () => console.log('Ok pressed') }]
              );
            }
          }
        }
      },
      { text: 'No', onPress: () => {} }
    ]);
  };

  return (
    <CollapsibleHeader
      shouldScale={true}
      extendedHeight={252}
      collapsedHeight={50}
      isCurved={true}
      bigContent={
        <ProfileImage
          image={student && student.image}
          title={student && student.firstName + ' ' + student.lastName}
          name={student && student.firstName + ' ' + student.lastName}
          editMode={student.schoolProvidedData}
          studentId={student && student.id}
        />
      }
      hasTitleBar={true}
      titleBarIconLeft={
        <NavigationButton
          icon={backArrowButton}
          onPress={() => Navigation.pop(componentId)}
          {...testProperties('view-student-profile-back-button-id')}
        />
      }
      titleBarIconRight={
        student.schoolProvidedData == false ? (
          <NavigationButton
            icon={editButton}
            onPress={() =>
              navigateTo(
                'Skiply.Account.StudentProfile.EditProfile',
                componentId,
                { studentId }
              )
            }
            {...testProperties('view-student-profile-edit-button-id')}
          />
        ) : null
      }
    >
      <Container
        as={Animated.ScrollView}
        {...testProperties('view-student-profile-container-id')}
      >
        <ProfileInfoListItem
          label='First Name'
          inputField={student && student.firstName}
        />
        <ProfileInfoListItem
          label='Last Name'
          inputField={student && student.lastName}
        />
        {student &&
          student.studentRegisterCustomFieldValues &&
          student.studentRegisterCustomFieldValues.map(
            ({ bcfdName, bcfdValue }) => {
              return (
                <ProfileInfoListItem
                  key={bcfdName}
                  label={bcfdName}
                  inputField={bcfdValue}
                />
              );
            }
          )}
        <Margin />
        <ButtonContainer>
          <Button secondary onPress={handleRemoveStudent}>
            Remove student
          </Button>
        </ButtonContainer>
        <Margin />
      </Container>
    </CollapsibleHeader>
  );
};

export default StudentProfile;

const Container = styled.ScrollView`
  height: 100%;
`;

const Margin = styled.View`
  margin-bottom: 40px;
`;

const ButtonContainer = styled.View`
  margin: 0 20px;
`;

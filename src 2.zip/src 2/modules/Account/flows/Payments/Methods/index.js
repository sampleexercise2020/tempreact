import React, { useEffect } from 'react';
import styled from 'styled-components/native';
import AvailableCardsList from './components/AvailableCardsList';
import { Headline } from 'components/common/Typography/';
import selectedCopy from '../../../../../i18n/copy';
import { Navigation } from 'react-native-navigation';
import { testProperties } from '../../../../../helpers/testProperties';

const copy =
  selectedCopy.components.modules.Account.flows.Payments.Methods.components
    .AvailableCardsList;

const Methods = (props) => {
  Navigation.mergeOptions(props.componentId, {
    topBar: {
      visible: true
    }
  });
  return (
    <Container {...testProperties('payments-methods-start-container-id')}>
      <InnerContainer>
        <AvailableCardsList componentId={props.componentId} />
      </InnerContainer>
    </Container>
  );
};

export default Methods;

const Container = styled.View`
  flex: 1;
  padding-bottom: 20px;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const Title = styled(Headline)`
  color: ${(props) => props.theme.color.primary.primaryText};
  font-size: 16px;
  margin: 20px 0px 20px 20px;
  font-family: 'OpenSans-Bold';
`;

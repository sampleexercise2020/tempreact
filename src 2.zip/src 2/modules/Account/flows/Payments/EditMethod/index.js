import React, { useState } from 'react';
import { Alert } from 'react-native';
import { useActions } from 'easy-peasy';
import R from 'ramda';
import { Navigation } from 'react-native-navigation';
import styled from 'styled-components/native';
import InfoBanner from '../components/InfoBanner';
import RadioButton from '/components/common/RadioButton/RadioButton';
import Button from '/components/common/Button/Button';
import FormInput from '/components/common/Input/FormInput';
import { Formik } from 'formik';
import * as yup from 'yup';
import selectedCopy from '../../../../../i18n/copy';
import { testProperties } from '../../../../../helpers/testProperties';
const copy =
  selectedCopy.components.modules.Account.flows.Payments.EditMethod.index;
const EditCardSchema = yup.object().shape({
  name: yup
    .string()
    .required(copy.nameRequired)
    .matches(
      /^[a-zA-Z\s]+$/,
      'You cannot add numbers or special characters in cardholder name.'
    ),
  pan: yup
    .number()
    .required(copy.panRequired)
    .min(19, copy.panMin),
  alias: yup.string(),
  expDate: yup
    .string()
    .ensure()
    .test('test-name', 'Please enter a valid expiry date.', function(value) {
      console.log('value', value);
      if (value == undefined || value == '') {
        return true;
      } else {
        var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
        var matches = v.match(/\d{2,4}/g);
        var match = (matches && matches[0]) || '';
        var utc = parseInt(
          new Date()
            .toJSON()
            .slice(2, 4)
            .split('-')
            .join('/')
        );
        var parts = [];
        for (let i = 0; i < match.length; i += 2) {
          parts.push(match.substring(i, i + 2));
        }
        var month = parseInt(parts[0]);
        var year = parseInt(parts[1]);
        console.log('Value', value);
        console.log('Matches', matches);
        console.log('Month', month);
        console.log('Year', year);
        if (year === parts[1] && month + 1 > parts[0]) {
          return false;
        }
        if (month === 0 || value[0] >= 2 || parts[0] > 12) {
          return false;
        } else if (month <= 12 && year >= utc) {
          return true;
        } else {
          return false;
        }
      }
    })
});
const EditCardSchemaNoPan = yup.object().shape({
  name: yup
    .string()
    .required(copy.nameRequired)
    .matches(
      /^[a-zA-Z\s]+$/,
      'You cannot add numbers or special characters in cardholder name.'
    ),
  alias: yup
    .string()
    .required('Please enter card nickname to continue.')
    .matches(
      /^[a-zA-Z0-9\s]+$/,
      'Only letters and numbers are allowed in nickname field.'
    ),
  expDate: yup
    .string()
    .ensure()
    .test('test-name', 'Please enter a valid expiry date.', function(value) {
      console.log('value', value);
      if (value == undefined || value == '') {
        return true;
      } else {
        var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
        var matches = v.match(/\d{2,4}/g);
        var match = (matches && matches[0]) || '';
        var utc = parseInt(
          new Date()
            .toJSON()
            .slice(2, 4)
            .split('-')
            .join('/')
        );
        var parts = [];
        for (let i = 0; i < match.length; i += 2) {
          parts.push(match.substring(i, i + 2));
        }
        var month = parseInt(parts[0]);
        var year = parseInt(parts[1]);
        console.log('Value', value);
        console.log('Matches', matches);
        console.log('Month', month);
        console.log('Year', year);
        if (year === parts[1] && month + 1 > parts[0]) {
          return false;
        }
        if (month === 0 || value[0] >= 2 || parts[0] > 12) {
          return false;
        } else if (month <= 12 && year >= utc) {
          return true;
        } else {
          return false;
        }
      }
    })
});
const formatCardString = (value) => {
  var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
  var matches = v.match(/\d{4,16}/g);
  var match = (matches && matches[0]) || '';
  var parts = [];
  for (i = 0, len = match.length; i < len; i += 4) {
    parts.push(match.substring(i, i + 4));
  }
  if (parts.length) {
    return parts.join(' ');
  } else {
    return value;
  }
};
const formatExpiryDateString = (value) => {
  var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
  var matches = v.match(/\d{2,4}/g);
  var match = (matches && matches[0]) || '';
  var parts = [];
  for (i = 0, len = match.length; i < len; i += 2) {
    parts.push(match.substring(i, i + 2));
  }
  if (parts.length) {
    return parts.join(' / ');
  } else {
    return value;
  }
};
const EditMethod = ({ card, componentId }) => {
  const updateCard = useActions((actions) => actions.cards.update);
  const deleteCard = useActions((actions) => actions.cards.delete);
  const [isMaskedPan, setIsMaskedPan] = useState(true);
  const handleSubmit = async ({ name, alias, pan, isDefault, expDate }) => {
    const expDateTuple = expDate
      .split('/')
      .map((item) => parseInt(item.trim()));
    const expMonth = expDateTuple[0];
    const expYear = expDateTuple[1];
    let payload = {
      name,
      alias,
      default: isDefault,
      id: card.id
    };
    if (!isMaskedPan) {
      payload['pan'] = pan;
    }
    if (expMonth && expYear) {
      payload['expMonth'] = expMonth;
      payload['expYear'] = expYear;
    }
    const response = await updateCard(payload);
    navigateToAddNewMethod();
    if (!response.success) {
      var message;
      if (response.message == 'Validation error in request data') {
        message =
          'The card details you have entered are invalid. Please re-enter valid card details.';
      } else {
        message = response.message;
      }
      Alert.alert('Could not update card', message);
    }
  };
  const navigateToAddNewMethod = () => {
    Navigation.pop(componentId);
  };
  const handleDelete = async () => {
    // Works on both iOS and Android
    Alert.alert(
      'Delete Card',
      'Are you sure you want to delete this card?',
      [
        {
          text: 'Yes',
          onPress: async () => {
            navigateToAddNewMethod();
            const response = await deleteCard(card.id);
            if (!response.success) {
              Alert.alert('Couldnt delete the card', response.message);
            }
          }
        },
        { text: 'No', onPress: () => {}, style: 'cancel' }
      ],
      { cancelable: false }
    );
  };
  return (
    <Formik
      initialValues={{
        name: card.cardHolderName,
        pan: card.maskedPan,
        expDate: '',
        alias: card.alias,
        isDefault: card.isDefault
      }}
      onSubmit={handleSubmit}
      enableReinitialize
      validationSchema={isMaskedPan ? EditCardSchemaNoPan : EditCardSchema}
      validateOnBlur={false}
      validateOnChange={false}
    >
      {(props) => (
        <Container
          {...testProperties('payments-edit-method-start-container-id')}
        >
          <InnerContainer keyboardShouldPersistTaps='never'>
            <FormContainer>
              <FormInput
                numberOfLines={1}
                logo={false}
                label={copy.cardHolderName}
                keyboardType='default'
                returnKeyType='go'
                value={props.values.name}
                onChangeText={R.compose(
                  props.handleChange('name'),
                  (string) => string.replace(/[^a-zA-Z_ ]*$/i, '')
                )}
                onBlur={props.handleBlur('name')}
                matches={/[a-zA-Z]+/}
                maxLength={30}
                testProperties={testProperties(
                  'payments-edit-method-cardholder-name-id'
                )}
              />
              <FormInput
                numberOfLines={1}
                logo={false}
                label={copy.cardNumber}
                keyboardType='numeric'
                returnKeyType='go'
                maxLength={19}
                onChangeText={(value) => {
                  if (/^[0-9\s]*$/.test(value)) {
                    props.setFieldValue('pan', formatCardString(value));
                  } else {
                    return;
                  }
                  const formattedValue = formatCardString(value);
                }}
                onFocus={() => {
                  if (isMaskedPan) {
                    props.setFieldValue('pan', '');
                    setIsMaskedPan(false);
                  }
                }}
                onBlur={props.handleBlur('pan')}
                value={props.values.pan}
                editable={false}
                testProperties={testProperties('payments-edit-method-pan-id')}
              />
              <FormInput
                numberOfLines={1}
                logo={false}
                label={copy.cardExpiryDate}
                keyboardType='numeric'
                returnKeyType='go'
                maxLength={7}
                value={props.values.expDate}
                onChangeText={(value) => {
                  props.setFieldValue('expDate', formatExpiryDateString(value));
                }}
                placeholder='xx/xx'
                onBlur={props.handleBlur('expDate')}
                testProperties={testProperties(
                  'payments-edit-method-pandate-id'
                )}
              />
            </FormContainer>
            <NickNameTitle>{copy.nickNameTitle}</NickNameTitle>
            <FormContainerNickName>
              <FormInput
                numberOfLines={1}
                logo={false}
                label={copy.cardNickname}
                keyboardType='default'
                returnKeyType='go'
                maxLength={45}
                value={props.values.alias}
                onChangeText={props.handleChange('alias')}
                onBlur={props.handleBlur('alias')}
                maxLength={15}
                testProperties={testProperties(
                  'payments-edit-method-pandate-id'
                )}
              />
            </FormContainerNickName>
            <RadioContainer
              onPress={() =>
                props.setFieldValue('isDefault', !props.values.isDefault)
              }
              {...testProperties('payments-edit-method-default-button-id')}
            >
              <RadioButton
                checked={props.values.isDefault}
                buttonType='checkbox'
              />
              <RadioText>{copy.default}</RadioText>
            </RadioContainer>
          </InnerContainer>
          <ErrorMessageContainer
            {...testProperties('edit-method-error-message-container')}
          >
            <ErrorMessage>{props.errors.name}</ErrorMessage>
            <ErrorMessage>{props.errors.pan}</ErrorMessage>
            <ErrorMessage>{props.errors.expDate}</ErrorMessage>
            <ErrorMessage>{props.errors.cvc}</ErrorMessage>
          </ErrorMessageContainer>
          <ButtonContainer>
            <Button
              secondary={true}
              onPress={() => {
                handleDelete();
              }}
              testProperties={testProperties(
                'payments-edit-method-remove-card-button-id'
              )}
            >
              {copy.RemoveCard}
            </Button>
            <Spacer />
            <Button
              primary={true}
              onPress={() => {
                props.handleSubmit();
              }}
              testProperties={testProperties(
                'payments-edit-method-handle-submit-button-id'
              )}
            >
              {copy.Update}
            </Button>
          </ButtonContainer>
        </Container>
      )}
    </Formik>
  );
};
export default EditMethod;
const Container = styled.View`
  flex: 1;
  margin-bottom: 10px;
`;
const InnerContainer = styled.ScrollView`
  margin-top: 40px;
  flex: 1;
`;
const RadioContainer = styled.TouchableOpacity`
  display: flex;
  flex-direction: row;
  margin-left: 20px;
  margin-bottom: 20px;
  align-items: center;
`;
const RadioText = styled.Text`
  margin-left: 20px;
  color: #36235e;
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
`;
const FormContainer = styled.View`
  margin: 0px 20px 20px 20px;
  background-color: #f5f5f7;
  padding: 15px;
  padding-bottom: 5px;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
`;
const FormContainerNickName = styled.View`
  margin: 0px 20px 20px 20px;
  background-color: #f5f5f7;
  padding: 15px;
  padding-bottom: 5px;
  border-radius: 4px;
`;
const NickNameTitle = styled.Text`
  margin-bottom: 20px;
  margin-left: 20px;
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  font-weight: bold;
  color: #0d1943;
`;
const ErrorMessageContainer = styled.View`
  justify-content: center;
  align-items: center;
  margin-bottom: 10px;
`;
const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  line-height: 22px;
  font-weight: normal;
`;
const ButtonContainer = styled.View`
  margin: 0 20px;
`;
const Spacer = styled.View`
  height: 10px;
`;

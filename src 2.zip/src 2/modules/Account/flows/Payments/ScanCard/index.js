import React from 'react';
import styled from 'styled-components/native';
import { Headline } from 'components/common/Typography/';
import TextLink from 'components/common/Link/TextLink';
import selectedCopy from '../../../../../i18n/copy';
import { testProperties } from '../../../../../helpers/testProperties';

const copy =
  selectedCopy.components.modules.Account.flows.Payments.ScanCard.index;

//TODO: dra in riktiga scan card component i containern

const ScanCard = ({ title, subtext }) => {
  return (
    <Container {...testProperties('payments-scan-card-start-container-id')}>
      <ScanCardContainer />
      <EnterManuallyTextContainer>
        <Title h4 {...testProperties('payments-scan-card-start-title-id')}>
          {title}
        </Title>
        <Subtext>{subtext}</Subtext>
        <TextLink
          linktext={copy.enterCardManually}
          textColor='#4F2C94'
          onPress={() => console.log('enter card manually on press')}
          {...testProperties('payments-scan-card-start-button-id')}
        />
      </EnterManuallyTextContainer>
    </Container>
  );
};

export default ScanCard;

const Container = styled.View`
  flex: 1;
`;

const ScanCardContainer = styled.View`
  background-color: lightgray;
  justify-content: center;
  align-items: center;
  flex: 1;
`;

const EnterManuallyTextContainer = styled.View`
  height: 210px;
  align-items: center;
`;

const Title = styled(Headline)`
  margin-top: 25px;
  margin-bottom: 11px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 20px;
  line-height: 24px;
  color: #0d1943;
`;

const Subtext = styled.Text`
  text-align: center;
  margin: 0px 45px 45px 45px;
  color: #0d1943;
  font-size: 16px;
  font-family: 'OpenSans-Regular';
  line-height: 22px;
`;

export const FAQParagraphs = [
  {
    key: '1',
    title: 'What is Skiply?',
    body:
      'Skiply is a convenient user friendly platform that allows user to pay the school fees without having to wait in the queue. Skiply provides fast shortcuts, snappy navigation and shows contents which are relevant to the user.'
  },
  {
    key: '2',
    title: 'How do I register myself?',
    body: `To register, you can download Skiply from the Google or Apple Store and click on “Sign Up”, then complete the registration process.`
  },
  {
    key: '3',
    title: 'I am unable to see my school on Skiply, How do I find it?',
    body:
      'If you are unable to see the school on Skiply, you may check with the school, as the app will only display schools that have registered with us.'
  },
  {
    key: '4',
    title: 'How do I find my school and add a student profile?',
    body: 'To create student profile you may follow the below steps:',
    withList: [
      {
        key: 1,
        bulletPoint: 'On the Home page of the app, click on “Add Student “ and'
      },
      {
        key: 2,
        bulletPoint: 'Input the school you are looking for'
      },
      {
        key: 3,
        bulletPoint: 'Select the school'
      },
      {
        key: 4,
        bulletPoint:
          'You can then search for the student either by inputting the student details or by adding the student profile manually'
      }
    ]
  },
  {
    key: '5',
    title: 'How can I find the student ID?',
    body:
      'For student ID, please contact the school and they will be able to help you with this information.'
  },
  {
    key: '6',
    title: 'How do I update my card details?',
    body: 'To update the card details, you may follow the below steps:',
    withList: [
      {
        key: 1,
        bulletPoint: 'Open Skiply'
      },
      {
        key: 2,
        bulletPoint: 'Click on the Profile tab'
      },
      {
        key: 3,
        bulletPoint: 'Tap on ‘Payment Method’'
      },
      {
        key: 4,
        bulletPoint: 'Select the card you wish to update'
      },
      {
        key: 5,
        bulletPoint: 'Enter the updated information'
      },
      {
        key: 6,
        bulletPoint: '‘Save’ your changes'
      }
    ]
  },
  {
    key: '7',
    title: 'I am unable to add my card to Skiply!',
    body:
      'Please note that Skiply accepts all Mastercard and Visa credit, debit and prepaid cards. Apart from the card number and expiry date, these cards will need to have a CVV code which is present on the reverse of the card. Please ensure that you have entered the card number correctly.'
  },
  {
    key: '8',
    title: 'Can I make purchases for multiple students in a single cart?',
    body:
      'Unfortunately, you will have to complete the purchase for 1 student at a time.'
  },
  {
    key: '9',
    title: 'Can both parents set up an account for the same student?',
    body:
      'Skiply provides both parents the ability to set up separate accounts for the same student.'
  },
  {
    key: '10',
    title: 'Why does my card keep getting declined at the time of purchase?',
    body:
      'For successful purchase on Skiply, your card should be active, has adequate balance and must be within the expiry period. In some cases, banks may block online transactions on your card, which can be resolved by calling your bank.'
  },
  {
    key: '11',
    title: 'Are payments secure with Skiply?',
    body:
      'Skiply is a service provided by RAKBANK. Rest assured that all payments are secure. No information will be stored on your device. Card information is securely saved on the Mastercard network.'
  },
  {
    key: '12',
    title: 'How can I keep track of my Skiply payments?',
    body:
      'You can view details of your Skiply e-receipts at any time on the Purchase Tab located on the home page of the app.'
  },
  {
    key: '13',
    title:
      'Can I use TouchID, FaceID or other biometric forms of login that my device allows?',
    body:
      'Skiply will allow biometric forms of login, if your device supports biometric features.'
  },
  {
    key: '14',
    title: 'The app is slow on my device. What do I do?',
    body:
      'Please ensure that you are connected to the internet via data or a wireless network. Also, ensure that you are using the latest version of the app. Additionally, your phone may also be running out of memory or disk space. Please ensure that you close running apps and re-launch Skiply.'
  },
  {
    key: '15',
    title:
      'The amount displayed on Skiply is different to what I believe is owed for payment?',
    body:
      'For any queries related to payment, you may contact the school directly for clarifications.'
  },
  {
    key: '16',
    title: 'How are Skiply refunds processed?',
    body:
      'For any refunds, please contact your school office directly to cancel the payment. The refund need to be processed through the school office according to the school policy.'
  },
  {
    key: '17',
    title: 'If I have any questions about Skiply, whom do I contact?',
    body:
      'Please contact the school for any additional queries about Skiply, you could also email us at contactus@skiply.ae.'
  },
  {
    key: '18',
    title: 'Can an existing QKR user login on Skiply?',
    body:
      'Yes QKR users can use their existing QKR credentials to login into Skiply.'
  },
  {
    key: '19',
    title:
      ' I have made the payment towards the school using Skiply, but the payment is not reflecting in the school?',
    body:
      'You may raise your concerns with your school admin office directly to resolve the issue.'
  }
];

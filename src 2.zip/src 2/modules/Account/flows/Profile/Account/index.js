import React, { useState, useEffect, useLayoutEffect } from 'react';
import { AsyncStorage, Alert, Animated, Linking } from 'react-native';
import { Headline } from 'components/common/Typography/';
import styled, { css } from 'styled-components';
import IconAndTextListItem from 'components/common/ListItem/IconAndTextListItem';
import { ThinLine } from 'components/common/Dividers/Dividers';
import Button from 'components/common/Button/Button';
import CollapsibleHeader from 'components/common/Header/CollapsibleHeader';
import { Navigation } from 'react-native-navigation';
import { navigateTo, options } from 'navigation';
import { useActions, useStore, useStoreState } from 'easy-peasy';
import ProfileHeader from '../../../../../components/common/Header/ProfileHeader.js';
import MySkiplyPoints from 'src/../modules/Promotion/MySkiplyPoints';
import PromotionAccountButton from 'src/../modules/Promotion/PromotionAccountButton';
import { root, loginRoot } from './../../../../../../src/navigation/root';
import ApplyForSPBox from '../../../../Promotion/components/ApplyForSPBox'; //don't remove
import PromotionCard from '../../../../Promotion/components/PromotionCard';
import { testProperties } from '../../../../../helpers/testProperties';
import FloatingCart from '../../../../Discover/School/flows/Store/ShoppingCart/components/FloatingCart';
import BiometricManager from '../../../../../biometric/BiometricManager';
import TouchID from 'react-native-touch-id';

const touchid = require('src/../../assets/icons/common/touchid.png');
const payment = require('src/../../assets/icons/common/payment.png');
const notice = require('src/../../assets/icons/common/notis.png');

const Account = (props) => {
  const fetchCards = useActions((actions) => actions.cards.fetchCards);
  const clearCart = useActions((actions) => actions.cart.clearCart);
  const setDidShowAutoDetectedStudents = useActions(
    (actions) => actions.student.setDidShowAutoDetectedStudents
  );

  useEffect(() => {
    fetchCards();
  }, []);

  const profile = useStore((state) => state.profile.data);
  const logout = useActions((actions) => actions.session.logout);
  const userName = profile
    ? profile.firstName
      ? profile.firstName + ' ' + (profile.lastName || '')
      : null
    : null;

  const navigateToAddNewMethod = () => {
    navigateTo('Skiply.Account.Payments.Methods', props.componentId);
  };

  // TODO: unused, to be used or remove?
  // const navigateToMyPointsSkiply = () => {
  //   Navigation.push(props.componentId, {
  //     component: {
  //       name: 'Skiply.Promotion.MySkiplyPoints',
  //       options: {
  //         topBar: {
  //           title: {
  //             text: 'Skiply Points PlaceholderBar'
  //           }
  //         }
  //       },
  //       passProps: {
  //         noRAKCard: false,
  //         appliedForCardInfo: false,
  //         hasPoints: true,
  //         showAddBtn: false
  //       }
  //     }
  //   });
  // };

  const logoutAndNavigateToLanding = () => {
    Alert.alert('Confirm', 'Please confirm, you want to logout.', [
      {
        text: 'Yes',
        onPress: async () => {
          clearCart();
          BiometricManager.removeBiometricLogin();
          logout();
          setDidShowAutoDetectedStudents(false);
          await Navigation.setRoot({ root: loginRoot });
        }
      },
      { text: 'No', onPress: () => {} }
    ]);
  };

  const navigateToShowProfile = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'Skiply.Account.Profile.Profile.ProfileInfoList',
        options: {
          topBar: {
            title: {
              text: 'My Profile'
            }
          }
        }
      }
    });
  };

  function checkBiometricsSupport() {
    TouchID.isSupported()
      .then((biometryType) => {
        // Success code
        console.log('BiometryType: ', biometryType);
        if (biometryType == 'FaceID') {
          setBiometryType('FaceID');
        } else if (biometryType == 'TouchID') {
          setBiometryType('TouchID');
        }
        setSupportsBiometrics(true);
      })
      .catch((error) => {
        // Failure code
        console.log(error);
      });
  }

  const [supportsBiometrics, setSupportsBiometrics] = useState(false);
  const [biometryType, setBiometryType] = useState('Biometrics');

  useLayoutEffect(function() {
    checkBiometricsSupport();
  });

  return (
    <CollapsibleHeader
      shouldScale={false}
      hasTitleBar={false}
      extendedHeight={134}
      collapsedHeight={0}
      positionFromBottom={40}
      isCurved={true}
      bigContent={
        <ProfileHeader
          onPress={navigateToShowProfile}
          name={userName}
          //{...testProperties('profile-account-onpress-id')}
          image={profile && profile.profilePhotoUrl}
        />
      }
    >
      <Container as={Animated.ScrollView}>
        {/* <Container {...testProperties('profile-account-start-container-id')}> */}
        {/* <ApplyForSPBox componentId={props.componentId} /> */}
        <PromotionCard componentId={props.componentId} />
        <HeaderMargin>
          <Title {...testProperties('profile-account-settings-title-id')}>
            Settings
          </Title>
        </HeaderMargin>
        <IconAndTextListItem
          icon={payment}
          //isButton={true}
          onPress={() => navigateToAddNewMethod()}
          listItemText='Payment methods'
          iconWidth='28px'
          // {...testProperties('profile-account-new-method-button-id')}
          // buttonOnPress={() =>
          //   navigateTo('Skiply.Account.Payments.AddMethod', props.componentId)
          // }
        />

        {/* Only show Touch ID if supported on device! */}
        {supportsBiometrics && (
          <IconAndTextListItem
            icon={touchid}
            onPress={async () =>
              navigateTo(
                'Skiply.Account.About.TouchId',
                props.componentId,
                {
                  isEnabled:
                    (await AsyncStorage.getItem('bio_login_require')) ===
                    'true',
                  biometryType
                },
                {
                  topBar: options.topBarWithTitle(biometryType)
                }
              )
            }
            listItemText={biometryType}
          />
        )}
        {/* <IconAndTextListItem
          icon={notice}
          onPress={() =>
            navigateTo('Skiply.Account.About.Notifications', props.componentId)
          }
          listItemText='Notifications'
        /> */}
        <Margin />
        <ThinLine />
        <Margin />
        <HeaderMargin>
          <Title {...testProperties('profile-account-about-title-id')}>
            About
          </Title>
        </HeaderMargin>
        <IconAndTextListItem
          listItemText='FAQ'
          onPress={() =>
            navigateTo('Skiply.Account.About.WhatsNew', props.componentId)
          }
          {...testProperties('profile-account-whats-new-list-item-id')}
        />
        <IconAndTextListItem
          listItemText='Contact us'
          onPress={() =>
            navigateTo('Skiply.Account.About.Contact', props.componentId)
          }
          {...testProperties('profile-account-contact-us-list-item-id')}
        />
        <IconAndTextListItem
          listItemText='Privacy policy'
          // onPress={() =>
          //   Linking.openURL(
          //     'https://rakbank.ae/wps/portal/footer/privacy-policy'
          //   )
          // }
          onPress={() =>
            navigateTo('Skiply.Account.About.Policy', props.componentId)
          }
          {...testProperties('profile-account-private-policy-list-item-id')}
        />
        <IconAndTextListItem
          listItemText='Terms &amp; conditions'
          onPress={() =>
            navigateTo('Skiply.Account.About.Terms', props.componentId)
          }
          {...testProperties('profile-account-terms-and-con-list-item-id')}
        />
        <Margin />
        <ThinLine />
        <Margin />
        <Margin />
        <ButtonContainer>
          <Button
            onPress={() => {
              logoutAndNavigateToLanding();
            }}
            secondary
            testProperties={testProperties('profile-account-logout-button-id')}
          >
            Sign Out
          </Button>
        </ButtonContainer>
        <Margin />
        <Margin />
      </Container>
    </CollapsibleHeader>
  );
};

export default Account;
// const Title = styled.Text`
//   color: blue;
//   padding: 50px;
//   font-size: 40px;
// `;

const Container = styled.ScrollView``;

const PromotionContainer = styled.View`
  align-items: center;
`;

const Title = styled(Headline)`
  color: rgb(13, 25, 67);
  font-family: OpenSans-Bold;
  font-size: 18px;
  margin-left: 20px;
`;
const Margin = styled.View`
  margin-bottom: 20px;
`;
const HeaderMargin = styled.View`
  margin-bottom: 10px;
`;

const ButtonContainer = styled.View`
  margin: 0 20px;
`;

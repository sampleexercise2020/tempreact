import React from 'react';
import LocalStorage from './LocalStorage';
import { promisify } from 'util';
import Promotion from '../models/promotion';
import { API_URL, API_KEY } from '../config';

var forge = require('node-forge'); // Load node-forge dependency

class HybridCrypto {
  static HOST = API_URL;

  /**
   * Create or retrieve symmetric key for session.
   * @param {*} success
   * Returns symmetric key in success callback.
   * @param {*} failure
   * Return error message in failure callback.
   */
  static getSymmetricKey(success, failure) {
    // For testing purpose if it creates a new key after removing all keys
    LocalStorage.getInstance().removeCryptoKeys();

    LocalStorage.getInstance().getSymmetricKey(
      (key) => {
        if (key === null || key === undefined || key === '') {
          // if symmetric key not found then create one and save it in local storage
          var symKeyBytes = forge.random.getBytesSync(16);
          var symKey = forge.util.encode64(symKeyBytes);
          LocalStorage.getInstance().setSymmetricKey(
            symKey,
            () => {
              success(symKey);
            },
            (error) => {
              failure('Unable to set symmetric key. ' + error);
            }
          );
        } else {
          success(key);
        }
      },
      (error) => {
        failure('Unable to get symmetric key. ' + error);
      }
    );
  }

  /**
   * It encrypts payload with symmetric key in AES-ECB.
   * @param {*} payload
   * Payload which needs to be ecrypted.
   * @param {*} key
   * Symmetric key
   */
  static encryptPayload(payload, key) {
    var cipher = forge.cipher.createCipher('AES-ECB', key);
    cipher.start();
    cipher.update(forge.util.createBuffer(forge.util.encodeUtf8(payload)));
    cipher.finish();
    var encrypted = forge.util.encode64(cipher.output.data);
    return encrypted;
  }

  /**
   * It encrypts the random key in RSA with public key.
   * @param {*} pem
   * Public key in pem format provided by server.
   * @param {*} symKey
   * Symmetric key which needs to be ecrypted.
   */
  static encryptSymmetricKey(pem, symKey) {
    var pki = forge.pki;
    var publicKey = pki.publicKeyFromPem(pem);
    var encryptedSymKey = publicKey.encrypt(forge.util.encodeUtf8(symKey));
    var encryptedSymKey64 = forge.util.encode64(encryptedSymKey);
    return encryptedSymKey64;
  }

  /**
   * Encrypts payload using Hybrid Encryption.
   * @param {*} payload
   * Payload in string format which needs to encrypted using Hybrid Crypto.
   * @param {*} success
   * Callback returns encrypted payload and encrypted symmetric key.
   * @param {*} failure
   * Callback returns error message.
   */
  static encrypt(payload) {
    const promise = new Promise((resolve, reject) => {
      HybridCrypto.getSymmetricKey(
        (symKey) => {
          HybridCrypto.getPublicKey(
            (pubKey) => {
              let encryptedPayload = HybridCrypto.encryptPayload(
                payload,
                symKey
              );
              let encryptedSymKey = HybridCrypto.encryptSymmetricKey(
                pubKey,
                symKey
              );
              resolve({
                encryptedPayload: encryptedPayload,
                encryptedSymKey: encryptedSymKey
              });
              // success(ecryptedPayload, ecryptedSymKey);
            },
            (error) => {
              // failure(error);
              reject(error);
            }
          );
        },
        (error) => {
          // failure(error);
          reject(error);
        }
      );
    });
    return promise;
  }

  /**
   * Downloads/Retrieve public key shared by server for Symmetric key encryption.
   * @param {*} success
   * Callback return public key shared by server.
   * @param {*} failure
   * Callback return error message.
   */
  static getPublicKey(success, failure) {
    LocalStorage.getInstance().getPublicKey(
      (key) => {
        if (key === null || key === undefined || key === '') {
          // if public key not found then download it from server and save it
          HybridCrypto.downloadPublicKey(
            (pubKey) => {
              LocalStorage.getInstance().setPublicKey(
                pubKey,
                () => {
                  success(pubKey);
                },
                (error) => {
                  failure('Unable to get public key. ' + error);
                }
              );
            },
            (error) => {
              failure(error);
            }
          );
        } else {
          success(key);
        }
      },
      (error) => {
        failure('Unable to get public key. ' + error);
      }
    );
  }

  /**
   * Downloads public key from server.
   * @param {*} success
   * Callback returns public key.
   * @param {*} failure
   * Callback returns error message.
   */
  static downloadPublicKey(success, failure) {
    fetch(HybridCrypto.HOST + 'skiply-auth/publickey', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        apikey: API_KEY
      }
    })
      .then((response) => response.json())
      .then((responseJson) => {
        let publicKey = responseJson.body;
        success(publicKey);
      })
      .catch((error) => {
        failure('Unable to download public key. ' + error);
      });
  }

  /**
   * Decrypts payload using Hybrid Encryption.
   * @param {*} payload
   * Payload needs to decrypted.
   * @param {*} success
   * Callback returns decrypted message in string format.
   * @param {*} failure
   * Callback returns error message.
   */
  static decrypt(payload) {
    const promise = new Promise((resolve, reject) => {
      LocalStorage.getInstance().getSymmetricKey(
        (key) => {
          var cipher = forge.cipher.createDecipher('AES-ECB', key);
          cipher.start();
          cipher.update(forge.util.createBuffer(forge.util.decode64(payload)));
          cipher.finish();
          resolve(cipher.output);
        },
        (error) => {
          // failure(error);
          reject(error);
        }
      );
    });
    return promise;
  }
}

export default HybridCrypto;

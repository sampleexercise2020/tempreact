import { action, thunk } from 'easy-peasy';
import axios from 'axios';
import { API_URL, API_URL_PROMOTIONS, API_KEY } from 'config';
import amendResponseObject from 'helpers/amendResponseObject';

const Promotion = {
  isLoading: false,
  errorMessage: '',
  offers: [],
  offer: {},

  // actions
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),
  setSingleOffer: action((state, payload) => {
    state.offer = payload;
  }),

  // thunks
  postCardApplication: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = `${API_URL}skiply-wallet/wallet/cards/cardleadinfo`;

    console.log('PROMOTION PAYLOAD:', payload);

    const response = await axios({
      method: 'post',
      url: endpoint,
      data: {
        ...payload
      },
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Post card application success response:', response);
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Post card application error response:', response);
        return response;
      });

    return response;
  }),
  getOffers: thunk(async (actions, payload) => {
    const endpoint = `${API_URL_PROMOTIONS}getDeals`;

    console.log('Offers payload: ', payload);

    const response = await axios({
      method: 'get',
      url: endpoint,
      params: payload
    })
      //.then(amendResponseObject)
      .then((response) => {
        console.log('Got all offers');
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Error getting all offers:', error);
        return response;
      });

    return response;
  }),
  getOffersCategories: thunk(async (actions, payload) => {
    const params = {
      bankId: 'RAK',
      channelId: 'MB',
      mode: 'HTML',
      pageContext: 'Offers',
      userSegment: 'CATEGORIES'
    };

    const endpoint = `${API_URL_PROMOTIONS}getDeals`;

    const response = await axios({
      method: 'get',
      url: endpoint,
      params
    })
      .then((response) => {
        console.log('Got all offer categories');
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Error getting all offers:', error);
        return response;
      });

    return response;
  }),
  getSingleOffer: thunk(async (actions, payload) => {
    actions.setIsLoading(true);

    const endpoint = `${API_URL_PROMOTIONS}getDeals`;

    const response = await axios({
      method: 'get',
      url: endpoint,
      params: payload
    })
      //.then(amendResponseObject)
      .then((response) => {
        response = response.data.contentListMap.OFFERS.DetailedOffers[0];
        console.log('Got one offer!');
        actions.setSingleOffer(response);
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.error('Error when getting single offer', error);
        return response;
      });
    actions.setIsLoading(false);
    return response;
  })
};

export default Promotion;

import { action, thunk, useActions } from 'easy-peasy';
import axios from 'axios';
import { API_URL, API_KEY } from 'config';
import amendResponseObject from 'helpers/amendResponseObject';
import SecureAPI from '../crypto/SecureAPI';

const Profile = {
  data: '',
  isLoading: false,
  errorMessage: '',

  // actions
  fetched: action((state, payload) => {
    state.data = payload;
  }),
  resetProfileImage: action((state, payload) => {
    state.data.profilePhotoUrl = '';
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),

  // thunks
  fetch: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-userprofile/profile';

    actions.setIsLoading(true);

    const response = await axios({
      method: 'get',
      url: endpoint,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Get profile success response');
        if (response.data.profilePhotoUrl) {
          response.data.profilePhotoUrl =
            response.data.profilePhotoUrl +
            `?query=${Math.floor(Math.random() * 10000) + 1}`;
        }
        actions.fetched(response.data);
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Get profile error response:', response);
        return response;
      });

    actions.setIsLoading(false);

    return response;
  }),
  update: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-userprofile/profile';

    const headers = {
      'Content-Type': 'application/json',
      'X-Auth-Token': getStoreState().session.token,
      Authorization: getStoreState().session.authorization,
      apikey: API_KEY
    };
    let api = new SecureAPI();

    const response = await api
      .request(endpoint, 'PUT', headers, payload)
      .then(async (response) => {
        console.log('Update profile success response');
        return {
          success: true,
          data: response.body
        };
      })
      .catch((error) => {
        console.log('Error:', error);

        if (error.code !== 'Y') {
          return {
            success: false,
            message: error.internalMessage,
            errorCode: error.errorCode
          };
        } else {
          return {
            success: false,
            message: error
          };
        }
      });

    await actions.fetch();

    return response;
  }),
  updatePassword: thunk(async (actions, payload, { getStoreState }) => {
    actions.setIsLoading(true);

    var endpoint = null;
    var headers = null;

    // if changing password using forgot password options
    if (payload.oldPassword === undefined) {
      // if qkr user then updatePassword
      if (!payload.existingQkrUser) {
        endpoint = API_URL + 'skiply-userprofile/updatepasswordcustom';
        headers = {
          'Content-Type': 'application/json',
          Authorization: getStoreState().session.authorization,
          apikey: API_KEY
        };
        console.log('Update Password Custom: ', headers);
      }
      // if existing qkr user
      else {
        endpoint = API_URL + 'skiply-auth/updatePassword';
        headers = {
          'Content-Type': 'application/json',
          apikey: API_KEY
        };
      }
    } else {
      endpoint = API_URL + 'skiply-userprofile/changePassword';
      headers = {
        'Content-Type': 'application/json',
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      };
    }

    let api = new SecureAPI();

    console.log('Change password payload:', payload);
    const response = await api
      .request(endpoint, 'POST', headers, payload)
      .then(async (response) => {
        console.log('Update password success response');
        return {
          success: true,
          data: response.body
        };
      })
      .catch((error) => {
        console.log('Error:', error);

        if (error.code !== 'Y') {
          return {
            success: false,
            message: error.internalMessage,
            errorCode: error.errorCode
          };
        } else {
          return {
            success: false,
            message: error
          };
        }
      });

    actions.setIsLoading(false);
    return response;
  }),
  uploadProfilePicture: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-userprofile/uploadprofileimage';

    actions.setIsLoading(true);

    const data = await axios({
      method: 'post',
      data: payload,
      url: endpoint,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        'Content-Type': 'multipart/form-data',
        apikey: API_KEY
      }
    })
      .then((response) => {
        console.log('Upload Photo Success');
        return response;
      })
      .catch((error) => {
        console.log('Upload Photo FAIL: ', error.response);
        actions.setErrorMessage(error.response.data);
        return error.response;
      });

    actions.setIsLoading(false);
    actions.resetProfileImage();
    actions.fetch();
    return data;
  }),
  deleteBeneficiary: thunk(
    async (actions, payload, { getStoreState, dispatch }) => {
      const endpoint = API_URL + 'skiply-userprofile/beneficiaryFromUser';

      actions.setIsLoading(true);

      const response = await axios({
        method: 'delete',
        params: payload,
        url: endpoint,
        headers: {
          'X-Auth-Token': getStoreState().session.token,
          Authorization: getStoreState().session.authorization,
          apikey: API_KEY
        }
      })
        .then(amendResponseObject)
        .then((response) => {
          console.log('Delete Student Success');
          return response;
        })
        .catch((error) => {
          const response = amendResponseObject(error.response);
          console.log('Delete Student FAIL: ', response);
          actions.setErrorMessage(response.message);

          return response;
        });

      await dispatch.student.fetchStudentProfiles();

      actions.setIsLoading(false);

      return response;
    }
  ),
  deleteUser: thunk(async (actions, payload, { getStoreState, dispatch }) => {
    const endpoint = API_URL + 'skiply-userprofile/profile';

    actions.setIsLoading(true);

    const data = await axios({
      method: 'delete',
      // params: payload,
      url: endpoint,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then((response) => {
        console.log('Delete User Success');
        return response;
      })
      .catch((error) => {
        console.log('Delete User FAIL: ', error.response);
        actions.setErrorMessage(error.response.data);
        return error.response;
      });
    actions.setIsLoading(false);
    return data;
  })
};

export default Profile;

/* Sample data for update user
{
"lastName": "martin",
   "firstName": "tester",
   "emailAddress": "tester02@wipro.com",
   "phoneNumber": "6163285648",
   "taxNumber": "1234",
   "countryOfResidence": "AE",
   "phoneNumberCountryCode": "1",
   "requestZipInAddCard": "DONT_SHOW",
   "masterPassMarketingConsent": false,
   "automaticEmailReceipts": false,
   "masterPassUser": false,
   "requestCvcInAddCard": false,
   "marketingConsent": false,
"id":"528395"
}

*/

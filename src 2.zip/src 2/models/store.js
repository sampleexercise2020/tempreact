import { action, thunk } from 'easy-peasy';
import axios from 'axios';
import { API_URL, API_KEY } from 'components/../config';

const Store = {
  data: [],
  isLoading: false,
  errorMessage: '',

  // actions
  fetched: action((state, payload) => {
    state.data = payload;
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),

  // thunks
  fetchStore: thunk(async (actions, payload) => {
    const endpoint = API_URL + 'skiply-schprod/schools/' + payload;
    actions.setIsLoading(true);

    let headers = {
      'Content-Type': 'application/json',
      apikey: API_KEY
    };
    const store = await axios({
      method: 'get',
      url: endpoint,
      headers: headers
    })
      .then((response) => {
        return response.data.body;
      })
      .catch((error) => actions.setErrorMessage(error.message));
    actions.setIsLoading(false);
    actions.fetched(store);
  })
};

export default Store;

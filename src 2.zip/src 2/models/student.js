import { action, thunk, select } from 'easy-peasy';
import axios from 'axios';
import R from 'ramda';
import { API_URL, API_KEY } from 'components/../config';
import amendResponseObject from 'helpers/amendResponseObject';
import firebase from 'react-native-firebase';

const Student = {
  // firstName: 'Sarah',
  // middleName: 'K',
  // lastName: 'Andersson',
  // gender: 'F',
  // grade: 'Kindergarden',
  // class: '3A',
  // age: '6',
  beneficiaryId: '',
  // schoolName: 'Skiply School of Excellence',
  // schoolAddress: 'Silicon Oasis, Dubai, UAE',
  // image:
  //   'https://testmssbucket.s3-eu-west-1.amazonaws.com/SkiplySchoolofExcellence/56ad1935-bbc8-4741-aafd-8c76a201d776.png',
  lists: {
    // Lists of students
    results: [],
    saved: []
  },
  didShowAutoDetectedStudents: false,
  isLoading: '',
  errorMessage: '',
  current: {},

  // actions
  fetched: action((state, payload) => {
    state.firstName = payload.name;
    state.lastName = payload.name;
    state.middleName = payload.name;
    state.grade = payload.grade;
    state.class = payload.class;
    state.age = payload.age;
  }),
  updateBeneficiary: action((state, payload) => {
    state.beneficiaryId = payload;
  }),
  resetProfileImage: action((state, payload) => {
    const index = state.lists.saved.findIndex(
      (student) => student.mcBeneficiaryId == state.beneficiaryId
    );
    state.lists.saved[index].profilePhotoUrl = '';
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),
  setDidShowAutoDetectedStudents: action((state, payload) => {
    state.didShowAutoDetectedStudents = payload;
  }),
  resetStudentProfiles: action((state, payload) => {
    state.lists = {
      // Lists of students
      results: [],
      saved: []
    };
  }),
  setStudentProfiles: action((state, { type, value }) => {
    if (type == 'results') {
      const students = value.map((student) => {
        const alreadySavedStudent = state.lists.saved.find((savedStudent) => {
          const isMatchingFirstName =
            savedStudent.firstName == student.firstName;
          const isMatchingLastName = savedStudent.lastName == student.lastName;
          const isMatchingGender = savedStudent.gender == student.gender;
          const isMatchingStudent =
            isMatchingFirstName && isMatchingLastName && isMatchingGender;

          return isMatchingStudent;
        });

        if (alreadySavedStudent) {
          return {
            ...alreadySavedStudent,
            isManuallyAdded: student.isManuallyAdded
          };
        } else {
          return student;
        }
      });

      state.lists.results = students;
    } else {
      state.lists[type] = value;
    }
  }),
  resetProfileImage: action((state, payload) => {
    state.lists.saved = state.lists.saved.map((student) => {
      if (student.id == payload) {
        return {
          ...student,
          image: ''
        };
      } else {
        return student;
      }
    });
  }),

  appendManualStudent: action((state, payload) => {
    const updatedResults = R.append(payload, state.lists.results);
    const isDuplicateStudent = ({ firstName, lastName, gender }) => {
      const isMatchingFirstName = firstName == payload.firstName;
      const isMatchingLastName = lastName == payload.lastName;
      const isMatchingGender = gender == payload.gender;
      const isDuplicate =
        isMatchingFirstName && isMatchingLastName && isMatchingGender;

      return isDuplicate;
    };

    state.lists.results = R.uniqBy(isDuplicateStudent, updatedResults);
  }),

  resetStudentResults: action((state, _payload) => {
    state.lists.results = [];
  }),

  resetNonManuallyAddedStudentResults: action((state, _payload) => {
    state.lists.results = state.lists.results.filter(
      (student) => student.isManuallyAdded
    );
  }),

  setCurrent: action((state, payload) => {
    state.current = payload;
  }),
  // Thunks
  save: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-studregister/studentregistration';
    const state = getStoreState();

    actions.setIsLoading(true);

    const response = await axios({
      method: 'post',
      url: endpoint,
      headers: {
        'X-Auth-Token': state.session.token,
        Authorization: state.session.authorization,
        apikey: API_KEY
      },
      data: R.dissoc('index', payload)
    })
      .then(async (axiosResponse) => {
        const response = amendResponseObject(axiosResponse);
        actions.updateBeneficiary(response.data.beneficiaryId);
        await actions.fetchStudentProfiles();

        if (!payload.otpRequired) {
          const payloadWithId = {
            ...payload,
            id: response.data.beneficiaryId
          };
          const amendedStudentResults = R.update(
            payload.index,
            payloadWithId,
            state.student.lists.results
          );

          actions.setStudentProfiles({
            type: 'results',
            value: amendedStudentResults
          });
        }

        firebase.analytics().logEvent('student_sign_up');

        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Save beneficiary error response:', response);
        actions.setErrorMessage(response.message);

        return response;
      });

    actions.setIsLoading(false);

    return response;
  }),
  uploadProfilePicture: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-studregister/studentprofileimage';
    actions.setIsLoading(true);

    const studentId = payload
      .getParts()
      .find(({ fieldName }) => fieldName == 'studentId').string;

    const data = await axios({
      method: 'post',
      data: payload,
      url: endpoint,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        'Content-Type': 'multipart/form-data',
        apikey: API_KEY
      }
    })
      .then((response) => {
        return response;
      })
      .catch((error) => {
        console.log('Upload Student Photo FAIL: ', error.response);
        actions.setErrorMessage(error.response.data);
        return error.response;
      });

    actions.resetProfileImage(studentId);
    actions.fetchStudentProfiles();
    actions.setIsLoading(false);

    return data;
  }),
  fetchStudentProfiles: thunk(
    async (actions, _payload, { getStoreState, dispatch }) => {
      actions.setIsLoading(true);
      try {
        // await dispatch.profile.fetch();
        // const profile = getStoreState().profile.data;

        const endpoint = API_URL + 'skiply-studregister/studentprofiles';
        const state = getStoreState();

        await axios({
          method: 'get',
          url: endpoint,
          headers: {
            'X-Auth-Token': state.session.token,
            Authorization: state.session.authorization,
            apikey: API_KEY
          }
        })
          .then((response) => {
            console.log('Student profiles success response');
            actions.setStudentProfiles({
              value: response.data.body,
              type: 'saved'
            });
          })
          .catch((error) => {
            console.log('Student profiles error response:', error.response);

            if (error.response.data.status.errorCode == 'NO_BENEFICIARIES') {
              actions.resetStudentProfiles();
            }
          });

        actions.setIsLoading(false);
      } catch (error) {
        console.log('Error:', error);
        actions.setErrorMessage('Please try again later');
      }
    }
  ),
  fetchAutodetectedStudentsByEmail: thunk(
    async (actions, payload, { getStoreState, dispatch }) => {
      actions.setIsLoading(true);

      const profile = getStoreState().profile.data;
      const endpoint = API_URL + 'skiply-studsearch/students/searchstudent';

      const state = getStoreState();

      const autoDetectedStudents = await axios({
        method: 'post',
        url: endpoint,
        data: {
          autoDetect: true,
          emailID1: profile.emailAddress,
          phoneNumber: `${profile.phoneNumberCountryCode}${profile.phoneNumber}`
        },
        headers: {
          'X-Auth-Token': state.session.token,
          Authorization: state.session.authorization,
          apikey: API_KEY
        }
      })
        .then((response) => {
          console.log('Autodetected student profiles sucess');
          actions.setStudentProfiles({
            value: response.data.body,
            type: 'results'
          });

          const autoDetectedStudents = getStoreState().student.lists.results;

          return response.data.body;
        })
        .catch((error) => {
          console.log(
            'Autodetected student profiles error response:',
            error.response
          );
        });

      actions.setIsLoading(false);

      return autoDetectedStudents;
    }
  ),
  searchStudents: thunk(
    async (actions, payload, { getStoreState, dispatch }) => {
      const endpoint = API_URL + 'skiply-studsearch/students/searchstudent';
      const state = getStoreState();

      actions.setIsLoading(true);

      const response = await axios({
        method: 'post',
        url: endpoint,
        data: payload,
        headers: {
          'X-Auth-Token': state.session.token,
          Authorization: state.session.authorization,
          apikey: API_KEY
        }
      })
        .then(amendResponseObject)
        .then((response) => {
          const students = response.data;

          console.log('Search Student succes');
          actions.setStudentProfiles({
            value: students,
            type: 'results'
          });

          return response;
        })
        .catch((error) => {
          const response = amendResponseObject(error.response);
          console.log('Search Student error response:', response);

          return response;
        });

      actions.setIsLoading(false);

      return response;
    }
  ),
  updateProfile: thunk(
    async (actions, payload, { getStoreState, dispatch }) => {
      const endpoint = API_URL + 'skiply-studregister/studentregistration';
      const state = getStoreState();

      actions.setIsLoading(true);

      const response = await axios({
        method: 'put',
        data: payload,
        url: endpoint,
        headers: {
          'X-Auth-Token': state.session.token,
          Authorization: state.session.authorization,
          apikey: API_KEY
        }
      })
        .then((response) => {
          console.log('UPDATING PROFILE SUCCESS');

          const savedStudents = getStoreState().student.lists.saved.map(
            (student) => {
              if (student.id === response.data.body.id) {
                return response.data.body;
              } else {
                return student;
              }
            }
          );
          actions.setStudentProfiles({
            value: savedStudents,
            type: 'saved'
          });
          actions.setIsLoading(false);
          return response;
        })
        .catch((error) => {
          console.log('UPDATING PROFILE FAILURE: ', error.response);
          actions.setIsLoading(false);
          try {
            actions.setErrorMessage(error.response.message);
          } catch (error) {
            actions.setErrorMessage('Failed to update student');
          }
          throw error.response;
        });
      return response;
    }
  ),
  verifyOtp: thunk(async (actions, payload, { getStoreState }) => {
    const state = getStoreState();
    const endpoint =
      API_URL + 'skiply-studregister/verifyotpstudentregistration';

    actions.setIsLoading(true);

    console.log('PAYLOAD:', R.dissoc('index', payload));

    const response = await axios({
      method: 'post',
      data: R.dissoc('index', payload),
      url: endpoint,
      headers: {
        'X-Auth-Token': state.session.token,
        Authorization: state.session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        function setStudentId(student) {
          return {
            ...student,
            id: payload.beneficiaryId
          };
        }

        const amendedStudentResults = R.adjust(
          payload.index,
          setStudentId,
          state.student.lists.results
        );

        actions.setStudentProfiles({
          type: 'results',
          value: amendedStudentResults
        });

        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Verify OTP error:', error.response);
        return response;
      });

    await actions.fetchStudentProfiles();

    actions.setIsLoading(false);

    return response;
  })
};

export default Student;

import { action, thunk, select } from 'easy-peasy';
import axios from 'axios';
import { API_URL, API_KEY } from 'components/../config';

const Products = {
  data: [],
  category: '',
  locatedScanId: null,
  list: [],
  title: '',
  isLoading: false,
  errorMessage: '',
  currentProduct: '',

  // actions
  fetched: action((state, payload) => {
    state.data = payload;
    state.list = payload.products;
    state.title = payload.title;
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),
  setCategory: action((state, payload) => {
    state.category = payload.category;
    state.title = payload.title;
    state.locatedScanId = payload.locatedScanId;
  }),

  // thunks
  fetch: thunk(async (actions, payload, { getStoreState }) => {
    let endpoint = '';
    // const endpoint =
    //   API_URL +
    //   `skiply-schprod/products/bygradeorstudid?menuId=${
    //     payload.menuId
    //   }&gradeText=${payload.gradeText}`;
    actions.setIsLoading(true);

    console.log('Payload Params: ', payload);

    let params = {};

    if (payload.menuId) {
      endpoint = API_URL + 'skiply-schprod/products/bygradeorstudid';
      params = {
        menuId: payload.menuId,
        gradeText: payload.gradeText
      };
      console.log('URL: ', endpoint);
      console.log('Params: ', params);
    } else {
      endpoint = API_URL + 'skiply-schprod/products/' + payload;
      params = null;
      console.log('URL: ', endpoint);
    }

    let options = {
      method: 'get',
      url: endpoint,
      params: params,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    };

    const products = await axios(options)
      .then((response) => {
        console.log('Products success response: ', response);
        let productGroup = response.data.body;
        if (productGroup.products) {
          productGroup = response.data.body.products;
        }
        const products = productGroup.map((product) => ({
          ...product,
          variants: product.variants.map((variant) => ({
            ...variant,
            isSelected: variant.isDefault
          })),
          optionSets: product.optionSets.map((optionSet) => ({
            ...optionSet,
            options: optionSet.options.map((option) => ({
              ...option,
              isSelected: option.selectedByDefault
            }))
          }))
        }));

        return {
          ...productGroup,
          products
        };
      })
      .catch((error) => {
        console.error('Error when fetching products: ', error);
        actions.setErrorMessage(error.message);
      });

    actions.setIsLoading(false);
    actions.fetched(products);
  })
};

export default Products;

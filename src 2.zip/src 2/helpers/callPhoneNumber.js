import { Linking, Alert, Platform } from 'react-native';

export const callPhoneNumber = (phone) => {
  const phoneTrimmed = phone.replace(/\s/g, '');

  console.log('callNumber ----> ', phoneTrimmed);
  let phoneNumber = '';
  if (Platform.OS !== 'android') {
    phoneNumber = `telprompt:${phoneTrimmed}`;
  } else {
    phoneNumber = `tel:${phoneTrimmed}`;
  }
  Linking.canOpenURL(phoneNumber)
    .then((supported) => {
      console.log(supported);
      if (!supported) {
        Alert.alert('Calling is not supported on this device.');
      } else {
        return Linking.openURL(phoneNumber);
      }
    })
    .catch((err) => console.log(err));
};

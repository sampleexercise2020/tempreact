import React, { useEffect } from 'react';
import { Button, Text, View } from 'react-native';
import styled from 'styled-components/native';
import { useFloatingSlideUp } from 'components/FloatingSlideUp';
import { useFloatingBottom } from 'components/FloatingBottom';

const PanelComponent = (props) => (
  <Panel>
    <Text>Here is the content inside panel</Text>
    <Button title='Hide' onPress={props.hidePanel} />
  </Panel>
);

const Actions = (props) => (
  <BottomPanel>
    <Text>Here is the content inside panel</Text>
    <Button title='Hide' onPress={props.hidePanel} />
  </BottomPanel>
);

export default () => {
  const showFloatingSlideUp = useFloatingSlideUp(PanelComponent);
  const showFloatingBottom = useFloatingBottom(Actions);

  return (
    <Button
      onPress={() => {
        showFloatingSlideUp(true);
        showFloatingBottom(true);
      }}
      title='Show panel'
    />
  );
};

const Panel = styled.View`
  flex: 1;
  background-color: red;
  align-items: center;
  justify-content: center;
  border-top-left-radius: 50;
`;

const BottomPanel = styled.View`
  background: blue;
  height: 100px;
`;

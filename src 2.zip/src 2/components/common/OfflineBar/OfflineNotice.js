import React from 'react';
import { View, NetInfo, Text, Dimensions, StyleSheet } from 'react-native';
import { ifIphoneX } from 'react-native-iphone-x-helper';

const { width } = Dimensions.get('window');

function MiniOfflineSign() {
  return (
    <View style={styles.offlineContainer} testID='offline-notice'>
      <Text style={styles.offlineTextTitle}>No Internet Connection</Text>
      <Text style={styles.offlineTextSubtitle}>
        Please check your internet settings and try again.
      </Text>
    </View>
  );
}

class OfflineNotice extends React.PureComponent {
  state = {
    isConnected: true
  };

  async componentDidMount() {
    const isConnected = await NetInfo.isConnected.fetch();

    this.handleConnectivityChange(isConnected);

    NetInfo.isConnected.addEventListener(
      'connectionChange',
      this.handleConnectivityChange.bind(this)
    );
  }

  componentWillUnmount() {
    NetInfo.isConnected.removeEventListener(
      'connectionChange',
      this.handleConnectivityChange.bind(this)
    );
  }

  handleConnectivityChange(isConnected) {
    this.setState({ isConnected });
  }

  render() {
    if (!this.state.isConnected) {
      return <MiniOfflineSign />;
    }
    return null;
  }
}

const styles = StyleSheet.create({
  offlineContainer: {
    backgroundColor: '#dd1414',
    ...ifIphoneX(
      {
        height: 130
      },
      {
        height: 80
      }
    ),
    justifyContent: 'center',
    alignItems: 'center',
    width,
    top: 0,
    zIndex: 1,
    ...ifIphoneX({
      paddingTop: 50
    })
  },
  offlineTextTitle: {
    color: '#fff',
    fontFamily: 'TeshrinAR-Bold',
    fontSize: 16,
    paddingTop: 5
  },
  offlineTextSubtitle: {
    color: '#fff',
    fontFamily: 'TeshrinAR-Regular',
    fontSize: 15
  }
});

export default OfflineNotice;

import React from 'react';
import styled, { css } from 'styled-components/native';
import SmallButton from 'components/common/Button/SmallButton';

const ProfileInfoListItem = ({
  label,
  inputField,
  passwordItem,
  isPassword,
  onPress
}) => {
  return (
    <Container>
      <Label passwordItem={passwordItem}>{label}</Label>
      <InputField passwordItem={passwordItem}>{inputField}</InputField>
      {isPassword ? (
        <PassContainer>
          <SmallButton available title='Change' onPress={onPress} />
        </PassContainer>
      ) : null}
    </Container>
  );
};

export default ProfileInfoListItem;

const Container = styled.View`
  height: 75px;
  flex-direction: column;
  justify-content: center;
  padding: 0 20px;
  border-color: ${(props) =>
    props.error
      ? props.theme.color.primary.warning
      : props.theme.color.misc.listItemDivider};
  border-bottom-width: 1px;
`;

const PassContainer = styled.View`
  position: absolute;
  right: 20px;
`;

const InputField = styled.Text`
  color: rgb(13, 25, 67);
  color: ${(props) =>
    props.passwordItem ? 'rgb(206, 209, 217)' : 'rgb(13, 25, 67)'};
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  letter-spacing: 0px;
  line-height: 22px;
`;

const Label = styled.Text`
  margin-top: -3px;
  color: ${(props) =>
    props.passwordItem ? 'rgb(13, 25, 67)' : 'rgb(109, 117, 142)'};
  font-size: 12px;
  font-family: 'OpenSans-Regular';
  line-height: 16px;
`;

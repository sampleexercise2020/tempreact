import React from 'react';
import { useStore, useActions } from 'easy-peasy';
import Avatar from 'components/common/Avatar/Avatar';
import styled, { css } from 'styled-components/native';

const StudentInfo = ({
  dark,
  image,
  firstName,
  lastName,
  schoolGrade,
  schoolClass,
  smallIcon
}) => {
  return (
    <Container>
      <Avatar
        light={true}
        isRemote={true}
        name={`${firstName} ${lastName}`}
        image={image}
        smallIcon={smallIcon}
      />
      <Information>
        <Name dark={dark}>
          {firstName} {lastName}
        </Name>
        <Grade dark={dark}>
          {schoolGrade} {schoolClass}
        </Grade>
      </Information>
    </Container>
  );
};

export default StudentInfo;

const Container = styled.View`
  flex-direction: row;
`;
const Information = styled.View`
  flex-direction: column;
  margin-left: 10px;
  justify-content: center;
`;
const Name = styled.Text`
  font-size: 16px;
  font-family: OpenSans-Regular;
  color: rgb(255, 255, 255);
  ${(props) =>
    props.dark &&
    css`
      color: #0d1943;
    `}
`;

const Grade = styled.Text`
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 18px;
  color: rgb(255, 255, 255);
  ${(props) =>
    props.dark &&
    css`
      color: #6d758e;
    `}
`;

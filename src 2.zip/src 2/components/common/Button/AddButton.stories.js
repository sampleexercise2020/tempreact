import React from 'react';
import { storiesOf } from '@storybook/react-native';
import AddButton from './AddButton';

storiesOf('Components|Buttons', module).add('Add Button/CTA', () => (
  <AddButton text='Add to calendar' />
));

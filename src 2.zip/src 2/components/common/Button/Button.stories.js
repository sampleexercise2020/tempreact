import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action, configureActions } from '@storybook/addon-actions';
import Button from './Button';

// TODO: Get notes working.

storiesOf('Components|Buttons', module)
  .add('Standard', () => (
    <Button onPress={action('button-click')}>Secondary</Button>
  ))
  .add(
    'Primary',
    () => (
      <Button onPress={action('button-click')} primary>
        Primary
      </Button>
    ),
    {
      notes: 'A very simple example of addon notes'
    }
  )
  .add('Disabled', () => <Button disabled>Disabled</Button>)
  .add('Error', () => <Button error>Error</Button>)
  .add('Secondary', () => <Button secondary>Secondary</Button>)
  .add('All White', () => <Button allWhite>All White</Button>)
  .add('Transparent', () => <Button transparent>Transparent</Button>);

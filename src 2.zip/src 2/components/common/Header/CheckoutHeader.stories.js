import React from 'react';
import { storiesOf } from '@storybook/react-native';
import CheckoutHeader from './CheckoutHeader';

storiesOf('Components|Header', module).add(
  'Checkout header - standard ',
  () => (
    <CheckoutHeader
      pageTitle='Checkout'
      title='Sara Andersson'
      subtitle='Brilliant Int School'
    />
  )
);

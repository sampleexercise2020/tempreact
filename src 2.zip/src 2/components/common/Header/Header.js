import React from 'react';
import styled from 'styled-components/native';
import SearchBar from 'components/common/SearchBar';
import { Headline } from 'components/common/Typography';

const HeaderNavigationBar = ({ children }) => {
  return (
    <NavigationBar>
      <Back>
        {/* <Image
          source={require('src/../../assets/icons/common/back-arrow.png')}
        /> */}
      </Back>
      <HeaderContainer>{children}</HeaderContainer>
      <Dots>
        <CloseBtn
          resizeMode='contain'
          source={require('src/../../assets/icons/common/close.png')}
        />
      </Dots>
    </NavigationBar>
  );
};

const SearchHeader = ({ withNavigation, onSubmit }) => {
  return (
    <SearchContainer>
      <SearchBar placeholderText='Search school' onSubmit={onSubmit} />
    </SearchContainer>
  );
};

const HeaderExtra = ({ variant, ...props }) => {
  switch (variant) {
    case 'search':
      return <SearchHeader {...props} />;
    default:
      return null;
  }
};

const Header = (props) => {
  return (
    <Container>
      <HeaderNavigationBar>
        <Headline white>Select your school</Headline>
      </HeaderNavigationBar>
      <HeaderExtra {...props} />
    </Container>
  );
};

const Container = styled.View`
  position: relative;
  background: #402ca8;
`;

const SearchContainer = styled.View`
  position: relative;
  background: #402ca8;
  padding: 10px 20px 20px;
`;

const NavigationBar = styled.View`
  flex-direction: row;
  justify-content: space-between;
  overflow: hidden;
  padding: 10px 20px;
`;
const CloseBtn = styled.Image`
  height: 23px;
  width: 23px;
`;

const Back = styled.TouchableOpacity`
  height: 35px;
  width: 35px;
  justify-content: center;
  align-items: center;
`;

const Dots = styled.TouchableOpacity`
  height: 35px;
  width: 35px;
  justify-content: center;
  align-items: center;
`;

const HeaderContainer = styled.View`
  flex-grow: 1;
  justify-content: center;
  align-items: center;
`;

export default Header;

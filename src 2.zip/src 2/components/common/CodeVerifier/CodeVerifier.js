import React, { useState, useEffect, useRef } from 'react';
import { Alert } from 'react-native';
import styled from 'styled-components';
import { useStore, useActions } from 'easy-peasy';
import { Navigation } from 'react-native-navigation';
import * as yup from 'yup';

// TODO: Add text from copy file
// import selectedCopy from 'src/i18n/copy';

import VerificationDots from 'components/common/VerificationDots/VerificationDots';
import Button from 'components/common/Button/Button';

let maskTimeout = null;

const CodeVerifier = ({
  children,
  length,
  errorMessageMin,
  errorMessageMax,
  errorMessageRequired,
  buttonText,
  onPress,
  passDataToParent,
  isLoading,
  resend,
  resendOnPress
}) => {
  const hiddenInput = useRef(null);
  const [valid, setValid] = useState(false);
  const [values, setValues] = useState([]);
  const [error, setError] = useState(false);
  const [code, setCode] = useState('');

  let validateCode = yup.object().shape({
    code: yup
      .string()
      .min(length, errorMessageMin)
      .max(length, errorMessageMax)
      .required(errorMessageRequired)
  });

  useEffect(() => {
    checkValidity();
    passDataToParent ? passDataToParent(code) : null;

    setValues(
      (code.length > values.length
        ? code.replace(/./g, '*').slice(0, code.length - 1) + code.slice(-1)
        : code.replace(/./g, '*')
      ).split('')
    );

    maskTimeout = setTimeout(
      () => setValues(code.replace(/./g, '*').split('')),
      1000
    );
    return () => clearTimeout(maskTimeout);
  }, [code]);

  const focusHiddenInputField = () => {
    hiddenInput.current.focus();
  };

  const checkValidity = async () => {
    const validity = await validateCode.isValid({
      code: code
    });
    validity ? setError(false) : setError(true);
  };

  const handleInput = (text) => {
    setCode(text.replace(/[^0-9]/g, ''));
  };

  return (
    <>
      <Container behavior='padding'>
        {children}
        <VerificationContainer>
          <VerificationDots values={values} length={length} />
        </VerificationContainer>
        <HiddenInputField
          ref={hiddenInput}
          autofocus={true}
          onChangeText={handleInput}
          value={code}
          maxLength={length}
          keyboardType={'numeric'}
          returnKeyType={'done'}
        />
        <InputFieldActivator onPress={focusHiddenInputField} />
      </Container>
      <ButtonContainer>
        {resend && (
          <Resend onPress={resendOnPress}>
            <ResendText>Resend code</ResendText>
          </Resend>
        )}
        <Button
          disabled={error || isLoading}
          primary={!error}
          onPress={onPress}
          isLoading={isLoading}
        >
          {buttonText}
        </Button>
      </ButtonContainer>
    </>
  );
};

export default CodeVerifier;

const Container = styled.KeyboardAvoidingView`
  position: relative;
  padding-bottom: 20px;
  flex: 1;
  align-items: center;
  justify-content: center;
`;

const Title = styled.Text`
  width: 200px;
  color: rgb(13, 25, 67);
  font-size: 20px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  text-align: center;
  letter-spacing: 0px;
  line-height: 28px;
`;

const ButtonContainer = styled.View`
  padding: 20px;
`;

const Resend = styled.TouchableOpacity`
  margin-bottom: 15px;
`;

const ResendText = styled.Text`
  color: rgb(64, 44, 168);
  font-size: 12px;
  font-family: OpenSans-SemiBold;
  font-weight: 600;
  text-align: center;
  letter-spacing: 0px;
  line-height: 16px;
`;

const VerificationContainer = styled.View`
  padding-top: 50px;
`;
const HiddenInputField = styled.TextInput`
  position: absolute;
  top: -1000px;
`;

const InputFieldActivator = styled.TouchableOpacity`
  position: absolute;
  height: 100%;
  width: 100%;
  opacity: 0;
`;

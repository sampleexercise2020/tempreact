import React from 'react';
import styled, { css } from 'styled-components/native';
import Dot from './Dot';

const VerificationDots = ({ values, length }) => {
  let dots = [];
  for (let i = 0; i < length; i++) {
    dots.push(<Dot number={values[i]} key={i} />);
  }

  return <Container>{dots}</Container>;
};

const Container = styled.View`
  justify-content: center;
  align-items: center;
  flex-direction: row;
  overflow: hidden;
  height: 50px;
`;

export default VerificationDots;

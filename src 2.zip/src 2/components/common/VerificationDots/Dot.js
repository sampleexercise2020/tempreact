import React from 'react';
import styled, { css } from 'styled-components/native';

const Dot = ({ number }) => {
  return <>{number ? <Number>{number}</Number> : <DotStyle />}</>;
};

const DotStyle = styled.View`
  height: 30px;
  width: 30px;
  border-radius: 15px;
  background-color: #f5f5f7;
  margin: 0 10px;
`;

const Number = styled.Text`
  color: #0d1943;
  font-family: OpenSans-Bold;
  font-size: 32px;
  font-weight: bold;
  margin: 0 10px;
  width: 30px;
  text-align: center;
`;

export default Dot;

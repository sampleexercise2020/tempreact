import React from 'react';
import styled, { css } from 'styled-components/native';
import Button from 'components/common/Button/Button';

const FullScreenModal = ({
  titleText,
  text,
  title,
  cancelText,
  onPressCancel,
  buttonText,
  onPressPrimaryButton,
  componentId
}) => {
  console.log('SHOULD LOG', componentId, title);
  return (
    <Background>
      <Modal title={title}>
        <InnerContainer>
          {title && <Title>{titleText}</Title>}
          <InnerText title={title}>{text}</InnerText>
          <ButtonContainer>
            <Button
              primary
              onPress={() => {
                onPressPrimaryButton(componentId);
              }}
            >
              {buttonText}
            </Button>

            <CancelContainer
              onPress={() => {
                onPressCancel(componentId);
              }}
            >
              <CancelText>{cancelText}</CancelText>
            </CancelContainer>
          </ButtonContainer>
        </InnerContainer>
      </Modal>
    </Background>
  );
};

export default FullScreenModal;

const Background = styled.View`
  background-color: #02071b99;
  flex: 1;
  justify-content: center;
  align-items: center;
  padding: 0 20px;
`;

const Modal = styled.View`
  background-color: #ffffff;
  min-height: 269px;
  ${(props) =>
    props.title &&
    css`
      min-height: 361px;
    `}
  width: 100%;
  border-top-left-radius: 40px;
  border-bottom-right-radius: 40px;
  box-shadow: 0px 3px 8px rgba(153, 153, 153, 0.6);
`;

const InnerContainer = styled.View`
  padding-top: 40px;
  padding-bottom: 40px;
`;

const Title = styled.Text`
  font-size: 20px;
  color: #0d1943;
  font-family: 'TeshrinAR+LT-Regular';
  font-weight: 900;
  text-align: center;
  padding: 20px 40px;
`;

const InnerText = styled.Text`
  font-size: 16px;
  text-align: center;
  line-height: 22px;
  font-family: 'OpenSans-Regular';
  color: #0d1943;
  padding: 0 40px;
  margin-top: 20px;
  ${(props) =>
    props.title &&
    css`
      margin-top: 0;
    `}
`;

const CancelContainer = styled.TouchableOpacity`
  align-items: center;
  margin-top: 16px;
`;

const CancelText = styled.Text`
  color: #402ca8;
  font-size: 14px;
  font-weight: 600;
  font-family: 'OpenSans-Regular';
`;

const ButtonContainer = styled.View`
  margin: 40px 15px 0px 15px;
`;

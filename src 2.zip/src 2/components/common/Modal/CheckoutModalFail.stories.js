import React from 'react';
import { storiesOf } from '@storybook/react-native';
import CheckoutModalFail from './CheckoutModalFail';

storiesOf('Components|Modal', module).add('Checkout Modal FAIL', () => (
  <CheckoutModalFail />
));

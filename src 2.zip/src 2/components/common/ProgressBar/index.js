import React from 'react';
import styled from 'styled-components/native';

const ProgressBar = ({ progressPercent }) => {
  return (
    <Container>
      <ProgressBarIndicator progressPercent={progressPercent} />
    </Container>
  );
};

const Container = styled.View`
  background-color: ${(props) => props.theme.color.brandDark};
  height: 10px;
`;

const ProgressBarIndicator = styled.View`
  background-color: ${(props) => props.theme.color.primary};
  height: 10px;
  width: ${(props) => props.progressPercent}%;
`;

export default ProgressBar;

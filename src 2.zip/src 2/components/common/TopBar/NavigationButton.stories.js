import React from 'react';
import { storiesOf } from '@storybook/react-native';
import NavigationButton from './NavigationButton/';

const editButton = require('src/../../assets/icons/common/edit-white.png');

storiesOf('Components/TopBar', module).add('Edit Profile', () => (
  <NavigationButton onPress={() => alert('Edit Profile')} icon={editButton} />
));

import React, { useState } from 'react';
import styled from 'styled-components/native';

const SignatureIcon = require('src/../../assets/images/signature.png');
const SignatureAttachedIcon = require('src/../../assets/images/signature_attached.png');

const Signature = ({ text, signed }) => {
  return (
    <Container>
      <ImageContainer>
        {signed ? (
          <Signed resizeMode='contain' source={SignatureAttachedIcon} />
        ) : (
          <Sign resizeMode='contain' source={SignatureIcon} />
        )}
      </ImageContainer>
      <SignatureText>{text}</SignatureText>
    </Container>
  );
};

const Container = styled.View`
  align-items: center;
  flex-direction: row;
`;

const SignatureText = styled.Text`
  color: #0065c8;
  font-size: 14px;
  font-family: 'TeshrinAR+LT-Regular';
  font-weight: normal;
  letter-spacing: 0;
  padding-left: 8px;
`;

const Sign = styled.Image`
  height: 16px;
  width: 30px;
`;

const Signed = styled.Image`
  height: 16px;
  width: 16px;
`;

const ImageContainer = styled.View`
  justify-content: center;
  align-items: center;
  height: 30px;
  width: 45px;
  border-radius: 14.5px;
  background: #e8f4ff;
`;

export default Signature;

import React from 'react';
import styled, { css } from 'styled-components/native';

const TextLink = ({ linktext, onPress, textColor, marginLeft, white }) => {
  return (
    <LinkContainer onPress={onPress} marginLeft={marginLeft}>
      <LinkText textColor={textColor} white={white}>
        {linktext}
      </LinkText>
      <Icon
        source={
          white
            ? require('../../../../assets/icons/common/forward-arrow.png')
            : require('../../../../assets/icons/common/arrow-forward-purple-24.png')
        }
      />
    </LinkContainer>
  );
};

export default TextLink;

const LinkContainer = styled.TouchableOpacity`
  flex-direction: row;
  align-items: center;
  margin-left: ${(props) => props.marginLeft};
`;

const LinkText = styled.Text`
  font-size: 14px;
  color: #402ca8;
  line-height: 18px;
  font-weight: 600;
  font-family: 'OpenSans-SemiBold';
  ${(props) =>
    props.white &&
    css`
      color: #ffffff;
    `}
`;

const Icon = styled.Image`
  margin-left: 5px;
  height: 16px;
  width: 16px;
`;

import styled from 'styled-components/native';

export const ThinLine = styled.View`
  margin-left: 20px;
  margin-right: 20px;
  border-bottom-width: 1px;
  border-bottom-color: ${(props) => props.theme.color.listItemDivider};
`;

export const CategoryViewProductSeparator = styled.View`
  border-bottom-width: 1px;
  border-bottom-color: rgba(0, 0, 0, 0.1);
  margin: 15px 0;
`;

export const CartItemSeparator = styled.View`
  height: 1px;
  background: rgb(237, 238, 241);
  margin: 20px;
`;

export const ProductViewDivider = styled.View`
  height: 1px;
  background: rgb(237, 238, 241);
  margin-top: 30px;
  margin-bottom: 20px;
`;

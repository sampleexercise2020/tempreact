import React, { useEffect, useRef } from 'react';
import { View, Dimensions, Animated } from 'react-native';
import styled from 'styled-components';
import { useStore, useActions } from 'easy-peasy';
import SlidingUpPanel from 'rn-sliding-up-panel';

const { height } = Dimensions.get('window');

class _FloatingSlideUp extends React.Component {
  static defaultProps = {
    draggableRange: {
      top: height - 100,
      middle: height * 0.65,
      bottom: 0
    }
  };

  constructor(props) {
    super(props);
    this.state = {
      panelPosition: 'bottom'
    };
  }

  _animatedValue = new Animated.Value(0);

  componentDidMount() {
    this._panel.show(this.props.draggableRange.default);
    this._animatedValue.addListener(this._onAnimatedValueChange.bind(this));
  }

  // External close logic
  componentDidUpdate(props) {
    if (!this.props.showFloating && !this.props.didDismiss.current) {
      this.hidePanel();
    }
  }

  componentWillUnmount() {
    this._animatedValue.removeListener(this._onAnimatedValueChange);
  }

  _onAnimatedValueChange({ value }) {
    const { top, bottom, middle } = this.props.draggableRange;

    if (value === top) {
      // this.setState({panel:'up'})
      // console.log('Panel at top');
      console.log('panel at top');
      this.setState({ panelPosition: 'top' });
    } else if (value === bottom) {
      // this.setState({panel:'up'})
      // console.log('Panel at bottom');
      this.setState({ panelPosition: 'bottom' });
    } else if (value === middle) {
      // this.setState({panel:'up'})
      // console.log('Panel at bottom');
      this.setState({ panelPosition: 'middle' });
    } else {
      this.setState({ panelPosition: value });
    }
  }

  hidePanel() {
    this._panel.hide();
    this.props.didDismiss.current = true;

    setTimeout(() => {
      this.props.setIsOverlay(false);
      this.props.setShowFloating(false);
    }, 300);
  }

  render() {
    const { component: Component, draggableRange } = this.props;

    return (
      <Container>
        <SlidingUpPanel
          ref={(c) => (this._panel = c)}
          // animatedValue={this._animatedValue}
          snappingPoints={[draggableRange.middle, draggableRange.top]}
          draggableRange={draggableRange}
          onRequestClose={this.hidePanel}
          onBackButtonPress={this.hidePanel}
          // onDragStart={(position, gestureState) => {}}
          onMomentumDragEnd={(value) => {
            if (value == 0) {
              this.hidePanel();
            }
          }}
        >
          {(dragHandler) => (
            <>
              <DragHandlerContainer {...dragHandler}>
                <DragHandler />
              </DragHandlerContainer>
              <ComponentContainer>
                <Component
                  hidePanel={this.hidePanel.bind(this)}
                  dragHandler={dragHandler}
                  panelPosition={this.state.panelPosition}
                />
              </ComponentContainer>
            </>
          )}
        </SlidingUpPanel>
      </Container>
    );
  }
}

const FloatingSlideUp = (props) => {
  const didDismiss = useRef(false);
  const showFloating = useStore((state) => state.global.showFloating);
  const setShowFloating = useActions(
    (actions) => actions.global.setShowFloating
  );

  return (
    <_FloatingSlideUp
      {...props}
      showFloating={showFloating}
      setShowFloating={setShowFloating}
      didDismiss={didDismiss}
    />
  );
};

const ComponentContainer = styled.View`
  position: relative;
  border-top-left-radius: 50;
  background-color: white;
  padding-bottom: 100px;
  flex: 1;
  overflow: hidden;
`;

const DragHandlerContainer = styled.View`
  /* top: -100px; */
  height: 100px;
  justify-content: flex-end;
  align-items: center;
  width: 100%;
  z-index: 1000;
  padding-bottom: 10px;
`;

const DragHandler = styled.View`
  width: 40px;
  height: 3px;
  background: rgb(255, 255, 255);
  border-radius: 2px;
`;

const Container = styled.View`
  flex: 1;
  background-color: transparent;
`;

export default FloatingSlideUp;

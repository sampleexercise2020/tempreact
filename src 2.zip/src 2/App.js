import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Platform,
  AsyncStorage
} from 'react-native';
import Biometrics from 'react-native-biometrics';
import { useStore } from 'easy-peasy';
import firebase from 'react-native-firebase';

// import * as firebase from 'firebase';

// To import the Appdynamics React Native Agent
import { Instrumentation } from '@appdynamics/react-native-agent';

// Initialize the instrumentation
Instrumentation.start({
  //  appKey: 'EUM-AAC-SUC',
  appKey: 'EUM-AAB-DRA',
  collectorURL: 'https://conv.rakbankonline.ae:7002'
});

// Firebase Push Notification Authorisation

const checkPermission = async () => {
  const enabled = await firebase.messaging().hasPermission();
  if (enabled) {
    getToken();
  } else {
    requestPermission();
  }
};
const getToken = async () => {
  let fcmToken = await AsyncStorage.getItem('fcmToken');
  if (!fcmToken) {
    fcmToken = await firebase.messaging().getToken();
    if (fcmToken) {
      // user has a device token
      await AsyncStorage.setItem('fcmToken', fcmToken);
    }
  }
};

const requestPermission = async () => {
  try {
    await firebase.messaging().requestPermission();
    // User has authorised
    getToken();
  } catch (error) {
    // User has rejected permissions
    console.log('permission rejected');
  }
};

checkPermission();

// Firebase Crashlytics
firebase.crashlytics().enableCrashlyticsCollection();

// if (Platform.OS === 'ios') {
//   var firebaseConfig = {
//     apiKey: 'AIzaSyA7Nj2DBOCXMhSEUNqgo1s36cU6alLq7rA',
//     authDomain: 'skiplyprod.firebaseapp.com',
//     databaseURL: 'https://skiplyprod.firebaseio.com',
//     projectId: 'skiplyprod',
//     storageBucket: '',
//     messagingSenderId: '539545560871',
//     appId: '1:539545560871:ios:642fa50d628843b4'
//   };
//   firebase.initializeApp(firebaseConfig);
// } else {
//   var firebaseConfig = {
//     apiKey: 'AIzaSyBrmANINmPofTFwq9ad-O5cIHbmcAc24yM',
//     authDomain: 'skiplyprod.firebaseapp.com',
//     databaseURL: 'https://skiplyprod.firebaseio.com',
//     projectId: 'skiplyprod',
//     storageBucket: '',
//     messagingSenderId: '539545560871',
//     appId: '1:539545560871:android:642fa50d628843b4'
//   };
//   firebase.initializeApp(firebaseConfig);
// }
// console.log('Firebase initialised');

const App = () => {
  const runBiometrics = () => {
    console.log('biometrics');
    Biometrics.isSensorAvailable().then((biometryType) => {
      if (biometryType === Biometrics.TouchID) {
        console.log('TouchID is supported');
        Biometrics.createKeys('Confirm fingerprint')
          .then((publicKey) => {
            console.log(publicKey);
            sendPublicKeyToServer(publicKey);
          })
          .catch(() => {
            console.log('handled promise rejection');
          });
      } else if (biometryType === Biometrics.FaceID) {
        console.log('FaceID is supported');
        Biometrics.createKeys('Confirm face id')
          .then((publicKey) => {
            console.log(publicKey);
            sendPublicKeyToServer(publicKey);
          })
          .catch(() => {
            console.log('handled promise rejection');
          });
      } else {
        console.log('Biometrics not supported');
      }
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.welcome}>VÄLKOMMEN TILL VÅRT QKR-REPO</Text>
      <TouchableOpacity
        style={{ borderWidth: 1, backgroundColor: 'blue', padding: 10 }}
        onPress={() => runBiometrics()}
      >
        <Text style={{ color: 'white' }}>use biometrics</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF'
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
    color: 'red'
  }
});

export default App;

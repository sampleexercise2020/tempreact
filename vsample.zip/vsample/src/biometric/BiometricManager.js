import React from 'react';
import { Alert, AsyncStorage } from 'react-native';
import TouchID from 'react-native-touch-id';

export default class BiometricManager {
  /**
   * Show biometric enable popup if biometric is supported to device.
   */
  static showEnableOptionsFor(email, password) {
    const promise = new Promise(function(resolve, reject) {
      const configObject = {
        title: 'Authentication Required',
        cancelText: 'Cancel',
        fallbackLabel: '',
        unifiedErrors: false,
        passcodeFallback: true
      };

      TouchID.isSupported(configObject)
        .then((biometryType) => {
          // fix for android because android devices return 'true' in biometryType
          var type = 'TouchID';
          if (biometryType === 'FaceID') {
            type = 'FaceID';
          }

          Alert.alert(
            `Enable ${type} Login`,
            `Do you want to enable ${type} login?`,
            [
              {
                text: 'Yes',
                onPress: () => {
                  resolve({ success: true });
                  BiometricManager.setEnableBiometricLogin(
                    true,
                    email,
                    password
                  );
                }
              },
              {
                text: 'No',
                onPress: () => {
                  resolve({ success: true });
                  BiometricManager.setEnableBiometricLogin(false);
                }
              }
            ]
          );
        })
        .catch((error) => {
          // TODO: Remove after testing if biometric is not supported
          // alert('Authentication Failed:'+ error);

          reject(error);
        });
    });
    return promise;
  }

  /**
   * Save biometric enable/disable key in database for email and password
   */
  static setEnableBiometricLogin(enable, email, password) {
    if (enable) {
      let value = enable ? 'true' : 'false';
      AsyncStorage.multiSet([
        ['bio_login_require', value],
        ['bio_email', email],
        ['bio_password', password]
      ]);
    } else {
      BiometricManager.removeBiometricLogin();
    }
  }

  /**
   * Update biometric password in case user changes password
   */
  static updatePassword(password) {
    AsyncStorage.setItem('bio_password', password);
  }

  /**
   * Get biometric enable key from database
   * and show if login popup if required.
   * It will retrun success true and email password as resolve parameters if bio metric login is approved.
   */
  static async showBiometricLogin() {
    const promise = new Promise(async function(resolve, reject) {
      const value = await AsyncStorage.getItem('bio_login_require');
      if (value == 'true') {
        const bio_email = await AsyncStorage.getItem('bio_email');
        const bio_password = await AsyncStorage.getItem('bio_password');

        // if value is true then
        if (value == 'true') {
          const configObject = {
            title: 'Authentication Required',
            cancelText: 'Cancel',
            fallbackLabel: '',
            unifiedErrors: false,
            passcodeFallback: true
          };

          // If touch id supported then show auto login feature
          TouchID.isSupported(configObject).then((biometryType) => {
            TouchID.authenticate('Skiply Touch ID', configObject)
              .then((success) => {
                if (success == true) {
                  resolve({
                    success: true,
                    email: bio_email,
                    password: bio_password
                  });
                } else {
                  reject({
                    error:
                      'Unable to auto login with biometric. Please follow manual login.'
                  });
                }
              })
              .catch((error) => {
                // may be touch id authentication failed
                reject(error);
              });
          });
        }
      } else {
        reject({ error: 'User has disabled the bio metric login.' });
      }
    });
    return promise;
  }

  /**
   * Remove biometric login
   */
  static removeBiometricLogin() {
    AsyncStorage.removeItem('bio_login_require');
    AsyncStorage.removeItem('bio_email');
    AsyncStorage.removeItem('bio_password');
    AsyncStorage.removeItem('PUB_KEY');
  }
}

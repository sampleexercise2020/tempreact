import React, { useEffect } from 'react';
import { StatusBar } from 'react-native';
import { StoreProvider } from 'easy-peasy';
import { ThemeProvider } from 'styled-components';
import theme from 'theme';
import { store } from '/store';
import OfflineNotice from 'components/common/OfflineBar/OfflineNotice';
import ErrorMessager from 'modules/Global/components/ErrorMessager/ErrorMessager';

/**
 * Global error boundary, catches exceptions thrown from every component in the
 * entire app and shows a screen with some information and a go back button.
 */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  componentDidCatch(error, errorInfo) {
    console.log('errorInfo: ', errorInfo);
    this.setState({ error });
  }

  render() {
    if (this.state.error) {
      return <ErrorMessager {...this.props} />;
    } else {
      return this.props.children;
    }
  }
}

/**
 * Add all global contexts here and they will be added to all screens.
 *
 * @param {React.Props} props
 * @returns {React.Component}
 */
const AppProvider = (props) => (
  <StoreProvider store={store}>
    <ThemeProvider theme={theme}>{props.children}</ThemeProvider>
  </StoreProvider>
);

/**
 * Helper for use when adding global components to the app,
 * used extensively when we register navigation components.
 *
 * @param {React.Component} Component
 * @returns {React.Component}
 */
export const withAppWrapper = (Component) => (props) => (
  <AppProvider>
    <ErrorBoundary {...props}>
      <StatusBar barStyle='light-content' />
      <OfflineNotice />
      <Component {...props} />
    </ErrorBoundary>
  </AppProvider>
);

export default AppProvider;

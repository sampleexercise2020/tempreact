import { Platform } from 'react-native';
import { Navigation } from 'react-native-navigation';
import { withAppWrapper } from 'AppProvider';
import R from 'ramda';
import { root, loginRoot } from './root';
import { showOverlay } from 'navigation';
import FloatingCart from '/modules/Discover/School/flows/Store/ShoppingCart/components/FloatingCart';
import { dismissOverlay } from '.';
import { routes } from './';
import { store } from 'store';

const BackArrowWhite = require('../../assets/icons/common/back-arrow.png');

/**
 * Register apps navigation components
 */
const registerNavigationComponents = () => {
  routes.forEach(({ path, withoutAppWrapper, component: Component }) => {
    Navigation.registerComponent(path, () =>
      withoutAppWrapper ? Component : withAppWrapper(Component)
    );
  });
};

/**
 * Register all navigation based event listeners
 */
const registerNavigationEvents = () => {
  Navigation.events().registerNavigationButtonPressedListener((event) => {
    if (event.buttonId == 'exitFlow') {
      Navigation.popToRoot(event.componentId);
    } else {
      Navigation.pop(event.componentId).catch(console.log);
    }
  });

  Navigation.events().registerComponentDidAppearListener((component) => {
    store.dispatch.navigation.setCurrentNavigationComponent(component);

    if (
      component.componentName !== 'Skiply.TitleComponent' &&
      component.componentName !== 'FloatingBottom'
    ) {
      console.log('Component Name: ', component.componentName);
      const cart = store.getState().cart.carts[0];
      const hasCartItems = cart && !R.isEmpty(cart.cartItems);
      const isFloatingCart = store.getState().cart.isFloatingCart;
      const componentIsCategoryList =
        component.componentName == 'Skiply.Store.Categories';
      const componentIsCategory =
        component.componentName == 'Skiply.Store.Category';
      if (componentIsCategoryList || componentIsCategory) {
        if (!isFloatingCart && hasCartItems) {
          showOverlay('FloatingBottom', 'FLOATING_CART', {
            component: FloatingCart
          });
        }
      } else {
        if (isFloatingCart && hasCartItems) {
          store.dispatch.cart.setIsFloatingCart(false);
        }
      }
    }
  });

  Navigation.events().registerBottomTabSelectedListener(
    ({ selectedTabIndex, unselectedTabIndex }) => {
      if (selectedTabIndex !== unselectedTabIndex) {
        const componentId =
          root.bottomTabs.children[unselectedTabIndex].stack.children[0]
            .component.id;
        Navigation.popToRoot(componentId)
          .then(console.log)
          .catch(console.log);
      }
    }
  );

  Navigation.events().registerAppLaunchedListener(() => {
    Navigation.setDefaultOptions({
      statusBar: {
        backgroundColor: '#402ca8',
        style: 'light' | 'dark'
      },
      layout: {
        orientation: ['portrait'],
        backgroundColor: '#ffffff'
      },
      topBar: {
        visible: false,
        animate: true,
        hideOnScroll: false,
        drawBehind: true,
        elevation: 0,
        title: {
          fontSize: 16,
          color: '#fff',
          fontFamily: 'OpenSans-Bold'
        },
        backButton: {
          icon: BackArrowWhite,
          visible: false,
          color: '#fff',
          id: 'back',
          ...Platform.select({
            ios: {
              testID: 'header-back-button-id'
            },
            android: {
              accessibilityLabel: 'header-back-button-id'
            }
          })
        },
        background: {
          color: 'transparent'
        },
        statusBarStyle: 'light',
        statusBar: {
          backgroundColor: 'red',
          color: '#fff'
        }
      },
      statusBarStyle: 'light',
      bottomTabs: {
        backgroundColor: 'white',
        titleDisplayMode: 'alwaysShow',
        hideShadow: true,
        visible: true,
        // ...Platform.select({ android: { drawBehind: true } })
        animate: true
      },
      bottomTab: {
        fontSize: 11,
        fontFamily: 'OpenSans-SemiBold',
        selectedFontSize: 11,
        iconColor: '#979797',
        selectedIconColor: '#0d1943',
        textColor: '#979797',
        selectedTextColor: '#0d1943'
      }
    });

    //TODO:Review  Check if console.log is required or not.
    Navigation.setRoot({ root: loginRoot })
      .then(console.log)
      .catch(console.log);
  });
};

export default () => {
  registerNavigationComponents();
  registerNavigationEvents();
};

import { action, thunk, select } from 'easy-peasy';
import axios from 'axios';
import { API_URL, API_KEY } from 'components/../config';
import amendResponseObject from 'helpers/amendResponseObject';
import SecureAPI from '../crypto/SecureAPI';

const Cart = {
  carts: [],
  isFloatingCart: false,

  // actions
  fetched: action((state, payload) => {
    state.carts = payload;
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setIsSaving: action((state, payload) => {
    state.isSaving = payload;
  }),
  clearCart: action((state, _payload) => {
    state.carts = [];
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),
  setIsFloatingCart: action((state, payload) => {
    state.isFloatingCart = payload;
  }),
  deleteItem: action((state, payload) => {
    state.carts = state.carts.map((cart) => {
      const cartItem = cart.cartItems.find(({ id }) => id == payload);
      const cartItemAmountMinorUnits = cartItem ? cartItem.amountMinorUnits : 0;
      return {
        ...cart,
        amountMinorUnits: cart.amountMinorUnits - cartItemAmountMinorUnits,
        cartItems: cart.cartItems.filter((cartItem) => {
          return cartItem.id !== payload;
        })
      };
    });
  }),

  // thunks
  fetch: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-cart/cart/query';
    actions.setIsLoading(true);

    const response = await axios({
      method: 'post',
      url: endpoint,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Carts success response: ', response);
        actions.fetched(response.data.list);
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Carts error response', response);
        actions.setErrorMessage(response);
        return response;
      });
    actions.setIsLoading(false);

    return response;
  }),

  saveCartItem: thunk(async (actions, payload, { getStoreState, dispatch }) => {
    actions.setIsSaving(true);

    const endpoint = API_URL + 'skiply-cart/cartItem/create';
    const state = getStoreState();

    const response = await axios({
      method: 'post',
      url: endpoint,
      headers: {
        'X-Auth-Token': state.session.token,
        Authorization: state.session.authorization,
        apikey: API_KEY
      },
      data: payload
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Cart item success response');
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Cart Save ERROR RESPONSE: ', response);
        actions.setErrorMessage(response);
        return response;
      });

    await actions.fetch();
    actions.setIsSaving(false);

    return response;
  }),

  updateCartItem: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-cart/cartItem/update';
    const state = getStoreState();

    actions.setIsSaving(true);

    const response = await axios({
      method: 'post',
      url: endpoint,
      headers: {
        'X-Auth-Token': state.session.token,
        Authorization: state.session.authorization,
        apikey: API_KEY
      },
      data: payload
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Update cart item response');
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Update cart item ERROR RESPONSE: ', response);
        actions.setErrorMessage(response);
        return response;
      });

    await actions.fetch();
    actions.setIsSaving(false);

    return response;
  }),

  deleteCartItem: thunk(
    async (actions, payload, { getState, getStoreState }) => {
      const endpoint = API_URL + 'skiply-cart/cartItem/delete';
      const state = getStoreState();

      actions.deleteItem(payload);

      const response = await axios({
        method: 'delete',
        url: endpoint,
        headers: {
          'X-Auth-Token': state.session.token,
          Authorization: state.session.authorization,
          apikey: API_KEY
        },
        data: {
          id: payload
        }
      })
        .then(amendResponseObject)
        .then((response) => {
          console.log('Delete cart item success response');
          return response;
        })
        .catch((error) => {
          const response = amendResponseObject(error.response);
          console.log('Delete cart item error response:', response);
          actions.setErrorMessage(response);
          return response;
        });

      await actions.fetch();

      return response;
    }
  ),

  makePayment: thunk(async (actions, payload, { getStoreState, dispatch }) => {
    const state = getStoreState();
    const cartId = state.cart.carts[0].cartId;
    const data = {
      cartId,
      cardId: payload.card.id,
      cvc2: payload.cvv
    };

    actions.setIsLoading(true);
    const endpoint = API_URL + 'skiply-payment/trans';
    const headers = {
      'Content-Type': 'application/json',
      'X-Auth-Token': getStoreState().session.token,
      Authorization: getStoreState().session.authorization,
      apikey: API_KEY
    };
    let api = new SecureAPI();

    const response = await api
      .request(endpoint, 'POST', headers, data)
      .then(async (response) => {
        console.log('Success payment');

        actions.clearCart();

        const receiptResponse = await dispatch.receipts.fetchSingleReceipt(
          response.body.id
        );

        if (receiptResponse.status == 200) {
          dispatch.receipts.fetch();
          return receiptResponse;
        } else {
          dispatch.receipts.fetch();
          return {
            success: false,
            message: receiptResponse.message
          };
        }
      })
      .catch((error) => {
        console.log('Error:', error);
        if (error.code !== 'Y') {
          return {
            success: false,
            message: error.internalMessage,
            errorCode: error.errorCode
          };
        } else {
          return {
            success: false,
            message: error
          };
        }
      });

    return response;
    // let headers = {
    //   'Content-Type': 'application/json',
    //   'X-Auth-Token': state.session.token,
    //   Authorization: state.session.authorization
    // };
    // let api = new SecureAPI();
    // await api.request(
    //   endpoint,
    //   'POST',
    //   headers,
    //   data,
    //   (responseString) => {
    //     actions.setIsLoading(false);
    //     actions.clearCart();
    //     success();
    //     console.log('Decrypted Payment Response: ' + responseString);

    //     let response = JSON.parse(responseString);
    //     dispatch.receipts.fetchSingleReceipt(response.body.id);

    //     const receipts = dispatch.receipts.fetchSingleReceipt(res.data.body.id);
    //     return receipts;
    //   },
    //   (error) => {
    //     console.log('Error API Request');
    //     actions.setIsLoading(false);
    //     actions.setErrorMessage(error);
    //   }
    // );

    // dispatch.receipts.fetch();
    // actions.clearCart();
    // actions.setIsLoading(false);

    // actions.setIsLoading(true);
    // const endpoint = API_URL + 'skiply-payment/trans';
    // const receipt = await axios({
    //   method: 'post',
    //   url: endpoint,
    //   headers: {
    //     'X-Auth-Token': state.session.token
    //   },
    //   data
    // })
    //   .then(async (res) => {
    //     console.log('Success payment', res);
    //     const receipts = await dispatch.receipts.fetchSingleReceipt(
    //       res.data.body.id
    //     );
    //     return receipts;
    //   })
    //   .catch(({ response }) => {
    //     console.log('payment failed', response);
    //     actions.setErrorMessage(response);
    //   });
    // console.log('after payment');
    // console.log('Receipts', receipt);
    // dispatch.receipts.fetch();
    // actions.clearCart();
    // actions.setIsLoading(false);
    // return receipt;
  }),

  deleteCart: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-cart/cart/delete';
    const state = getStoreState();

    actions.setIsFloatingCart(false);
    actions.clearCart();

    const response = await axios({
      method: 'delete',
      url: endpoint,
      headers: {
        'X-Auth-Token': state.session.token,
        Authorization: state.session.authorization,
        apikey: API_KEY
      },
      data: {
        id: payload
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Delete cart success response');
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Delete cart error response:', response);
        return response;
      });

    return response;
  })
};

export default Cart;

import { action, thunk } from 'easy-peasy';

// Separate Models into separate files. These are examples for the Easy Peasy examples for Storybook.
import cards from './cards';
import cart from './cart';
import products from './products';
import currentProduct from './currentProduct';
import searchResults from './searchResults';
import store from './store';
import merchant from './merchant';
import student from './student';
import session from './session';
import global from './global';
import profile from './profile';
import navigation from './navigation';
import receipts from './receipts';
import promotion from './promotion';

// Add "real" models here.

export default {
  navigation,
  cards: cards,
  products: products,
  currentProduct: currentProduct,
  store: store,
  merchant: merchant,
  searchResults: searchResults,
  student: student,
  cart: cart,
  session: session,
  profile: profile,
  receipts: receipts,
  promotion: promotion,
  global
};

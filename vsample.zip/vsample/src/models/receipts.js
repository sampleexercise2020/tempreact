import { action, thunk } from 'easy-peasy';
import axios from 'axios';
import { API_URL, API_KEY } from 'components/../config';
import amendResponseObject from 'helpers/amendResponseObject';

// This store contains the search results from the Discovery screen

const Receipts = {
  results: [],
  singleReceipt: {},
  isLoading: false,
  isLoadingSendingReceipt: false,
  errorMessage: '',

  // actions
  fetched: action((state, payload) => {
    state.results = payload;
  }),
  fetchedSingleReceipt: action((state, payload) => {
    state.singleReceipt = payload;
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setLoadingSendingReceipt: action((state, payload) => {
    state.isLoadingSendingReceipt = payload;
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),

  // thunks
  // Takes nothing, queryString or lat and long
  fetch: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = `${API_URL}skiply-payment/trans/query/0/5`;

    actions.setIsLoading(true);

    await axios({
      method: 'get',
      url: endpoint,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then((response) => {
        actions.fetched(response.data.body.list);
      })
      .catch((error) => {
        actions.setErrorMessage(error.message);
      });

    actions.setIsLoading(false);
  }),
  fetchSingleReceipt: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = `${API_URL}skiply-payment/trans/${payload}`;

    actions.setIsLoading(true);

    const response = await axios({
      method: 'get',
      url: endpoint,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Fetch receipt success response');

        // 0. Fetch Single Receipt
        const receipt = response.data;
        const items = receipt.transactionItems;
        // 1. Loop through beneficiaries
        receipt.beneficiaries.forEach((beneficiary) => {
          let beneficiaryItems = [];
          items.forEach((item) => {
            item.beneficiaryId == beneficiary.id
              ? beneficiaryItems.push(item)
              : null;
          });
          beneficiary.items = beneficiaryItems;
        });
        actions.fetchedSingleReceipt(receipt);

        const receiptResponse = {
          ...response,
          data: { ...receipt, transactionId: payload }
        };

        return receiptResponse;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Fetch receipt error response', response);
      });

    actions.setIsLoading(false);

    return response;
  }),
  sendEmailReceipt: thunk(async (actions, payload, { getStoreState }) => {
    var data = {};
    if (payload.email != undefined) {
      data = {
        emailId: payload.email,
        transactionId: payload.id
      };
    } else {
      data = { transactionId: payload.id };
    }

    const endpoint = `${API_URL}skiply-payment/sendreceipt`;
    actions.setLoadingSendingReceipt(true);

    const response = await axios({
      method: 'post',
      url: endpoint,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      },
      data: data
    })
      .then((response) => {
        console.log('Email receipt success response');
        actions.setLoadingSendingReceipt(false);
        return response;
      })
      .catch((error) => {
        console.log('Send email error: ', error);
        actions.setLoadingSendingReceipt(false);
        if (error == undefined) {
          return null;
        } else {
          return error.response.data.status.message;
        }
      });
    return response;
  }),
  setLoadingSendingReceiptToDefault: thunk(
    async (actions, payload, { getStoreState }) => {
      actions.setLoadingSendingReceipt(false);
    }
  )
};

export default Receipts;

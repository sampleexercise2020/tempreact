import axios from 'axios';
import { action, select, thunk, useStoreActions } from 'easy-peasy';
import R from 'ramda';
import { API_URL, API_KEY } from 'components/../config';
import amendResponseObject from 'helpers/amendResponseObject';

const currentProduct = {
  data: null,
  currentProductId: '',
  options: [],
  selectedOptions: [], // Full list of options selected with all
  selectedOptionsIdArray: select((state) => {
    return state.selectedOptions.map((option) => {
      option = option.id;
    });
  }), // Only IDs for adding to cart as well as customPaymentAdjust.
  variantId: '',
  singleVariantPricing: 0,
  locatedScanId: '',
  quantity: 1,
  formSigned: null,
  formFields: [],
  isLoadingFormFields: false,
  isEditing: false,
  purchaseNote: '',

  // In order to pop to product list from deeply navigated product
  productListComponentId: null,

  totalPrice: select((state) => {
    // Calculates the total price of all the options.
    let optionTotal = 0;

    if (state.selectedOptions && state.selectedOptions.length > 0) {
      optionTotal = state.selectedOptions.reduce((total, list) => {
        if (list.options && list.options.length > 0) {
          return (
            total +
            list.options.reduce((listTotal, option) => {
              if (option && typeof option.paymentAdjust == 'number') {
                return listTotal + option.paymentAdjust;
              } else {
                return listTotal;
              }
            }, 0)
          );
        } else {
          return total;
        }
      }, 0);
    }

    // Calculates the current variants price.
    let variantPrice;
    if (state.data && state.data.variants) {
      variantPrice = state.data.variants
        .filter((i) => i.id == state.variantId)
        .map((i) => (i = i.amountMinorUnits));
      variantPrice = variantPrice[0];
    }

    typeof variantPrice == 'number' ? null : (variantPrice = 0);

    // Returns the total price calculated from options and variant.
    return (optionTotal + variantPrice * state.quantity) / 100;
  }),

  setIsEditing: action((state, payload) => {
    state.isEditing = payload;
  }),

  // actions
  saveCurrentProduct: action((state, payload) => {
    state.data = payload;
  }),
  setPurchaseNote: action((state, payload) => {
    state.purchaseNote = payload;
  }),
  setIsLoadingFormFields: action((state, payload) => {
    state.isLoadingFormFields = payload;
  }),
  setFormFields: action((state, payload) => {
    state.formFields = payload;
  }),
  updateOptions: action((state, payload) => {
    state.options = state.options.concat(payload);
  }),
  setLocatedScanId: action((state, payload) => {
    state.locatedScanId = payload;
  }),
  setSingleVariantProductDetails: action((state, payload) => {
    state.variantId = payload.id;
    state.singleVariantPricing = payload.price / 100;
  }),
  resetSelectedOptions: action((state, payload) => {
    state.selectedOptions = [];
    state.variantId = '';
  }),
  updateSelectedOptions: action((state, payload) => {
    var removeByAttr = function(arr, attr, value) {
      var i = arr.length;
      while (i--) {
        if (
          arr[i] &&
          arr[i].hasOwnProperty(attr) &&
          (arguments.length > 2 && arr[i][attr] === value)
        ) {
          arr.splice(i, 1);
        }
      }
      return arr;
    };

    let tempOptions = removeByAttr(
      state.selectedOptions,
      'title',
      payload.title
    );

    state.selectedOptions = tempOptions.concat(payload);
  }),
  setVariantId: action((state, payload) => {
    state.variantId = payload;
  }),
  selectVariant: action((state, payload) => {
    state.data.variants = state.data.variants.map((variant, index) => {
      if (index == payload) {
        return {
          ...variant,
          isSelected: !variant.isSelected
        };
      } else {
        return {
          ...variant,
          isSelected: false
        };
      }
    });
  }),

  setProductListComponentId: action((state, payload) => {
    state.productListComponentId = payload;
  }),

  // TODO: Could be moved to VariantList, try it out!
  variantLists: select((state) => {
    if (state.data) {
      const variantLabels = state.data.variants[0].variantDetails.map(
        (variantDetail) => variantDetail.variantLabel
      );

      const _variantLists = variantLabels.map((variantLabel) => {
        const duplicatedValues = state.data.variants
          .map((variant) => {
            const relevantVariantDetails = variant.variantDetails
              .filter(
                (variantDetail) => variantDetail.variantLabel == variantLabel
              )
              .map((variantDetail) => {
                const _variantDetail = {
                  value: variantDetail.variantValue,
                  isSelected: variant.isSelected
                };

                return _variantDetail;
              });

            return relevantVariantDetails;
          })
          .map(([variant]) => variant);

        const values = duplicatedValues.reduce(
          (variantDetails, variantDetail) => {
            // 1. kolla igenom variantDetails och se om den redan har variantDetail addad
            // 2. om inte, lägg till variant detail där isSelected == true har prioritet för att läggas till
            const isVariantValueIncluded = variantDetails
              .map(R.prop('value'))
              .includes(variantDetail.value);

            if (isVariantValueIncluded) {
              return variantDetails;
            } else {
              const selectedVariantDetail = R.find(
                ({ isSelected, value }) =>
                  isSelected && value == variantDetail.value,
                duplicatedValues
              );

              if (selectedVariantDetail) {
                return [...variantDetails, selectedVariantDetail];
              } else {
                return [...variantDetails, variantDetail];
              }
            }
          },
          []
        );

        return {
          label: variantLabel,
          values: values
        };
      });

      return _variantLists;
    } else {
      return [];
    }
  }),
  selectCurrentProduct: thunk(
    async (actions, payload, { getStoreState, dispatch }) => {
      const productType = payload.type;

      actions.resetSelectedOptions();

      console.log('Select current product payload: ', payload);

      if (productType === 'cartItem') {
        console.log("It's a cart item: ", payload.productGroupId);
        await dispatch.products.fetch(payload.productGroupId);

        const products = getStoreState().products.list;

        if (!R.isEmpty(products)) {
          const _product = products.find(
            (product) => product.id === payload.productId
          );

          const optionSets = _product.optionSets.map((optionSet) => {
            return {
              ...optionSet,
              options: optionSet.options.map((option) => {
                return {
                  ...option,
                  isSelected: payload.options
                    .map(R.prop('id'))
                    .includes(option.id)
                };
              })
            };
          });

          const variants = _product.variants.map((variant) => {
            return {
              ...variant,
              isSelected: variant.id == payload.productVariantId
            };
          });

          const product = {
            ..._product,
            optionSets,
            variants
          };

          actions.saveCurrentProduct(product);
        }
      } else {
        const product = getStoreState().products.list[payload.index];
        actions.saveCurrentProduct(product);
      }
    }
  ),
  fetchFields: thunk(async (actions, payload, { getStoreState, dispatch }) => {
    const endpoint = API_URL + 'skiply-schprod/consentform/' + payload.formId;

    console.log('Endpoint: ', endpoint);

    console.log('Payload for Conset Form: ', payload);

    const response = await axios({
      method: 'get',
      url: endpoint,
      params: { beneficiaryId: payload.beneficiaryId },
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Fetch consent form success response:', response);
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Fetch consent form error response:', error);
        return response;
      });

    return response;
  }),

  saveConsentForm: thunk(async (_actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-schprod/consentform';

    const response = await axios({
      method: 'post',
      url: endpoint,
      data: payload,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Save consent form success response', response);
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Save consent form error response:', error.response);
        return response;
      });

    return response;
  }),

  saveOrUpdateCartItem: thunk(
    async (_actions, payload, { getStoreState, getState, dispatch }) => {
      const carts = getStoreState().cart.carts;
      const cart = carts[0];
      const duplicate =
        cart &&
        cart.cartItems.find(
          (cartItem) => cartItem.productVariantId == payload.variantId
        );

      if (duplicate) {
        const quantity = getState().isEditing
          ? duplicate.quantity
          : duplicate.quantity + payload.quantity;
        return await dispatch.cart.updateCartItem({
          ...payload,
          id: duplicate.id,
          quantity
        });
      } else {
        return await dispatch.cart.saveCartItem(payload);
      }
    }
  ),

  addToCart: thunk(
    async (_actions, _payload, { dispatch, getStoreState, getState }) => {
      const options = getState()
        .selectedOptions.map((option) => {
          return (option = option.options).map((option, i) => {
            if (option.name === 'Enter Amount') {
              return (option = {
                optionId: option.id,
                customPaymentAdjust: option.paymentAdjust
              });
            } else {
              return (option = {
                optionId: option.id
              });
            }
          });
        })
        .flat(2);

      const item = {
        cartId:
          getStoreState().cart.carts.length > 0
            ? getStoreState().cart.carts[0].cartId
            : null,
        locatedScanId: getState().locatedScanId,
        quantity: getState().quantity,
        variantId: getState().variantId,
        selectedOptions: options, // change this
        beneficiaryId: getStoreState().student.beneficiaryId, // change this
        purchaseNote: getState().purchaseNote
          ? getState().purchaseNote
          : 'Placeholder Note.'
      };

      console.log('ITEM:', item);

      return await dispatch.currentProduct.saveOrUpdateCartItem(item);
    }
  ),
  updatePurchaseNote: thunk((actions, payload) => {
    actions.setPurchaseNote(payload);
  })
};

export default currentProduct;

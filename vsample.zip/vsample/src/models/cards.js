import { action, thunk } from 'easy-peasy';
import axios from 'axios';
import R from 'ramda';
import { API_URL, API_KEY } from 'components/../config';
import SecureAPI from '../crypto/SecureAPI';
import firebase from 'react-native-firebase';

const Cards = {
  items: [],
  isLoading: false,
  errorMessage: '',
  isScanned: false,

  // actions
  fetched: action((state, payload) => {
    state.items = payload;
  }),
  saved: action((state, payload) => {
    state.items.push(payload);
  }),
  deleted: action((state, payload) => {
    state.items = state.items.filter(({ id }) => id != payload);
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),
  storeUpdate: action((state, payload) => {
    state.items = state.items.map((item) => {
      if (item.id == payload.id) {
        return {
          ...item,
          ...payload
        };
      } else {
        return item;
      }
    });
  }),
  isScanned: action((state) => {
    state.isScanned = true;
  }),

  // thunks
  fetchCards: thunk(async (actions, payload, { getStoreState }) => {
    // actions.setIsLoading(true);
    // const endpoint = API_URL + 'skiply-wallet/wallet/cards';
    // let headers = {
    //   'Content-Type': 'application/json',
    //   'X-Auth-Token': getStoreState().session.token
    // };
    // let api = new SecureAPI();
    // api.request(
    //   endpoint, 'GET', headers, undefined, (responseString) => {

    //     actions.setIsLoading(false);

    //     let response = JSON.parse(responseString);
    //     if (response === null || response === undefined || response == '') {
    //       actions.setErrorMessage('Unable to parse response JSON.');
    //     }
    //     else {
    //       if (response.body != null && response.body.userAccessToken !== undefined) {
    //         actions.fetched(response.body.list);
    //         actions.setErrorMessage('');
    //       }
    //       else {

    //         // TODO: Handle Errors from Server
    //         actions.setErrorMessage("An error has occurred. Please try again.");
    //       }
    //     }
    //   },
    //   (error) => {
    //     actions.setIsLoading(false);
    //     actions.setErrorMessage(error);
    //   });

    const endpoint = API_URL + 'skiply-wallet/wallet/cards';
    actions.setIsLoading(true);
    await axios({
      method: 'get',
      url: endpoint,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then((response) => {
        actions.setIsLoading(false);
        actions.fetched(response.data.body.list.sort((a, b) => a.id - b.id));
        actions.setErrorMessage('');
      })
      .catch((error) => {
        actions.setIsLoading(false);
        console.log(error);
        actions.setErrorMessage(error.message);
      });
  }),

  save: thunk(async (actions, payload, { getStoreState }) => {
    const panLens = R.lensProp('pan');
    const trimmedPayload = R.set(panLens, R.trim(payload.pan), payload);
    const endpoint = API_URL + 'skiply-wallet/wallet/cards';
    const headers = {
      'Content-Type': 'application/json',
      'X-Auth-Token': getStoreState().session.token,
      Authorization: getStoreState().session.authorization,
      apikey: API_KEY
    };
    let api = new SecureAPI();

    const response = await api
      .request(endpoint, 'POST', headers, trimmedPayload)
      .then(async (response) => {
        firebase.analytics().logEvent('payment_method_added');

        await actions.fetchCards();

        return {
          success: true,
          data: response.body
        };
      })
      .catch((error) => {
        console.log('Error:', error);
        if (error.code !== 'Y') {
          return {
            success: false,
            message: error.internalMessage,
            errorCode: error.errorCode
          };
        } else {
          return {
            success: false,
            message: error
          };
        }
      });

    return response;

    // console.log(payload);

    // const endpoint = API_URL + 'skiply-wallet/wallet/cards';

    // actions.setIsLoading(true);

    // const panLens = R.lensProp('pan');
    // const data = R.set(panLens, R.trim(payload.pan), payload);

    // console.log('Card data', data);

    // return axios({
    //   method: 'post',
    //   url: endpoint,
    //   headers: {
    //     'X-Auth-Token': getStoreState().session.token
    //   },
    //   data
    // })
    //   .then((response) => {
    //     actions.saved(payload);
    //     actions.setIsLoading(false);
    //     actions.setErrorMessage('');
    //     actions.fetchCards();
    //   })
    //   .catch((error) => {
    //     console.log(error.response.data.status.internalMessage);
    //     actions.setErrorMessage(error.response.data.status.internalMessage);
    //     actions.setIsLoading(false);
    //   });
  }),

  update: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-wallet/wallet/cards';
    let headers = {
      'Content-Type': 'application/json',
      'X-Auth-Token': getStoreState().session.token,
      Authorization: getStoreState().session.authorization,
      apikey: API_KEY
    };
    let api = new SecureAPI();

    actions.storeUpdate(payload);

    const response = await api
      .request(endpoint, 'PUT', headers, payload)
      .then((response) => {
        return {
          success: true,
          data: response.body
        };
      })
      .catch((error) => {
        console.log('Error:', error);

        actions.fetchCards();

        if (error.code !== 'Y') {
          return {
            success: false,
            message: error.message,
            errorCode: error.errorCode
          };
        } else {
          return {
            success: false,
            message: error
          };
        }
      });

    actions.fetchCards();

    return response;

    // const endpoint = API_URL + 'skiply-wallet/wallet/cards';

    // actions.setIsLoading(true);

    // console.log('Update card with payload:', payload);

    // await axios({
    //   method: 'put',
    //   url: endpoint,
    //   headers: {
    //     'X-Auth-Token': getStoreState().session.token
    //   },
    //   data: payload
    // })
    //   .then((response) => {
    //     console.log('Update card response:', response);
    //     actions.setErrorMessage('');
    //     actions.fetchCards();
    //   })
    //   .catch((error) => {
    //     console.log('Update card error:', error);
    //     actions.setErrorMessage(error.message);
    //   });

    // actions.setIsLoading(false);
  }),

  delete: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + `skiply-wallet/wallet/cards/${payload}`;
    let headers = {
      'Content-Type': 'application/json',
      'X-Auth-Token': getStoreState().session.token,
      Authorization: getStoreState().session.authorization,
      apikey: API_KEY
    };
    let api = new SecureAPI();

    actions.deleted(payload);

    const response = await api
      .request(endpoint, 'DELETE', headers, payload)
      .then((response) => {
        return {
          success: true,
          data: response.body
        };
      })
      .catch((error) => {
        console.log('Error:', error);

        actions.fetchCards();

        if (error.code !== 'Y') {
          return {
            success: false,
            message: error.message,
            errorCode: error.errorCode
          };
        } else {
          return {
            success: false,
            message: error
          };
        }
      });

    return response;

    // actions.setIsLoading(true);
    // console.log('Delete card with id:', payload);
    // await axios({
    //   method: 'delete',
    //   url: endpoint,
    //   headers: {
    //     'X-Auth-Token': getStoreState().session.token
    //   }
    // })
    //   .then((response) => {
    //     console.log('Delete card response:', response);
    //     actions.setErrorMessage('');
    //     actions.deleted(payload);
    //   })
    //   .catch((error) => {
    //     console.log('Delete card error:', error);
    //     actions.setErrorMessage(error.message);
    //   });

    // actions.setIsLoading(false);
  })
};

export default Cards;

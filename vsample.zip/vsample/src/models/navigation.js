import { action } from 'easy-peasy';

const Navigation = {
  currentNavigationComponent: {},

  // actions
  setCurrentNavigationComponent: action((state, payload) => {
    if (!payload.passProps.isOverlayComponent) {
      state.currentNavigationComponent = payload;
    }
  })
};

export default Navigation;

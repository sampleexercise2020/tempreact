import React from 'react';
import { storiesOf } from '@storybook/react-native';
import AddMethod from './AddMethod/';
import EditMethod from './EditMethod/';
import Methods from './Methods/';
import ScanCard from './ScanCard/';

// TODO: Get notes working.

storiesOf('Modules|Account/Payments', module)
  .add('Cards overview/start', () => <Methods />)
  .add('Add Method', () => <AddMethod />)
  .add('Edit Card', () => <EditMethod />)
  .add('Scan Card', () => (
    <ScanCard
      title='Scan Card'
      subtext='Position your card in the marked area. It will scan automatically'
    />
  ));

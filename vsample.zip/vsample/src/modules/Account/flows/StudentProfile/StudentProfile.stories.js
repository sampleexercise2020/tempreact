import React from 'react';
import { storiesOf } from '@storybook/react-native';
import EditProfile from './EditProfile/';
import ViewProfile from './ViewProfile/';

// TODO: Get notes working.

const mockStudent = {
  id: '5d03b76a5251780001fa8320',
  lastName: 'Fgj',
  firstName: 'Rg',
  image: null,
  studentRegisterCustomFieldValues: [
    {
      bcfdValue: 'One',
      updateRequiredMessage: null,
      bcfdName: 'Year',
      bcfdType: null
    },
    {
      bcfdValue: 'Red',
      updateRequiredMessage: null,
      bcfdName: 'Class',
      bcfdType: null
    },
    {
      bcfdValue: 'Dfv',
      updateRequiredMessage: null,
      bcfdName: 'Student ID',
      bcfdType: null
    },
    {
      bcfdValue: 'Grade 1',
      updateRequiredMessage: null,
      bcfdName: 'Grade',
      bcfdType: null
    },
    {
      bcfdValue: 'Dch',
      updateRequiredMessage: null,
      bcfdName: 'ParentID',
      bcfdType: null
    }
  ],
  gender: 'F',
  merchantId: '387943',
  middleName: null,
  parentEmailAddress: null,
  otpRequired: false,
  studentId: null,
  enabled: false,
  mcBeneficiaryId: '566183',
  userId: 'tester02@wipro.com',
  grade: null,
  division: null,
  dateOfBirth: null,
  nationality: null,
  studentConfigId: null,
  primaryMobileNum: 0,
  emergencyMobileNum: 0,
  address: null,
  schoolName: null,
  createdDate: '2019-06-14T15:04:09.918',
  updatedDate: '2019-06-14T15:04:09.918',
  createdBy: null,
  updatedBy: null
};

// String, Int, Dropdown custom fields.

storiesOf('Modules|Account/StudentProfile', module)
  .add('Edit StudentProfile', () => <EditProfile student={mockStudent} />)
  .add('View Student Profile', () => <ViewProfile student={mockStudent} />);

import React, { useEffect, useState } from 'react';
import { Animated, Alert } from 'react-native';
import styled from 'styled-components/native';
import { Navigation } from 'react-native-navigation';
import { useActions, useStore } from 'easy-peasy';
import { Formik } from 'formik';
import Button from 'components/common/Button/Button';
import FormInput from 'components/common/Input/FormInput';
import ProfileImage from 'components/common/ProfileImage/ProfileImage';
import CollapsibleHeader from '../../../../../components/common/Header/CollapsibleHeader';
import * as yup from 'yup';
import NavigationButton from 'components/common/TopBar/NavigationButton';
import { popToPrevious } from 'navigation';
import { testProperties } from 'helpers/testProperties';
import LoaderContainer from 'components/common/LoaderContainer';
import R from 'ramda';

const backArrowButton = require('../../../../../../assets/icons/common/back_arrow_big.png');

const StudentUpdateSchema = yup.object().shape({
  firstName: yup
    .string()
    .required('Please enter first name to continue.')
    .matches(
      /^[a-zA-Z\s]+$/,
      'Invalid first name due to the number or special character used.'
    ),
  lastName: yup
    .string()
    .required('Please enter last name to continue.')
    .matches(
      /^[a-zA-Z\s]+$/,
      'Invalid last name due to the number or special character used.'
    )
});

const EditStudentProfile = ({ studentId, componentId }) => {
  const updateProfile = useActions((actions) => actions.student.updateProfile);
  const savedStudents = useStore((state) => state.student.lists.saved);
  const isLoading = useStore((state) => state.student.isLoading);
  const [isLoadingCustomFields, setIsLoadingCustomFields] = useState(false);
  const [customFields, setCustomFields] = useState([]);
  const [customFieldsNames, setCustomFieldsNames] = useState({});
  const sessionExpire = useActions((actions) => actions.session.expire);

  const student = savedStudents.find((student) => {
    return studentId === student.id;
  });

  const fetchCustomFields = useActions(
    (actions) => actions.merchant.fetchCustomFieldsEditStudent
  );
  const makeStudentRegisterCustomFieldValue = (name, value) => {
    return {
      bcfdName: name,
      bcfdValue: value
    };
  };
  const makePreStudentRegisterCustomFieldValues = (customFields) => {
    var getBcfdNames = R.pluck('bcfdName');
    var getBcfdValues = R.pluck('bcfdValue');
    const fieldNames = getBcfdNames(customFields);
    const fieldValues = getBcfdValues(customFields);
    return R.zipObj(fieldNames, fieldValues);
  };
  const getGrade = (studentRegisterCustomFieldValues) => {
    var grades = '';
    if (
      !(
        studentRegisterCustomFieldValues === null ||
        studentRegisterCustomFieldValues === undefined ||
        studentRegisterCustomFieldValues === ''
      )
    ) {
      var i;
      for (i = 0; i < studentRegisterCustomFieldValues.length; i++) {
        if (
          studentRegisterCustomFieldValues[i].bcfdName.toLowerCase() == 'grade'
        ) {
          grades = studentRegisterCustomFieldValues[i].bcfdValue;
          break;
        }
      }
      return grades;
    }
  };
  /**
   * Updates student profile with new student payload
   * @param {Object} student Skiply student object
   */
  const makeStudentRegisterCustomFieldValues = (customFieldsNames) => {
    const fieldNames = R.keys(customFieldsNames);
    const fieldValues = R.values(customFieldsNames);
    return R.zipWith(
      makeStudentRegisterCustomFieldValue,
      fieldNames,
      fieldValues
    );
  };
  async function handleSubmit(student) {
    console.log('Submit edit profile with:', student);
    try {
      const studentRegisterCustomFieldValues = makeStudentRegisterCustomFieldValues(
        student.customFieldsNames
      );
      console.log(
        'console custom fields selected ',
        studentRegisterCustomFieldValues
      );
      const manualStudent = {
        ...student,
        studentRegisterCustomFieldValues,
        grade: getGrade(studentRegisterCustomFieldValues)
      };
      console.log(
        'student register custom field values with all student',
        manualStudent
      );
      const updateResponse = await updateProfile(manualStudent);
      console.log('student update successfully', updateResponse);
      if (updateResponse) {
        Navigation.pop(componentId);
        Alert.alert('Student profile has been updated successfully.', '', [
          { text: 'OK', onPress: () => {} }
        ]);
      }
    } catch (error) {
      if (error.status === 401 || error.status === 403) {
        sessionExpire();
      } else {
        Alert.alert(
          'Failed to update student',
          'Something went wrong while updating student profile. Please try again.',
          [{ text: 'OK', onPress: () => {} }]
        );
      }
    }
  }
  const fetchCustomFieldsWithLoader = async () => {
    setIsLoadingCustomFields(true);

    const response = await fetchCustomFields(student.merchantId);

    if (response.status == 200) {
      console.log('response from fetch custom field is ', response);
      setCustomFieldsNames(
        makePreStudentRegisterCustomFieldValues(
          student.studentRegisterCustomFieldValues
        )
      );
      setCustomFields(response.data.list);
    } else if (response.status == 401 || response.status == 403) {
      sessionExpire();
    } else {
      popToPrevious(componentId);
    }

    setIsLoadingCustomFields(false);
  };

  useEffect(() => {
    fetchCustomFieldsWithLoader();
  }, []);

  /**
   * Renders formik errors if there are any
   * @param {Object} props Formik props
   */
  function renderErrors(props) {
    if (!R.isEmpty(props.errors)) {
      return (
        <ErrorMessageContainer
          {...testProperties('student-edit-profile-error-message-container')}
        >
          {props.errors.firstName ? (
            <ErrorMessage>{props.errors.firstName}</ErrorMessage>
          ) : null}
          {props.errors.lastName ? (
            <ErrorMessage>{props.errors.lastName}</ErrorMessage>
          ) : null}
        </ErrorMessageContainer>
      );
    }
  }

  return (
    <Formik
      initialValues={{
        ...student,
        customFieldsNames: {},
        customFields: {}
      }}
      onSubmit={handleSubmit}
      enableReinitialize
      validationSchema={StudentUpdateSchema}
    >
      {(props) => (
        <CollapsibleHeader
          shouldScale={true}
          extendedHeight={252}
          collapsedHeight={50}
          isCurved={true}
          bigContent={
            <ProfileImage
              image={student.image}
              title={student.firstName + ' ' + student.lastName}
              name={student.firstName + ' ' + student.lastName}
              editMode={true}
              studentId={student.id}
            />
          }
          hasTitleBar={true}
          titleBarIconLeft={
            <NavigationButton
              icon={backArrowButton}
              onPress={() => Navigation.pop(componentId)}
              {...testProperties('edit-profile-back-arrow-button-id')}
            />
          }
        >
          <Container
            keyboardShouldPersistTaps='never'
            as={Animated.ScrollView}
            {...testProperties('edit-profile-container-id')}
          >
            <FormContainer>
              <LoaderContainer isLoading={isLoadingCustomFields}>
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label='First Name'
                  keyboardType='default'
                  returnKeyType='go'
                  matches={/[a-zA-Z]+/}
                  maxLength={15}
                  value={props.values.firstName}
                  onChangeText={props.handleChange('firstName')}
                  onBlur={props.handleBlur('firstName')}
                  testProperties={testProperties(
                    'edit-profile-firstname-input-id'
                  )}
                />
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label='Last Name'
                  keyboardType='default'
                  matches={/[a-zA-Z]+/}
                  returnKeyType='go'
                  maxLength={15}
                  value={props.values.lastName}
                  onChangeText={props.handleChange('lastName')}
                  onBlur={props.handleBlur('lastName')}
                  testProperties={testProperties(
                    'edit-profile-lastname-input-id'
                  )}
                />
                {customFieldsNames &&
                  customFields.map(({ label, name, type, options }, index) => {
                    const _options =
                      options &&
                      options.map((option) => ({
                        label: option,
                        value: option
                      }));

                    return (
                      <FormInput
                        key={name}
                        numberOfLines={1}
                        logo={false}
                        label={label}
                        keyboardType='default'
                        type={type}
                        options={_options}
                        returnKeyType='go'
                        value={props.values.customFieldsNames[name]}
                        onChangeText={props.handleChange(
                          `customFieldsNames[${name}]`
                        )}
                        onBlur={props.handleBlur(`customFieldsNames[${name}]`)}
                        testProperties={testProperties(
                          'edit-profile-bcfdname-input-id'
                        )}
                      />
                    );
                  })}
              </LoaderContainer>
            </FormContainer>
            {renderErrors(props)}
            <ButtonContainer>
              <Button
                outline
                disabled={!props.isValid}
                onPress={props.handleSubmit}
                isLoading={isLoading}
                testProperties={testProperties(
                  'edit-profile-button-handle-submit-id'
                )}
              >
                Update profile
              </Button>
            </ButtonContainer>
          </Container>
        </CollapsibleHeader>
      )}
    </Formik>
  );
};

export default EditStudentProfile;

const Container = styled.ScrollView`
  height: 100%;
`;

const FormContainer = styled.View`
  margin: 0px 20px 20px 20px;
  background-color: #f5f5f7;
  padding: 15px;
  padding-bottom: 5px;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
`;

const ErrorMessageContainer = styled.View`
  justify-content: center;
  align-items: center;
  margin-bottom: 10px;
`;

const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  line-height: 22px;
  font-weight: normal;
`;

const ButtonContainer = styled.View`
  margin: 0 20px;
`;

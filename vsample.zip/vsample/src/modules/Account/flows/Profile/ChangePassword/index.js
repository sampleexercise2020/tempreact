import React, { useState } from 'react';
import { Alert } from 'react-native';
import styled from 'styled-components/native';
import { Navigation } from 'react-native-navigation';
import { root, loginRoot } from 'src/../navigation/root';
import { useActions, useStoreState } from 'easy-peasy';
import Button from 'components/common/Button/Button';
import FormInput from 'components/common/Input/FormInput';
import { Formik } from 'formik';
import * as yup from 'yup';
import { testProperties } from '../../../../../helpers/testProperties';
import { navigateTo } from '../../../../../navigation';
import BiometricManager from '../../../../../biometric/BiometricManager';

const CloseIcon = require('../../../../../../assets/icons/common/close.png');

// TODO: Actually send the update command to the API.

const UpdatePasswordSchema = yup.object().shape({
  currentPassword: yup
    .string()
    .required('Please enter your current password to continue.'),
  newPassword: yup
    .string()
    .required('Please enter new password to continue.')
    .min(8, 'Your password must have at least 8 characters.')
    .max(16, 'Your password cannot have more than 16 characters.')
    .matches(
      /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
      'Your password should contain alphabets, numbers and at least one special character and one capital letter.'
    ),
  newPasswordRepeated: yup
    .string()
    .required('Please enter repeat password to continue.')
    .oneOf(
      [yup.ref('newPassword'), null],
      'Your new password does not match with repeat password.'
    )
});

const ResetPasswordSchema = yup.object().shape({
  newPassword: yup
    .string()
    .required('Please enter new password to continue.')
    .min(8, 'Your password must have at least 8 characters.')
    .max(16, 'Your password cannot have more than 16 characters.')
    .matches(
      /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
      'Your password should contain alphabets, numbers and at least one special character and one capital letter.'
    ),
  newPasswordRepeated: yup
    .string()
    .required('Please enter repeat password to continue.')
    .oneOf(
      [yup.ref('newPassword'), null],
      'Your new password does not match with repeat password.'
    )
});

const ChangePassword = (props) => {
  Navigation.mergeOptions(props.componentId, {
    topBar: {
      visible: true,
      drawBehind: false,
      leftButtons: [],
      rightButtons: [
        {
          icon: CloseIcon,
          id: 'exitFlow'
        }
      ]
    }
  });

  const [showPassword, setShowPassword] = useState({
    old: true,
    new: true,
    repeat: true
  });

  const toggleShowPasswordOld = () => {
    setShowPassword({ ...showPassword, old: !showPassword.old });
  };
  const toggleShowPasswordNew = () => {
    setShowPassword({ ...showPassword, new: !showPassword.new });
  };
  const toggleShowPasswordRepeat = () => {
    setShowPassword({ ...showPassword, repeat: !showPassword.repeat });
  };

  const isLoading = useStoreState((state) => state.profile.isLoading);
  const errorMessage = useStoreState((state) => state.profile.errorMessage);
  const profile = useStoreState((state) => state.profile.data);
  const fetchdetails = useStoreState(
    (state) => state.session.resetPasswordFetchDetails
  );
  const token = useStoreState((state) => state.session.token);
  const updatePassword = useActions(
    (actions) => actions.profile.updatePassword
  );

  const sessionExpire = useActions((actions) => actions.session.expire);

  const handleSubmit = async ({ currentPassword, newPassword }) => {
    // TODO: Add logic to check if error or not before navigating.

    var params = null;
    if (props.oldPasswordRequired == true) {
      if (currentPassword == newPassword) {
        Alert.alert(
          'Invalid New Password',
          'Your new password cannot be same as your old password. Please try again.'
        );
        return;
      }
      params = {
        emailAddress: profile.emailAddress,
        oldPassword: currentPassword,
        newPassword
      };
    } else {
      params = {
        existingQkrUser: props.existingQkrUser,
        emailAddress: props.email,
        newPassword
      };
    }

    const response = await updatePassword(params);
    if (response.success) {
      Alert.alert(
        'Password Updated',
        'Your password has been updated successfully.',
        [
          {
            text: 'OK',
            onPress: () => {
              if (props.oldPasswordRequired == true) {
                BiometricManager.updatePassword(newPassword);
                Navigation.pop(props.componentId);
              } else {
                Navigation.setRoot({ root: loginRoot });
              }
            }
          }
        ]
      );
    } else {
      if (props.oldPasswordRequired == true) {
        if (response.message === 'Bad credentials') {
          Alert.alert(
            'Invalid Current Password',
            'Please try again with correct current password.',
            [{ text: 'OK', onPress: () => {} }]
          );
        } else {
          sessionExpire();
        }
      } else {
        Alert.alert(
          'Unable to Change Password',
          'Something went wrong while changing your password. Please try again.',
          [{ text: 'OK', onPress: () => {} }]
        );
      }
    }
  };

  return (
    <Formik
      initialValues={{
        newPassword: '',
        currentPassword: '',
        newPasswordRepeated: ''
      }}
      onSubmit={handleSubmit}
      enableReinitialize
      validationSchema={
        props.oldPasswordRequired ? UpdatePasswordSchema : ResetPasswordSchema
      }
      render={(formikProps) => (
        <Container {...testProperties('change-password-container-id')}>
          <InnerContainer keyboardShouldPersistTaps='never'>
            <FormContainer>
              {console.log('Prop old password req: ', props)}
              {props.oldPasswordRequired == true ? (
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label='Current Password'
                  keyboardType='default'
                  returnKeyType='go'
                  value={formikProps.values.currentPassword}
                  onChangeText={formikProps.handleChange('currentPassword')}
                  onBlur={formikProps.handleBlur('currentPassword')}
                  toggleShowPassword={toggleShowPasswordOld}
                  secureTextEntry={showPassword.old}
                  showPW={true}
                  showPWText={showPassword.old ? 'Show' : 'Hide'}
                  testProperties={testProperties('current-password-input-id')}
                />
              ) : null}
              <FormInput
                numberOfLines={1}
                logo={false}
                label='New password'
                keyboardType='default'
                returnKeyType='go'
                onChangeText={formikProps.handleChange('newPassword')}
                onBlur={formikProps.handleBlur('newPassword')}
                value={formikProps.values.newPassword}
                toggleShowPassword={toggleShowPasswordNew}
                secureTextEntry={showPassword.new}
                showPW={true}
                showPWText={showPassword.new ? 'Show' : 'Hide'}
                testProperties={testProperties('new-password-input-id')}
              />
              <FormInput
                numberOfLines={1}
                logo={false}
                label='Repeat password'
                keyboardType='default'
                returnKeyType='go'
                value={formikProps.values.newPasswordRepeated}
                onChangeText={formikProps.handleChange('newPasswordRepeated')}
                onBlur={formikProps.handleBlur('newPasswordRepeated')}
                toggleShowPassword={toggleShowPasswordRepeat}
                secureTextEntry={showPassword.repeat}
                showPW={true}
                showPWText={showPassword.repeat ? 'Show' : 'Hide'}
                testProperties={testProperties('repeat-password-input-id')}
              />
            </FormContainer>
          </InnerContainer>
          <ErrorMessageContainer
            {...testProperties('change-password-error-message-container')}
          >
            <ErrorMessage>{formikProps.errors.currentPassword}</ErrorMessage>
            <ErrorMessage>{formikProps.errors.newPassword}</ErrorMessage>
            <ErrorMessage>
              {formikProps.errors.newPasswordRepeated}
            </ErrorMessage>
          </ErrorMessageContainer>
          <ButtonContainer>
            <Button
              outline={!isLoading}
              onPress={formikProps.handleSubmit}
              testProperties={testProperties(
                'change-password-handle-submit-button-id'
              )}
              disabled={isLoading}
            >
              Update password
            </Button>
          </ButtonContainer>
        </Container>
      )}
    />
  );
};

export default ChangePassword;

const Container = styled.View`
  flex: 1;
  margin-bottom: 20px;
  margin-top: 20px;
`;

const InnerContainer = styled.ScrollView`
  flex: 1;
`;

const RadioContainer = styled.TouchableOpacity`
  display: flex;
  flex-direction: row;
  margin-left: 20px;
  margin-bottom: 20px;
  align-items: center;
`;

const RadioText = styled.Text`
  margin-left: 20px;
  color: #36235e;
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
`;

const FormContainer = styled.View`
  margin: 0px 20px 20px 20px;
  background-color: #f5f5f7;
  padding: 15px;
  padding-bottom: 5px;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
`;

const FormContainerNickName = styled.View`
  margin: 0px 20px 20px 20px;
  background-color: #f5f5f7;
  padding: 15px;
  padding-bottom: 5px;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
`;

const NickNameTitle = styled.Text`
  margin-bottom: 20px;
  margin-left: 20px;
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  font-weight: bold;
  color: #0d1943;
`;

const ErrorMessageContainer = styled.View`
  justify-content: center;
  align-items: center;
  margin-bottom: 10px;
`;

const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  line-height: 22px;
  font-weight: normal;
`;

const ButtonContainer = styled.View`
  margin: 0 20px;
`;

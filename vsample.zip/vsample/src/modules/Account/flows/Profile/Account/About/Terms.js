import React from 'react';
import styled from 'styled-components/native';
import { TermsAndConditionList } from './TermsConstant.js';

const MarkedList = ({ key, body }) => (
  <ListElement key={key}>
    <ListMark>
      <BodyText>{key}</BodyText>
    </ListMark>
    <ListBody>
      <Paragraph>{body}</Paragraph>
    </ListBody>
  </ListElement>
);

const TermList = ({ key, title, body, withList }) => (
  <TNCItem>
    <TitleContainer>
      <Number>{key}.</Number>
      <ParagraphHeader>{title}</ParagraphHeader>
    </TitleContainer>
    <TNCBody>
      <Paragraph>{body}</Paragraph>
      {withList && withList.map(MarkedList)}
    </TNCBody>
  </TNCItem>
);

const Terms = () => {
  return (
    <Container
      resource-id='account-terms-container-id'
      testID='account-terms-container-id'
    >
      <TNCWrapper>
        <TNCItem>
          <ParagraphTop>
            These Skiply User Terms and Conditions (
            <TextBold>"Terms and Conditions"</TextBold>) are binding between
            each Skiply user (“you”) and The National Bank of Ras Al Khaimah
            (P.S.C) (<TextBold>"RAKBANK"</TextBold>). By downloading,
            installing, accessing or using Skiply (the "Application" or
            “Skiply”), a software application that allows you to order and
            purchase products or services from Skiply-enabled merchants (“Skiply
            Merchants”), you agree to comply with and will be bound by these
            Terms and Conditions. If you do not agree to these Terms and
            Conditions, RAKBANK does not grant you any right to use or access
            the Application. In such event, you should not download, install,
            access, use or copy the Application or any content located therein.
          </ParagraphTop>
        </TNCItem>
        {TermsAndConditionList.map(TermList)}
      </TNCWrapper>
    </Container>
  );
};

export default Terms;

const Container = styled.ScrollView`
  flex: 1;
`;

const TNCWrapper = styled.View`
  padding: 30px 20px 20px 20px;
`;

const BodyText = styled.Text``;

const TNCItem = styled.View`
  margin-bottom: 20px;
`;

const TNCBody = styled.View``;

const Number = styled.Text`
  font-family: TeshrinAR-Bold;
  width: 20px;
  flex-direction: row;
`;

const TitleContainer = styled.View`
  flex-direction: row;
  margin-bottom: 3px;
`;

const ParagraphHeader = styled.Text`
  font-family: TeshrinAR-Bold;
  padding-right: 20px;
`;

const Paragraph = styled.Text`
  padding-left: 20px;
`;

const ParagraphTop = styled.Text`
  padding: 0 10px 15px 10px;
`;

const TextBold = styled.Text`
  font-weight: bold;
`;

const ListElement = styled.View`
  flex: 1;
  flex-direction: row;
  margin-top: 6px;
`;

const ListMark = styled.View`
  width: 20;
  margin-left: 30px;
`;

const ListBody = styled.View`
  flex-grow: 1;
  flex-shrink: 1;
  padding-top: 3px;
  margin-left: -10px;
`;

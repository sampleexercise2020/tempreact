import React from 'react';
import styled from 'styled-components/native';
import { FAQParagraphs } from './FAQParagraphs';

const MarkedList = ({ key, bulletPoint }) => (
  <ListElement key={key}>
    <ListBody>
      <ListParagraph>• {bulletPoint}</ListParagraph>
    </ListBody>
  </ListElement>
);

const FAQList = ({ key, title, body, withList }) => (
  <FAQItem>
    <TitleContainer>
      <Number>{key}.</Number>
      <ParagraphHeader>{title}</ParagraphHeader>
    </TitleContainer>
    <FAQBody>
      <Paragraph>{body}</Paragraph>
      {withList && withList.map(MarkedList)}
    </FAQBody>
  </FAQItem>
);

const WhatsNew = () => {
  return (
    <Container
      resource-id='account-terms-container-id'
      testID='account-terms-container-id'
    >
      <FAQWrapper>{FAQParagraphs.map(FAQList)}</FAQWrapper>
    </Container>
  );
};

export default WhatsNew;

const Container = styled.ScrollView`
  flex: 1;
`;

const FAQWrapper = styled.View`
  padding: 30px 20px 20px 20px;
`;

const FAQItem = styled.View`
  margin-bottom: 20px;
`;

const FAQBody = styled.View``;

const Paragraph = styled.Text`
  padding-left: 20px;
`;

const ListParagraph = styled.Text``;

const Number = styled.Text`
  font-family: TeshrinAR-Bold;
  width: 20px;
  flex-direction: row;
`;

const TitleContainer = styled.View`
  flex-direction: row;
  margin-bottom: 3px;
`;

const ParagraphHeader = styled.Text`
  font-family: TeshrinAR-Bold;
  padding-right: 20px;
`;

const ListElement = styled.View`
  flex: 1;
  flex-direction: row;
  margin-top: 3px;
`;

const ListBody = styled.View`
  flex-grow: 1;
  flex-shrink: 1;
  padding-left: 35px;
  padding-top: 3px;
`;

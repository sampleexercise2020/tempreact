import React, { useEffect } from 'react';
import { Linking } from 'react-native';
import styled from 'styled-components/native';
import Button from 'components/common/Button/Button';

const Notifications = ({ componentId }) => {
  return (
    <Container
      resource-id='account-notifications-container-id'
      testID='account-notifications-container-id'
    >
      <BodyText>Notification settings WIP</BodyText>
    </Container>
  );
};

export default Notifications;

const Container = styled.View`
  flex: 1;
  margin: 20px;
`;
const BodyText = styled.Text`
  margin-bottom: 40px;
`;

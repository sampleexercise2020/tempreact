import React, { useState, useEffect } from 'react';
import styled from 'styled-components/native';
import { useStoreState } from 'easy-peasy';
import SettingListItem from 'components/common/ListItem/SettingListItem';
import BiometricManager from 'biometric/BiometricManager';
import { AsyncStorage } from 'react-native';

const TouchId = (props) => {
  const email = useStoreState((state) => state.session.emailAddress);
  const password = useStoreState((state) => state.session.password);

  const [toggleValue, setToggleValue] = useState(props.isEnabled);

  async function handleToggle(isEnabled) {
    setToggleValue(isEnabled);

    if (isEnabled) {
      await showEnableBiometricsPrompt();
    } else {
      await resetBiometricLogin();
    }

    const value = await AsyncStorage.getItem('bio_login_require');

    console.log('bio_login_require value: ', value);
  }

  async function resetBiometricLogin() {
    return await AsyncStorage.multiSet([
      ['bio_login_require', 'false'],
      ['bio_email', ''],
      ['bio_password', '']
    ]).catch(() => console.log('Error when saving data'));
  }

  function showEnableBiometricsPrompt() {
    return BiometricManager.showEnableOptionsFor(email, password).catch(
      (error) => {
        console.log('Biometric Error: ', error);
      }
    );
  }

  return (
    <Container
      resource-id='account-touchid-container-id'
      testID='account-touchid-container-id'
    >
      <SettingListItem
        text={props.biometryType}
        toggleValue={toggleValue}
        toggle={handleToggle}
      />
    </Container>
  );
};

export default TouchId;

const Container = styled.View`
  flex: 1;
  margin: 20px;
`;

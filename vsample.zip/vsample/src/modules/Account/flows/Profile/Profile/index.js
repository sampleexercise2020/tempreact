import React from 'react';
import { Animated, Alert } from 'react-native';
import styled from 'styled-components/native';
import { Navigation } from 'react-native-navigation';
import { navigateTo } from 'navigation';
import { useStore, useActions } from 'easy-peasy';
import { root, loginRoot } from 'src/../../src/navigation/root';
import CollapsibleHeader from 'components/common/Header/CollapsibleHeader';
import ProfileInfoListItem from 'components/common/ListItem/ProfileInfoListItem';
import Button from 'components/common/Button/Button';
import ProfileImage from 'components/common/ProfileImage/ProfileImage';
import NavigationButton from 'components/common/TopBar/NavigationButton';
import selectedCopy from '../../../../../i18n/copy';
import { testProperties } from '../../../../../helpers/testProperties';
import BiometricManager from '../../../../../biometric/BiometricManager';

const copy =
  selectedCopy.components.modules.Account.flows.Profile.Profile.index;

const backArrowButton = require('../../../../../../assets/icons/common/back_arrow_big.png');
const editButton = require('../../../../../../assets/icons/common/edit-white.png');

const ProfileInfoList = (props) => {
  const profile = useStore((state) => state.profile.data);
  console.log('Profile', profile);

  const username = useStore((state) => state.profile.data.emailAddress);
  const deleteUser = useActions((actions) => actions.profile.deleteUser);
  const logout = useActions((actions) => actions.session.logout);
  const clearCart = useActions((actions) => actions.cart.clearCart);
  const sessionExpire = useActions((actions) => actions.session.expire);
  const setDidShowAutoDetectedStudents = useActions(
    (actions) => actions.student.setDidShowAutoDetectedStudents
  );

  const handleDeleteUser = () => {
    Alert.alert('Confirm', 'Please confirm, you want to delete your account.', [
      {
        text: 'Yes',
        onPress: async () => {
          const response = await deleteUser({});
          if (response.status === 200) {
            BiometricManager.removeBiometricLogin();
            logout();
            clearCart();
            setDidShowAutoDetectedStudents(false);
            Navigation.setRoot({ root: loginRoot });
          } else if (response.status == 401 || response.status == 403) {
            sessionExpire();
          } else {
            Alert.alert(
              'Unable to Delete Profile',
              'Something went wrong while deleting profile. Please try again.',
              [{ text: 'OK', onPress: () => {} }]
            );
          }
        }
      },
      { text: 'No', onPress: () => {} }
    ]);
  };

  const navigateToEditProfile = () => {
    navigateTo('Skiply.Account.Profile.EditProfile', props.componentId);
  };

  const navigateToChangePassword = () => {
    navigateTo(
      'Skiply.Account.Profile.MyProfile.ChangePassword',
      props.componentId,
      {
        oldPasswordRequired: true
      }
    );
  };
  return (
    <CollapsibleHeader
      shouldScale={true}
      extendedHeight={252}
      collapsedHeight={50}
      isCurved={true}
      bigContent={
        <ProfileImage
          image={profile.profilePhotoUrl}
          title={profile.firstName + ' ' + profile.lastName}
          name={profile.firstName + ' ' + profile.lastName}
          editMode={false}
        />
      }
      hasTitleBar={true}
      titleBarIconRight={
        <NavigationButton
          icon={editButton}
          onPress={navigateToEditProfile}
          {...testProperties('profile-edit-profile-button-id')}
        />
      }
      titleBarIconLeft={
        <NavigationButton
          icon={backArrowButton}
          onPress={() => Navigation.pop(props.componentId)}
          {...testProperties('profile-back-arrow-button-id')}
        />
      }
    >
      <Container
        as={Animated.ScrollView}
        {...testProperties('profile-container-id')}
      >
        <Content>
          <ProfileInfoListItem
            label={copy.name}
            inputField={profile.firstName + ' ' + profile.lastName}
          />
          <ProfileInfoListItem
            label={copy.phone}
            inputField={
              '+' + profile.phoneNumberCountryCode + ' ' + profile.phoneNumber
            }
          />
          <ProfileInfoListItem
            label={copy.mail}
            inputField={profile.emailAddress}
          />
          <ProfileInfoListItem
            passwordItem
            label={copy.password}
            inputField='xxxxxxxx'
            isPassword
            onPress={navigateToChangePassword}
          />
          <Margin />
          <ButtonContainer>
            <Button children={copy.deleteAccount} onPress={handleDeleteUser} />
          </ButtonContainer>
        </Content>
      </Container>
    </CollapsibleHeader>
  );
};

export default ProfileInfoList;

const Container = styled.ScrollView`
  height: 100%;
`;

const Content = styled.View`
  padding-bottom: 30px;
`;

const Margin = styled.View`
  margin-bottom: 40px;
`;

const ButtonContainer = styled.View`
  margin: 0 20px;
`;

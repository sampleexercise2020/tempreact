import React, { useEffect, useState } from 'react';
import { Animated, Alert } from 'react-native';
import styled from 'styled-components/native';
import { Navigation } from 'react-native-navigation';
import { useActions, useStore } from 'easy-peasy';
import Button from 'components/common/Button/Button';
import FormInput from 'components/common/Input/FormInput';
import { Formik } from 'formik';
import * as yup from 'yup';
import ProfileImage from 'components/common/ProfileImage/ProfileImage';
import NavigationButton from 'components/common/TopBar/NavigationButton';
import CollapsibleHeader from 'components/common/Header/CollapsibleHeader';
import { testProperties } from '../../../../../helpers/testProperties';
import { Platform } from 'react-native';
import CountryCodeForm from '../../../../LoginAndSignup/flows/Signup/components/CountryCodeForm';

const backArrowButton = require('../../../../../../assets/icons/common/back-arrow.png');

// TODO: Actually send the update command to the API.

const UpdateProfileSchema = yup.object().shape({
  firstName: yup
    .string()
    .required('Please enter your first name to continue.')
    .matches(
      /^[a-zA-Z\s]+$/,
      'Invalid first name due to the number or special character used.'
    ),
  lastName: yup
    .string()
    .required('Please enter your last name to continue.')
    .matches(
      /^[a-zA-Z\s]+$/,
      'Invalid last name due to the number or special character used.'
    ),
  phoneNumber: yup
    .string()
    .required('Please enter your mobile number to continue.')
    .min(9, 'Your phone number has to contain a minimum of 9 digits ')
});

const EditProfile = (props) => {
  const profile = useStore((state) => state.profile.data);
  const [isUpdating, setIsUpdating] = useState(false);
  const [countryCode, setCountryCode] = useState(
    '+' + profile.phoneNumberCountryCode
  );
  const updateProfile = useActions((actions) => actions.profile.update);
  const sessionExpire = useActions((actions) => actions.session.expire);

  const handleSubmit = async ({
    firstName,
    lastName,
    phoneNumber,
    emailAddress,
    address
  }) => {
    setIsUpdating(true);

    const response = await updateProfile({
      ...profile,
      firstName,
      lastName,
      phoneNumber,
      emailAddress,
      phoneNumberCountryCode: parseInt(countryCode)
    });
    if (response.success) {
      Navigation.pop(props.componentId);
      Alert.alert('Updated profile', 'Your profile has now been updated.', [
        { text: 'OK', onPress: () => console.log('Ok pressed') }
      ]);
    } else {
      if (response.errorCode === 401 || response.errorCode === 403) {
        sessionExpire();
      } else {
        Alert.alert(
          'Unable to Update Profile',
          'Something went wrong while updating profile. Please try again.',
          [{ text: 'OK', onPress: () => {} }]
        );
      }
    }

    setIsUpdating(false);
  };

  const removeFirstZeroFromInputField = (string = '') => {
    const regex = /^0$/;

    return string.replace(regex, '');
  };

  useEffect(() => {
    console.log('Country Code: ', countryCode);
  }, [countryCode]);

  console.log('Country Code: ', countryCode);
  console.log('Edit Profile: ', profile);

  return (
    <CollapsibleHeader
      shouldScale={true}
      extendedHeight={252}
      collapsedHeight={50}
      isCurved={true}
      bigContent={
        <ProfileImage
          image={profile.profilePhotoUrl}
          title={profile.firstName + ' ' + profile.lastName}
          name={profile.firstName + ' ' + profile.lastName}
          editMode={true}
        />
      }
      hasTitleBar={true}
      titleBarIconLeft={
        <NavigationButton
          icon={backArrowButton}
          onPress={() => Navigation.pop(props.componentId)}
          {...testProperties('header-back-button-id')}
        />
      }
    >
      <Container
        as={Animated.ScrollView}
        {...testProperties('edit-profile-container-id')}
      >
        <Formik
          initialValues={{
            emailAddress: profile.emailAddress,
            firstName: profile.firstName,
            lastName: profile.lastName,
            phoneNumber: profile.phoneNumber,
            phoneNumberCountryCode: profile.phoneNumberCountryCode
          }}
          onSubmit={handleSubmit}
          enableReinitialize
          validationSchema={UpdateProfileSchema}
          validateOnBlur={false}
          validateOnChange={false}
        >
          {(props) => (
            <>
              <FormContainer>
                <CountryCodeForm
                  content-desc='edit-profile-phone-input-id'
                  {...testProperties('edit-profile-phone-input-id')}
                  numberOfLines={1}
                  logo={false}
                  label='Phone Number'
                  keyboardType='numeric'
                  returnKeyType='go'
                  matches={/^((?!(0))[0-9])/}
                  maxLength={10}
                  onChangeText={props.handleChange('phoneNumber')}
                  onBlur={props.handleBlur('phoneNumber')}
                  value={removeFirstZeroFromInputField(
                    props.values.phoneNumber
                  )}
                  setCountryCode={setCountryCode}
                  defaultCountryCode={countryCode}
                />
              </FormContainer>

              <FormContainer
                keyboardDismissMode='on-drag'
                keyboardShouldPersistTaps='never'
              >
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label='First name'
                  keyboardType='default'
                  returnKeyType='go'
                  value={props.values.firstName}
                  maxLength={31}
                  onChangeText={props.handleChange('firstName')}
                  onBlur={props.handleBlur('firstName')}
                  testProperties={testProperties('edit-profile-first-name-id')}
                />
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label='Last name'
                  keyboardType='default'
                  returnKeyType='go'
                  value={props.values.lastName}
                  maxLength={31}
                  onChangeText={props.handleChange('lastName')}
                  onBlur={props.handleBlur('lastName')}
                  testProperties={testProperties('edit-profile-last-name-id')}
                />
                {/* <FormInput
                  numberOfLines={1}
                  logo={false}
                  label='Phone Number'
                  keyboardType='numeric'
                  returnKeyType='go'
                  maxLength={13}
                  onChangeText={props.handleChange('phoneNumber')}
                  onBlur={props.handleBlur('phoneNumber')}
                  value={props.values.phoneNumber}
                  testProperties={testProperties('edit-profile-phonenumber-id')}
                /> */}
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label='Email'
                  keyboardType='email-address'
                  returnKeyType='go'
                  value={props.values.emailAddress}
                  onChangeText={props.handleChange('emailAddress')}
                  onBlur={props.handleBlur('emailAddress')}
                  editable={false}
                  testProperties={testProperties('edit-profile-email-id')}
                />
              </FormContainer>
              <ErrorMessageContainer
                {...testProperties('edit-profile-error-message-container')}
              >
                {props.errors.firstName && (
                  <ErrorMessage>{props.errors.firstName}</ErrorMessage>
                )}
                {props.errors.lastName && (
                  <ErrorMessage>{props.errors.lastName}</ErrorMessage>
                )}
                {props.errors.phoneNumber && (
                  <ErrorMessage>{props.errors.phoneNumber}</ErrorMessage>
                )}
                {props.errors.emailAddress && (
                  <ErrorMessage>{props.errors.emailAddress}</ErrorMessage>
                )}
              </ErrorMessageContainer>
              <ButtonContainer ios={Platform.OS === 'ios'}>
                {console.log(props.values)}
                <Button
                  outline
                  onPress={props.handleSubmit}
                  isLoading={isUpdating}
                  disabled={
                    profile.firstName == props.values.firstName &&
                    profile.lastName == props.values.lastName &&
                    profile.phoneNumber == props.values.phoneNumber
                  }
                  testProperties={testProperties(
                    'edit-profile-handle-submit-button-id'
                  )}
                >
                  Update profile
                </Button>
              </ButtonContainer>
            </>
          )}
        </Formik>
      </Container>
    </CollapsibleHeader>
  );
};

export default EditProfile;

const Container = styled.ScrollView`
  height: 100%;
`;

const FormContainer = styled.View`
  margin: 0px 20px 0px 20px;

  background-color: #f5f5f7;
  padding: 15px 15px 5px;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
`;

const ErrorMessageContainer = styled.View`
  justify-content: center;
  align-items: center;
  padding-bottom: 10px;
`;

const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  font-weight: normal;
  margin-bottom: 5px;
`;

const ButtonContainer = styled.View`
  padding: 10px 20px 20px;
  background: #ffffff;
  padding-bottom: ${(props) => (props.ios ? '60px' : '30px')};
`;

import React, { useEffect } from 'react';
import { Platform } from 'react-native';
import { useStore } from 'easy-peasy';
import { Navigation } from 'react-native-navigation';
import styled, { css } from 'styled-components/native';
import Button from '../../../components/common/Button/Button';
import { navigateTo, popToRoot } from 'navigation';
import R from 'ramda';
import { testProperties } from '../../../helpers/testProperties';

const background = require('../../../../assets/backgrounds/school.png');

const Home = ({ componentId }) => {
  const navigateToHome = () => {
    popToRoot(componentId);
  };

  const navigateSchoolSearch = () => {
    navigateTo('Skiply.Discover.School.SearchSchool', componentId);
  };

  const navigateToTakeATour = () => {
    navigateTo('Skiply.Onboarding.Slider', componentId, {
      onClose: navigateToHome
    });
  };

  return (
    <Container {...testProperties('home-schoolpayment-card-container-id')}>
      <Background source={background} />
      <InnerContainer>
        <SchoolsTitle {...testProperties('home-schoolpayment-card-title-id')}>
          School payments made easy
        </SchoolsTitle>
        <Button
          allWhite
          onPress={navigateSchoolSearch}
          {...testProperties('home-schoolpayment-card-button-id')}
        >
          Add students and schools
        </Button>
        <Margin />
        {/* <LearnMore>Learn more</LearnMore> */}
      </InnerContainer>
      <BottomInfo
        onPress={navigateToTakeATour}
        {...testProperties('home-schoolpayment-card-link-id')}
      >
        <BottomText {...testProperties('home-schoolpayment-card-subtitle-id')}>
          Take a tour!
        </BottomText>
      </BottomInfo>
    </Container>
  );
};

const Container = styled.View`
  overflow: hidden;
  border-top-left-radius: 40px;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 40px;
  border-bottom-left-radius: 4px;
  margin: 15px 20px;
  background-color: #2f78dc;
`;
const InnerContainer = styled.View`
  margin: 40px 20px 0 20px;
`;
const Margin = styled.View`
  margin: 10px 0;
`;
const BottomInfo = styled.TouchableOpacity`
  background-color: #1e549a;
  position: relative;
`;
const BottomText = styled.Text`
  color: rgb(255, 255, 255);
  font-size: 14px;
  font-family: 'OpenSans-SemiBold';
  font-weight: 600;
  text-align: center;
  margin-top: 16px;
  margin-bottom: 20px;
`;

const SchoolsTitle = styled.Text`
  width: 100%;
  color: rgb(255, 255, 255);
  font-size: 32px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  line-height: 40px;
  margin-bottom: 30px;
`;

// const LearnMore = styled.Text`
//   color: rgb(255, 255, 255);
//   font-size: 14px;
//   font-family: 'OpenSans-SemiBold';
//   font-weight: 600;
//   text-align: center;
//   margin-top: 16px;
//   margin-bottom: 20px;
// `;

const Background = styled.Image`
  position: absolute;
  width: 100%;
  width: 100%;
  top: 0;
  left: 0;
`;

export default Home;

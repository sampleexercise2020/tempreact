import React from 'react';
import { storiesOf } from '@storybook/react-native';
import SchoolPaymentCard from './SchoolPaymentCard';

// TODO: Get notes working.

storiesOf('Modules|Home/Content Cards/School Payment Card', module)
  .add('Basic Card', () => <SchoolPaymentCard />)
  .add('Student Found', () => <SchoolPaymentCard StudentsFound />);

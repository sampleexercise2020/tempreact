import React from 'react';
import styled from 'styled-components/native';

const rocket = require('../../../assets/images/discover_rocket.png');

const EmptyDiscover = (props) => {
  return (
    <Container>
      <RocketImage source={rocket} />
      <Title>Watch this space</Title>
      <Subtitle>
        We have great plans for Skiply. Soon you will be able to discover more
        ways to skipping the line.
      </Subtitle>
    </Container>
  );
};

export default EmptyDiscover;

const Container = styled.View`
  flex: 1;
  margin: 0 60px;
  justify-content: center;
  align-items: center;
`;

const Title = styled.Text`
  color: #0d1943;
  font-size: 16px;
  font-weight: bold;
  font-family: 'OpenSans-Bold';
  text-align: center;
  margin-bottom: 5px;
  margin-top: 40px;
`;

const Subtitle = styled.Text`
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  line-height: 18px;
  text-align: center;
  color: #0d1943;
`;

const RocketImage = styled.Image`
  height: 121px;
  width: 121px;
`;

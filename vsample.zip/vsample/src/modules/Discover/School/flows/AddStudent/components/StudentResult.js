import React, { useState, useEffect } from 'react';
import { Alert, Animated, Platform } from 'react-native';
import { useActions, useStore } from 'easy-peasy';
import styled from 'styled-components/native';
import SchoolHeader from './SchoolHeader';
import StudentInfo from 'components/common/ListItem/StudentInfo';
import Button from 'components/common/Button/Button';
import NotCorrectStudent from '../components/NotCorrectStudent';
import StudentLoader from '../components/StudentLoader';
import ImagePicker from 'react-native-image-picker';

const Checkmark = require('src/../../assets/images/checkmark.png');
import selectedCopy from 'i18n/copy';
import { navigateTo } from 'navigation';

const copy =
  selectedCopy.components.modules.Discover.School.flows.AddStudent
    .StudentResults;

// TODO fix copy here

const StudentResult = ({
  btnText,
  school,
  merchant,
  notCorrect,
  isLoading,
  dismissBtnText,
  dismissBtn,
  student,
  componentId,
  index,
  isSaved,
  isAutodetected
}) => {
  const [errorMessage, setErrorMessage] = useState('');
  const [loadAddedView, setLoadAddedView] = useState(false);
  const [uploadedPhoto, setUploadedPhoto] = useState(false);
  const [uploadedImageURL, setUploadedImageURL] = useState(false);
  const [animation, setAnimated] = useState(new Animated.Value(1));
  const profile = useStore(({ profile }) => profile.data);
  const [isAdded, setIsAdded] = useState(isSaved);
  const saveStudent = useActions(({ student }) => student.save);
  const [isAdding, setIsAdding] = useState(false);
  const fetchStudentProfiles = useActions(
    ({ student }) => student.fetchStudentProfiles
  );
  const ActionUploadStudentProfilePicture = useActions(
    ({ student }) => student.uploadProfilePicture
  );
  // const schoolName = useStore((state) => { return state.merchant.data.name; });

  const manuallyAddedStudentPayload = {
    firstName: student.firstName,
    lastName: student.lastName,
    middleName: student.middleName,
    gender: student.gender,
    grade: student.grade,
    merchantId: student.merchantId,
    schoolName: student.schoolName,
    schoolStudentId: null,
    schoolProvidedData: false,
    otpRequired: school.otpRequired,
    userId: profile.emailAddress,
    studentRegisterCustomFieldValues: student.studentRegisterCustomFieldValues
  };

  const searchResultStudentPayload = {
    address: student.address,
    dateOfBirth: student.dateOfBirth,
    division: student.division,
    firstName: student.firstName,
    gender: student.gender == 'Female' ? 'F' : 'M',
    grade: student.grade,
    lastName: student.lastName,
    merchantId: student.merchantId,
    middleName: student.middleName,
    nationality: student.nationality,
    otpRequired: school.otpRequired,
    parentEmailAddress: student.emailId1,
    primaryMobileNum: student.primaryMobileNum,
    schoolName: school.name,
    schoolProvidedData: true,
    schoolStudentId: student.studentId,
    userId: profile.emailAddress
  };

  /**
   * Starts the animation when the student is added
   */
  useEffect(
    function startAnimation() {
      if (isAdded) {
        Animated.timing(animation, { toValue: 0, duration: 1500 }).start();
        setLoadAddedView(true);
      }
    },
    [isAdded]
  );

  /**
   * Handles disabling the "Student added" overlay after the given time
   */
  useEffect(
    function handleLoadAddedView() {
      console.log('Student: ', student);
      if (loadAddedView) {
        const timer = setTimeout(() => {
          setLoadAddedView(false);
        }, 1500);

        return () => clearTimeout(timer);
      }
    },
    [loadAddedView]
  );

  /**
   * Gets the payload depending if the school provided the data or if it was
   * entered manually by the user using the school provided fields.
   */
  function getStudentPayload() {
    if (!school.schoolDataProvided && !isAutodetected) {
      return manuallyAddedStudentPayload;
    } else {
      return searchResultStudentPayload;
    }
  }

  /**
   * Navigate to Verify student screen containing the OTP input
   * @param {Object} response
   */
  function navigateToVerifyStudent(response) {
    navigateTo('Skiply.Discover.School.VerifyStudent', componentId, {
      ...response.data,
      primaryMobileNum: student.primaryMobileNum,
      userId: profile.emailAddress,
      index,
      setIsAdded
    });
  }

  /**
   * Adds (saves) a student OR navigates to the verification screen where the
   * user will get a SMS containing an OTP in order for the student to be saved.
   */
  async function addStudent() {
    setIsAdding(true);
    setErrorMessage('');

    const studentPayload = getStudentPayload();
    const payload = { ...studentPayload, index };
    console.log('PAYLOAD:', studentPayload);
    const savedStudentResponse = await saveStudent(payload);

    if (savedStudentResponse.status == 200) {
      if (studentPayload.otpRequired) {
        navigateToVerifyStudent(savedStudentResponse);
      } else {
        setIsAdded(true);
      }
    } else {
      setErrorMessage(savedStudentResponse.message);
    }

    setIsAdding(false);
  }

  /**
   * Create form data
   * @todo @kevin help me out with some minor docs here
   * @param {Object} photo
   * @param {Object} body
   */
  function createFormData(photo, body) {
    const data = new FormData();

    data.append('image', {
      name: photo.fileName,
      type: photo.type,
      uri:
        Platform.OS === 'android' ? photo.uri : photo.uri.replace('file://', '')
    });

    Object.keys(body).forEach((key) => {
      data.append(key, body[key]);
    });
    return data;
  }

  /**
   * Uploads the student profile picture and fetches all studentprofiles anew
   */
  function uploadStudentProfilePicture(response) {
    ActionUploadStudentProfilePicture(
      createFormData(response, { studentId: student.id })
    )
      .then((response) => {
        console.log('Image upload response: ', response);
        Alert.alert('Upload photo', 'Successful.');
        setUploadedPhoto(response.data.body.imageUrl);
        fetchStudentProfiles();
      })
      .catch(() =>
        Alert.alert(
          'Error',
          'Something went wrong when trying to upload a photo. Please try again.'
        )
      );
  }

  /**
   * Handles the photo upload/capturing logic
   */
  async function handleChoosePhoto() {
    const options = {
      quality: 1,
      maxWidth: 500,
      maxHeight: 500
    };

    try {
      await ImagePicker.showImagePicker(options, (response) => {
        console.log('Response = ', response);

        if (response.didCancel) {
          console.log('User cancelled photo picker');
        } else if (response.error) {
          console.log('ImagePicker Error: ', response.error);
        } else if (response.customButton) {
          console.log('User tapped custom button: ', response.customButton);
        } else {
          uploadStudentProfilePicture(response);
        }
      });
    } catch {
      Alert.alert(
        'Error',
        'Something went wrong when trying to upload a photo. Please try again.'
      );
    }
  }

  return (
    <Container>
      <SchoolHeader
        isLight
        schoolName={school.name}
        schoolAddress={school.address}
        schoolImageUrl={merchant && merchant.icon ? merchant.icon : ''}
        hideArrow={true}
      />
      <Outer>
        {loadAddedView ? (
          <Animated.View style={{ opacity: animation }}>
            <IsAddedContainer>
              <Inner>
                <Image source={Checkmark} />
              </Inner>
              <Title>{student.firstName} added.</Title>
            </IsAddedContainer>
          </Animated.View>
        ) : (
          <>
            <StudentInfo
              firstName={student.firstName}
              lastName={student.lastName}
              schoolGrade={student.grade || student.Grade}
              schoolClass={student.class || student.Class}
              image={uploadedPhoto || student.image}
              smallIcon={false}
              dark={true}
            />
            {(isSaved || isAdded) && !uploadedPhoto && (
              <ProfileButton>
                <Button allWhite onPress={handleChoosePhoto}>
                  Upload profile photo
                </Button>
              </ProfileButton>
            )}
          </>
        )}
      </Outer>
      {errorMessage ? <ErrorContainer>{errorMessage}</ErrorContainer> : null}
      {!isAdded && !isSaved && (
        <OuterBtn>
          <Button
            primary
            disabled={isAdding}
            error={errorMessage}
            onPress={addStudent}
            isLoading={isAdding}
          >
            {btnText}
          </Button>
          {dismissBtn ? (
            <InnerBtn>
              <Button isLoading={isAdding} secondary>
                {dismissBtnText}
              </Button>
            </InnerBtn>
          ) : null}
        </OuterBtn>
      )}
      {notCorrect ? <NotCorrectStudent /> : null}
      {isLoading ? <StudentLoader /> : null}
    </Container>
  );
};

const Container = styled.View`
  flex-direction: column;
  background-color: #f5f5f7;
  margin: 10px 20px;
  border-radius: 4px;
`;

const MarginButton = styled(Button)`
  margin: 10px;
  background-color: red;
`;

const Outer = styled.View`
  margin: 20px;
`;

const OuterBtn = styled.View`
  margin-bottom: 20px;
  padding: 0 20px;
`;

const InnerBtn = styled.View`
  margin-top: 10px;
`;

const ErrorContainer = styled.Text`
  color: red;
  text-align: center;
  margin-bottom: 10px;
`;

const Inner = styled.View`
  align-items: center;
  justify-content: center;
  width: 60px;
  height: 60px;
  border-radius: 30px;
  background-color: #ffffff;
  margin: 25px 0 10px 0;
`;

const Image = styled.Image`
  height: 22px;
  width: 28px;
`;

const Title = styled.Text`
  color: rgb(13, 25, 67);
  font-family: OpenSans-Bold;
  font-size: 16px;
  letter-spacing: 0px;
  line-height: 22px;
  margin-bottom: 25px;
`;

const IsAddedContainer = styled.View`
  flex-direction: column;
  align-items: center;
`;
const ProfileButton = styled.View`
  margin-top: 15px;
`;

export default StudentResult;

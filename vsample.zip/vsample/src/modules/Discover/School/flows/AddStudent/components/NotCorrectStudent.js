import React from 'react';
import styled from 'styled-components/native';

import selectedCopy from '../../../../../../i18n/copy';

const copy =
  selectedCopy.components.modules.Discover.School.flows.AddStudent.components
    .NotCorrectStudent;

const NotCorrectStudent = (props) => {
  return (
    <Container>
      <NotStudent>{copy.notCorrect}</NotStudent>
    </Container>
  );
};

export default NotCorrectStudent;

const NotStudent = styled.Text`
  color: rgb(64, 44, 168);
  font-family: OpenSans-SemiBold;
  font-size: 12px;
  text-align: center;
`;
const Container = styled.View`
  justify-content: center;
  align-items: center;
  margin: -5px 0 15px 0;
`;

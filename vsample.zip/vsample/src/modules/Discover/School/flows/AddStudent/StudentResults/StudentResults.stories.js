import React from 'react';
import { storiesOf } from '@storybook/react-native';
import StudentResults from './StudentResults';

const mockData_1 = [
  {
    schoolName: 'Skiply School of Excellence DSO',
    schoolAddress: 'Silicon Oasis, Dubai, UAE',
    grade: 'Kindergarden A',
    name: 'Sarah Andersson'
  }
];

const mockData_2 = [
  {
    schoolName: 'Brilliant Int School',
    schoolAddress: '152 adress, Dubai',
    grade: 'Kindergarden A',
    name: 'Sarah Andersson'
  },
  {
    schoolName: 'Brilliant Int School',
    schoolAddress: '152 adress, Dubai 2',
    grade: 'Kindergarden A',
    name: 'Joel Andersson'
  }
];

storiesOf('Modules|Discover/School/AddStudent/Student Results', module)
  .add('1 result', () => (
    <StudentResults
      btnText='Add & Verify'
      items='1 result'
      result={mockData_1}
    />
  ))
  .add('2 results', () => (
    <StudentResults
      btnText='Add & Verify'
      items='2 results'
      result={mockData_2}
    />
  ));

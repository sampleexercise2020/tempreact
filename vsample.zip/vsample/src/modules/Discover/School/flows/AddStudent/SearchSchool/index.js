import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Navigation } from 'react-native-navigation';
import { Platform, PermissionsAndroid, Text } from 'react-native';
import {
  useActions,
  useStore,
  useStoreActions,
  useStoreState
} from 'easy-peasy';
import styled from 'styled-components/native';
import {
  navigateTo,
  navigateToRoot,
  showOverlay,
  dismissOverlay
} from 'navigation';
import axios from 'axios';
import SearchBar from 'components/common/SearchBar';
import LoaderContainer from 'components/common/LoaderContainer';
import SchoolList from '../components/List/SchoolList';
import R from 'ramda';

import Button from 'components/common/Button/Button';
import { testProperties } from 'helpers/testProperties';

const makeSection = (data, title, id, type) => ({
  data,
  title,
  id,
  type
});

const FloatingBottomControls = ({ componentId, selectedSchool }) => {
  const merchantData = useStore((state) => state.merchant.data);

  const navigateAddStudentManually = async () => {
    if (merchantData && merchantData.schoolDataProvided) {
      navigateTo('Skiply.Discover.School.FindStudentById', componentId);
    } else {
      navigateTo('Skiply.Discover.School.AddStudentManually', componentId);
    }
  };

  return (
    <FloatingBottom
      elevation={5}
      style={{
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 7
        },
        shadowOpacity: 0.43,
        shadowRadius: 9.51,

        elevation: 15
      }}
    >
      <Button
        testProperties={testProperties(
          'discover-searchschool-nextstep-button-id'
        )}
        primary
        disabled={!selectedSchool}
        onPress={navigateAddStudentManually}
      >
        Next
      </Button>
    </FloatingBottom>
  );
};

const addSchoolToSection = (acc, curr) => {
  const currentSection = R.last(acc);
  const currentSchoolSectionTitle = R.head(R.toUpper(curr.name));

  if (currentSection && currentSchoolSectionTitle == currentSection.title) {
    const updatedSection = {
      ...currentSection,
      data: R.append(curr, currentSection.data)
    };

    return R.append(updatedSection, R.dropLast(1, acc));
  } else {
    const newSection = {
      title: currentSchoolSectionTitle,
      type: 'sectionHeader',
      data: [curr]
    };

    return R.append(newSection, acc);
  }
};

const makeSections = (schools) => {
  const sortByName = R.sortBy(R.prop('name'));
  const sortedSchools = sortByName(schools);

  return R.reduce(addSchoolToSection, [], sortedSchools);
};

const showAutoDetectedStudentsModal = (
  autoDetectedStudents,
  componentId,
  setStudentProfiles
) => {
  showOverlay(
    'Skiply.Modal.FullScreen',
    'MODAL_FULLSCREEN',
    makeAutodetectStudentsModalProps(
      autoDetectedStudents,
      componentId,
      setStudentProfiles
    )
  );
};

const makeAutodetectStudentsModalProps = (
  autodetectedStudents,
  searchSchoolComponentId,
  setStudentProfiles
) => {
  const titleText = `We found ${autodetectedStudents.length} student(s)`;
  const text = `We found ${
    autodetectedStudents.length
  } student(s) registered with your email. Do you want to add 
    them to Skiply to pay your tuition fees and more with ease?`;
  const buttonText = 'Yes, add now';
  const cancelText = 'Not now';

  const navigateToResults = async (componentId) => {
    try {
      await dismissOverlay(componentId);
      navigateTo(
        'Skiply.Discover.School.StudentResults',
        searchSchoolComponentId,
        {
          title: `${autodetectedStudents.length} results`,
          isAutodetected: true
        }
      );
    } catch (e) {
      console.log(e);
    }
  };

  const dismissModal = (componentId) => {
    setStudentProfiles({ type: 'results', value: [] });
    dismissOverlay(componentId);
  };

  return {
    title: true,
    titleText,
    text,
    buttonText,
    cancelText,
    onPressPrimaryButton: navigateToResults,
    onPressCancel: dismissModal
  };
};

const store = {
  storeSearchSchools: ({ searchResults }) => searchResults.search,
  setMerchant: (actions) => actions.merchant.setData,
  merchant: ({ merchant }) => merchant.data,
  setStudentProfiles: (actions) => actions.student.setStudentProfiles,
  setDidShowAutoDetectedStudents: ({ student }) =>
    student.setDidShowAutoDetectedStudents,
  setComponentId: ({ searchResults }) => searchResults.setComponentId,
  didShowAutoDetectedStudents: ({ student }) =>
    student.didShowAutoDetectedStudents,
  fetchAutodetectedStudentsByEmail: ({ student }) =>
    student.fetchAutodetectedStudentsByEmail
};

const SearchSchool = ({ componentId }) => {
  const [isLoadingSchools, setIsLoadingSchools] = useState(false);
  const [sections, setSections] = useState([]);
  const [navigationConstants, setNavigationConstants] = useState({});

  const call = useRef(null);

  const storeSearchSchools = useActions(store.storeSearchSchools);
  const setMerchant = useActions(store.setMerchant);
  const merchant = useStoreState(store.merchant);
  const setStudentProfiles = useStoreActions(store.setStudentProfiles);
  const setDidShowAutoDetectedStudents = useStoreActions(
    store.setDidShowAutoDetectedStudents
  );
  const setComponentId = useActions(store.setComponentId);
  const didShowAutoDetectedStudents = useStoreState(
    store.didShowAutoDetectedStudents
  );
  const fetchAutodetectedStudentsByEmail = useStoreActions(
    store.fetchAutodetectedStudentsByEmail
  );
  const sessionExpire = useActions((actions) => actions.session.expire);

  const aToZListHeader = {
    data: [],
    title: 'A-Z',
    type: 'listHeader',
    id: 'schoolsAToZ'
  };

  async function searchSchoolsAndFetchAutoDetect() {
    await setComponentId(componentId);
    await searchSchoolsAndSetSections();
    await fetchAndShowAutoDetectedStudents();
  }

  useEffect(function componentDidMount() {
    searchSchoolsAndFetchAutoDetect();
    getSetNavigationConstants();
  }, []);

  async function getSetNavigationConstants() {
    const constants = await Navigation.constants();
    setNavigationConstants(constants);
  }

  /**
   * If on Android, check if location premission is granted or request
   * fine location permission, otherwise, if we're on iOS then just
   * return true since location permission is enabled by default.
   */
  async function getHasFineLocationPermission() {
    if (Platform.OS == 'android') {
      const hasLocationPermission = await PermissionsAndroid.check(
        'ACCESS_FINE_LOCATION'
      );

      if (!hasLocationPermission) {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
        );
        const didGrantPermission =
          granted === PermissionsAndroid.RESULTS.GRANTED;
        return didGrantPermission;
      } else {
        return hasLocationPermission;
      }
    } else {
      return Platform.OS == 'ios';
    }
  }

  /**
   * Search schools, if no querystring is provided all schools including
   * autodetected nearby schools will be included in the search.
   * @param { queryString, longitute, latitude } payload
   */
  async function searchSchoolsAndSetSections(payload) {
    setIsLoadingSchools(true);

    const response = await searchSchools(payload);

    if (response.status == 200) {
      const sections = getListSections(response.data.list);

      setSections(sections);

      const hasFineLocationPermission = await getHasFineLocationPermission();

      if ((!payload || !payload.queryString) && hasFineLocationPermission) {
        await fetchPositionAndUpdateSectionsWithAutodetectedSchools(sections);
      }
    } else if (response.status == 401 || response.status == 403) {
      sessionExpire();
    }

    if (response.status !== 'cancelled') {
      setIsLoadingSchools(false);
    }
  }

  function makeSchoolsNearYouSection(data) {
    return makeSection(
      data,
      'Schools near you',
      'schoolsNearYou',
      'listHeader'
    );
  }

  function getListSections(schoolResults) {
    if (!R.isEmpty(schoolResults)) {
      const schoolSections = makeSections(schoolResults);
      return R.prepend(aToZListHeader, schoolSections);
    } else {
      return [];
    }
  }

  function fetchCurrentPosition() {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 10000
      });
    });
  }

  async function fetchPositionAndUpdateSectionsWithAutodetectedSchools(
    sections
  ) {
    return fetchCurrentPosition()
      .then(async (position) => {
        const payload = {
          latitude: position.coords.latitude.toPrecision(7),
          longitude: position.coords.longitude.toPrecision(7),
          queryString: ''
        };

        const response = await searchSchools(payload);

        if (response.status == 200) {
          updateSectionsWithAutodetectedSchools(response.data.list, sections);
        }
      })
      .catch((error) => {
        console.log('Fetch position error:', error);
      });
  }

  function updateSectionsWithAutodetectedSchools(
    autodetectedSchools,
    sections
  ) {
    const schoolsNearYouSection = makeSchoolsNearYouSection(
      autodetectedSchools
    );

    const firstSection = R.head(sections);

    if (firstSection.id !== 'schoolsNearYou') {
      setSections(R.prepend(schoolsNearYouSection, sections));
    } else {
      const updatedSchoolsNearYouSection = R.prop(
        'data',
        autodetectedSchools,
        firstSection
      );
      setSections(R.update(0, updatedSchoolsNearYouSection, sections));
    }
  }

  async function searchSchools(payload) {
    if (call.current) {
      call.current.cancel();
    }

    call.current = axios.CancelToken.source();

    const response = await storeSearchSchools({
      ...payload,
      call: call.current
    });

    if (response.status == 401) {
      sessionExpire();
    }

    return response;
  }

  async function fetchAndShowAutoDetectedStudents() {
    const autoDetectedStudents = await fetchAutodetectedStudentsByEmail();
    const didAutoDetectStudents =
      autoDetectedStudents && !R.isEmpty(autoDetectedStudents);

    if (!didShowAutoDetectedStudents && didAutoDetectStudents) {
      showAutoDetectedStudentsModal(
        autoDetectedStudents,
        componentId,
        setStudentProfiles
      );
      setDidShowAutoDetectedStudents(true);
    }
  }

  const emptyContent = (
    <Middle>
      <Text>No schools found</Text>
    </Middle>
  );

  const mainContent = (
    <ListContainer>
      <SchoolList
        {...testProperties('discover-searchschool-schoollist-id')}
        title='Schools near you'
        sections={sections}
        sendDataToParent={setMerchant}
      />
    </ListContainer>
  );

  function content() {
    const noSchools = R.isEmpty(sections);

    if (noSchools) {
      return emptyContent;
    } else {
      return mainContent;
    }
  }

  return (
    <Container
      behavior='padding'
      enabled={Platform.OS !== 'android'}
      keyboardVerticalOffset={
        navigationConstants.topBarHeight + navigationConstants.statusBarHeight
      }
      {...testProperties('discover-searchschool-searchcontainer-container-id')}
    >
      <SearchContainer>
        <SearchBar
          {...testProperties('discover-searchschool-searchbar-id')}
          placeholderText='Search school'
          onSubmit={searchSchoolsAndSetSections}
        />
      </SearchContainer>
      <LoaderContainer isLoading={isLoadingSchools}>
        {content()}
      </LoaderContainer>
      <FloatingBottomControls
        {...testProperties('discover-searchschool-FloatingBottomControls-id')}
        componentId={componentId}
        selectedSchool={merchant}
      />
    </Container>
  );
};

export default SearchSchool;

const Container = styled.KeyboardAvoidingView`
  flex: 1;
`;

const Content = styled.KeyboardAvoidingView`
  flex: 1;
`;

const FloatingBottom = styled.View`
  background-color: white;
  padding: 20px 20px 30px;
`;

const ListContainer = styled.View`
  flex-grow: 1;
  flex: 1;
`;

const Middle = styled.View`
  justify-content: center;
  align-items: center;
  flex: 1;
`;

const SearchContainer = styled.View`
  position: relative;
  background: #402ca8;
  padding: 20px 20px 20px;
`;

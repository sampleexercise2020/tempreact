import React, { useEffect, useState, useCallback } from 'react';
import { Navigation } from 'react-native-navigation';
import { Platform } from 'react-native';
import { useStore, useActions, useStoreActions } from 'easy-peasy';
import { ActivityIndicator, Alert } from 'react-native';
import styled, { css } from 'styled-components/native';
import { Formik } from 'formik';
import Button from 'components/common/Button/Button';
import SchoolInfo from '../components/SchoolInfo';
import FormInput from 'components/common/Input/FormInput';
import { useFloatingBottom } from 'components/FloatingBottom';
import { navigateTo, popToPrevious } from 'navigation';
import R from 'ramda';
import * as yup from 'yup';
import BackArrowIcon from 'src/../../assets/icons/common/back-arrow.png';
//TODO: Needs to change to a white close button.
import CloseIcon from 'src/../../assets/images/close.png';
import LoaderContainer from 'components/common/LoaderContainer';
import { testProperties } from 'helpers/testProperties';

let validateStudent = yup.object().shape({
  firstName: yup
    .string()
    .required('Please enter first name to continue.')
    .matches(
      /^[a-zA-Z\s]+$/,
      'Invalid first name due to the number or special character used.'
    )
    .max(15, 'First name is too long'),
  lastName: yup
    .string()
    .required('Please enter last name to continue.')
    .matches(
      /^[a-zA-Z\s]+$/,
      'Invalid last name due to the number or special character used.'
    )
    .max(15, 'Last name is too long'),
  gender: yup
    .string()
    .typeError('Please pick a gender.')
    .required('Please enter gender to continue.')
});

const FloatingBottomControls = ({
  errors,
  handleSubmit,
  componentId,
  touched
}) => {
  return (
    <FloatingBottom
      elevation={5}
      style={{
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 7
        },
        shadowOpacity: 0.43,
        shadowRadius: 9.51,

        elevation: 15
      }}
    >
      {errors && (
        <ErrorMessageContainer
          {...testProperties(
            'discover-addstudentmanually-error-message-container'
          )}
        >
          {errors.firstName && touched.firstName && (
            <ErrorMessage>{errors.firstName}</ErrorMessage>
          )}
          {errors.lastName && touched.lastName && (
            <ErrorMessage>{errors.lastName}</ErrorMessage>
          )}
          {errors.gender && touched.gender && (
            <ErrorMessage>{errors.gender}</ErrorMessage>
          )}
          {errors.grade && touched.grade && (
            <ErrorMessage>{errors.grade}</ErrorMessage>
          )}
        </ErrorMessageContainer>
      )}
      <Button
        testProperties={testProperties(
          'discover-addstudentmanually-nextstep-button-id'
        )}
        primary
        disabled={errors.name}
        onPress={handleSubmit}
      >
        Add
      </Button>
    </FloatingBottom>
  );
};

const AddStudentManually = ({ componentId }) => {
  const [isLoadingCustomFields, setIsLoadingCustomFields] = useState(false);
  const [customFields, setCustomFields] = useState([]);
  const [navigationConstants, setNavigationConstants] = useState({});
  const merchant = useStore((state) => state.merchant.data);
  const school = merchant.outlets && merchant.outlets[0];
  const schoolName = useStore((state) => state.merchant.data.name);
  const schoolIcon = useStore((state) => state.merchant.data.icon);
  const resetStudentResults = useStoreActions(
    ({ student }) => student.resetStudentResults
  );
  const appendManualStudent = useActions(
    (actions) => actions.student.appendManualStudent
  );

  const fetchCustomFields = useActions(
    ({ merchant }) => merchant.fetchCustomFields
  );

  const sessionExpire = useActions((actions) => actions.session.expire);

  useEffect(function componentDidMount() {
    getSetNavigationConstants();
  }, []);

  const makeStudentRegisterCustomFieldValue = (name, value) => {
    return {
      bcfdName: name,
      bcfdValue: value
    };
  };

  const makeStudentRegisterCustomFieldValues = (customFields) => {
    const fieldNames = R.keys(customFields);
    const fieldValues = R.values(customFields);

    return R.zipWith(
      makeStudentRegisterCustomFieldValue,
      fieldNames,
      fieldValues
    );
  };
  const getGrade = (studentRegisterCustomFieldValues) => {
    var grades = '';
    if (
      !(
        studentRegisterCustomFieldValues === null ||
        studentRegisterCustomFieldValues === undefined ||
        studentRegisterCustomFieldValues === ''
      )
    ) {
      var i;
      for (i = 0; i < studentRegisterCustomFieldValues.length; i++) {
        if (
          studentRegisterCustomFieldValues[i].bcfdName.toLowerCase() == 'grade'
        ) {
          grades = studentRegisterCustomFieldValues[i].bcfdValue;
          break;
        }
      }
      return grades;
    }
  };

  async function getSetNavigationConstants() {
    const constants = await Navigation.constants();
    setNavigationConstants(constants);
  }

  const handleSubmit = useCallback(
    ({ firstName, lastName, grade, gender, customFields }) => {
      const studentRegisterCustomFieldValues = makeStudentRegisterCustomFieldValues(
        customFields
      );

      const manualStudent = {
        ...customFields,
        firstName,
        lastName,
        gender,
        grade: getGrade(studentRegisterCustomFieldValues),
        merchantId: merchant.id,
        schoolName: schoolName,
        studentRegisterCustomFieldValues,
        isManuallyAdded: true
      };

      console.log('Manual student', manualStudent);

      resetStudentResults();
      appendManualStudent(manualStudent);
      navigateTo('Skiply.Discover.School.StudentResults', componentId);
    },
    []
  );

  const fetchCustomFieldsWithLoader = async () => {
    setIsLoadingCustomFields(true);

    const response = await fetchCustomFields();

    if (response.status == 200) {
      setCustomFields(response.data.list);
    } else if (response.status == 401 || response.status == 403) {
      sessionExpire();
    } else {
      popToPrevious(componentId);
    }

    setIsLoadingCustomFields(false);
  };

  useEffect(() => {
    fetchCustomFieldsWithLoader();
  }, []);

  return (
    <Formik
      initialValues={{
        firstName: '',
        lastName: '',
        gender: '',
        grade: '',
        customFields: {}
      }}
      validationSchema={validateStudent}
      onSubmit={handleSubmit}
      enableReinitialize
    >
      {(props) => {
        return (
          <Container
            behavior='padding'
            enabled={Platform.OS !== 'android'}
            keyboardVerticalOffset={
              navigationConstants.topBarHeight +
              navigationConstants.statusBarHeight
            }
            {...testProperties('discover-addstudentmanually-container-id')}
          >
            <Content>
              <HeaderText
                {...testProperties(
                  'discover-addstudentmanually-header-text-id'
                )}
              >
                Enter student info
              </HeaderText>
              <FormContainer>
                <BoxHead
                  {...testProperties('discover-addstudentmanually-boxhed-id')}
                >
                  <SchoolInfo
                    {...testProperties(
                      'discover-addstudentmanually-schoolinfo-id'
                    )}
                  />
                </BoxHead>
                <LoaderContainer isLoading={isLoadingCustomFields}>
                  <Form>
                    <FormInput
                      testProperties={testProperties(
                        'discover-addstudentmanually-firstname-input-id'
                      )}
                      numberOfLines={1}
                      logo={false}
                      maxLength={15}
                      label='First name'
                      keyboardType='default'
                      returnKeyType='go'
                      value={props.values.firstName}
                      onChangeText={props.handleChange('firstName')}
                      onBlur={props.setFieldTouched}
                      fieldName='firstName'
                    />
                    <FormInput
                      testProperties={testProperties(
                        'discover-addstudentmanually-lastname-input-id'
                      )}
                      numberOfLines={1}
                      logo={false}
                      maxLength={15}
                      label='Last name'
                      keyboardType='default'
                      returnKeyType='go'
                      value={props.values.lastName}
                      onChangeText={props.handleChange('lastName')}
                      onBlur={props.setFieldTouched}
                      fieldName='lastName'
                    />
                    <FormInput
                      testProperties={testProperties(
                        'discover-addstudentmanually-gender-input-id'
                      )}
                      numberOfLines={1}
                      logo={false}
                      label='Gender'
                      type='DROPDOWN'
                      options={[
                        {
                          label: 'Male',
                          value: 'M'
                        },
                        {
                          label: 'Female',
                          value: 'F'
                        }
                      ]}
                      keyboardType='default'
                      returnKeyType='go'
                      value={props.values.gender}
                      onChangeText={props.handleChange('gender')}
                      onBlur={props.setFieldTouched}
                      fieldName='gender'
                    />
                    {customFields.map(({ label, name, type, options }) => {
                      const _options =
                        options &&
                        options.map((option) => ({
                          label: option,
                          value: option
                        }));

                      return (
                        <FormInput
                          testProperties={testProperties(
                            'discover-addstudentmanually-default-input-id'
                          )}
                          numberOfLines={1}
                          logo={false}
                          label={label}
                          keyboardType='default'
                          type={type}
                          options={_options}
                          returnKeyType='go'
                          value={props.values.customFields[name]}
                          onChangeText={props.handleChange(
                            `customFields.${name}`
                          )}
                          onBlur={props.handleBlur(`customFields.${name}`)}
                        />
                      );
                    })}
                  </Form>
                </LoaderContainer>
              </FormContainer>
            </Content>
            {!isLoadingCustomFields && (
              <FloatingBottomControls
                errors={props.errors}
                componentId={props.componentId}
                handleSubmit={props.handleSubmit}
                touched={props.touched}
              />
            )}
          </Container>
        );
      }}
    </Formik>
  );
};

const Container = styled.KeyboardAvoidingView`
  flex: 1;
`;

const TitleBar = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  background: #2c1e75;
  height: 48px;
  width: 100%;
  padding: 0px 20px;
`;

const FloatingBottom = styled.View`
  background-color: white;
  padding: 20px 20px 30px;
`;

const Content = styled.ScrollView`
  flex: 1;
`;

const FormContainer = styled.View`
  background: #f5f5f7;
  margin: 0px 20px;
  border-radius: 4px;
  overflow: hidden;
`;

const HeaderText = styled.Text`
  height: 22px;
  color: rgb(13, 25, 67);
  font-size: 16px;
  font-family: OpenSans-Bold;
  font-weight: bold;
  letter-spacing: 0px;
  line-height: 22px;
  margin-top: 30px;
  margin-bottom: 20px;
  padding: 0px 20px;
`;

const BoxHead = styled.View`
  background: #edeef1;
  padding: 15px 20px;
`;

const Form = styled.View`
  padding: 10px 15px 0px;
  padding-bottom: 2px;
`;

const ErrorMessageContainer = styled.View`
  justify-content: center;
  align-items: center;
  margin-bottom: 10px;
`;

const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  line-height: 22px;
  font-weight: normal;
`;

export default AddStudentManually;

import StudentResults from './StudentResults';

export default StudentResults;

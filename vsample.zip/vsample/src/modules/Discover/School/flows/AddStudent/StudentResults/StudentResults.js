import React, { useEffect, useState } from 'react';
import { View, Platform } from 'react-native';
import { Navigation } from 'react-native-navigation';
import styled, { css } from 'styled-components/native';
import { useActions, useStore } from 'easy-peasy';
import StudentResult from '../components/StudentResult';
import AddStudentBtn from '../components/AddStudentBtn';
import Button from 'components/common/Button/Button';
import { Headline } from 'components/common/Typography';
import R from 'ramda';
import { testProperties } from '../../../../../../helpers/testProperties';
import { ErrorMessage } from 'formik';

const FloatingBottomControls = ({ onPress, errorMessage }) => {
  return (
    <FloatingBottom
      {...testProperties('discover-studentresults-floatingbottom-id')}
      elevation={5}
      style={{
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 7
        },
        shadowOpacity: 0.43,
        shadowRadius: 9.51,

        elevation: 15
      }}
    >
      <Button
        {...testProperties('discover-studentresults-done-button-id')}
        secondary
        error={errorMessage}
        onPress={onPress}
      >
        Done
      </Button>
    </FloatingBottom>
  );
};

const StudentResults = ({
  btnText,
  result,
  title,
  componentId,
  isAutodetected
}) => {
  const setMerchantData = useActions((actions) => actions.merchant.setData);
  const resetStudentResults = useActions(
    ({ student }) => student.resetStudentResults
  );
  const studentResults = useStore((state) => state.student.lists.results);
  const savedStudents = useStore((state) => state.student.lists.saved);
  const schoolSearchResults = useStore((state) => state.searchResults.results);
  const merchant = useStore((state) => state.merchant.data);
  // const school = merchant.outlets[0];
  const searchSchoolComponentId = useStore(
    (state) => state.searchResults.componentId
  );

  const navigateToHome = () => {
    resetStudentResults();

    Navigation.popToRoot(componentId, {
      topBar: {
        visible: false,
        height: 0,
        elevation: 0
      },
      bottomTabs: {
        visible: true,
        elevation: 0,
        ...Platform.select({ android: { drawBehind: false } })
      }
    });
  };

  const hasSavedStudents = savedStudents.some((savedStudent) =>
    studentResults.some(({ id }) => id == savedStudent.id)
  );

  const checkIfStudentIsSaved = (student) => {
    return savedStudents.some((item) => {
      return item.id == student.id;
    });
  };

  const navigateToSchoolSearch = () => {
    Navigation.popTo(searchSchoolComponentId);
  };

  const getMerchantFromStudentWithFallback = (student, merchant) => {
    const merchantFromStudentMerchantID = schoolSearchResults.find(
      ({ id }) => id == student.merchantId
    );

    return merchantFromStudentMerchantID || merchant;
  };

  const getSchoolFromStudentOrMerchant = (student, merchant) => {
    const safeMerchant = getMerchantFromStudentWithFallback(student, merchant);
    const school = safeMerchant.outlets.find(
      ({ id }) => id == student.schoolId
    );

    console.log('school', school);

    const merchantSchoolData = {
      otpRequired: safeMerchant.otpRequired,
      schoolDataProvided: safeMerchant.schoolDataProvided
    };

    console.log('SAFE MERCHANT', safeMerchant);

    const safeSchool = school || safeMerchant.outlets[0];
    const amendedSchool = { ...safeSchool, ...merchantSchoolData };

    return amendedSchool;
  };

  return (
    <Container
      {...testProperties('discover-studentresults-addstudent-container-id')}
    >
      <Results>
        <Title
          {...testProperties('discover-studentresults-addstudent-title-id')}
        >
          {title}
        </Title>
        {studentResults.map((student, index) => {
          const school = getSchoolFromStudentOrMerchant(student, merchant);

          return (
            <StudentResult
              {...testProperties(
                `discover-studentresults-addstudent-${index}-id`
              )}
              merchant={merchant}
              school={school}
              key={student.id || index}
              student={student}
              btnText={school.otpRequired ? 'Verify & add' : 'Add'}
              componentId={componentId}
              index={index}
              isSaved={checkIfStudentIsSaved(student)}
              isAutodetected={isAutodetected}
            />
          );
        })}
        {hasSavedStudents && <AddStudentBtn onPress={navigateToSchoolSearch} />}
      </Results>
      {hasSavedStudents && <FloatingBottomControls onPress={navigateToHome} />}
    </Container>
  );
};

const FloatingBottom = styled.View`
  background-color: white;
  padding: 20px 20px 30px;
`;

const Container = styled.View`
  flex: 1;
`;

const Results = styled.ScrollView`
  flex: 1;
  padding-bottom: 30px;
`;

const Title = styled(Headline)`
  color: rgb(13, 25, 67);
  font-family: OpenSans-Bold;
  font-size: 16px;
  margin: 20px 0 10px 20px;
`;

const Test = styled.View`
  padding: 0 10px;
`;

export default StudentResults;

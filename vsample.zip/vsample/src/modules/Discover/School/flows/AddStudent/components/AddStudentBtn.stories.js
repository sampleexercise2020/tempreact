import React from 'react';
import { storiesOf } from '@storybook/react-native';
import AddStudentBtn from './AddStudentBtn';

storiesOf('Modules|Discover/School/AddStudent', module).add(
  'Add Student Button',
  () => <AddStudentBtn />
);

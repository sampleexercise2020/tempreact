import React from 'react';
import styled, { css } from 'styled-components/native';
import { Image } from 'react-native';
import Avatar from 'components/common/Avatar/Avatar';
import { useStore, useActions } from 'easy-peasy';

const SchoolHeader = ({
  pending,
  schoolName,
  schoolAddress,
  bgTransparent,
  cardBg,
  arrowOnPress,
  closeOnPress,
  schoolImageUrl,
  hideArrow,
  isBig,
  isLight,
  innerColor
}) => {
  const student = useStore((state) => state.student);

  const forwardArrow = require('src/../../assets/icons/common/right-arrow.png');
  const close = require('src/../../assets/icons/common/close-dark.png');
  const pendingClock = require('src/../../assets/icons/common/clock.png');

  return (
    <Container cardBg={cardBg} bgTransparent={bgTransparent}>
      {pending ? (
        <Avatar
          name={schoolName}
          light={isLight}
          innerColor='rgb(247, 247, 247);'
          smallIcon={!isBig}
          isRemote={false}
          image={pendingClock}
        />
      ) : (
        <Avatar
          name={schoolName}
          light={isLight}
          innerColor='rgb(247, 247, 247);'
          isRemote={true}
          smallIcon={!isBig}
          image={schoolImageUrl}
        />
      )}

      {/* <Avatar {pending ? ( image={student.image} ) : ( image={student.image} )} /> */}

      <Inner>
        <BoldName pending={pending}>{schoolName}</BoldName>
        <ThinAdress pending={pending}>{schoolAddress}</ThinAdress>
        {pending ? (
          <CloseOnPress onPress={closeOnPress}>
            <Close resizeMode='contain' source={close} />
          </CloseOnPress>
        ) : hideArrow ? null : (
          <ArrowOnPress onPress={arrowOnPress}>
            <Arrow resizeMode='contain' source={forwardArrow} />
          </ArrowOnPress>
        )}
      </Inner>
    </Container>
  );
};

const Container = styled.View`
  align-items: center;
  flex-direction: row;
  padding: 17px 22px;
  background-color: ${(props) =>
    props.bgTransparent
      ? 'transparent'
      : props.cardBg
      ? 'rgb(234, 241, 251)'
      : '#edeef1'};
`;

const Inner = styled.View`
  margin-left: 10px;
  justify-content: center;
  flex: 1;
`;

const Arrow = styled.Image`
  position: absolute;
  height: 15px;
  width: 15px;
  right: 0;
`;
const ArrowOnPress = styled.TouchableOpacity`
  position: absolute;
  right: 0;
  height: 15px;
  width: 15px;
`;
const Close = styled.Image`
  position: absolute;
  height: 15px;
  width: 15px;
  right: 0;
`;
const CloseOnPress = styled.TouchableOpacity`
  position: absolute;
  right: 0;
  height: 15px;
  width: 15px;
`;

const BoldName = styled.Text`
  opacity: ${(props) => (props.pending ? '0.5' : '1')};
  color: rgb(13, 25, 67);
  font-family: OpenSans-Bold;
  font-size: 14px;
  font-weight: bold;
  letter-spacing: 0px;
  line-height: 18px;
`;

const ThinAdress = styled.Text`
  opacity: ${(props) => (props.pending ? '0.5' : '1')};
  color: rgb(109, 117, 142);
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 18px;
`;

export default SchoolHeader;

import React, { useState, useCallback } from 'react';
import { Platform, Alert } from 'react-native';
import styled from 'styled-components';
import { useStoreState, useActions } from 'easy-peasy';
import { Navigation } from 'react-native-navigation';
import * as yup from 'yup';

// TODO: Add text from copy file
// import selectedCopy from 'src/i18n/copy';

import VerificationDots from 'components/common/VerificationDots/VerificationDots';
import Button from 'components/common/Button/Button';
import CodeVerifier from 'components/common/CodeVerifier/CodeVerifier';
import { popTo } from 'navigation';
import { testProperties } from 'helpers/testProperties';

const VerifyStudent = ({
  componentId,
  beneficiaryId,
  otpToken,
  userId,
  registeredWithUserAndDisabled,
  primaryMobileNum,
  index
}) => {
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [verificationCode, setVerificationCode] = useState(null);
  const verifyOtp = useActions((actions) => actions.student.verifyOtp);

  const getVerifyOtpPayload = useCallback(() => ({
    beneficiaryId,
    otp: verificationCode,
    otpToken,
    registeredWithUserAndDisabled,
    userId
  }));

  const verifyStudent = async () => {
    setIsVerifyingOtp(true);

    const verifyOtpPayload = getVerifyOtpPayload();
    const response = await verifyOtp({ ...verifyOtpPayload, index });

    if (response.status == 200) {
      Navigation.pop(componentId);
    } else {
      Alert.alert('Error', response.message);
      Navigation.pop(componentId);
    }

    setIsVerifyingOtp(false);
  };

  return (
    <CodeVerifier
      {...testProperties('discover-school-verifystudent-codeverifier-id')}
      length={6}
      onPress={() => {
        verifyStudent(verificationCode);
      }}
      passDataToParent={setVerificationCode}
      isLoading={isVerifyingOtp}
      buttonText='Next'
    >
      <Title {...testProperties('discover-school-verifystudent-title-id')}>
        Enter your verification code
      </Title>
      <Subtitle>{`Sent to +${primaryMobileNum}`}</Subtitle>
    </CodeVerifier>
  );
};

export default VerifyStudent;

const Container = styled.View`
  position: relative;
  padding-bottom: 20px;
  flex: 1;
  align-items: center;
  justify-content: center;
`;

const Title = styled.Text`
  width: 165px;
  color: rgb(13, 25, 67);
  font-size: 20px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  text-align: center;
  letter-spacing: 0px;
  line-height: 28px;
  margin-bottom: 8px;
`;

const Subtitle = styled.Text`
  color: rgb(13, 25, 67);
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  font-weight: normal;
  height: 22px;
  letter-spacing: 0px;
  line-height: 22px;
  text-align: center;
`;

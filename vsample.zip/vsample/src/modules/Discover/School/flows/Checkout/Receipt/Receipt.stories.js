import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Receipt from './Receipt';

storiesOf('Modules|Discover/School/Checkout', module).add(
  'Receipt page',
  () => <Receipt />
);

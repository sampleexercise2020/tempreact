import React, { useState, useEffect, useRef } from 'react';
import { Platform } from 'react-native';
import styled from 'styled-components';
import { useStore, useActions } from 'easy-peasy';
import { Navigation } from 'react-native-navigation';
import * as yup from 'yup';

import CardItem from './components/CardItem';

// TODO: Add text from copy file
// import selectedCopy from 'src/i18n/copy';

import VerificationDots from 'components/common/VerificationDots/VerificationDots';
import Button from 'components/common/Button/Button';
import CodeVerifier from 'components/common/CodeVerifier/CodeVerifier';
import { testProperties } from '../../../../../../helpers/testProperties';
import R from 'ramda';
import { showOverlay } from '../../../../../../navigation';

const CardCVV = ({ card, componentId }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [cvv, setCvv] = useState('');
  const storeMakePayment = useActions((actions) => actions.cart.makePayment);
  const sendEmailReceipt = useActions((actions) => {
    return actions.receipts.sendEmailReceipt;
  });

  const navigateToHome = () => {
    return Navigation.popToRoot(componentId, {
      topBar: {
        visible: false,
        height: 0,
        elevation: 0
      },
      bottomTabs: {
        visible: true,
        elevation: 0,
        // height: 0,
        ...Platform.select({ android: { drawBehind: false } })
      }
    });
  };

  const showCheckoutModal = (receipt) => {
    if (receipt) {
      sendEmailReceipt({ id: receipt.id });
      showOverlay('Skiply.Modal.Checkout', 'CHECKOUT_SUCCESS_MODAL', {
        receipt
      });
    } else {
      showOverlay('Skiply.Modal.Checkout.Fail', 'CHECKOUT_FAIL_MODAL');
    }
  };

  const makePayment = async () => {
    setIsLoading(true);

    const response = await storeMakePayment({ card, cvv });

    await navigateToHome();
    showCheckoutModal(response.data);
    setIsLoading(false);
  };

  useEffect(() => {
    console.log('CVV: ', cvv);
  }, [cvv]);

  return (
    <CodeVerifier
      {...testProperties('discover-checkout-cvv-codeverifier-id')}
      length={3}
      onPress={makePayment}
      passDataToParent={setCvv}
      buttonText='Pay now'
      isLoading={isLoading}
    >
      <Title {...testProperties('discover-checkout-cvv-title-id')}>
        Please enter your card's CVV code
      </Title>
      <CardItem
        {...testProperties('discover-checkout-cvv-carditem-id')}
        listItemText={card.alias}
        maskedPan={card.maskedPan}
        imageUrl={card.imageUrl}
        isDefault={card.isDefault}
        isButton={false}
      />
    </CodeVerifier>
  );
};

export default CardCVV;

const Title = styled.Text`
  text-align: center;
  width: 200px;
  color: rgb(13, 25, 67);
  font-size: 20px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  text-align: center;
  letter-spacing: 0px;
  line-height: 28px;
`;

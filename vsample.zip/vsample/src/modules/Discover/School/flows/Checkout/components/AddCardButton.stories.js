import React from 'react';
import { storiesOf } from '@storybook/react-native';
import AddCardButton from './AddCardButton';

storiesOf('Modules|Discover/School/Checkout/components', module)
  .add('Button - no cards', () => (
    <AddCardButton empty onPress={() => console.log('add button')} />
  ))
  .add('Button - available cards', () => (
    <AddCardButton available onPress={() => console.log('add button')} />
  ));

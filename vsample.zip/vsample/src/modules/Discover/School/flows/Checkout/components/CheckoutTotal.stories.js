import React from 'react';
import { storiesOf } from '@storybook/react-native';
import CheckoutTotal from './CheckoutTotal';

storiesOf('Modules|Discover/School/Checkout/components', module).add(
  'Total box',
  () => <CheckoutTotal total={3423} vat={54} currency='AED' />
);

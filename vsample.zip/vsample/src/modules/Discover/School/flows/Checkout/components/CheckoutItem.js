import React from 'react';
import styled from 'styled-components';
import { addCommaSeparator } from 'helpers/addCommaSeparator';

const CheckoutItem = ({ productTitle, amount, currency, quantity }) => {
  return (
    <Container>
      <ProductTitle>
        {productTitle} {quantity}
      </ProductTitle>
      <Amount>
        {currency} {addCommaSeparator(amount)}
      </Amount>
    </Container>
  );
};

export default CheckoutItem;

const Container = styled.View`
  flex-direction: row;
  margin: 0px 20px;
`;

const ProductTitle = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #6d758e;
  flex-wrap: wrap;
  flex: 1;
  padding-right: 80px;
`;

const Amount = styled.Text`
  position: absolute;
  right: 0;
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
`;

import React from 'react';
import styled, { css } from 'styled-components';
import selectedCopy from '../../../../../../i18n/copy';

const copy =
  selectedCopy.components.modules.Account.flows.Checkout.components
    .AddCardButton;

const AddCardButton = ({ empty, available, onPress }) => {
  return (
    <Container empty={empty} available={available} onPress={onPress}>
      <Title empty={empty} available={available}>
        {empty ? copy.empty : copy.notEmpty}
      </Title>
    </Container>
  );
};

export default AddCardButton;

const Container = styled.TouchableOpacity`
  border-radius: 4px;
  justify-content: center;
  align-items: center;
  height: 30px;
  ${(props) =>
    props.empty &&
    css`
      background-color: #0d857b;
      width: 113px;
    `}
  ${(props) =>
    props.available &&
    css`
      background-color: #ffffff;
      border-width: 1;
      border-color: #4f2c94;
      width: 83px;
    `}
`;

const Title = styled.Text`
  font-size: 14px;
  font-weight: 600;
  font-family: 'OpenSans-SemiBold';
  line-height: 18px;
  ${(props) =>
    props.empty &&
    css`
      color: #ffffff;
    `}
  ${(props) =>
    props.available &&
    css`
      color: #4f2c94;
    `}
`;

import React, { Fragment, useState, useEffect } from 'react';
import { useStore, useActions } from 'easy-peasy';
import styled from 'styled-components';
import AddCardButton from './AddCardButton';
import IconAndTextListItem from 'components/common/ListItem/IconAndTextListItem';

const iconVisa = require('../../../../../../../assets/icons/payment/Mobile-VISA.png');

const AvailableCardsCO = ({
  title,
  selectedCardState,
  navigateToAddNewMethod
}) => {
  const [selectedCardIndex, setSelectedCardIndex] = selectedCardState;
  const fetchCards = useActions((actions) => actions.cards.fetchCards);
  const cards = useStore((state) => state.cards.items);

  useEffect(() => {
    fetchCards();
  }, []);

  useEffect(() => {
    if (cards[0]) {
      console.log('Cards', cards);
    }
  }, [cards]);

  // useEffect(() => {
  //   setSelectedCardIndex(selectedCardIndex);
  // }, [selected]);

  const isCardSelected = (index) => {
    return index === selectedCardIndex;
  };

  return (
    <OuterContainer>
      <Container>
        {cards.length === 0 && (
          <EmptyContainer>
            <Title>{title}</Title>
            <EmptyList>
              <EmptyTitle>No card added</EmptyTitle>
              <AddCardButton empty={true} onPress={navigateToAddNewMethod} />
            </EmptyList>
          </EmptyContainer>
        )}
        {cards.length > 0 && (
          <Fragment>
            <ListExistsContainer>
              <Title>{title}</Title>
              <AddCardButton available onPress={navigateToAddNewMethod} />
            </ListExistsContainer>
            <CardList
              scrollEnabled={false}
              data={cards}
              renderItem={({ item: card, index }) => (
                <IconAndTextListItem
                  onPress={() => setSelectedCardIndex(index)}
                  selected={isCardSelected(index)}
                  check={true}
                  listItemText={card.alias}
                  maskedPan={card.maskedPan}
                />
              )}
              ItemSeparatorComponent={() => <Separator />}
            />
          </Fragment>
        )}
      </Container>
      {/* {cardList.length > 0 ? (
        <Button primary>Confirm &amp; Pay</Button>
      ) : (
        <Button disabled>Confirm &amp; Pay</Button>
      )} */}
    </OuterContainer>
  );
};

export default AvailableCardsCO;

const OuterContainer = styled.View``;

const Container = styled.View`
  margin: 30px 20px 90px 20px;
`;

const EmptyContainer = styled.View`
  height: 210px;
`;

const EmptyList = styled.View`
  flex-direction: row;
  justify-content: space-between;
  margin-right: 20px;
  align-items: center;
  margin-top: 20px;
`;

const EmptyTitle = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  line-height: 18px;
  color: #6d758e;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  line-height: 22px;
  font-weight: bold;
  color: #36235e;
`;

const CardList = styled.FlatList``;

const ListExistsContainer = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
`;

const Separator = styled.View`
  border-width: 0.5px;
  border-color: #edeef1;
`;

import React from 'react';
import styled from 'styled-components';
import { addCommaSeparator } from 'helpers/addCommaSeparator';

import selectedCopy from '../../../../../../i18n/copy';

const copy =
  selectedCopy.components.modules.Account.flows.Checkout.components
    .CheckoutTotal;

const CheckoutTotal = ({ total, vat, currency }) => {
  return (
    <BorderWrapper>
      <TotalContainer>
        <SumContainer>
          <Total>{copy.total}</Total>
          <TotalAmount>
            {currency}
            {addCommaSeparator(total)}
          </TotalAmount>
        </SumContainer>
        {/* <VatContainer>
          <Vat>{copy.vat}</Vat>
          <VatAmount>
            {currency}
            {addCommaSeparator(vat)}
          </VatAmount>
        </VatContainer> */}
      </TotalContainer>
    </BorderWrapper>
  );
};

export default CheckoutTotal;

const TotalContainer = styled.View`
  background-color: #f5f5f7;
  margin: 0 20px;
  border-radius: 4px;
  justify-content: center;
  height: 80px;
`;

const BorderWrapper = styled.View`
  border-bottom-width: 1px;
  border-bottom-color: #edeef1;
  padding: 30px 0;
`;

const SumContainer = styled.View`
  flex-direction: row;
`;

const Total = styled.Text`
  font-family: 'OpenSans-Bold';
  margin-left: 20px;
  font-size: 18px;
  line-height: 22px;
  font-weight: bold;
  color: #0d1943;
`;
const TotalAmount = styled.Text`
  font-family: 'OpenSans-Bold';
  position: absolute;
  right: 0;
  margin-right: 20px;
  font-size: 18px;
  line-height: 22px;
  font-weight: bold;
  color: #0d1943;
`;

const VatContainer = styled.View`
  flex-direction: row;
`;
const Vat = styled.Text`
  font-family: 'OpenSans-Regular';
  color: #6d758e;
  font-size: 14px;
  line-height: 18px;
  margin-left: 20px;
`;
const VatAmount = styled.Text`
  font-family: 'OpenSans-Regular';
  color: #6d758e;
  font-size: 14px;
  line-height: 18px;
  position: absolute;
  right: 0;
  margin-right: 20px;
`;

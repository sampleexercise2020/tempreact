import React from 'react';
import { storiesOf } from '@storybook/react-native';

import ListItemProduct from './ListItemProduct';

const mockData = {
  title: 'School Uniform',
  shortDesc: 'Short Description'
};

storiesOf(
  'Modules|Discover/School/Store/Components/Product/List Item - Product',
  module
)
  .add('Basic', () => (
    <ListItemProduct title={mockData.title} shortDesc={mockData.shortDesc} />
  ))
  .add('Long Name', () => (
    <ListItemProduct
      title='This is a very long product name that continues for eternity'
      shortDesc={mockData.shortDesc}
    />
  ))
  .add('With Image', () => (
    <ListItemProduct
      title={mockData.title}
      shortDesc={mockData.shortDesc}
      image='https://placekitten.com/300/300'
      requiresSignature={false}
      inCart={false}
    />
  ))
  .add('In Cart', () => (
    <ListItemProduct
      title={mockData.title}
      shortDesc={mockData.shortDesc}
      inCart={true}
    />
  ))
  .add('Signature Required', () => (
    <ListItemProduct
      title={mockData.title}
      shortDesc={mockData.shortDesc}
      requiresSignature={true}
      inCart={false}
    />
  ))
  .add('Signature Required and In Cart', () => (
    <ListItemProduct
      title={mockData.title}
      shortDesc={mockData.shortDesc}
      requiresSignature={true}
      inCart={true}
    />
  ))
  .add('With Everything', () => (
    <ListItemProduct
      title={mockData.title}
      shortDesc={mockData.shortDesc}
      requiresSignature={true}
      image='https://placekitten.com/200/300'
      inCart={true}
    />
  ));

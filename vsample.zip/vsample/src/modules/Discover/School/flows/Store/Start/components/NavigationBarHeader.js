import React from 'react';
import { Image } from 'react-native';
import styled from 'styled-components/native';

//TODO: rätt font
//TODO: rätt färgvariabel och storlek på fonten

const NavigationBarHeader = ({ children }) => {
  return (
    <Container>
      <Back>
        <Image
          source={require('src/../../assets/icons/common/back-arrow.png')}
        />
      </Back>
      <HeaderContainer>{children}</HeaderContainer>
      <Dots>
        <Image
          source={require('src/../../assets/icons/common/three-dots.png')}
        />
      </Dots>
    </Container>
  );
};

export default NavigationBarHeader;

const Container = styled.View`
  flex-direction: row;
  justify-content: space-between;
  height: 35px;
  overflow: hidden;
`;
const Back = styled.TouchableOpacity`
  height: 35px;
  width: 35px;
  margin-left: 20px;
  justify-content: center;
  align-items: center;
`;
const Dots = styled.TouchableOpacity`
  height: 35px;
  width: 35px;
  margin-right: 20px;
  justify-content: center;
  align-items: center;
`;

const HeaderContainer = styled.View`
  flex-grow: 1;
`;

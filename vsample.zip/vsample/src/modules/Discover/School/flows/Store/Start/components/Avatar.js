import React from 'react';
import styled from 'styled-components/native';
import UserAvatar from 'react-native-user-avatar';

const Avatar = ({
  pending,
  small,
  image,
  containerSize,
  stokeSize,
  outerRingColor,
  innerRingColor,
  name
}) => {
  containerSize = containerSize ? containerSize : '45px';
  stokeSize = stokeSize ? stokeSize : '42px';
  return (
    <Container
      small={small}
      containerSize={containerSize}
      outerRingColor={outerRingColor}
    >
      <Stroke
        small={small}
        strokeSize={stokeSize}
        innerRingColor={innerRingColor}
      >
        {image ? (
          <Img source={{ uri: image }} />
        ) : (
          <UserAvatar
            name={name ? name.toUpperCase() : 'Test Placeholder'}
            size={small ? 35 : 45}
            color='#4f2c94'
          />
        )}
      </Stroke>
    </Container>
  );
};

export default Avatar;

const Container = styled.View`
  height: ${(props) => (props.small ? '35px' : props.containerSize)};
  width: ${(props) => (props.small ? '35px' : props.containerSize)};
  border-radius: 50px;
  border-width: 2px;
  border-color:${(props) =>
    props.outerRingColor ? props.outerRingColor : '#f7f7f7'} 
  justify-content: center;
  align-items: center;
  overflow: hidden;
`;
const Stroke = styled.View`
  height: ${(props) => (props.small ? '32px' : props.strokeSize)};
  width: ${(props) => (props.small ? '32px' : props.strokeSize)};
  border-radius: 50px;
  border-width: 2.5px;
  border-color:${(props) =>
    props.innerRingColor ? props.innerRingColor : '#3E30A4'} 
  justify-content: center;
  align-items: center;
  overflow: hidden;
`;
const Img = styled.Image`
  width: 100%;
  height: 100%;
`;

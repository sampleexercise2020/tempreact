import React, { useLayoutEffect, useEffect, useState, useRef } from 'react';
import { Animated, Easing } from 'react-native';
import styled from 'styled-components/native';
import { useStoreState, useStoreActions } from 'easy-peasy';
import { navigateTo, dismissOverlay } from 'navigation';
import { addCommaSeparator } from 'helpers/addCommaSeparator';

const FloatingCart = ({ currentNavigationComponentId }) => {
  const carts = useStoreState((state) => state.cart.carts);
  const cart = carts[0];
  const [posY] = useState(new Animated.Value(60));
  const didTouch = useRef(false);
  const firstTick = useRef(true);
  const isFloatingCart = useStoreState(({ cart }) => cart.isFloatingCart);
  const setIsFloatingCart = useStoreActions(
    ({ cart }) => cart.setIsFloatingCart
  );

  const cartIcon = require('src/../../assets/icons/common/cart-white.png');
  const numberOfItemsInCart = cart && cart.cartItems && cart.cartItems.length;
  const totalCost = cart ? cart.amountMinorUnits / 100 : 0;
  const currency = cart ? cart.currency : '';

  const style = {
    transform: [
      {
        translateY: posY
      }
    ]
  };

  useEffect(function componentDidMount() {
    setIsFloatingCart(true);
  }, []);

  useLayoutEffect(() => {
    moveY(0, 0, 200);
  });

  useEffect(() => {
    if (!firstTick.current) {
      if (!isFloatingCart) {
        dismissFloatingCart();
      }
    } else {
      firstTick.current = false;
    }
  }, [isFloatingCart]);

  async function dismissFloatingCart() {
    await moveY(60, 0, 200);
    dismissOverlay('FLOATING_CART');
  }

  async function navigateToCart() {
    if (!didTouch.current) {
      didTouch.current = true;
      await dismissFloatingCart();
      navigateTo('Skiply.Store.Cart', currentNavigationComponentId);
    }
  }

  function moveY(val, delay = 0, duration = 200) {
    return new Promise((resolve) => {
      return Animated.timing(posY, {
        useNativeDriver: true,
        toValue: val,
        duration,
        delay,
        easing: Easing.cubic
      }).start(resolve);
    });
  }

  return (
    <Container style={style}>
      <Button onPress={navigateToCart}>
        <ContentLeft>
          <CartIcon source={cartIcon} />
          <CartText>View cart ({numberOfItemsInCart})</CartText>
        </ContentLeft>
        <ContenRight>
          <Cost>
            {addCommaSeparator(totalCost)} {currency}
          </Cost>
        </ContenRight>
      </Button>
    </Container>
  );
};

const Container = styled(Animated.View)`
  padding: 10px 20px;
`;

const Button = styled.TouchableOpacity`
  background: #0d857b;
  border-radius: 4px;
  padding: 15px;
  width: 100%;
  height: 52px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  align-self: center;
`;

const ContentLeft = styled.View`
  flex-direction: row;
  justify-content: flex-start;
`;

const ContenRight = styled.View`
  flex-direction: row;
  justify-content: flex-end;
`;

const CartIcon = styled.Image`
  height: 22px;
  width: 22px;
  margin-right: 15px;
`;

const CartText = styled.Text`
  color: #fff;
  font-size: 18px;
  line-height: 23px;
  font-family: 'OpenSans-Semibold';
  font-weight: 600;
  letter-spacing: 0;
`;

const Cost = styled.Text`
  color: #fff;
  font-family: OpenSans-Regular;
  font-size: 18px;
  font-weight: normal;
  letter-spacing: 0;
  line-height: 18px;
`;

export default FloatingCart;

import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components/native';

const PlusIcon = require('src/../../assets/images/picker_plus.png');
const MinusIcon = require('src/../../assets/images/picker_minus.png');

const QuantityPicker = ({ setParentQuantity, min, max }) => {
  const [quantity, setQuantity] = useState(min > 1 ? min : 1);

  useEffect(() => {
    setParentQuantity ? setParentQuantity(quantity) : null;
  }, [quantity]);

  return (
    <Container>
      <Picker>
        <Button
          onPress={() => setQuantity(quantity - 1)}
          disabled={quantity < min + 1}
        >
          <Decrement source={MinusIcon} />
        </Button>
        <Quantity>{quantity}</Quantity>
        <Button
          onPress={() => setQuantity(quantity + 1)}
          disabled={quantity > max - 1}
        >
          <Increment source={PlusIcon} />
        </Button>
      </Picker>
    </Container>
  );
};

const Container = styled.View`
  justify-content: center;
  align-items: center;
  flex-direction: row;
  height: 52px;
`;

const Picker = styled.View`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  height: 52px;
  min-width: 172px;
  background: #f2f0f5;
  border-radius: 26px;
`;

const Content = styled.View`
  flex-direction: row;
  flex: 1;
  justify-content: flex-end;
  align-items: center;
`;

const Price = styled.Text`
  height: 36px;
  color: #0d857b;
  font-size: 24px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  letter-spacing: 0;
`;

const Quantity = styled.Text`
  padding: 0px 10px;
  color: #2f2f2f;
  font-size: 18px;
  font-family: 'OpenSans-Semibold';
  font-weight: 600;
  text-align: center;
  letter-spacing: 0px;
  flex-grow: 1;
`;

const Button = styled.TouchableOpacity`
  justify-content: center;
  align-items: center;
  width: 46px;
  height: 46px;
  background: #ffffff;
  border-radius: 23px;
  margin: 2px;
`;

const Increment = styled.Image`
  width: 20px;
  height: 20px;
`;
const Decrement = styled.Image`
  width: 20px;
  height: 3px;
`;

export default QuantityPicker;

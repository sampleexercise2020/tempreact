import React, { useState, useEffect } from 'react';
import { storiesOf } from '@storybook/react-native';
import { Button, Text, View, ScrollView } from 'react-native';
import styled from 'styled-components/native';
import { useFloatingSlideUp } from 'components/FloatingSlideUp';
import { useStore, useActions, useRef } from 'easy-peasy';
import { useFloatingBottom } from 'components/FloatingBottom';
import ShoppingCart from './ShoppingCart';
import Confirmation from './Confirmation';
import ProductView from './ProductView';
import ProductControls from './components/ProductControls';

const testProduct = {
  ageRestricted: null,
  smallDescription: 'Short Description for Uniform',
  description: 'Long Description for Uniform',
  variants: [
    {
      gtin: null,
      isDefault: false,
      ean: null,
      variantDetails: [
        {
          variantLabel: 'Size',
          visible: true,
          variantValue: 's'
        }
      ],
      amountMinorUnits: 9500,
      upc: null,
      currency: null,
      id: '514449',
      priority: null,
      sku: '9b499391-0769-42ab-8cba-62357fb297b7',
      stockLevel: null
    },
    {
      gtin: null,
      isDefault: false,
      ean: null,
      variantDetails: [
        {
          variantLabel: 'Size',
          visible: true,
          variantValue: 'L'
        }
      ],
      amountMinorUnits: 9500,
      upc: null,
      currency: null,
      id: '514447',
      priority: null,
      sku: '031b394b-7fd0-47e1-a83d-cd9237909096',
      stockLevel: null
    },
    {
      gtin: null,
      isDefault: false,
      ean: null,
      variantDetails: [
        {
          variantLabel: 'Size',
          visible: true,
          variantValue: 'M'
        }
      ],
      amountMinorUnits: 9500,
      upc: null,
      currency: null,
      id: '514445',
      priority: null,
      sku: '25bd3eb8-d89c-413e-b004-d744b88964bc',
      stockLevel: null
    }
  ],
  mediumImageUrl:
    'https://testmssbucket.s3-eu-west-1.amazonaws.com/SkiplySchoolofExcellence/44c84b1a-5d96-4eb2-9cab-35102f3fe120.jpg',
  availableDates: [
    1557864000000,
    1557950400000,
    1558036800000,
    1558123200000,
    1558209600000,
    1558296000000,
    1558382400000,
    1558468800000,
    1558555200000,
    1558641600000,
    1558728000000,
    1558814400000,
    1558900800000,
    1558987200000
  ],
  form: null,
  name: 'Uniform',
  optionSets: [
    {
      maxSelected: null,
      name: 'Deliver',
      options: [
        {
          paymentAdjust: 3000,
          name: 'Yes',
          id: '514426',
          selectedByDefault: true
        },
        {
          paymentAdjust: 0,
          name: 'No',
          id: '514427',
          selectedByDefault: false
        }
      ],
      minSelected: null,
      label: 'Home Delivery',
      type: 'bool'
    }
  ],
  allowPurchaseNote: true,
  id: '514444',
  category: 'Misc',
  shippingAddressRequired: null
};

const testProductWithOneVariant = {
  ageRestricted: null,
  smallDescription: 'SD for Academic Books',
  description: 'LD for Academic Books',
  variants: [
    {
      gtin: null,
      isDefault: true,
      ean: null,
      variantDetails: [],
      amountMinorUnits: 20000,
      upc: null,
      currency: null,
      id: '517407',
      priority: null,
      sku: 'fed0838c-17a5-404a-85bf-c6ae62e31b62',
      stockLevel: null
    }
  ],
  mediumImageUrl:
    'https://d1wfs5jdtdt7am.cloudfront.net/mss/product-placeholder.png',
  availableDates: [
    1558382400000,
    1558468800000,
    1558555200000,
    1558641600000,
    1558728000000,
    1558814400000,
    1558900800000,
    1558987200000,
    1559073600000,
    1559160000000,
    1559246400000,
    1559332800000,
    1559419200000,
    1559505600000
  ],
  form: null,
  name: 'Academic Books',
  optionSets: [
    {
      maxSelected: 1,
      name: 'DOP',
      options: [
        {
          paymentAdjust: 3000,
          name: 'Home Delivery',
          id: '517388',
          selectedByDefault: false
        },
        {
          paymentAdjust: 0,
          name: 'No Delivery',
          id: '517389',
          selectedByDefault: true
        }
      ],
      minSelected: 1,
      label: 'Delivery Options',
      type: 'list1'
    }
  ],
  allowPurchaseNote: true,
  id: '517406',
  category: 'Misc',
  shippingAddressRequired: null
};

const styles = {
  container: {
    flex: 1,
    zIndex: 1,
    backgroundColor: 'tomato',
    alignItems: 'center',
    justifyContent: 'center'
  },
  dragHandler: {
    alignSelf: 'stretch',
    height: 64,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ccc'
  }
};

const Floating = styled.View`
  border-top-left-radius: 50;
  background-color: white;
  flex: 1;
`;

const FloatingBottom = styled.View`
  background-color: white;
  padding: 10px 20px 30px;
`;

const PanelComponent = (props) => (
  <Panel>
    <Text>Here is the content inside panel</Text>
    <Button title='Hide' onPress={props.hidePanel} />
  </Panel>
);

const FloatingProduct = ({ dragHandler, panelPosition }) => {
  const [isScrolledToTop, setIsScrolledToTop] = useState(false);

  const handleScroll = (event) => {
    // console.log(event, 'handlescrollevent');
    // console.log('Scroll Event, Y Offset: ', event.NativeEvent.contentOffset.y);
  };

  useEffect(() => {
    if (panelPosition !== 'top') {
    }
  }, [panelPosition]);

  return (
    <Floating {...panelPosition == 'top' && vy < 0 && dragHandler}>
      {/* <View {...!isScrolledToTop && dragHandler}>
        <Text>Drag</Text>
      </View> */}
      {/* <ProductView /> */}
      {/* {(dragHandler) => ( */}
      <View style={styles.container}>
        <View style={styles.dragHandler} {...dragHandler}>
          <Text>Drag handler</Text>
        </View>
        <ScrollView onScroll={(e) => handleScroll(e)} scrollEventThrottle={16}>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
          <Text>Here is the content inside panel</Text>
        </ScrollView>
      </View>
      {/* )} */}
    </Floating>
  );
};

const FloatingProductControls = (props) => (
  <FloatingBottom>
    <ProductControls
      price={300}
      currency='AED'
      addToCart={() => {}}
      addToCartAction={() => {}}
      payNowAction={() => {}}
      hidePanel={props.hidePanel}
    />
  </FloatingBottom>
);

const OpenProductView = () => {
  // const [showFloating, setShowFloating] = useState(false);
  const setShowFloating = useActions(
    (actions) => actions.global.setShowFloating
  );
  const showFloatingSlideUp = useFloatingSlideUp(FloatingProduct);
  const showFloatingBottom = useFloatingBottom(FloatingProductControls);

  // useEffect(() => {
  //   console.log('showFloating:', showFloating);
  // }, [showFloating]);

  return (
    <Button
      onPress={() => {
        showFloatingSlideUp(true);
        showFloatingBottom(true);
        setShowFloating(true);
      }}
      title='Show product'
    />
  );
};

// TODO: Get notes working.

storiesOf('Modules|Discover/School/Store', module)
  .add('Shopping Cart', () => <ShoppingCart />)
  .add('Product View with variants and one option set', () => (
    <ProductView
      product={testProduct}
      category='Utilities'
      updateItem={false}
    />
  ))
  .add('Product View with one option set', () => (
    <ProductView
      product={testProductWithOneVariant}
      category='Utilities'
      updateItem={false}
    />
  ))
  .add('Product View no variants ', () => <ProductView product={testProduct} />)
  .add('Product View - Floating panel', () => <OpenProductView />)
  .add('Confirmation', () => <Confirmation />);

const Panel = styled.View`
  flex: 1;
  background-color: red;
  align-items: center;
  justify-content: center;
  border-top-left-radius: 50;
`;

const BottomPanel = styled.View`
  background: blue;
  height: 100px;
`;

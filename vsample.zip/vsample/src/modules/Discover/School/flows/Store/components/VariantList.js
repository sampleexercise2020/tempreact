import React, { useState, useEffect } from 'react';
import { TouchableOpacity, Text, View } from 'react-native';
import styled, { css } from 'styled-components/native';
import R from 'ramda';

import { useStore, useStoreState, useActions } from 'easy-peasy';

import ListItem from './ListItem';

const VariantLists = ({ list, type, buttonType, isRequired }) => {
  const currentProduct = useStore((state) => state.currentProduct);
  const [variantLists, setVariantLists] = useState(currentProduct.variantLists);
  const setVariantId = useActions(
    (actions) => actions.currentProduct.setVariantId
  );
  const currency = useStoreState((state) => state.merchant.currency);

  const [selected, setSelected] = useState(
    list[
      list.findIndex((item) => {
        return (
          item ===
          list.find((variant) => {
            return variant.isDefault == true;
          })
        );
      })
    ]
  );
  const [priceRange, setPriceRange] = useState([]);

  // Gets the range of prices that can be selected from the variants.
  useEffect(() => {
    let range = [];

    list.forEach((item) => {
      range.push(item.amountMinorUnits);
    });

    const sortedRange = range.sort((a, b) => a - b).map((i) => i / 100);

    let priceRangeString =
      sortedRange[0] + ' - ' + sortedRange[sortedRange.length - 1];

    sortedRange[0] == sortedRange[sortedRange.length - 1]
      ? (priceRangeString = sortedRange[0])
      : null;

    setPriceRange(priceRangeString);
  }, []);

  useEffect(() => {
    const selectedVariantValues = variantLists
      .map((variantList) => {
        return variantList.values
          .filter(({ isSelected }) => isSelected)
          .map((item) => item.value);
      })
      .flat(2);

    if (selectedVariantValues.length == variantLists.length) {
      const selectedVariant = currentProduct.data.variants.find((variant) => {
        const variantValues = variant.variantDetails.map(
          ({ variantValue }) => variantValue
        );
        const hasVariantValue = (variantValue) => {
          return R.contains(variantValue, variantValues);
        };

        return R.all(hasVariantValue, selectedVariantValues);
      });

      setVariantId(selectedVariant.id);
    }
  }, [variantLists]);

  const selectVariant = useActions(
    (actions) => actions.currentProduct.selectVariant
  );

  const toggleVariant = (variantListIndex, variantDetailIndex) => {
    const selectVariant = (variantDetail) => {
      return R.assoc('isSelected', true, variantDetail);
    };

    const deselectVariant = (variantDetail) => {
      return R.assoc('isSelected', false, variantDetail);
    };

    const toggleVariantValue = (variantList) => {
      const deselectedValues = R.map(deselectVariant, variantList.values);

      const values = R.adjust(
        variantDetailIndex,
        selectVariant,
        deselectedValues
      );

      const updatedVariantList = R.assoc('values', values, variantList);

      return updatedVariantList;
    };

    const updatedVariantLists = R.adjust(
      variantListIndex,
      toggleVariantValue,
      variantLists
    );

    setVariantLists(updatedVariantLists);
  };

  const checkSelected = (item) => {
    return item == selected;
  };

  return (
    <Container>
      {variantLists.map((list, variantListIndex) => (
        <VariantList key={list.label}>
          <Header>
            <Title>{list.label}</Title>
            {isRequired ? (
              <RequiredBox>
                <RequiredText>Required</RequiredText>
              </RequiredBox>
            ) : null}
          </Header>
          {list.values.map((variantDetail, variantDetailIndex) => (
            <TouchableOpacity
              key={variantDetail.value}
              onPress={() =>
                toggleVariant(variantListIndex, variantDetailIndex)
              }
            >
              <ListItem
                type={type}
                buttonType={buttonType}
                title={variantDetail.value}
                checked={variantDetail.isSelected}
                price={priceRange}
                currency={currency}
              />
            </TouchableOpacity>
          ))}
        </VariantList>
      ))}
    </Container>
  );
};

const Container = styled.View`
  flex: 1;
  margin: auto 7px;
`;

const VariantList = styled.View`
  margin-bottom: 20px;
`;

const Header = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin: 0 20px;
`;

const Title = styled.Text`
  color: #36235e;
  font-size: 20px;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  letter-spacing: 0;
`;

const RequiredBox = styled.View`
  background: rgb(234, 241, 251);
  border-radius: 4px;
  align-items: center;
  justify-content: center;
`;

const RequiredText = styled.Text`
  color: rgb(12, 95, 204);
  font-size: 12px;
  font-family: OpenSans-Semibold;
  font-weight: 600;
  text-align: center;
  letter-spacing: 0px;
  line-height: 16px;
  margin: 2px;
`;

export default VariantLists;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Sign from './Sign';
import Consent from './Consent';

storiesOf('Modules|Discover/School/Store', module)
  .add('Consent form page', () => <Consent />)
  .add('Signature page', () => <Sign />);

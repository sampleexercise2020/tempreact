import React from 'react';
import { storiesOf } from '@storybook/react-native';

import QuantityPicker from './QuantityPicker';

storiesOf(
  'Modules|Discover/School/Store/Components/Product/Quantity Picker',
  module
)
  .add('Basic (min 1)', () => <QuantityPicker min={1} />)
  .add('Max 5', () => <QuantityPicker min={1} max={5} />)
  .add('Between 2 and 8', () => <QuantityPicker min={2} max={8} />);

import React from 'react';
import styled from 'styled-components/native';
import CircleIndicator from 'components/common/CircleIndicator/index';

const TopIndicationBar = ({ steps, activeStep }) => {
  const renderCircles = () => {
    const circles = [];

    for (var i = 1; i <= steps; i++) {
      if (i === activeStep) {
        circles.push(<CircleIndicator active key={i} />);
      } else {
        circles.push(<CircleIndicator key={i} />);
      }
    }
    return circles;
  };

  return <Container>{renderCircles()}</Container>;
};

export default TopIndicationBar;

const Container = styled.View`
  background-color: #402ca8;
  align-items: center;
  justify-content: center;
  height: 30px;
  flex-direction: row;
`;

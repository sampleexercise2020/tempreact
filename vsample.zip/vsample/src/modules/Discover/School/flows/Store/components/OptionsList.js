import React, { useState, useEffect } from 'react';
import { TouchableOpacity, KeyboardAvoidingView } from 'react-native';
import { useStoreState } from 'easy-peasy';
import styled, { css } from 'styled-components/native';
import { useStore, useActions } from 'easy-peasy';

import ListItem from './ListItem';

const OptionsList = ({
  title,
  list,
  type,
  buttonType,
  isRequired,
  min,
  max,
  internalName,
  index
}) => {
  const currency = useStoreState((state) => state.merchant.currency);

  const [selected, setSelected] = useState(
    list[
      list.findIndex((item) => {
        return (
          item ===
          list.find((option) => {
            return (
              option.selectedByDefault == true || option.isSelected == true
            );
          })
        );
      })
    ]
  );
  const [options, setOptions] = useState(
    list.filter((item) => item.isSelected)
  );

  const [customPrice, setCustomPrice] = useState(0);

  const currentProduct = useStore((state) => state.currentProduct);

  const updateSelectedOptions = useActions(
    (actions) => actions.currentProduct.updateSelectedOptions
  );

  useEffect(() => {
    updateSelectedOptions({
      title,
      type,
      options: options
      // options: currentProduct.selectedOptions.filter((option) => option.id !== item.id)
    });
  }, [options]);

  useEffect(() => {
    updateSelectedOptions({
      title,
      type,
      options: [
        {
          ...selected,
          paymentAdjust:
            selected && selected.name == 'Enter Amount'
              ? customPrice
              : selected
              ? selected.paymentAdjust
              : 0,
          isSelected: true
        }
      ]
      // options: currentProduct.selectedOptions.filter((option) => option.id !== item.id)
    });
  }, [selected, customPrice]);

  // Runs onPress.
  const _updateSelectedOptions = (item) => {
    if (type === 'multi') {
      // Logic to handle what items are selected.
      let temp = options;

      temp.includes(item)
        ? (temp = temp.filter((option) => option !== item))
        : (temp = [...temp, item]);

      temp.length > max ? (temp = [...temp.slice(1)]) : null;

      setOptions(temp);
    } else {
      setSelected(item);
    }
  };

  // Checks if item is selected or not.
  const checkSelected = (item) => {
    if (type === 'multi') {
      return options.includes(item);
    } else if (type === 'single') {
      return item === selected;
    }
  };

  return (
    <Container behavior='padding' enabled>
      <Header>
        <Title>{title}</Title>
        {isRequired ? (
          <RequiredBox>
            <RequiredText>Required</RequiredText>
          </RequiredBox>
        ) : null}
      </Header>
      {list.map((item, index) => (
        <TouchableOpacity
          key={item.id}
          onPress={() => _updateSelectedOptions(item)}
        >
          <ListItem
            type={type}
            buttonType={buttonType}
            title={item.name}
            price={item.paymentAdjust / 100}
            checked={checkSelected(item)}
            editable={checkSelected(item)}
            setCustomPrice={setCustomPrice}
            currency={currency}
          />
        </TouchableOpacity>
      ))}
    </Container>
  );
};

const Container = styled.KeyboardAvoidingView`
  flex: 1;
  margin: auto 7px;
`;

const Header = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin: 0 20px;
`;

const Title = styled.Text`
  color: #36235e;
  font-size: 20px;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  letter-spacing: 0;
`;

const RequiredBox = styled.View`
  background: rgb(234, 241, 251);
  border-radius: 4px;
  align-items: center;
  justify-content: center;
`;

const RequiredText = styled.Text`
  color: rgb(12, 95, 204);
  font-size: 12px;
  font-family: OpenSans-Semibold;
  font-weight: 600;
  text-align: center;
  letter-spacing: 0px;
  line-height: 16px;
  margin: 2px;
`;

export default OptionsList;

import React from 'react';
import { WebView, Text } from 'react-native';
import styled from 'styled-components/native';
import { testProperties } from '../../helpers/testProperties';

const simpleArrowForward =
  '../../../assets/icons/navigation/simple-arrow-forward-dark.png';
const skiplyPoints = '../../../assets/icons/common/skiply-points.png';

const PromotionAccountButton = ({ onPress }) => {
  return (
    <Container
      {...testProperties('promotion-accountbutton-container-id')}
      onPress={onPress}
    >
      <PointsIconContainer>
        <PointsIcon source={require(skiplyPoints)} />
      </PointsIconContainer>
      <TextContainer>
        <Title {...testProperties('promotion-accountbutton-title-id')}>
          My Skiply Points
        </Title>
        <PointsText>2 200 pts</PointsText>
      </TextContainer>
      <ArrowIconContainer>
        <ArrowIcon source={require(simpleArrowForward)} />
      </ArrowIconContainer>
    </Container>
  );
};

export default PromotionAccountButton;

const Container = styled.TouchableOpacity`
  margin: 20px;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  background: rgb(255, 241, 226);
  border-radius: 4px;
  padding: 20px;
`;

const Title = styled.Text`
  color: rgb(44, 30, 117);
  font-size: 12px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 16px;
`;

const PointsIconContainer = styled.View`
  height: 45px;
  width: 45px;
  margin-right: 20px;
`;

const PointsIcon = styled.Image`
  height: 45px;
  width: 45px;
`;

const PointsText = styled.Text`
  color: rgb(44, 30, 117);
  font-size: 20px;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  letter-spacing: 0px;
  line-height: 28px;
`;

const TextContainer = styled.View`
  flex: 1;
`;

const Border = styled.View`
  border-bottom-width: 1px;
  border-color: #edeef1;
`;

const ArrowIconContainer = styled.View`
  align-items: center;
  height: 20px;
`;
const ArrowIcon = styled.Image`
  height: 16px;
  width: 10px;
`;

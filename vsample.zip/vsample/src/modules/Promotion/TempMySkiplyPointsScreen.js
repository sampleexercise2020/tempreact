import React from 'react';
import { WebView, Text } from 'react-native';
import MySkiplyPoints from './MySkiplyPoints';

const TempMySkiplyPoints = () => {
  return (
    <MySkiplyPoints
      noRAKCard={false}
      appliedForCardInfo={false}
      hasPoints={true}
      showAddBtn={false}
    />
  );
};

export default MySkiplyPoints;

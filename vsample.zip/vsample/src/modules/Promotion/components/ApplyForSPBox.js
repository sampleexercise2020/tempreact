import React from 'react';
import { Platform } from 'react-native';
import styled from 'styled-components/native';
import TextLink from '../../../components/common/Link/TextLink';
import { navigateTo } from 'navigation';
import { Navigation } from 'react-native-navigation';

const logo = require('../../../../assets/images/skiply_pts.png');
const backArrowDark = require('../../../../assets/icons/common/back_arrow_dark.png');

const ApplyForSPBox = ({ componentId }) => {
  const navigateToSkiplyPointsPage = () => {
    navigateTo(
      'Skiply.Promotion.MySkiplyPoints',
      componentId,
      {
        //TILL PERSONEN SOM GÖR DETTA: kolla i MySkiplyPoints.stories.js för att se alla olika conditions
        //screenen kan vara i, alla conditions är klara men behöver passas ner här nere.
        noRAKCard: true,
        showAddBtn: true
      },
      {
        topBar: {
          background: {
            color: '#fff1e2'
          },
          backButton: {
            icon: backArrowDark,
            color: '#0d1943'
          }
        }
      }
    );
  };

  return (
    <Container>
      <TopContainer>
        <Logo source={logo} />
        <TextWrapper>
          <Title>Skiply Points</Title>
          <Subtitle>Earn cashback on every purchase</Subtitle>
        </TextWrapper>
      </TopContainer>
      <BottomContainer>
        <TextLink
          marginLeft={20}
          linktext='Apply here'
          onPress={() => navigateToSkiplyPointsPage()}
        />
      </BottomContainer>
    </Container>
  );
};

export default ApplyForSPBox;

const Container = styled.View`
  margin: 0 20px;
  height: 140px;
  border-top-left-radius: 40px;
  border-bottom-right-radius: 40px;
  margin-bottom: 30px;
  box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.08);
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 16px;
  font-weight: 900;
  line-height: 22px;
  color: #2c1e75;
`;

const Logo = styled.Image`
  height: 26px;
  width: 28px;
  margin-left: 25px;
`;

const Subtitle = styled.Text`
  color: #2c1e75;
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  line-height: 16px;
`;

const TopContainer = styled.View`
  background-color: #fff1e2;
  height: 90px;
  border-top-left-radius: 40px;
  align-items: center;
  flex-direction: row;
  border: 4px solid white;
`;

const TextWrapper = styled.View`
  flex-direction: column;
  margin-left: 15px;
`;

const BottomContainer = styled.View`
  flex: 1;
  align-items: center;
  flex-direction: row;
  background-color: white;
  overflow: hidden;
  border-bottom-right-radius: 40px;
`;

import React, { useState } from 'react';
import { Dimensions } from 'react-native';
import styled from 'styled-components/native';
import CarouselSlide from './CarouselSlide';
import CircleIndicator from 'components/common/CircleIndicator/index';
import { testProperties } from '../../../helpers/testProperties';

const RakBankCardCarousel = ({ setSelectedCard, cardsList }) => {
  const [scrollIndex, setScrollIndex] = useState(0);
  const screenWidth = Dimensions.get('window').width;

  const handleScroll = (e) => {
    const offset = e.nativeEvent.contentOffset.x;
    const index = Math.ceil(offset / screenWidth);

    setScrollIndex(index);
    setSelectedCard(index);
  };

  return (
    <Container {...testProperties('rakbank-carousel-container-id')}>
      <CardList
        horizontal
        showsHorizontalScrollIndicator={false}
        snapToAlignment='center'
        decelerationRate='fast'
        snapToInterval={screenWidth}
        onMomentumScrollEnd={handleScroll}
      >
        {cardsList.map((item) => (
          <CarouselSlide
            key={item.id}
            cardImg={item.cardImg}
            cardType={item.cardType}
            cardDesc={item.cardDesc}
          />
        ))}
      </CardList>
      <IndicatorContainer>
        {cardsList.map((item, i) => (
          <CircleIndicator key={item.id} darkActive={i === scrollIndex} dark />
        ))}
      </IndicatorContainer>
    </Container>
  );
};

export default RakBankCardCarousel;

const CardList = styled.ScrollView`
  flex: 1;
`;

const Container = styled.View`
  flex: 1;
`;

const IndicatorContainer = styled.View`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin: 30px 0;
`;

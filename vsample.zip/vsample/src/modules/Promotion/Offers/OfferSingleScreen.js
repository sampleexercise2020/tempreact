import React, { useState, useEffect } from 'react';
import { Linking } from 'react-native';
import { useStore, useActions, useStoreActions } from 'easy-peasy';
import styled from 'styled-components/native';
import Button from 'components/common/Button/Button';
import { navigateTo } from 'navigation';
import OffersSingleScreenCard from './components/OffersSingleScreenCard';
import LoaderContainer from 'components/common/LoaderContainer';
import { testProperties } from '../../../helpers/testProperties';
import { callPhoneNumber } from '../../../helpers/callPhoneNumber';
import openMap from 'react-native-open-maps';

//TODO: fixa så man faktiskt öppnar länken som finns. - TERMS AND CONDITIONS och WEBSITE URL

const markerIcon = require('../../../../assets/images/marker.png');

const OfferSingleScreen = ({ componentId, offerId }) => {
  const offer = useStore((state) => state.promotion.offer);
  const isLoading = useStore((state) => state.promotion.isLoading);
  const errorMessage = useStore((state) => state.promotion.errorMessage);
  const getSingleOffer = useActions(
    (actions) => actions.promotion.getSingleOffer
  );

  useEffect(() => {
    getSingleOffer({
      bankId: 'RAK',
      channelId: 'MB',
      mode: 'Content',
      pageContext: 'Offers',
      cId: offerId
    });
  }, []);

  const openWebsite = (url) => {
    Linking.canOpenURL(url)
      .then((supported) => {
        if (supported) {
          Linking.openURL(url);
        } else {
          console.log("Don't know how to open URI: " + url);
        }
      })
      .catch((e) => console.log('Something went wrong when opening url:', e));
  };

  const openMaps = (latitude, longitude) => {
    openMap({
      latitude: parseFloat(latitude),
      longitude: parseFloat(longitude)
    });
  };

  return (
    <>
      <LoaderContainer isLoading={isLoading}>
        {errorMessage ? (
          <ErrorMessage>{errorMessage}</ErrorMessage>
        ) : (
          <>
            <Container>
              <BannerImage
                source={{ uri: offer.onThumbNail }}
                resizeMode='cover'
              />
              <InnerContainer>
                <LocationContainer>
                  <LocationIcon source={markerIcon} />
                  <LocationName numberOfLines={2}>
                    {offer.onDetailedAddress}
                  </LocationName>
                </LocationContainer>
                <TitleOffer
                  numberOfLines={2}
                  {...testProperties('offers-single-page-title-id')}
                >
                  {offer.onDescription}
                </TitleOffer>
                <CityName numberOfLines={1}>{offer.onCityName}</CityName>
                <LongDescription>
                  {offer.onOfferDetailedDescription}
                </LongDescription>
                <LinkToWebsiteOnPress
                  {...testProperties('offers-single-page-website-link-id')}
                  onPress={() => openWebsite('https://' + offer.onWebsite)} // FIXME: gives error because the URLs are not starting with https
                >
                  <Subtitle>Visit the website:</Subtitle>
                  <URL>{offer.onWebsite}</URL>
                </LinkToWebsiteOnPress>
              </InnerContainer>
              <Separator />
              <InnerContainer>
                <TermsTitle>Terms and Conditions</TermsTitle>
                <TermsText>
                  Please press the link below to take you to the terms and
                  conditions regarding this specific offer.
                </TermsText>
                <TermsButton>
                  <Button
                    onPress={() => openWebsite(offer.termsAndConditions)}
                    {...testProperties('offers-single-page-tnc-link-id')}
                  >
                    Visit the link here
                  </Button>
                </TermsButton>
                <OffersSingleScreenCard componentId={componentId} />
              </InnerContainer>
            </Container>
            <ButtonContainer
              elevation={5}
              style={{
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: 7
                },
                shadowOpacity: 0.43,
                shadowRadius: 9.51,

                elevation: 15
              }}
            >
              <Action>
                <Button
                  primary
                  onPress={() => callPhoneNumber(offer.onTelephone)}
                  {...testProperties(
                    'offers-single-page-call-company-button-id'
                  )}
                >
                  Call
                </Button>
              </Action>
              <Action>
                <Button
                  onPress={() => openMaps(offer.onLatitude, offer.onLangitude)}
                  {...testProperties(
                    'offers-single-page-get-directions-button-id'
                  )}
                >
                  Get Directions
                </Button>
              </Action>
            </ButtonContainer>
          </>
        )}
      </LoaderContainer>
    </>
  );
};

export default OfferSingleScreen;

const Container = styled.ScrollView``;

const InnerContainer = styled.View`
  margin: 0 20px;
`;
const ButtonContainer = styled.View`
  padding: 15px 20px;
  background-color: #ffffff;
  flex-direction: row;
`;

const Action = styled.View`
  flex-basis: 0
  flex-grow: 1;
  padding: 0 5px;
`;

const TitleOffer = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  color: #0d1943;
  font-size: 32px;
  line-height: 40px;
  font-weight: 900;
`;

const BannerImage = styled.Image`
  height: 225px;
  background-color: #f5f5f7;
`;

const LocationContainer = styled.View`
  flex-direction: row;
  margin: 30px 20px 15px 20px;
  align-items: center;
`;

const LocationIcon = styled.Image`
  height: 22px;
  width: 18px;
  margin-right: 7px;
`;

const LocationName = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  line-height: 20px;
  color: #333333;
  margin-right: 20px;
`;

const CityName = styled.Text`
  font-family: 'OpenSans-Bold';
  color: #333333;
  font-size: 16px;
  font-weight: bold;
  line-height: 20px;
  margin-top: 7px;
`;

const LongDescription = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
  margin-top: 25px;
`;

const LinkToWebsiteOnPress = styled.TouchableOpacity`
  margin-top: 35px;
`;

const Subtitle = styled.Text`
  font-family: 'TeshrinAR+LT-Regular';
  font-size: 18px;
  line-height: 28px;
  color: #210b4d;
`;

const URL = styled.Text`
  font-family: 'TeshrinAR+LT-Regular';
  font-size: 18px;
  line-height: 28px;
  color: #210b4d;
`;

const Separator = styled.View`
  border-width: 0.5px;
  border-color: #edeef1;
  margin: 25px 0;
`;

const TermsTitle = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 18px;
  font-weight: bold;
  line-height: 28px;
  color: #0d1943;
`;

const TermsText = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
  margin-top: 25px;
`;

const TermsButton = styled.View`
  margin-top: 35px;
`;

const TermsURLText = styled.Text`
  font-family: 'TeshrinAR+LT-Regular';
  font-size: 18px;
  line-height: 28px;
  color: #210b4d;
`;

const ErrorMessage = styled.Text`
  color: red;
  text-align: center;
  margin-bottom: 10px;
`;

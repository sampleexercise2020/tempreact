import React from 'react';
import styled from 'styled-components/native';

const downArrowIcon = require('../../../../../assets/icons/common/down-arrow.png');

const CategoryInputField = ({ onPress }) => {
  return (
    <Container onPress={onPress}>
      <Placeholder>Pick category</Placeholder>
      <Arrow source={downArrowIcon} />
    </Container>
  );
};

export default CategoryInputField;

const Container = styled.TouchableOpacity`
  border: 1px solid rgb(237, 238, 241);
  background-color: #ffffff;
  height: 50px;
  margin: 0 15px;
  flex-direction: row;
  align-items: center;
  border-radius: 4px;
`;

const Placeholder = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
  margin-left: 20px;
`;

const Arrow = styled.Image`
  height: 10px;
  width: 10px;
  position: absolute;
  right: 20;
`;

import React from 'react';
import { View } from 'react-native';
import styled from 'styled-components/native';

const OffersCategoryCard = (props) => {
  function handleOnPress() {
    props.onPress({
      title: props.title,
      id: props.id,
      categoryImage: props.categoryImage
    });
  }

  return (
    <View
      style={{
        shadowColor: '#000',
        shadowOffset: {
          width: 1,
          height: 1
        },
        shadowOpacity: 0.13,
        elevation: 4
      }}
    >
      <Container onPress={handleOnPress}>
        <PicContainer>
          <OfferBannerPicture
            resizeMode='cover'
            source={{ uri: props.categoryImage }}
          />
        </PicContainer>
        <TextContainer>
          <Title>{props.title}</Title>
        </TextContainer>
      </Container>
    </View>
  );
};

export default OffersCategoryCard;

const Container = styled.TouchableOpacity`
  height: 160px;
  border-top-left-radius: 40px;
  border-bottom-right-radius: 40px;
  border-top-right-radius: 4px;
  border-bottom-left-radius: 4px;
  overflow: hidden;
  margin-bottom: 20px;
  border: 1px solid #edeef1;
  background-color: #ffffff;
`;

const Title = styled.Text`
  font-size: 14px;
  color: #0d1943;
  line-height: 18px;
  font-family: 'TeshrinAR-Bold';
  margin-left: 20px;
`;

const OfferBannerPicture = styled.Image`
  height: 120px;
  width: 100%;
  border-top-right-radius: 4px;
`;

const PicContainer = styled.View`
  height: 120px;
  width: 100%;
  border-top-right-radius: 4px;
`;

const TextContainer = styled.View`
  height: 40px;
  justify-content: center;
`;

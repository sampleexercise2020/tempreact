import React, { useState, useEffect } from 'react';
import { useStore, useActions, useStoreActions } from 'easy-peasy';
import styled from 'styled-components/native';
import { navigateTo, options } from 'navigation';
import CategoryListItem from './components/CategoryListItem';
import LoaderContainer from 'components/common/LoaderContainer';
import SearchBar from 'components/common/SearchBar';

const OffersScreen = (props) => {
  const fetchOffersAction = useActions(({ promotion }) => promotion.getOffers);

  const [isFetchingOffers, setIsFetchingOffers] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [offers, setOffers] = useState([]);
  const [searchString, setSearchString] = useState('');
  const [filteredOffers, setFilteredOffers] = useState([]);

  useEffect(() => {
    fetchOffers();
  }, []);

  useEffect(() => {
    setFilteredOffers(offers);
  }, [offers]);

  useEffect(() => {
    console.log('Searchstring: ', searchString);
    if (offers && offers.length > 0) {
      setFilteredOffers(
        offers.filter((offer) =>
          matchString(offer.onDealTitle, searchString.queryString)
        )
      );
    }
  }, [searchString]);

  async function fetchOffers() {
    setIsFetchingOffers(true);

    const response = await fetchOffersAction({
      bankId: 'RAK',
      channelId: 'MB',
      mode: 'HTML',
      pageContext: 'Offers',
      userSegment: props.category.id
    });

    if (response.status == 200) {
      const categoryId =
        props.category.id == 'ALL_OFFERS' ? 'All_Offers' : props.category.id;
      setOffers(response.data.contentListMap.OFFERS[categoryId]);
    } else {
      setErrorMessage(response.message);
    }

    setIsFetchingOffers(false);
  }

  const matchString = (string = '', compare = '') => {
    return string.toLowerCase().includes(compare.toLowerCase());
  };

  const navigateToOffer = (offer) => {
    navigateTo(
      'Skiply.Promotion.Offers.OffersSingleScreen',
      props.componentId,
      {
        offerId: offer.onOfferName
      },
      {
        topBar: options.topBarWithTitle(offer.onDealTitle)
      }
    );
  };

  return (
    <Container>
      <SearchContainer>
        <SearchInner>
          <SearchBar
            placeholderText='Search for an offer'
            onSubmit={setSearchString}
          />
        </SearchInner>
      </SearchContainer>
      <LoaderContainer isLoading={isFetchingOffers}>
        {errorMessage ? (
          <ErrorMessage>{errorMessage}</ErrorMessage>
        ) : (
          <OffersList
            data={filteredOffers}
            getItemLayout={(data, index) => ({
              length: 216,
              offset: 216 * index,
              index
            })}
            renderItem={({ item }) => (
              <CategoryListItem
                thumbnail={item.onThumbNail}
                key={item.onOfferName}
                companyName={item.onDealTitle}
                offer={item.OnDescription} // Not camelcase??
                location={`${item.onAreaName}, ${item.onCityName}`}
                onPress={
                  () => navigateToOffer(item) // Very odd parameter name for offer id?
                }
              />
            )}
            ItemSeparatorComponent={() => <Separator />}
          />
        )}
      </LoaderContainer>
    </Container>
  );
};

export default OffersScreen;

const Container = styled.ScrollView`
  flex: 1;
`;

const SearchContainer = styled.View`
  padding-top: 30px;
`;

const SearchInner = styled.View`
  margin-top: 30px;
  background-color: #f5f5f7;
  height: 81px;
  justify-content: center;
  padding: 0 15px;
  margin: 0 20px 20px 20px;
  border-radius: 4px;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 32px;
  font-weight: 900;
  line-height: 40;
  margin: 30px 20px 25px 20px;
  color: #0d1943;
`;

const Separator = styled.View`
  border-width: 0.5px;
  border-color: #edeef1;
`;

const ErrorMessage = styled.Text`
  color: red;
  text-align: center;
  margin-bottom: 10px;
`;

const OffersList = styled.FlatList``;

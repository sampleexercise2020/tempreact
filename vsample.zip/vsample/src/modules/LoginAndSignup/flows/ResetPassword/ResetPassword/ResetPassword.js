import React, { useState, useEffect } from 'react';
import { Alert } from 'react-native';
import styled from 'styled-components/native';
import * as yup from 'yup'; // for everything
import FormInput from 'components/common/Input/FormInput';
import Button from 'components/common/Button/Button';
import { useStoreActions, useStoreState } from 'easy-peasy';
import { navigateTo } from 'navigation';
import selectedCopy from 'i18n/copy';
import { testProperties } from 'helpers/testProperties';
import MessageBox from '../../Login/components/MessageBox';

const copy = selectedCopy.components.modules.LoginAndSignup.flows.ResetPassword;

let emailSchema = yup.object().shape({
  email: yup
    .string()
    .email()
    .required()
});

const ResetPassword = ({ componentId }) => {
  const [email, setEmail] = useState('');
  const [valid, setValid] = useState(false);
  const resetPassword = useStoreActions(
    (actions) => actions.session.resetPassword
  );
  const setOtpToken = useStoreActions((actions) => actions.session.setOtpToken);
  const isLoading = useStoreState((state) => state.session.isLoading);
  const errorMessage = useStoreState((state) => state.session.errorMessage);
  const otpToken = useStoreState((state) => state.session.otpToken);
  const resetPasswordFetchDetails = useStoreState(
    (state) => state.session.resetPasswordFetchDetails
  );

  const checkValidity = async () => {
    const validity = await emailSchema.isValid({
      email: email
    });
    validity ? setValid(true) : setValid(false);
    console.log(validity);
  };

  const handleReset = async () => {
    const response = await resetPassword(email);
    if (response == 200) {
      navigateTo('Skiply.VerifyReset', componentId, { email: email });
    }
  };

  useEffect(() => {
    checkValidity();
  }, [email]);

  return (
    <Container
      {...testProperties('resetpassword-resetpasswordform-container-id')}
    >
      <InnerContainer>
        <Title {...testProperties('resetpassword-title-id')}>
          {copy.Title}
        </Title>
        <FormContainer>
          <FormInput
            testProperties={testProperties('resetpassword-email-input-id')}
            numberOfLines={1}
            logo={false}
            label='E-mail'
            keyboardType='email-address'
            returnKeyType='go'
            value={email}
            autoCapitalize={'none'}
            onChangeText={(text) => setEmail(text)}
          />
        </FormContainer>
        {errorMessage != '' ? (
          <MessageBox error={true} message={errorMessage} />
        ) : null}
      </InnerContainer>

      <Button
        testProperties={testProperties('resetpassword-nextstep-button-id')}
        disabled={!valid || isLoading}
        primary={valid}
        onPress={handleReset}
      >
        Send reset code
      </Button>
    </Container>
  );
};

export default ResetPassword;

const Container = styled.View`
  margin: 0 20px 20px 20px;
  flex: 1;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  line-height: 22px;
  padding: 25px 40px;
  text-align: center;
  color: #0d1943;
`;

const FormContainer = styled.View`
  background-color: #f5f5f7;
  border-radius: 4px;
  padding: 10px 15px 5px 15px;
`;

const ErrorContainer = styled.View``;

const ErrorText = styled.Text``;

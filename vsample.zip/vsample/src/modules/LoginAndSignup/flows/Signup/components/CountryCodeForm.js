import React, { useState } from 'react';
import styled from 'styled-components/native';
import PickerSelect from 'react-native-picker-select';

export default class CountryCodeForm extends React.Component {
  static defaultProps = {
    source: '../../../../../../assets/flags/united_arab_emirates_uae.png'
  };

  constructor(props) {
    super(props);

    this.state = {
      currentIndex: 220,
      source: require('../../../../../../assets/flags/united_arab_emirates_uae.png'),
      items: [
        {
          countryCode: '+93',
          label: 'Afghanistan',
          value: 'Afghanistan',
          source: require('../../../../../../assets/flags/afghanistan.png')
        },
        {
          countryCode: '+355',
          label: 'Albania',
          value: 'Albania',
          source: require('../../../../../../assets/flags/albania.png')
        },
        {
          countryCode: '+213',
          label: 'Algeria',
          value: 'Algeria',
          source: require('../../../../../../assets/flags/algeria.png')
        },
        {
          countryCode: '+1 684',
          label: 'American Samoa',
          value: 'American Samoa',
          source: require('../../../../../../assets/flags/american_samoa.png')
        },
        {
          countryCode: '+376',
          label: 'Andorra',
          value: 'Andorra',
          source: require('../../../../../../assets/flags/andorra.png')
        },
        {
          countryCode: '+244',
          label: 'Angola',
          value: 'Angola',
          source: require('../../../../../../assets/flags/angola.png')
        },
        {
          countryCode: '+1 264',
          label: 'Anguilla',
          value: 'Anguilla',
          source: require('../../../../../../assets/flags/anguilla.png')
        },
        {
          countryCode: '+1 268',
          label: 'Antigua and Barbuda',
          value: 'Antigua and Barbuda',
          source: require('../../../../../../assets/flags/antigua_and_barbuda.png')
        },
        {
          countryCode: '+54',
          label: 'Argentina',
          value: 'Argentina',
          source: require('../../../../../../assets/flags/argentina.png')
        },
        {
          countryCode: '+374',
          label: 'Armenia',
          value: 'Armenia',
          source: require('../../../../../../assets/flags/armenia.png')
        },
        {
          countryCode: '+297',
          label: 'Aruba',
          value: 'Aruba',
          source: require('../../../../../../assets/flags/aruba.png')
        },
        {
          countryCode: '+247',
          label: 'Ascension',
          value: 'Ascension',
          source: require('../../../../../../assets/flags/united_kingdom.png')
        },
        {
          countryCode: '+61',
          label: 'Australia',
          value: 'Australia',
          source: require('../../../../../../assets/flags/australia.png')
        },
        {
          countryCode: '+672',
          label: 'Australian External Territories',
          value: 'Australian External Territories',
          source: require('../../../../../../assets/flags/australia.png')
        },
        {
          countryCode: '+43',
          label: 'Austria',
          value: 'Austria',
          source: require('../../../../../../assets/flags/austria.png')
        },
        {
          countryCode: '+994',
          label: 'Azerbaijan',
          value: 'Azerbaijan',
          source: require('../../../../../../assets/flags/azerbaijan.png')
        },
        {
          countryCode: '+1 242',
          label: 'Bahamas',
          value: 'Bahamas',
          source: require('../../../../../../assets/flags/bahamas.png')
        },
        {
          countryCode: '+973',
          label: 'Bahrain',
          value: 'Bahrain',
          source: require('../../../../../../assets/flags/bahrain.png')
        },
        {
          countryCode: '+880',
          label: 'Bangladesh',
          value: 'Bangladesh',
          source: require('../../../../../../assets/flags/bangladesh.png')
        },
        {
          countryCode: '+1 246',
          label: 'Barbados',
          value: 'Barbados',
          source: require('../../../../../../assets/flags/barbados.png')
        },
        {
          countryCode: '+1 268',
          label: 'Barbuda',
          value: 'Barbuda',
          source: require('../../../../../../assets/flags/antigua_and_barbuda.png')
        },
        {
          countryCode: '+375',
          label: 'Belarus',
          value: 'Belarus',
          source: require('../../../../../../assets/flags/belarus.png')
        },
        {
          countryCode: '+32',
          label: 'Belgium',
          value: 'Belgium',
          source: require('../../../../../../assets/flags/belgium.png')
        },
        {
          countryCode: '+501',
          label: 'Belize',
          value: 'Belize',
          source: require('../../../../../../assets/flags/belize.png')
        },
        {
          countryCode: '+229',
          label: 'Benin',
          value: 'Benin',
          source: require('../../../../../../assets/flags/benin.png')
        },
        {
          countryCode: '+1 441',
          label: 'Bermuda',
          value: 'Bermuda',
          source: require('../../../../../../assets/flags/bermuda.png')
        },
        {
          countryCode: '+975',
          label: 'Bhutan',
          value: 'Bhutan',
          source: require('../../../../../../assets/flags/bhutan.png')
        },
        {
          countryCode: '+591',
          label: 'Bolivia',
          value: 'Bolivia',
          source: require('../../../../../../assets/flags/bolivia.png')
        },
        {
          countryCode: '+387',
          label: 'Bosnia and Herzegovina',
          value: 'Bosnia and Herzegovina',
          source: require('../../../../../../assets/flags/bosnia_and_herzegovina.png')
        },
        {
          countryCode: '+267',
          label: 'Botswana',
          value: 'Botswana',
          source: require('../../../../../../assets/flags/botswana.png')
        },
        {
          countryCode: '+55',
          label: 'Brazil',
          value: 'Brazil',
          source: require('../../../../../../assets/flags/brazil.png')
        },
        {
          countryCode: '+246',
          label: 'British Indian Ocean Territory',
          value: 'British Indian Ocean Territory',
          source: require('../../../../../../assets/flags/united_kingdom.png')
        },
        {
          countryCode: '+1 284',
          label: 'British Virgin Islands',
          value: 'British Virgin Islands',
          source: require('../../../../../../assets/flags/british_virgin_islands.png')
        },
        {
          countryCode: '+673',
          label: 'Brunei',
          value: 'Brunei',
          source: require('../../../../../../assets/flags/brunei.png')
        },
        {
          countryCode: '+359',
          label: 'Bulgaria',
          value: 'Bulgaria',
          source: require('../../../../../../assets/flags/bulgaria.png')
        },
        {
          countryCode: '+226',
          label: 'Burkina Faso',
          value: 'Burkina Faso',
          source: require('../../../../../../assets/flags/burkina_faso.png')
        },
        {
          countryCode: '+257',
          label: 'Burundi',
          value: 'Burundi',
          source: require('../../../../../../assets/flags/burundi.png')
        },
        {
          countryCode: '+855',
          label: 'Cambodia',
          value: 'Cambodia',
          source: require('../../../../../../assets/flags/cambodia.png')
        },
        {
          countryCode: '+237',
          label: 'Cameroon',
          value: 'Cameroon',
          source: require('../../../../../../assets/flags/cameroon.png')
        },
        {
          countryCode: '+1',
          label: 'Canada',
          value: 'Canada',
          source: require('../../../../../../assets/flags/canada.png')
        },
        {
          countryCode: '+238',
          label: 'Cape Verde',
          value: 'Cape Verde',
          source: require('../../../../../../assets/flags/cape_verde.png')
        },
        {
          countryCode: '+ 345',
          label: 'Cayman Islands',
          value: 'Cayman Islands',
          source: require('../../../../../../assets/flags/cayman_islands.png')
        },
        {
          countryCode: '+236',
          label: 'Central African Republic',
          value: 'Central African Republic',
          source: require('../../../../../../assets/flags/central_african_republic.png')
        },
        {
          countryCode: '+235',
          label: 'Chad',
          value: 'Chad',
          source: require('../../../../../../assets/flags/chad.png')
        },
        {
          countryCode: '+56',
          label: 'Chile',
          value: 'Chile',
          source: require('../../../../../../assets/flags/chile.png')
        },
        {
          countryCode: '+86',
          label: 'China',
          value: 'China',
          source: require('../../../../../../assets/flags/china.png')
        },
        {
          countryCode: '+61',
          label: 'Christmas Island',
          value: 'Christmas Island',
          source: require('../../../../../../assets/flags/christmas_island.png')
        },
        {
          countryCode: '+61',
          label: 'Cocos-Keeling Islands',
          value: 'Cocos-Keeling Islands',
          source: require('../../../../../../assets/flags/cocos_islands.png')
        },
        {
          countryCode: '+57',
          label: 'Colombia',
          value: 'Colombia',
          source: require('../../../../../../assets/flags/colombia.png')
        },
        {
          countryCode: '+269',
          label: 'Comoros',
          value: 'Comoros',
          source: require('../../../../../../assets/flags/comoros.png')
        },
        {
          countryCode: '+242',
          label: 'Congo',
          value: 'Congo',
          source: require('../../../../../../assets/flags/congo_republic.png')
        },
        {
          countryCode: '+243',
          label: 'Congo, Dem. Rep.',
          value: 'Congo, Dem. Rep.',
          source: require('../../../../../../assets/flags/congo_democratic_republic.png')
        },
        {
          countryCode: '+682',
          label: 'Cook Islands',
          value: 'Cook Islands',
          source: require('../../../../../../assets/flags/the_cook_islands.png')
        },
        {
          countryCode: '+506',
          label: 'Costa Rica',
          value: 'Costa Rica',
          source: require('../../../../../../assets/flags/costa_rica.png')
        },
        {
          countryCode: '+385',
          label: 'Croatia',
          value: 'Croatia',
          source: require('../../../../../../assets/flags/costa_rica.png')
        },
        {
          countryCode: '+53',
          label: 'Cuba',
          value: 'Cuba',
          source: require('../../../../../../assets/flags/cuba.png')
        },
        {
          countryCode: '+599',
          label: 'Curacao',
          value: 'Curacao',
          source: require('../../../../../../assets/flags/curacao.png')
        },
        {
          countryCode: '+537',
          label: 'Cyprus',
          value: 'Cyprus',
          source: require('../../../../../../assets/flags/cyprus.png')
        },
        {
          countryCode: '+420',
          label: 'Czech Republic',
          value: 'Czech Republic',
          source: require('../../../../../../assets/flags/czech_republic.png')
        },
        {
          countryCode: '+45',
          label: 'Denmark',
          value: 'Denmark',
          source: require('../../../../../../assets/flags/denmark.png')
        },
        {
          countryCode: '+246',
          label: 'Diego Garcia',
          value: 'Diego Garcia',
          source: require('../../../../../../assets/flags/united_kingdom.png')
        },
        {
          countryCode: '+253',
          label: 'Djibouti',
          value: 'Djibouti',
          source: require('../../../../../../assets/flags/djibouti.png')
        },
        {
          countryCode: '+1 767',
          label: 'Dominica',
          value: 'Dominica',
          source: require('../../../../../../assets/flags/dominica.png')
        },
        {
          countryCode: '+1 809',
          label: 'Dominican Republic',
          value: 'Dominican Republic',
          source: require('../../../../../../assets/flags/dominican_republic.png')
        },
        {
          countryCode: '+670',
          label: 'East Timor',
          value: 'East Timor',
          source: require('../../../../../../assets/flags/east_timor.png')
        },
        {
          countryCode: '+593',
          label: 'Ecuador',
          value: 'Ecuador',
          source: require('../../../../../../assets/flags/ecuador.png')
        },
        {
          countryCode: '+20',
          label: 'Egypt',
          value: 'Egypt',
          source: require('../../../../../../assets/flags/egypt.png')
        },
        {
          countryCode: '+503',
          label: 'El Salvador',
          value: 'El Salvador',
          source: require('../../../../../../assets/flags/el_salvador.png')
        },
        {
          countryCode: '+240',
          label: 'Equatorial Guinea',
          value: 'Equatorial Guinea',
          source: require('../../../../../../assets/flags/equatorial_guinea.png')
        },
        {
          countryCode: '+291',
          label: 'Eritrea',
          value: 'Eritrea',
          source: require('../../../../../../assets/flags/eritrea.png')
        },
        {
          countryCode: '+372',
          label: 'Estonia',
          value: 'Estonia',
          source: require('../../../../../../assets/flags/estonia.png')
        },
        {
          countryCode: '+251',
          label: 'Ethiopia',
          value: 'Ethiopia',
          source: require('../../../../../../assets/flags/ethiopia.png')
        },
        {
          countryCode: '+500',
          label: 'Falkland Islands',
          value: 'Falkland Islands',
          source: require('../../../../../../assets/flags/falkland_islands.png')
        },
        {
          countryCode: '+298',
          label: 'Faroe Islands',
          value: 'Faroe Islands',
          source: require('../../../../../../assets/flags/the_faroe_islands.png')
        },
        {
          countryCode: '+679',
          label: 'Fiji',
          value: 'Fiji',
          source: require('../../../../../../assets/flags/fiji.png')
        },
        {
          countryCode: '+358',
          label: 'Finland',
          value: 'Finland',
          source: require('../../../../../../assets/flags/finland.png')
        },
        {
          countryCode: '+33',
          label: 'France',
          value: 'France',
          source: require('../../../../../../assets/flags/france.png')
        },
        {
          countryCode: '+596',
          label: 'French Antilles',
          value: 'French Antilles',
          source: require('../../../../../../assets/flags/france.png')
        },
        {
          countryCode: '+594',
          label: 'French Guiana',
          value: 'French Guiana',
          source: require('../../../../../../assets/flags/french_guiana.png')
        },
        {
          countryCode: '+689',
          label: 'French Polynesia',
          value: 'French Polynesia',
          source: require('../../../../../../assets/flags/french_polynesia.png')
        },
        {
          countryCode: '+241',
          label: 'Gabon',
          value: 'Gabon',
          source: require('../../../../../../assets/flags/gabon.png')
        },
        {
          countryCode: '+220',
          label: 'Gambia',
          value: 'Gambia',
          source: require('../../../../../../assets/flags/gambia.png')
        },
        {
          countryCode: '+995',
          label: 'Georgia',
          value: 'Georgia',
          source: require('../../../../../../assets/flags/georgia.png')
        },
        {
          countryCode: '+49',
          label: 'Germany',
          value: 'Germany',
          source: require('../../../../../../assets/flags/germany.png')
        },
        {
          countryCode: '+233',
          label: 'Ghana',
          value: 'Ghana',
          source: require('../../../../../../assets/flags/ghana.png')
        },
        {
          countryCode: '+350',
          label: 'Gibraltar',
          value: 'Gibraltar',
          source: require('../../../../../../assets/flags/gibraltar.png')
        },
        {
          countryCode: '+30',
          label: 'Greece',
          value: 'Greece',
          source: require('../../../../../../assets/flags/greece.png')
        },
        {
          countryCode: '+299',
          label: 'Greenland',
          value: 'Greenland',
          source: require('../../../../../../assets/flags/greenland.png')
        },
        {
          countryCode: '+1 473',
          label: 'Grenada',
          value: 'Grenada',
          source: require('../../../../../../assets/flags/grenada.png')
        },
        {
          countryCode: '+590',
          label: 'Guadeloupe',
          value: 'Guadeloupe',
          source: require('../../../../../../assets/flags/france.png')
        },
        {
          countryCode: '+1 671',
          label: 'Guam',
          value: 'Guam',
          source: require('../../../../../../assets/flags/guam.png')
        },
        {
          countryCode: '+502',
          label: 'Guatemala',
          value: 'Guatemala',
          source: require('../../../../../../assets/flags/guatemala.png')
        },
        {
          countryCode: '+224',
          label: 'Guinea',
          value: 'Guinea',
          source: require('../../../../../../assets/flags/guinea.png')
        },
        {
          countryCode: '+245',
          label: 'Guinea-Bissau',
          value: 'Guinea-Bissau',
          source: require('../../../../../../assets/flags/guinea_bissau.png')
        },
        {
          countryCode: '+595',
          label: 'Guyana',
          value: 'Guyana',
          source: require('../../../../../../assets/flags/guyana.png')
        },
        {
          countryCode: '+509',
          label: 'Haiti',
          value: 'Haiti',
          source: require('../../../../../../assets/flags/haiti.png')
        },
        {
          countryCode: '+504',
          label: 'Honduras',
          value: 'Honduras',
          source: require('../../../../../../assets/flags/honduras.png')
        },
        {
          countryCode: '+852',
          label: 'Hong Kong',
          value: 'Hong Kong',
          source: require('../../../../../../assets/flags/hongkong.png')
        },
        {
          countryCode: '+36',
          label: 'Hungary',
          value: 'Hungary',
          source: require('../../../../../../assets/flags/hungary.png')
        },
        {
          countryCode: '+354',
          label: 'Iceland',
          value: 'Iceland',
          source: require('../../../../../../assets/flags/iceland.png')
        },
        {
          countryCode: '+91',
          label: 'India',
          value: 'India',
          source: require('../../../../../../assets/flags/india.png')
        },
        {
          countryCode: '+62',
          label: 'Indonesia',
          value: 'Indonesia',
          source: require('../../../../../../assets/flags/indonesia.png')
        },
        {
          countryCode: '+98',
          label: 'Iran',
          value: 'Iran',
          source: require('../../../../../../assets/flags/iran.png')
        },
        {
          countryCode: '+964',
          label: 'Iraq',
          value: 'Iraq',
          source: require('../../../../../../assets/flags/iraq.png')
        },
        {
          countryCode: '+353',
          label: 'Ireland',
          value: 'Ireland',
          source: require('../../../../../../assets/flags/ireland.png')
        },
        {
          countryCode: '+972',
          label: 'Israel',
          value: 'Israel',
          source: require('../../../../../../assets/flags/israel.png')
        },
        {
          countryCode: '+39',
          label: 'Italy',
          value: 'Italy',
          source: require('../../../../../../assets/flags/italy.png')
        },
        {
          countryCode: '+225',
          label: 'Ivory Coast',
          value: 'Ivory Coast',
          source: require("../../../../../../assets/flags/cote_d'ivoire.png")
        },
        {
          countryCode: '+1 876',
          label: 'Jamaica',
          value: 'Jamaica',
          source: require('../../../../../../assets/flags/jamaica.png')
        },
        {
          countryCode: '+81',
          label: 'Japan',
          value: 'Japan',
          source: require('../../../../../../assets/flags/japan.png')
        },
        {
          countryCode: '+962',
          label: 'Jordan',
          value: 'Jordan',
          source: require('../../../../../../assets/flags/jordan.png')
        },
        {
          countryCode: '+7 7',
          label: 'Kazakhstan',
          value: 'Kazakhstan',
          source: require('../../../../../../assets/flags/kazakhstan.png')
        },
        {
          countryCode: '+254',
          label: 'Kenya',
          value: 'Kenya',
          source: require('../../../../../../assets/flags/kenya.png')
        },
        {
          countryCode: '+686',
          label: 'Kiribati',
          value: 'Kiribati',
          source: require('../../../../../../assets/flags/kiribati.png')
        },
        {
          countryCode: '+965',
          label: 'Kuwait',
          value: 'Kuwait',
          source: require('../../../../../../assets/flags/kuwait.png')
        },
        {
          countryCode: '+996',
          label: 'Kyrgyzstan',
          value: 'Kyrgyzstan',
          source: require('../../../../../../assets/flags/kyrgyzstan.png')
        },
        {
          countryCode: '+856',
          label: 'Laos',
          value: 'Laos',
          source: require('../../../../../../assets/flags/laos.png')
        },
        {
          countryCode: '+371',
          label: 'Latvia',
          value: 'Latvia',
          source: require('../../../../../../assets/flags/latvia.png')
        },
        {
          countryCode: '+961',
          label: 'Lebanon',
          value: 'Lebanon',
          source: require('../../../../../../assets/flags/lebanon.png')
        },
        {
          countryCode: '+266',
          label: 'Lesotho',
          value: 'Lesotho',
          source: require('../../../../../../assets/flags/lesotho.png')
        },
        {
          countryCode: '+231',
          label: 'Liberia',
          value: 'Liberia',
          source: require('../../../../../../assets/flags/liberia.png')
        },
        {
          countryCode: '+218',
          label: 'Libya',
          value: 'Libya',
          source: require('../../../../../../assets/flags/libya.png')
        },
        {
          countryCode: '+423',
          label: 'Liechtenstein',
          value: 'Liechtenstein',
          source: require('../../../../../../assets/flags/liechtenstein.png')
        },
        {
          countryCode: '+370',
          label: 'Lithuania',
          value: 'Lithuania',
          source: require('../../../../../../assets/flags/lithuania.png')
        },
        {
          countryCode: '+352',
          label: 'Luxembourg',
          value: 'Luxembourg',
          source: require('../../../../../../assets/flags/luxembourg.png')
        },
        {
          countryCode: '+853',
          label: 'Macau',
          value: 'Macau',
          source: require('../../../../../../assets/flags/macau.png')
        },
        {
          countryCode: '+389',
          label: 'Macedonia',
          value: 'Macedonia',
          source: require('../../../../../../assets/flags/macedonia.png')
        },
        {
          countryCode: '+261',
          label: 'Madagascar',
          value: 'Madagascar',
          source: require('../../../../../../assets/flags/madagascar.png')
        },
        {
          countryCode: '+265',
          label: 'Malawi',
          value: 'Malawi',
          source: require('../../../../../../assets/flags/malawi.png')
        },
        {
          countryCode: '+60',
          label: 'Malaysia',
          value: 'Malaysia',
          source: require('../../../../../../assets/flags/malaysia.png')
        },
        {
          countryCode: '+960',
          label: 'Maldives',
          value: 'Maldives',
          source: require('../../../../../../assets/flags/maldives.png')
        },
        {
          countryCode: '+223',
          label: 'Mali',
          value: 'Mali',
          source: require('../../../../../../assets/flags/mali.png')
        },
        {
          countryCode: '+356',
          label: 'Malta',
          value: 'Malta',
          source: require('../../../../../../assets/flags/malta.png')
        },
        {
          countryCode: '+692',
          label: 'Marshall Islands',
          value: 'Marshall Islands',
          source: require('../../../../../../assets/flags/marshall_islands.png')
        },
        {
          countryCode: '+596',
          label: 'Martinique',
          value: 'Martinique',
          source: require('../../../../../../assets/flags/france.png')
        },
        {
          countryCode: '+222',
          label: 'Mauritania',
          value: 'Mauritania',
          source: require('../../../../../../assets/flags/mauritania.png')
        },
        {
          countryCode: '+230',
          label: 'Mauritius',
          value: 'Mauritius',
          source: require('../../../../../../assets/flags/mauritius.png')
        },
        {
          countryCode: '+262',
          label: 'Mayotte',
          value: 'Mayotte',
          source: require('../../../../../../assets/flags/france.png')
        },
        {
          countryCode: '+52',
          label: 'Mexico',
          value: 'Mexico',
          source: require('../../../../../../assets/flags/mexico.png')
        },
        {
          countryCode: '+691',
          label: 'Micronesia',
          value: 'Micronesia',
          source: require('../../../../../../assets/flags/micronesia.png')
        },
        {
          countryCode: '+1 808',
          label: 'Midway Island',
          value: 'Midway Island',
          source: require('../../../../../../assets/flags/united_states.png')
        },
        {
          countryCode: '+373',
          label: 'Moldova',
          value: 'Moldova',
          source: require('../../../../../../assets/flags/moldova.png')
        },
        {
          countryCode: '+377',
          label: 'Monaco',
          value: 'Monaco',
          source: require('../../../../../../assets/flags/monaco.png')
        },
        {
          countryCode: '+976',
          label: 'Mongolia',
          value: 'Mongolia',
          source: require('../../../../../../assets/flags/mongolia.png')
        },
        {
          countryCode: '+382',
          label: 'Montenegro',
          value: 'Montenegro',
          source: require('../../../../../../assets/flags/montenegro.png')
        },
        {
          countryCode: '+1664',
          label: 'Montserrat',
          value: 'Montserrat',
          source: require('../../../../../../assets/flags/montserrat.png')
        },
        {
          countryCode: '+212',
          label: 'Morocco',
          value: 'Morocco',
          source: require('../../../../../../assets/flags/morocco.png')
        },
        {
          countryCode: '+95',
          label: 'Myanmar',
          value: 'Myanmar',
          source: require('../../../../../../assets/flags/myanmar_burma.png')
        },
        {
          countryCode: '+264',
          label: 'Namibia',
          value: 'Namibia',
          source: require('../../../../../../assets/flags/namibia.png')
        },
        {
          countryCode: '+674',
          label: 'Nauru',
          value: 'Nauru',
          source: require('../../../../../../assets/flags/nauru.png')
        },
        {
          countryCode: '+977',
          label: 'Nepal',
          value: 'Nepal',
          source: require('../../../../../../assets/flags/nepal.png')
        },
        {
          countryCode: '+31',
          label: 'Netherlands',
          value: 'Netherlands',
          source: require('../../../../../../assets/flags/netherlands.png')
        },
        {
          countryCode: '+599',
          label: 'Netherlands Antilles',
          value: 'Netherlands Antilles',
          source: require('../../../../../../assets/flags/netherlands_antilles.png')
        },
        {
          countryCode: '+1 869',
          label: 'Nevis',
          value: 'Nevis',
          source: require('../../../../../../assets/flags/saint_kitts_and_nevis.png')
        },
        {
          countryCode: '+687',
          label: 'New Caledonia',
          value: 'New Caledonia',
          source: require('../../../../../../assets/flags/new_caledonia.png')
        },
        {
          countryCode: '+64',
          label: 'New Zealand',
          value: 'New Zealand',
          source: require('../../../../../../assets/flags/new_zealand.png')
        },
        {
          countryCode: '+505',
          label: 'Nicaragua',
          value: 'Nicaragua',
          source: require('../../../../../../assets/flags/nicaragua.png')
        },
        {
          countryCode: '+227',
          label: 'Niger',
          value: 'Niger',
          source: require('../../../../../../assets/flags/niger.png')
        },
        {
          countryCode: '+234',
          label: 'Nigeria',
          value: 'Nigeria',
          source: require('../../../../../../assets/flags/nigeria.png')
        },
        {
          countryCode: '+683',
          label: 'Niue',
          value: 'Niue',
          source: require('../../../../../../assets/flags/niue.png')
        },
        {
          countryCode: '+672',
          label: 'Norfolk Island',
          value: 'Norfolk Island',
          source: require('../../../../../../assets/flags/norfolk_island.png')
        },
        {
          countryCode: '+850',
          label: 'North Korea',
          value: 'North Korea',
          source: require('../../../../../../assets/flags/north_korea.png')
        },
        {
          countryCode: '+47',
          label: 'Norway',
          value: 'Norway',
          source: require('../../../../../../assets/flags/norway.png')
        },
        {
          countryCode: '+968',
          label: 'Oman',
          value: 'Oman',
          source: require('../../../../../../assets/flags/oman.png')
        },
        {
          countryCode: '+92',
          label: 'Pakistan',
          value: 'Pakistan',
          source: require('../../../../../../assets/flags/pakistan.png')
        },
        {
          countryCode: '+680',
          label: 'Palau',
          value: 'Palau',
          source: require('../../../../../../assets/flags/palau.png')
        },
        {
          countryCode: '+970',
          label: 'Palestinian Territory',
          value: 'Palestinian Territory',
          source: require('../../../../../../assets/flags/palestine.png')
        },
        {
          countryCode: '+507',
          label: 'Panama',
          value: 'Panama',
          source: require('../../../../../../assets/flags/panama.png')
        },
        {
          countryCode: '+675',
          label: 'Papua New Guinea',
          value: 'Papua New Guinea',
          source: require('../../../../../../assets/flags/papua_new_guinea.png')
        },
        {
          countryCode: '+595',
          label: 'Paraguay',
          value: 'Paraguay',
          source: require('../../../../../../assets/flags/paraguay.png')
        },
        {
          countryCode: '+51',
          label: 'Peru',
          value: 'Peru',
          source: require('../../../../../../assets/flags/peru.png')
        },
        {
          countryCode: '+63',
          label: 'Philippines',
          value: 'Philippines',
          source: require('../../../../../../assets/flags/philippines.png')
        },
        {
          countryCode: '+48',
          label: 'Poland',
          value: 'Poland',
          source: require('../../../../../../assets/flags/poland.png')
        },
        {
          countryCode: '+351',
          label: 'Portugal',
          value: 'Portugal',
          source: require('../../../../../../assets/flags/portugal.png')
        },
        {
          countryCode: '+1 787',
          label: 'Puerto Rico',
          value: 'Puerto Rico',
          source: require('../../../../../../assets/flags/puerto_rico.png')
        },
        {
          countryCode: '+974',
          label: 'Qatar',
          value: 'Qatar',
          source: require('../../../../../../assets/flags/qatar.png')
        },
        {
          countryCode: '+262',
          label: 'Reunion',
          value: 'Reunion',
          source: require('../../../../../../assets/flags/france.png')
        },
        {
          countryCode: '+40',
          label: 'Romania',
          value: 'Romania',
          source: require('../../../../../../assets/flags/romania.png')
        },
        {
          countryCode: '+7',
          label: 'Russia',
          value: 'Russia',
          source: require('../../../../../../assets/flags/russia.png')
        },
        {
          countryCode: '+250',
          label: 'Rwanda',
          value: 'Rwanda',
          source: require('../../../../../../assets/flags/rwanda.png')
        },
        {
          countryCode: '+685',
          label: 'Samoa',
          value: 'Samoa',
          source: require('../../../../../../assets/flags/samoa.png')
        },
        {
          countryCode: '+378',
          label: 'San Marino',
          value: 'San Marino',
          source: require('../../../../../../assets/flags/san_marino.png')
        },
        {
          countryCode: '+966',
          label: 'Saudi Arabia',
          value: 'Saudi Arabia',
          source: require('../../../../../../assets/flags/saudi_arabia.png')
        },
        {
          countryCode: '+221',
          label: 'Senegal',
          value: 'Senegal',
          source: require('../../../../../../assets/flags/senegal.png')
        },
        {
          countryCode: '+381',
          label: 'Serbia',
          value: 'Serbia',
          source: require('../../../../../../assets/flags/serbia.png')
        },
        {
          countryCode: '+248',
          label: 'Seychelles',
          value: 'Seychelles',
          source: require('../../../../../../assets/flags/seychelles.png')
        },
        {
          countryCode: '+232',
          label: 'Sierra Leone',
          value: 'Sierra Leone',
          source: require('../../../../../../assets/flags/sierra_leone.png')
        },
        {
          countryCode: '+65',
          label: 'Singapore',
          value: 'Singapore',
          source: require('../../../../../../assets/flags/singapore.png')
        },
        {
          countryCode: '+421',
          label: 'Slovakia',
          value: 'Slovakia',
          source: require('../../../../../../assets/flags/slovakia.png')
        },
        {
          countryCode: '+386',
          label: 'Slovenia',
          value: 'Slovenia',
          source: require('../../../../../../assets/flags/slovenia.png')
        },
        {
          countryCode: '+677',
          label: 'Solomon Islands',
          value: 'Solomon Islands',
          source: require('../../../../../../assets/flags/solomon_islands.png')
        },
        {
          countryCode: '+27',
          label: 'South Africa',
          value: 'South Africa',
          source: require('../../../../../../assets/flags/south_africa.png')
        },
        {
          countryCode: '+500',
          label: 'South Georgia and the South Sandwich Islands',
          value: 'South Georgia and the South Sandwich Islands',
          source: require('../../../../../../assets/flags/united_kingdom.png')
        },
        {
          countryCode: '+82',
          label: 'South Korea',
          value: 'South Korea',
          source: require('../../../../../../assets/flags/south_korea.png')
        },
        {
          countryCode: '+34',
          label: 'Spain',
          value: 'Spain',
          source: require('../../../../../../assets/flags/spain.png')
        },
        {
          countryCode: '+94',
          label: 'Sri Lanka',
          value: 'Sri Lanka',
          source: require('../../../../../../assets/flags/sri_lanka.png')
        },
        {
          countryCode: '+249',
          label: 'Sudan',
          value: 'Sudan',
          source: require('../../../../../../assets/flags/sudan.png')
        },
        {
          countryCode: '+597',
          label: 'Suriname',
          value: 'Suriname',
          source: require('../../../../../../assets/flags/suriname.png')
        },
        {
          countryCode: '+268',
          label: 'Swaziland',
          value: 'Swaziland',
          source: require('../../../../../../assets/flags/swaziland.png')
        },
        {
          countryCode: '+46',
          label: 'Sweden',
          value: 'Sweden',
          source: require('../../../../../../assets/flags/sweden.png')
        },
        {
          countryCode: '+41',
          label: 'Switzerland',
          value: 'Switzerland',
          source: require('../../../../../../assets/flags/switzeland.png')
        },
        {
          countryCode: '+963',
          label: 'Syria',
          value: 'Syria',
          source: require('../../../../../../assets/flags/syria.png')
        },
        {
          countryCode: '+886',
          label: 'Taiwan',
          value: 'Taiwan',
          source: require('../../../../../../assets/flags/taiwan.png')
        },
        {
          countryCode: '+992',
          label: 'Tajikistan',
          value: 'Tajikistan',
          source: require('../../../../../../assets/flags/tajikistan.png')
        },
        {
          countryCode: '+255',
          label: 'Tanzania',
          value: 'Tanzania',
          source: require('../../../../../../assets/flags/tanzania.png')
        },
        {
          countryCode: '+66',
          label: 'Thailand',
          value: 'Thailand',
          source: require('../../../../../../assets/flags/thailand.png')
        },
        {
          countryCode: '+670',
          label: 'Timor Leste',
          value: 'Timor Leste',
          source: require('../../../../../../assets/flags/east_timor.png')
        },
        {
          countryCode: '+228',
          label: 'Togo',
          value: 'Togo',
          source: require('../../../../../../assets/flags/togo.png')
        },
        {
          countryCode: '+690',
          label: 'Tokelau',
          value: 'Tokelau',
          source: require('../../../../../../assets/flags/tokelau.png')
        },
        {
          countryCode: '+676',
          label: 'Tonga',
          value: 'Tonga',
          source: require('../../../../../../assets/flags/tonga.png')
        },
        {
          countryCode: '+1 868',
          label: 'Trinidad and Tobago',
          value: 'Trinidad and Tobago',
          source: require('../../../../../../assets/flags/trinidad_and_tobago.png')
        },
        {
          countryCode: '+216',
          label: 'Tunisia',
          value: 'Tunisia',
          source: require('../../../../../../assets/flags/tunisia.png')
        },
        {
          countryCode: '+90',
          label: 'Turkey',
          value: 'Turkey',
          source: require('../../../../../../assets/flags/turkey.png')
        },
        {
          countryCode: '+993',
          label: 'Turkmenistan',
          value: 'Turkmenistan',
          source: require('../../../../../../assets/flags/turkmenistan.png')
        },
        {
          countryCode: '+1 649',
          label: 'Turks and Caicos Islands',
          value: 'Turks and Caicos Islands',
          source: require('../../../../../../assets/flags/the_turks_and_caicos_islands.png')
        },
        {
          countryCode: '+688',
          label: 'Tuvalu',
          value: 'Tuvalu',
          source: require('../../../../../../assets/flags/tuvalu.png')
        },
        {
          countryCode: '+1 340',
          label: 'U.S. Virgin Islands',
          value: 'U.S. Virgin Islands',
          source: require('../../../../../../assets/flags/united_states_virgin_islands.png')
        },
        {
          countryCode: '+256',
          label: 'Uganda',
          value: 'Uganda',
          source: require('../../../../../../assets/flags/uganda.png')
        },
        {
          countryCode: '+380',
          label: 'Ukraine',
          value: 'Ukraine',
          source: require('../../../../../../assets/flags/ukraine.png')
        },
        {
          countryCode: '+971',
          label: 'United Arab Emirates',
          value: 'United Arab Emirates',
          source: require('../../../../../../assets/flags/united_arab_emirates_uae.png')
        },
        {
          countryCode: '+44',
          label: 'United Kingdom',
          value: 'United Kingdom',
          source: require('../../../../../../assets/flags/united_kingdom.png')
        },
        {
          countryCode: '+1',
          label: 'United States',
          value: 'United States',
          source: require('../../../../../../assets/flags/united_states.png')
        },
        {
          countryCode: '+598',
          label: 'Uruguay',
          value: 'Uruguay',
          source: require('../../../../../../assets/flags/uruguay.png')
        },
        {
          countryCode: '+998',
          label: 'Uzbekistan',
          value: 'Uzbekistan',
          source: require('../../../../../../assets/flags/uzbekistan.png')
        },
        {
          countryCode: '+678',
          label: 'Vanuatu',
          value: 'Vanuatu',
          source: require('../../../../../../assets/flags/vanuatu.png')
        },
        {
          countryCode: '+58',
          label: 'Venezuela',
          value: 'Venezuela',
          source: require('../../../../../../assets/flags/venezuela.png')
        },
        {
          countryCode: '+84',
          label: 'Vietnam',
          value: 'Vietnam',
          source: require('../../../../../../assets/flags/vietnam.png')
        },
        {
          countryCode: '+681',
          label: 'Wallis and Futuna',
          value: 'Wallis and Futuna',
          source: require('../../../../../../assets/flags/wallis_and_futuna.png')
        },
        {
          countryCode: '+967',
          label: 'Yemen',
          value: 'Yemen',
          source: require('../../../../../../assets/flags/yemen.png')
        },
        {
          countryCode: '+260',
          label: 'Zambia',
          value: 'Zambia',
          source: require('../../../../../../assets/flags/zambia.png')
        },
        {
          countryCode: '+255',
          label: 'Zanzibar',
          value: 'Zanzibar',
          source: require('../../../../../../assets/flags/tanzania.png')
        },
        {
          countryCode: '+263',
          label: 'Zimbabwe',
          value: 'Zimbabwe',
          source: require('../../../../../../assets/flags/zimbabwe.png')
        }
      ]
    };
  }

  componentWillMount() {
    // if the component is using the optional `value` prop, the parent
    // has the abililty to both set the initial value and also update it
    setTimeout(() => {
      for (var index = 0; index < this.state.items.length; index++) {
        if (
          this.state.items[index].countryCode == this.props.defaultCountryCode
        ) {
          this.setState({
            code: this.props.defaultCountryCode,
            currentIndex: index + 1
          });
          break;
        }
      }
    }, 0.1);
  }

  render() {
    return (
      <Container>
        <TextContainer>
          <PickerSelect
            items={this.state.items}
            onValueChange={(value, index) => {
              if (value) {
                const countryCode = this.state.items[index - 1].countryCode;
                this.setState({
                  currentIndex: Math.max(1, index),
                  code: countryCode
                });
                this.props.setCountryCode(countryCode);
              }
            }}
            itemKey={this.state.items[this.state.currentIndex - 1].label}
          >
            <FlagDropdown>
              <Flag
                resizeMode='contain'
                source={this.state.items[this.state.currentIndex - 1].source}
              />

              <Arrow
                resizeMode='contain'
                source={require('../../../../../../assets/icons/common/right-arrow.png')}
              />
            </FlagDropdown>
          </PickerSelect>

          <CountryCode editable={false} value={this.state.code} />

          <InputField
            numberOfLines={1}
            keyboardType='number-pad'
            returnKeyType='go'
            maxLength={10}
            error={this.props.error}
            placeholder=''
            placeholderTextColor='rgb(206, 209, 217)'
            onChangeText={this.props.onChangeText}
            selectionColor='#0d8177'
            value={this.props.value}
          />
        </TextContainer>
      </Container>
    );
  }
}

const Container = styled.View`
  border-width: 1px;
  border-color: ${(props) =>
    props.error
      ? props.theme.color.primary.warning
      : props.theme.color.misc.listItemDivider};
  border-radius: 4px;
  height: 50px;
  background-color: ${(props) => props.theme.color.primary.white};
`;

const TextContainer = styled.View`
  flex-direction: row;
  align-items: center;
  height: 50px;
`;

const InputField = styled.TextInput`
  color: rgb(206, 209, 217);
  position: relative;
  font-size: 16px;
  color: rgb(13, 25, 67);
  flex-grow: 1;
  margin-left: 5px;
  overflow: hidden;
`;
const CountryCode = styled.TextInput`
  color: rgb(13, 25, 67);
  font-size: 16px;
  margin-left: 10px;
  min-width: 45px;
`;
const TextText = styled.Text`
  color: rgb(13, 25, 67);
  font-size: 16px;
  margin-left: 10px;
`;

const FlagDropdown = styled.View`
  justify-content: center;
  align-items: center;
  flex-direction: row;
  width: 70px;
  height: 100%;
  background: rgb(237, 238, 241);
  left: 0;
`;

const Flag = styled.Image`
  height: 30px;
  width: 30px;
`;

const Arrow = styled.Image`
  height: 12px;
  width: 12px;
  transform: rotate(90deg);
  margin-left: 10px;
`;

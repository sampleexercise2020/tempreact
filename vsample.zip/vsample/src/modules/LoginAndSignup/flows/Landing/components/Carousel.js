import React, { useState, useRef, useEffect } from 'react';
import { Dimensions } from 'react-native';
import styled, { css } from 'styled-components/native';
import CircleIndicator from 'components/common/CircleIndicator/index';
import { testProperties } from '../../../../../helpers/testProperties';
import selectedCopy from '../../../../../i18n/copy';

const copy = selectedCopy.components.modules.LoginAndSignup.flows.Landing.index;

const screenWidth = Dimensions.get('window').width;

//TODO: be Eshan ge mig all copy till karusellen idag: 9/7.

const array = [
  {
    image: require('../../../../../../assets/images/landing-school-big.png'),
    id: 1,
    backgroundColor: '#0d8177',
    title: 'All your school fees in one place',
    subtitle: 'Payments made easy, cashless and waitless.'
  },
  {
    image: require('../../../../../../assets/images/landing-boy-big.png'),
    id: 2,
    backgroundColor: '#2c79de',
    title: 'Skip the line',
    subtitle: 'Payments made easy, cashless and waitless.'
  },
  {
    image: require('../../../../../../assets/images/landing-girl-big.png'),
    id: 3,
    backgroundColor: '#030303',
    title: 'Skip the line',
    subtitle: 'Payments made easy, cashless and waitless.'
  }
];

const skiplyLogo = require('../../../../../../assets/images/skiply-logo-white-big.png');

const Carousel = ({ active }) => {
  const [scrollIndex, setScrollIndex] = useState(0);
  const scrollView = useRef();

  const handleScroll = (e) => {
    const offset = e.nativeEvent.contentOffset.x;
    const index = Math.ceil(offset / screenWidth);
    setScrollIndex(index);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (scrollIndex < 2) {
        scrollView.current.scrollTo({ x: screenWidth * (scrollIndex + 1) });
        setScrollIndex((index) => index + 1);
      } else {
        scrollView.current.scrollTo({ x: 0 });
        setScrollIndex((_) => 0);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [scrollIndex]);

  return (
    <Container>
      <Around pointerEvents={'none'}>
        <InnerContent>
          <Logo resizeMode='contain' source={skiplyLogo} />
          {array.map((item, i) => (
            <TextBox key={item.id} active={i === scrollIndex}>
              <Title
                active={active}
                {...testProperties('landing-carousel-title-id')}
              >
                {item.title}
              </Title>
              <Subtitle
                active={active}
                {...testProperties('landing-carousel-subtitle-id')}
              >
                {item.subtitle}
              </Subtitle>
            </TextBox>
          ))}
        </InnerContent>
      </Around>

      <ScrollContainer
        horizontal
        ref={scrollView}
        showsHorizontalScrollIndicator={false}
        snapToInterval={screenWidth}
        snapToAlignment='center'
        decelerationRate='fast'
        onMomentumScrollEnd={handleScroll}
      >
        {array.map((item) => (
          <PicContainer key={item.id}>
            <Picture
              //   source={{ uri: item.image }}
              source={item.image}
              screenWidth={screenWidth}
              backgroundColor={item.backgroundColor}
            />
          </PicContainer>
        ))}
      </ScrollContainer>
      <InnerContainer>
        {array.map((item, i) => (
          <CircleIndicator key={item.id} active={i === scrollIndex} />
        ))}
      </InnerContainer>
    </Container>
  );
};

export default Carousel;

const Container = styled.View`
  background-color: #402ca8;
  position: relative;
  flex: 1;
`;

const ScrollContainer = styled.ScrollView`
  width: 100%;
  background-color: #130d32;
  border-bottom-right-radius: 40px;
  flex: 1;
`;

const InnerContent = styled.View`
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
`;

const Around = styled.View`
  position: absolute;
  justify-content: center;
  align-items: center;
  height: 100%;
  width: 100%;
  z-index: 1;
`;

const Logo = styled.Image`
  position: relative;
  width: 165px;
  max-height: 65px;
`;

const TextBox = styled.View`
  position: absolute;
  padding-top: 150px;
  opacity: 0;
  ${(props) =>
    props.active &&
    css`
      opacity: 1;
    `}
`;

const Title = styled.Text`
  text-align: center;
  margin-bottom: 5px;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  font-size: 16px;
  font-weight: bold;
  line-height: 22px;
  color: #ffffff;
  text-shadow: 1px 1px 6px #000;
`;

const Subtitle = styled.Text`
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  font-size: 12px;
  font-weight: 600;
  line-height: 16px;
  color: #ffffff;
  margin: 0 20px;
  text-align: center;
  text-shadow: 1px 1px 6px #000;
`;

const InnerContainer = styled.View`
  position: absolute;
  flex-direction: row;
  justify-content: center;
  width: 100%;
  bottom: 10px;
`;

const PicContainer = styled.View`
  flex: 1;
`;

const Picture = styled.ImageBackground`
  justify-content: center;
  align-items: center;
  width: ${(props) => screenWidth};
  flex: 1;
`;

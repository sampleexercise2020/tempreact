import React, { useState, useEffect } from 'react';
import styled from 'styled-components/native';
import FormInput from 'components/common/Input/FormInput';
import Button from 'components/common/Button/Button';
import ForgotPW from './components/ForgotPW';
import MessageBox from './components/MessageBox';
import * as yup from 'yup';
import { useStore, useStoreActions } from 'easy-peasy';
import selectedCopy from 'i18n/copy';
import { Navigation } from 'react-native-navigation';
import { root } from 'navigation/root';
import { testProperties } from 'helpers/testProperties';
import { AsyncStorage } from 'react-native';
import { navigateTo } from 'navigation';
import BiometricManager from '../../../../biometric/BiometricManager';
import firebase from 'react-native-firebase';
import LoaderWithOverlay from 'components/common/LoaderWithOverlay';

const copy =
  selectedCopy.components.modules.LoginAndSignup.flows.Login.LoginForm;

let schema = yup.object().shape({
  email: yup
    .string()
    .email()
    .required(''),
  password: yup
    .string()
    .required('Password is a required field.')
    .matches(/[a-zA-Z-0-9]+/, 'Only letters and numbers allowed')
});

const LoginForm = (props) => {
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [showPassword, setShowPassword] = useState(true);
  const [valid, setValid] = useState(false);
  const [email, setEmail] = useState(''); // john@andersson.se
  const [password, setPassword] = useState(''); // andersson123
  const [errorMessage, setErrorMessage] = useState('');
  const login = useStoreActions((actions) => actions.session.login);
  const fetchProfile = useStoreActions(({ profile }) => profile.fetch);
  const setAccessToken = useStoreActions((actions) => actions.session.setToken);
  const setAuthorization = useStoreActions(
    (actions) => actions.session.setAuthorization
  );

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  useEffect(() => {
    checkValidity();
  }, [email, password]);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    setErrorMessage('');

    const response = await login({ emailAddress: email, password });

    if (response.success) {
      await AsyncStorage.setItem('ONBOARDING_DONE', 'true');
      setAccessToken(response.data.userAccessToken);
      setAuthorization(response.data.authorization);
      const bm = BiometricManager.showEnableOptionsFor(email, password);
      bm.then((response) => {
        console.log('Biometric Response: ', response);
        fetchProfileAndMoveToHome();
      }).catch((error) => {
        console.log('Biometric Error: ', error);
        fetchProfileAndMoveToHome();
      });
    } else {
      if (response.message == 'invalid user name and password') {
        setErrorMessage(
          'The email id or password you have entered is incorrect. Please check and login again.'
        );
      } else {
        setErrorMessage(response.message);
      }
      setIsLoggingIn(false);
    }
  };

  const fetchProfileAndMoveToHome = async () => {
    const profileResponse = await fetchProfile();
    if (profileResponse.status == 200) {
      console.log('Response: ', profileResponse);
      firebase.analytics().setUserId(profileResponse.data.id);
      firebase.analytics().logEvent('login');
      setIsLoggingIn(false);
      navigateToHome();
    } else {
      setErrorMessage(profileResponse.profileResponse);
      setIsLoggingIn(false);
    }
  };

  const navigateToHome = async () => {
    Navigation.setRoot({ root });
  };

  const checkValidity = async () => {
    const validity = await schema.isValid({
      email: email,
      password: password
    });

    setValid(validity);
  };

  const navigateToResetPassword = () => {
    navigateTo('Skiply.ResetPassword', props.componentId);
  };

  return (
    <Container {...testProperties('login-loginform-container-id')}>
      <FormContainer>
        <FormInput
          content-desc='login-email-input-id'
          testProperties={testProperties('login-email-input-id')}
          numberOfLines={1}
          logo={false}
          label={copy.mail}
          keyboardType='email-address'
          returnKeyType='go'
          maxLength={40}
          value={email}
          onChangeText={(text) => setEmail(text)}
          autoCapitalize={'none'}
        />
        <FormInput
          content-desc='login-password-input-id'
          testProperties={testProperties('login-password-input-id')}
          numberOfLines={1}
          logo={false}
          label={copy.password}
          keyboardType='default'
          returnKeyType='go'
          minLength={8}
          matches={/[a-zA-Z-0-9]+/}
          toggleShowPassword={toggleShowPassword}
          secureTextEntry={showPassword}
          showPW={true}
          showPWText={showPassword ? 'Show' : 'Hide'}
          value={password}
          onChangeText={(text) => setPassword(text)}
        />
      </FormContainer>
      <MessageBox regular={false} error={true} message={errorMessage} />
      <Button
        testProperties={testProperties('login-submit-button-id')}
        primary={valid}
        disabled={!valid || isLoggingIn}
        error={errorMessage}
        onPress={() => handleLogin()}
      >
        {copy.login}
      </Button>
      <ForgotPW
        {...testProperties('login-forgotPW-text-id')}
        onPress={navigateToResetPassword}
        text={copy.forgotPassword}
      />
      {isLoggingIn && <LoaderWithOverlay />}
    </Container>
  );
};

export default LoginForm;

const Container = styled.View`
  margin: 40px 20px 0px 20px;
`;

const FormContainer = styled.View`
  height: 140px;
  background-color: #f5f5f7;
  border-radius: 4px;
  padding: 15px;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 22px;
  margin-bottom: 20px;
  text-align: center;
  width: 100%;
  color: rgb(13, 25, 67);
`;

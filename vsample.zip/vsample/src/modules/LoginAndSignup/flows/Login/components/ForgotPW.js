import React from 'react';
import styled from 'styled-components/native';

const ForgotPW = ({ text, onPress }) => {
  return (
    <Container onPress={onPress}>
      <Title>{text}</Title>
    </Container>
  );
};

export default ForgotPW;

const Container = styled.TouchableOpacity``;

const Title = styled.Text`
  font-family: 'OpenSans-SemiBold';
  font-size: 12px;
  font-weight: 600;
  text-align: center;
  line-height: 16px;
  color: #402ca8;
  margin-top: 15px;
`;

import React from 'react';
import styled from 'styled-components/native';

const FormMessage = ({ message }) => {
  return <Message>{message}</Message>;
};

export default FormMessage;

const Message = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  color: #2c79de;
  line-height: 17px;
  margin: 4px 0 0px 20px;
`;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import LoginForm from './LoginForm';
import SessionExpired from './SessionExpired';
import ReEnterPassword from './ReEnterPassword';

// TODO: Get notes working.

storiesOf('Modules|LoginAndSignup/Login form', module)
  .add('Login form', () => <LoginForm />)
  .add('Session expired', () => <SessionExpired />)
  .add('Re-enter password', () => <ReEnterPassword />);

import { render } from 'react-native-testing-library';
import AppProvider from './AppProvider';

// NOTE: Could be something for us:
// import { TranslationProvider } from 'my-i18n-lib'
// import defaultStrings from 'i18n/en-x-default'

const customRender = (ui, options) =>
  render(ui, { wrapper: AppProvider, ...options });

// re-export everything
export * from 'react-native-testing-library';

// override render method
export { customRender as render };

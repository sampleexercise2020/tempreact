import en from './en';

const copy = en;

export default copy;

import React, { useState, useEffect } from 'react';
import { Alert, Platform, Animated, Dimensions } from 'react-native';
import styled, { css } from 'styled-components/native';
import { useActions, useStore } from 'easy-peasy';
import ImagePicker from 'react-native-image-picker';
import UserAvatar from 'react-native-user-avatar';

const CameraIcon = require('src/../../assets/icons/common/camera.png');

const ProfileImage = ({
  image,
  name,
  editMode,
  studentId,
  title,
  subtitle,
  style,
  heightOfHeader
}) => {
  const username = useStore((state) => state.profile.data.emailAddress);
  const ActionUploadProfilePicture = useActions(
    (actions) => actions.profile.uploadProfilePicture
  );
  const ActionUploadStudentProfilePicture = useActions(
    (actions) => actions.student.uploadProfilePicture
  );
  const sessionExpire = useActions((actions) => actions.session.expire);

  function makePhotoUri(photoUri) {
    if (Platform.OS === 'android') {
      return photoUri;
    } else {
      return photoUri.replace('file://', '');
    }
  }

  function createFormData(photo, body) {
    const data = new FormData();
    const photoUri = makePhotoUri(photo.uri);
    const name = photo.fileName
      ? photo.fileName
      : (title + 'Photo').replace(/\s/g, '');

    data.append('image', {
      name: name,
      type: photo.type,
      uri: photoUri
    });

    Object.keys(body).forEach((key) => {
      data.append(key, body[key]);
    });
    return data;
  }

  function getFormBody() {
    if (studentId) {
      return { studentId };
    } else {
      return { status: 'USER', username };
    }
  }

  function getUploadProfilePictureAction() {
    if (studentId) {
      return ActionUploadStudentProfilePicture;
    } else {
      return ActionUploadProfilePicture;
    }
  }

  async function uploadProfilePicture(response) {
    const body = getFormBody();
    const uploadProfilePictureAction = getUploadProfilePictureAction();
    const formData = createFormData(response, body, title);

    let res = await uploadProfilePictureAction(formData);
    if (res.status == 200) {
      console.log('Image uploaded.');
      Alert.alert('Success!', 'Your photo has been uploaded.');
    } else if (res.status === 401 || res.status === 403) {
      sessionExpire();
    } else {
      Alert.alert(
        'Error',
        'Something went wrong when trying to upload the photo. Please try again.'
      );
    }
    // .then((response) => {
    //   console.log('Image upload response: ', response);
    // })
    // .catch(() =>
    //   Alert.alert(
    //     'Error',
    //     'Something went wrong when trying to upload the photo. Please try again.'
    //   )
    // );
  }

  async function handleChoosePhoto() {
    const options = {
      quality: 1,
      maxWidth: 500,
      maxHeight: 500
    };

    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
        console.log('User cancelled photo picker');
      } else if (response.error) {
        console.log('ImagePicker Error: ', response.error);
      } else if (response.customButton) {
        console.log('User tapped custom button: ', response.customButton);
      } else {
        uploadProfilePicture(response, title);
      }
    });
  }

  return (
    <Container style={style}>
      <ImageContainer onPress={editMode ? handleChoosePhoto : null}>
        <PurpleStroke>
          {editMode ? (
            <Overlay>
              <Camera source={CameraIcon} />
            </Overlay>
          ) : null}
          {image ? (
            <Profile
              testID='image'
              key={image}
              source={{
                uri: image,
                cache: 'reload'
              }}
            />
          ) : editMode ? null : (
            <UserAvatar
              name={name ? name.toUpperCase() : 'Test Placeholder'}
              size={120}
              color='#4f2c94'
            />
          )}
        </PurpleStroke>
      </ImageContainer>
      {title && <Title heightOfHeader={heightOfHeader}>{title}</Title>}
      {subtitle && <Subtitle>{subtitle}</Subtitle>}
    </Container>
  );
};

export default ProfileImage;

const Container = styled(Animated.View)`
  height: 120px;
  width: 120px;
  border-radius: 60px;
  border-width: 3px;
  border-color: #f7f7f7;
  justify-content: center;
  align-items: center;
  margin-bottom: 35px;
  padding-top: 0;
`;

const ImageContainer = styled.TouchableWithoutFeedback`
  height: 120px;
  width: 120px;
  border-radius: 60px;
  border-width: 2px;
  border-color: #f7f7f7;
  justify-content: center;
  align-items: center;
  overflow: hidden;
`;

const PurpleStroke = styled.View`
  position: relative;
  height: 115px;
  width: 115px;
  border-radius: 60px;
  border-width: 3px;
  border-color: rgb(62, 48, 164);
  justify-content: center;
  align-items: center;
  overflow: hidden;
`;
const Profile = styled.Image`
  width: 100%;
  height: 100%;
`;

const Title = styled.Text`
  color: rgb(221, 221, 255);
  font-size: 18px;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  text-align: center;
  letter-spacing: 0px;
  line-height: 26px;
  position: absolute;
  bottom: -50px;
  height: 35px;
  width: ${Dimensions.get('window').width};

  ${(props) =>
    props.heightOfHeader !== 0 &&
    props.heightOfHeader <= 130 &&
    css`
      color: #402ca8;
    `}
`;
const Subtitle = styled.Text`
  width: 262px;
  height: 18px;
  color: rgb(255, 255, 255);
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  text-align: center;
  letter-spacing: 0px;
  line-height: 18px;
`;

const Overlay = styled.View`
  position: absolute;
  height: 120px;
  width: 120px;
  border-radius: 60px;
  background: #eceaf699;
  z-index: 50;
  justify-content: center;
  align-items: center;
`;

const Camera = styled.Image`
  width: 28px;
  height: 22px;
`;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import ProfileImage from './ProfileImage';

storiesOf('Components|Profile', module)
  .add('without text', () => <ProfileImage image='https://i.pravatar.cc/300' />)
  .add('with title', () => (
    <ProfileImage image='https://i.pravatar.cc/300' title='John Andersson' />
  ))
  .add('with title and subtitle', () => (
    <ProfileImage
      image='https://i.pravatar.cc/300'
      title='John Andersson'
      subtitle='Kindergarden 3A'
    />
  ))
  .add('with everything and Edit Mode', () => (
    <ProfileImage
      image='https://i.pravatar.cc/300'
      title='John Andersson'
      subtitle='Kindergarden 3A'
      editMode={true}
    />
  ))
  .add('Student Profile Image with everything and Edit Mode', () => (
    <ProfileImage
      image='https://i.pravatar.cc/300'
      title='John Andersson'
      subtitle='Kindergarden 3A'
      editMode={true}
      studentId='565540'
    />
  ));

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import BottomControlPanel from './BottomControlPanel';

import Button from 'components/common/Button/Button';

storiesOf('Components|Panels/Bottom Control', module)
  .add('One Button', () => <BottomControlPanel />)
  .add('Two Buttons', () => <BottomControlPanel />)
  .add('Price', () => <BottomControlPanel />)
  .add('Price and VAT', () => <BottomControlPanel />);

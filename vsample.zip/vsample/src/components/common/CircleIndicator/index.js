import React from 'react';
import styled, { css } from 'styled-components/native';

const CircleIndicator = ({ active, dark, darkActive, key }) => {
  return (
    <Circle key={key} active={active} dark={dark} darkActive={darkActive} />
  );
};

export default CircleIndicator;

const Circle = styled.View`
  height: 6px;
  width: 6px;
  border-radius: 3px;
  background-color: #d9d9d972;
  margin-right: 6px;
  ${(props) =>
    props.active &&
    css`
      background-color: #ffffff;
    `}
  ${(props) =>
    props.dark &&
    css`
      background-color: #0d194340;
    `}
      ${(props) =>
        props.darkActive &&
        css`
          background-color: #0d1943;
        `}
`;

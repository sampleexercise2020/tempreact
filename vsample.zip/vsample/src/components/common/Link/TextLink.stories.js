import React from 'react';
import { storiesOf } from '@storybook/react-native';
import TextLink from './TextLink';

// TODO: Get notes working.

storiesOf('Components|Links', module).add('Text link', () => (
  <TextLink
    linktext='Enter card manually'
    onPress={() => console.log('on press works')}
  />
));

import React from 'react';
import styled from 'styled-components/native';

const TextLink = ({ linktext, onPress }) => {
  return (
    <LinkContainer onPress={onPress}>
      <LinkText>{linktext}</LinkText>
    </LinkContainer>
  );
};

export default TextLink;

const LinkContainer = styled.TouchableOpacity``;

const LinkText = styled.Text`
  color: rgb(64, 44, 168);
  font-family: OpenSans-Regular;
  text-decoration: underline;
  font-size: 12px;
  font-weight: normal;
  line-height: 16px;
`;

import React from 'react';
import styled from 'styled-components/native';
import { ActivityIndicator, View } from 'react-native';

const LoaderWithOverlay = ({ isLoading }) => {
  return (
    <Loader>
      <ActivityIndicator size='large' />
    </Loader>
  );
};

const Loader = styled.View`
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  align-items: center;
  justify-content: center;
  background-color: rgba(245, 252, 255, 0.3);
  z-index: 10;
`;

export default LoaderWithOverlay;

import React, { useState, useEffect } from 'react';
import styled from 'styled-components/native';

const SearchBar = ({ placeholderText, value, onSubmit }) => {
  const [searchText, setSearchText] = useState('');
  const [didSearch, setDidSearch] = useState(false);

  useEffect(() => {
    if (didSearch && searchText.length === 0) {
      onSubmit({ queryString: '' });
    }
    if (searchText.length >= 2) {
      setDidSearch(true);
      onSubmit({ queryString: searchText });
    }
  }, [searchText, didSearch]);
  return (
    <Container>
      <Icon
        resizeMode='contain'
        source={require('src/../../assets/icons/common/search.png')}
      />
      <Input
        placeholder={placeholderText}
        onChangeText={(text) => {
          setSearchText(text);
        }}
        onSubmitEditing={() => onSubmit({ queryString: searchText })}
      />
    </Container>
  );
};

export default SearchBar;

const Container = styled.View`
  position: relative;
  border: 1px solid #edeef1;
  border-radius: 4px;
`;

const Input = styled.TextInput`
  background-color: white;
  height: 50px;
  border-radius: 4px;
  padding: 0 10px 0 60px;
  font-size: 16px;
  color: rgb(13, 25, 67);
  font-family: OpenSans-Regular;
`;

const Icon = styled.Image`
  position: absolute;
  left: 22px;
  width: 25px;
  height: 25px;
  z-index: 100;
  top: 12.5px;
`;

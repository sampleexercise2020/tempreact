import React from 'react';
import styled from 'styled-components/native';

const NavigationTitle = ({ title, icon }) => {
  return (
    <Container>
      <Icon source={icon} />
      <Title>{title}</Title>
    </Container>
  );
};

export default NavigationTitle;

const Container = styled.View`
  flex-direction: row;
`;

const Icon = styled.Image`
  height: 22px;
  width: 22px;
  margin-right: 7px;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR-Bold';
  font-size: 16px;
  font-weight: bold;
  color: #ffffff;
`;

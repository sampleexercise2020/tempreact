import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action, configureActions } from '@storybook/addon-actions';
import SmallButton from './SmallButton';

storiesOf('Components|Buttons', module).add('Small Button', () => (
  <SmallButton
    available
    title='Small button'
    onPress={action('button-click')}
  />
));

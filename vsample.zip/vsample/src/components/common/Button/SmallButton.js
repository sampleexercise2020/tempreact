import React from 'react';
import styled, { css } from 'styled-components';

const SmallButton = ({ empty, available, onPress, title }) => {
  return (
    <Container empty={empty} available={available} onPress={onPress}>
      <Title empty={empty} available={available}>
        {title}
      </Title>
    </Container>
  );
};

export default SmallButton;

const Container = styled.TouchableOpacity`
  border-radius: 4px;
  justify-content: center;
  align-items: center;
  height: 30px;
  padding: 0 10px;
  ${(props) =>
    props.empty &&
    css`
      background-color: #0d857b;
    `}
  ${(props) =>
    props.available &&
    css`
      background-color: #ffffff;
      border-width: 1;
      border-color: #4f2c94;
    `}
`;

const Title = styled.Text`
  font-size: 14px;
  font-weight: 600;
  font-family: 'OpenSans-SemiBold';
  line-height: 18px;
  ${(props) =>
    props.empty &&
    css`
      color: #ffffff;
    `}
  ${(props) =>
    props.available &&
    css`
      color: #4f2c94;
    `}
`;

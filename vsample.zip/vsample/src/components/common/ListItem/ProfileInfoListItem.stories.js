import React from 'react';
import { storiesOf } from '@storybook/react-native';
import ProfileInfoListItem from './ProfileInfoListItem';

storiesOf('Components|List items', module).add(
  'Profile Information Listitem',
  () => <ProfileInfoListItem label='Name' inputField='John Andersson' />
);

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import styled from 'styled-components/native';
import Header from './Header';

storiesOf('Components|Header', module)
  .addDecorator((storyFn) => <Decorator>{storyFn()}</Decorator>)
  .add('Search', () => <Header variant='search' />);

const Decorator = styled.View`
  background-color: #efefef;
  height: 100%;
  display: flex;
  justify-content: center;
`;

import React from 'react';
import styled, { css } from 'styled-components/native';
import { Platform } from 'react-native';

//TODO: rätt font
//TODO: rätt färgvariabel och storlek på fonten

const NavigationBarHeader = ({
  children,
  leftIcon,
  rightIcon,
  deviceHasNotch
}) => {
  return (
    <Container deviceHasNotch={deviceHasNotch} platform={Platform.OS}>
      <Back>{leftIcon}</Back>
      <HeaderContainer>{children}</HeaderContainer>
      <Dots>{rightIcon}</Dots>
    </Container>
  );
};

export default NavigationBarHeader;

const Container = styled.View`
  flex-direction: row;
  justify-content: space-between;
  overflow: hidden;
  ${(props) =>
    props.deviceHasNotch &&
    css`
      margin-top: 10px;
    `}
  ${(props) =>
    props.platform === 'android' &&
    css`
      margin-top: -20px;
    `}
`;
const Back = styled.TouchableOpacity`
  height: 35px;
  width: 35px;
  margin-left: 20px;
  justify-content: center;
  align-items: center;
`;
const Dots = styled.TouchableOpacity`
  height: 35px;
  width: 35px;
  margin-right: 20px;
  justify-content: center;
  align-items: center;
`;

const HeaderContainer = styled.View`
  flex-grow: 1;
`;

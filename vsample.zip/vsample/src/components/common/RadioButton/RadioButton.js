import React from 'react';
import styled, { css } from 'styled-components/native';
import PropTypes from 'prop-types';

const CheckMarkIcon = require('src/../../assets/images/checkmark.png');

const RadioButton = ({ buttonType, checked }) => {
  if (buttonType == 'checkbox') {
    return (
      <Check>{checked ? <CheckMark source={CheckMarkIcon} /> : null}</Check>
    );
  } else {
    return <Radio>{checked ? <RadioCheck /> : null}</Radio>;
  }
};

RadioButton.propTypes = {
  buttonType: PropTypes.string,
  checked: PropTypes.bool.isRequired
};

const Radio = styled.View`
  justify-content: center;
  align-items: center;
  height: 28px;
  width: 28px;
  background: #67539111;
  border-radius: 14px;
`;

const RadioCheck = styled.View`
  width: 14px;
  height: 14px;
  background: #1cbb96;
  border: 2px solid #ffffff;
  border-radius: 7px;
`;

const Check = styled.View`
  justify-content: center;
  align-items: center;
  width: 28px;
  height: 28px;
  background: #67539111;
  border-radius: 18px;
`;

const CheckMark = styled.Image`
  height: 11px;
  width: 14px;
`;

export default RadioButton;

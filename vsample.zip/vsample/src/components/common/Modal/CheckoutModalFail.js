import React from 'react';
import { Navigation } from 'react-native-navigation';
import styled from 'styled-components/native';
import Button from 'components/common/Button/Button';

import { useStoreActions } from 'easy-peasy';

const CheckoutModalFail = (props) => {
  const setCurrentStudent = useStoreActions(
    (actions) => actions.student.setCurrent
  );
  const handleDissmiss = () => {
    setCurrentStudent({});
    Navigation.dismissOverlay(props.componentId);
  };

  return (
    <Background>
      <Modal>
        <InnerContainer>
          <Title>Failure!</Title>

          <PaymentInfo>
            <TotalAmountContainer>
              <FailureMessage>
                We could not process your payment. Please check your card
                information or try again later.
              </FailureMessage>
            </TotalAmountContainer>
          </PaymentInfo>

          <ButtonContainer>
            <Button primary onPress={handleDissmiss}>
              Close
            </Button>
          </ButtonContainer>
        </InnerContainer>
      </Modal>
    </Background>
  );
};

export default CheckoutModalFail;

const Background = styled.View`
  background: rgba(0, 0, 0, 0.6);
  flex: 1;
  justify-content: center;
  align-items: center;
  padding-top: 100px;
  padding-bottom: 60px;
`;

const FailureMessage = styled.Text`
  font-size: 16px;
  text-align: center;
  line-height: 22px;
  font-family: 'OpenSans-Regular';
  color: #0d1943;
  padding: 0 20px;
  margin-top: 20px;
`;

const Modal = styled.View`
  background-color: #ffffff;
  height: 325px;
  position: absolute;
  left: 0;
  right: 0;
  border-radius: 24px;
  box-shadow: 0px 3px 8px rgba(153, 153, 153, 0.6);
  margin: 0 20px;
  justify-content: center;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 32px;
  font-weight: 900;
  text-align: center;
  color: #0d1943;
  margin-top: 40px;
  line-height: 40px;
`;

const PaymentInfo = styled.View`
  margin-bottom: 20px;

  width: 100%;
  padding: 20px;
`;

const TotalAmountContainer = styled.View`
  flex-direction: row;
  justify-content: space-between;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const ButtonContainer = styled.View`
  position: absolute;
  bottom: 20px;
  left: 0px;
  right: 0px;
  width: 100%;
  padding-left: 20px;
  padding-right: 20px;
`;

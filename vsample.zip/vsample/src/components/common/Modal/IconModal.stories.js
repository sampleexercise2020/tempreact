import React from 'react';
import { storiesOf } from '@storybook/react-native';
import IconModal from './IconModal';

storiesOf('Components|Modal', module).add('Icon modal', () => <IconModal />);

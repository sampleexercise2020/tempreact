import React from 'react';
import styled, { css } from 'styled-components/native';

const Label = ({ title, required, passed }) => {
  return (
    <Container required={required} passed={passed}>
      <Title required={required}>{title}</Title>
    </Container>
  );
};

export default Label;

const Container = styled.View`
  background-color: #f15b60;
  padding: 2px 3px 3px 3px;
  border-radius: 4px;
  justify-content: center;
  align-items: center;
  width: 50px;
  ${(props) =>
    props.required &&
    css`
      background-color: #eaf1fb;
      width: 61px;
    `}
  ${(props) =>
    props.passed &&
    css`
      width: 50px;
    `}
`;

const Title = styled.Text`
  color: #fff;
  font-family: 'OpenSans-Semibold';
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0px;
  line-height: 16px;
  ${(props) =>
    props.required &&
    css`
      color: #0c5fcc;
    `}
`;

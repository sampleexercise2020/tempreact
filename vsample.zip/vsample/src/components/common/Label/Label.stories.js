import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Label from './Label';

storiesOf('Components/Label', module)
  .add('Expired', () => <Label title='Expired' />)
  .add('Required', () => <Label title='Required' required />)
  .add('Passed', () => <Label title='Passed' passed />);

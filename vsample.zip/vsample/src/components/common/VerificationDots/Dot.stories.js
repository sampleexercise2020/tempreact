import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Dot from './Dot';

storiesOf('Components/Label', module).add('Expired', () => (
  <Label title='Expired' />
));

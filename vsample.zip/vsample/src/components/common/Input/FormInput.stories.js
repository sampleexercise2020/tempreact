import React from 'react';
import { storiesOf } from '@storybook/react-native';
import FormInput from './FormInput';

storiesOf('Components|Inputs', module)
  .add('Input', () => (
    <FormInput
      numberOfLines={1}
      logo={false}
      logoImg={require('../../../../assets/icons/payment/Mobile-VISA.png')}
      label='Cardholder name'
      keyboardType='default'
      returnKeyType='go'
    />
  ))
  .add('show pw', () => (
    <FormInput
      numberOfLines={1}
      label='Password'
      keyboardType='default'
      returnKeyType='go'
      showPW={true}
      showPWText='Show'
      secureTextEntry={true}
    />
  ))
  .add('error input', () => (
    <FormInput
      numberOfLines={1}
      label='Error'
      keyboardType='default'
      returnKeyType='go'
      secureTextEntry={true}
      error={true}
    />
  ));

import React, { useState } from 'react';
import styled, { css } from 'styled-components/native';
import PickerSelect from 'react-native-picker-select';
import { Platform } from 'react-native';

//TODO: needs some handling when pressing on the "next" button
//TODO: addera formik validation.

const DropdownInput = ({ label, options, onChange, value }) => {
  const placeholder = {
    label: '',
    value: null
  };

  return (
    <PickerSelect
      style={{ inputIOS: { color: '#000000', fontSize: 16 } }}
      placeholder={placeholder}
      items={options}
      onValueChange={(value) => {
        onChange(value);
      }}
      onUpArrow={() => {
        // this.inputRefs.firstTextInput.focus();
      }}
      onDownArrow={() => {
        // this.inputRefs.favSport1.togglePicker();
      }}
      value={value}
      ref={(el) => {
        // this.inputRefs.favSport0 = el;
      }}
    />
  );
};

export default function FormInput({
  numberOfLines,
  logo,
  logoImg,
  label,
  keyboardType,
  returnKeyType,
  maxLength,
  onChangeText,
  onBlur,
  value,
  error,
  secureTextEntry,
  showPW,
  showPWText,
  toggleShowPassword,
  type,
  placeholder,
  options,
  onFocus,
  editable,
  autoCapitalize,
  testProperties,
  onSubmitEditing,
  blurOnSubmit,
  innerRef,
  fieldName
}) {
  const [isFocused, setIsFocused] = useState(false);

  function handleBlur() {
    onBlur ? onBlur(fieldName, true) : null;
    setIsFocused(false);
  }

  const makeInputField = (type) => {
    if (type == 'DROPDOWN') {
      return (
        <DropdownInputContainer>
          <DropdownInput
            label={label}
            options={options}
            value={value}
            onChange={onChangeText}
          />
        </DropdownInputContainer>
      );
    } else {
      return (
        <TextInput
          onFocus={() => {
            setIsFocused(true);

            if (onFocus) {
              onFocus();
            }
          }}
          {...testProperties}
          autoCorrect={false}
          spellCheck={false}
          value={value}
          numberOfLines={numberOfLines}
          spellCheck={false}
          autoCorrect={false}
          keyboardType={keyboardType}
          onChangeText={onChangeText}
          error={error}
          returnKeyType={returnKeyType}
          maxLength={maxLength}
          selectionColor='#0d8177'
          onBlur={handleBlur}
          secureTextEntry={secureTextEntry}
          placeholder={placeholder}
          editable={editable}
          autoCapitalize={autoCapitalize}
          onSubmitEditing={onSubmitEditing}
          blurOnSubmit={blurOnSubmit}
          ref={innerRef}
        />
      );
    }
  };

  return (
    <Container>
      <TextContainer>
        {label && <Label isFocused={isFocused}>{label}</Label>}
        {makeInputField(type)}
      </TextContainer>
      {showPW && (
        <ShowPW onPress={toggleShowPassword}>
          <ShowPWText>{showPWText}</ShowPWText>
        </ShowPW>
      )}
      {error && <ErrorStar>*</ErrorStar>}
      {logo && (
        <LogoContainer>
          <Logo source={logoImg} />
        </LogoContainer>
      )}
    </Container>
  );
}

const Container = styled.View`
  border-width: 1px;
  border-color: ${(props) =>
    props.error
      ? props.theme.color.primary.warning
      : props.theme.color.misc.listItemDivider};
  border-radius: 4px;
  margin-bottom: 10px;
  height: 50px;
  flex-direction: row;
  background-color: ${(props) => props.theme.color.primary.white};
  position: relative;
`;

const TextInput = styled.TextInput`
  height: 40px;
  position: absolute;
  top: 10px;
  width: 100%;
  left: 0;
  font-size: 16px;
  color: #000000;
`;

const DropdownInputContainer = styled.View`
  height: 45px;
  position: absolute;
  top: 20px;
  width: 100%;
  ${Platform.select({
    ios: css`
      top: 20px;
    `,
    android: css`
      top: 5px;
    `
  })};
  left: 0;
`;

const LogoContainer = styled.View`
  width: 15%;
  justify-content: center;
  align-items: center;
`;

const Logo = styled.Image`
  min-height: 21px;
  min-width: 31px;
`;

const Label = styled.Text`
  margin-top: 3px;
  color: ${({ isFocused }) => (isFocused ? '#6d758e' : '#0d1943')};
  font-size: 12px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  line-height: 16px;
`;

const TextContainer = styled.View`
  margin-left: 20px;
  width: 80%;
`;

const ShowPW = styled.TouchableOpacity`
  height: 18px;
  margin-top: 3px;
  position: absolute;
  right: 0;
  top: 0;
  margin-right: 20px;
`;

const ShowPWText = styled.Text`
  color: #402ca8;
  font-family: 'OpenSans-Regular';
  font-size: 12px;
`;

const ErrorStar = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 18px;
  line-height: 22px;
  color: #d9363b;
  position: absolute;
  right: 0;
  bottom: 0;
  margin-right: 20px;
`;

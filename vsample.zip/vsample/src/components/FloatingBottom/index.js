import FloatingBottom from './FloatingBottom';
import useFloatingBottom from './useFloatingBottom';

export default FloatingBottom;

export { useFloatingBottom };

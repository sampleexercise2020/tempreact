import setupNavigation from 'navigation/setupNavigation';

console.disableYellowBox = true;

// This essentially bootstraps the App
setupNavigation();

import { composeWithDevTools } from 'remote-redux-devtools';
import { createStore, action } from 'easy-peasy';
import model from './models';

let initialState = {};

const compose = () => {
  if (process.env.NODE_ENV !== 'test' && __DEV__) {
    return {
      compose: composeWithDevTools({ realtime: true, trace: true })
    };
  } else {
    return {};
  }
};


export const store = createStore(
  {
    ...model,
    reset: action((state, payload) => {
      state = initialState;
    })
  },
  compose()
);

// Set initialState to
initialState = store.getState();

export const reset = () => {
  store.dispatch.reset();
};

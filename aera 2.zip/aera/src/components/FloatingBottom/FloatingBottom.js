import React from 'react';
import styled from 'styled-components/native';
import { useStore } from 'easy-peasy';
import { dismissOverlay } from 'navigation';

export default ({ component: Component, componentId }) => {
  const currentNavigationComponent = useStore(
    (state) => state.navigation.currentNavigationComponent
  );

  const hidePanel = () => {
    dismissOverlay(componentId);
  };

  return (
    <BottomPanel currentScreenName={currentNavigationComponent.componentName}>
      <Component
        currentNavigationComponentId={currentNavigationComponent.componentId}
        hidePanel={hidePanel}
      />
    </BottomPanel>
  );
};

const BottomPanel = styled.View`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
`;

import React, { useState, useCallback, useEffect } from 'react';
import { Navigation } from 'react-native-navigation';
import useFloating from 'hooks/useFloating';

export default (component) => {
  return useFloating({
    component,
    componentId: 'FLOATING_BOTTOM_ID',
    componentName: 'FloatingBottom',
    interceptTouchOutside: false
  });
};

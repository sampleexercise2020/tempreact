import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

const NavigationButton = ({ onPress, icon }) => {
  return (
    <Button onPress={onPress}>
      <Icon resizeMode='contain' source={icon} />
    </Button>
  );
};

NavigationButton.propTypes = {
  onPress: PropTypes.func
};

const Button = styled.TouchableOpacity`
  justify-content: center;
  align-items: center;
`;

const Icon = styled.Image`
  width: 24px;
`;

export default NavigationButton;

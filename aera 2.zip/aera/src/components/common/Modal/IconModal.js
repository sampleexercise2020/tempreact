import React from 'react';
//import { Navigation } from 'react-native-navigation';
import styled from 'styled-components/native';
import Button from 'components/common/Button/Button';

const cardImg = require('../../../../assets/icons/promo-card.png');
const checkIcon = require('../../../../assets/icons/rectangle_checkmark.png');

const userInfo = {
  name: 'John Andersson',
  email: 'john.andersson@gmail.com',
  phone: '+46 123 456 789'
};

const IconModal = ({ componentId }) => {
  return (
    <Background>
      <Modal>
        <CheckIconContainer>
          <CheckIcon source={checkIcon} />
        </CheckIconContainer>
        <InnerContainer>
          <Title>Thank you!</Title>
          <Subtitle>
            RAKBANK will contact you within a day or two to help you with your
            application.
          </Subtitle>
          <CardContainer>
            <CardImg source={cardImg} />
            <CardInfo>RAKBANK Platinum</CardInfo>
          </CardContainer>
          <UserInfoContainer>
            <Name>{userInfo.name}</Name>
            <Email>{userInfo.email}</Email>
            <Phone>{userInfo.phone}</Phone>
          </UserInfoContainer>
          <ButtonContainer>
            <Button primary onPress={() => console.log('close modal')}>
              Close
            </Button>
          </ButtonContainer>
        </InnerContainer>
      </Modal>
    </Background>
  );
};

export default IconModal;

const Background = styled.View`
  background-color: #02071b99;
  flex: 1;
  justify-content: center;
  align-items: center;
  padding-top: 100px;
  padding-bottom: 60px;
`;

const Modal = styled.View`
  background-color: #ffffff;
  height: 100%;
  position: absolute;
  left: 0;
  right: 0;
  border-radius: 24px;
  box-shadow: 0px 3px 8px rgba(153, 153, 153, 0.6);
  margin: 0 20px;
  padding: 0 20px;
  justify-content: center;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 32px;
  font-weight: 900;
  text-align: center;
  color: #0d1943;
  margin-top: 80px;
  line-height: 40px;
`;

const Subtitle = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
  text-align: center;
  margin-top: 30px;
`;

const CardContainer = styled.View`
  flex-direction: row;
  margin-top: 25px;
  align-items: center;
  justify-content: center;
`;

const CardInfo = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  line-height: 18px;
  color: #0d1943;
  padding-left: 10px;
`;

const CardImg = styled.Image`
  height: 24px;
  width: 40px;
`;

const UserInfoContainer = styled.View`
  margin-top: 40px;
  align-items: center;
  justify-content: center;
  height: 75px;
  background-color: #f5f5f7;
  border-radius: 4px;
  width: 100%;
`;

const Name = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  color: #0d1943;
  line-height: 16px;
  margin-bottom: 3px;
`;

const Email = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  color: #0d1943;
  line-height: 16px;
  margin-bottom: 3px;
`;

const Phone = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  color: #0d1943;
  line-height: 16px;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const ButtonContainer = styled.View`
  position: absolute;
  bottom: 20;
  left: 0;
  right: 0;
  width: 100%;
`;

const CheckIcon = styled.Image`
  height: 100px;
  width: 100px;
  top: -50px;
  position: absolute;
`;

const CheckIconContainer = styled.View`
  align-items: center;
`;

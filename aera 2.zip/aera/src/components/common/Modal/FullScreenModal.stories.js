import React from 'react';
import { storiesOf } from '@storybook/react-native';
import FullScreenModal from './FullScreenModal';

storiesOf('Components|Modal', module)
  .add('with title', () => (
    <FullScreenModal
      title={true}
      titleText="Couldn't add payment method"
      text='Your card details might be incorrect try re-adding your card or use a different card'
      cancelText='Cancel'
      onPressCancel={() => console.log('on press cancel')}
      buttonText='Yes, clear cart'
      onPressPrimaryButton={console.log('on press primaryyy')}
    />
  ))
  .add('without title', () => (
    <FullScreenModal
      title={false}
      text='A verification code has been sent to +46 123 456 789'
      cancelText='Back'
      onPressCancel={() => console.log('on press cancel')}
      buttonText='Enter code'
      onPressPrimaryButton={console.log('on press primaryyy')}
    />
  ));

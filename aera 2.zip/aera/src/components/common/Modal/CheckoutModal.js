import React, { useState, useEffect } from 'react';
import { Navigation } from 'react-native-navigation';
import styled from 'styled-components/native';
import Button from 'components/common/Button/Button';
import Avatar from '../../../modules/Discover/School/flows/Store/Start/components/Avatar';
import { Animated, Easing } from 'react-native';
import { useStoreState, useStoreActions, useStore } from 'easy-peasy';
import { navigateTo } from '../../../navigation';

const checkIcon = require('../../../../assets/icons/rectangle_checkmark.png');
const arrowForwardPurpleSmall = require('../../../../assets/icons/common/arrow-forward-purple-16.png');

const CheckoutModal = (props) => {
  const currentStudent = useStoreState((state) => state.student.current);
  const setCurrentStudent = useStoreActions(
    (actions) => actions.student.setCurrent
  );
  const totalAmount =
    props.receipt.currency + ' ' + props.receipt.totalOrderAmount / 100;
  const fullName = currentStudent.firstName + ' ' + currentStudent.lastName;
  const grade = currentStudent.grade;
  const profileImage = currentStudent.image;
  const receipt = props.receipt;
  const amountOfItemsPurchased = receipt.transactionItems.length;

  const [fadeIn, setFadeIn] = useState(new Animated.Value(0.01));
  const [fadeOut, setFadeOut] = useState(new Animated.Value(1));
  const [scrollOut, setScrollOut] = useState(new Animated.Value(0.01));
  const [scaleUp, setScaleUp] = useState(new Animated.Value(0.8));

  const backgroundOpacity = fadeOut.interpolate({
    inputRange: [0, 1],
    outputRange: ['rgba(0, 0, 0, 0)', 'rgba(0, 0, 0, 0.6)']
  });

  useEffect(function AnimateContent() {
    Animated.timing(
      // Animate over time
      fadeIn, // The animated value to drive
      {
        toValue: 1, // Animate to opacity: 1 (opaque)
        duration: 300,
        easing: Easing.quad
      }
    ).start();
    Animated.timing(
      // Animate over time
      scaleUp, // The animated value to drive
      {
        toValue: 1, // Increase size from 0.8 to 1
        duration: 300,
        easing: Easing.quad
      }
    ).start();
  }, []);

  function AnimateContent() {
    Animated.timing(
      // Animate over time
      scrollOut, // The animated value to drive
      {
        toValue: -1000, // Move modal out of sight to the top.
        duration: 900, // Make it take a while,
        easing: Easing.quad
      }
    ).start();
    Animated.timing(
      // Animate over time
      fadeOut, // The animated value to drive
      {
        toValue: 0.01, // Fade out background color
        duration: 500, // Make it take a while,
        easing: Easing.quad
      }
    ).start();
  }

  const handleDissmiss = () => {
    AnimateContent();
    const timer = setTimeout(() => {
      Navigation.dismissOverlay(props.componentId);
      setCurrentStudent({});
      clearTimeout(timer);
    }, 1000);
  };

  return (
    <Background style={{ backgroundColor: backgroundOpacity }}>
      <Modal
        style={{
          opacity: fadeIn,
          transform: [
            {
              translateY: scrollOut
            },
            {
              scaleX: scaleUp
            },
            {
              scaleY: scaleUp
            }
          ]
        }}
      >
        <CheckIconContainer>
          <CheckIcon source={checkIcon} />
        </CheckIconContainer>
        <InnerContainer>
          <Title>Success!</Title>

          <UserInfoContainer>
            <Avatar
              image={profileImage}
              stokeSize={37}
              containerSize={40}
              innerRingColor='#fefefe'
              outerRingColor='#c8ccd5'
              name={fullName}
            />
            <TextContainer>
              <ProfileName>{fullName}</ProfileName>
              <SubTitle>{grade}</SubTitle>
            </TextContainer>
          </UserInfoContainer>

          <PaymentInfo>
            <TotalAmountContainer>
              <TotalLabel>Total</TotalLabel>
              <TotalAmount>{totalAmount}</TotalAmount>
            </TotalAmountContainer>
            <AmountOfItemsPurchased>
              {amountOfItemsPurchased === 1
                ? amountOfItemsPurchased + ' item'
                : amountOfItemsPurchased + ' items'}
            </AmountOfItemsPurchased>
          </PaymentInfo>

          <ShowReceiptContainer>
            <ShowReceiptButton
              onPress={() => {
                handleDissmiss();
                navigateTo('Skiply.Purchases.Receipt', 'Skiply.Home', {
                  receipt
                });
              }}
            >
              <ShowReceiptText>Show receipt</ShowReceiptText>
              <ArrowImage source={arrowForwardPurpleSmall} />
            </ShowReceiptButton>
          </ShowReceiptContainer>

          <ButtonContainer>
            <Button primary onPress={handleDissmiss}>
              Close
            </Button>
          </ButtonContainer>
        </InnerContainer>
      </Modal>
    </Background>
  );
};

export default CheckoutModal;

const Background = styled(Animated.View)`
  flex: 1;
  justify-content: center;
  align-items: center;
  padding-top: 100px;
  padding-bottom: 60px;
`;

const Modal = styled(Animated.View)`
  background-color: #ffffff;
  height: 425px;
  position: absolute;
  left: 0;
  right: 0;
  border-radius: 24px;
  box-shadow: 0px 3px 8px rgba(153, 153, 153, 0.6);
  margin: 0 20px;
  /* padding: 0 20px;*/
  justify-content: center;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 32px;
  font-weight: 900;
  text-align: center;
  color: #0d1943;
  margin-top: 80px;
  line-height: 40px;
  margin-bottom: 35px;
`;
const PaymentInfo = styled.View`
  margin-top: 20px;
  margin-bottom: 20px;
  background-color: #f5f5f7;
  width: 100%;
  padding: 20px;
`;

const Subtitle = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
  text-align: center;
  margin-top: 30px;
`;

const AmountOfItemsPurchased = styled.Text`
  font-family: 'OpenSans-Regular';
  color: #6d758e;
  font-size: 14px;
  line-height: 18px;
`;

const TotalAmountContainer = styled.View`
  flex-direction: row;
  justify-content: space-between;
`;

const ShowReceiptButton = styled.TouchableOpacity`
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;

const ShowReceiptText = styled.Text`
  color: rgb(64, 44, 168);
  font-family: 'OpenSans-SemiBold';
  font-size: 14px;
  font-weight: 600;
  margin-right: 10px;
`;

const ArrowImage = styled.Image`
  height: 12px;
  width: 13px;
  align-self: center;
  margin-top: 3px;
`;

const CashbackPoints = styled.Text`
  color: rgb(109, 117, 142);
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  font-weight: normal;
`;

const ShowReceiptContainer = styled.View``;

const TotalLabel = styled.Text`
  color: rgb(13, 25, 67);
  font-family: 'OpenSans-Bold';
  font-size: 18px;
  font-weight: bold;
  letter-spacing: 0px;
  line-height: 22px;
`;

const TotalAmount = styled.Text`
  color: rgb(13, 25, 67);
  font-family: 'OpenSans-Bold';
  font-size: 18px;
  font-weight: bold;
  letter-spacing: 0px;
  line-height: 22px;
  text-align: right;
`;
const TextContainer = styled.View`
  margin-left: 10px;
`;
const ProfileName = styled.Text`
  color: rgb(13, 25, 67);
  font-family: 'OpenSans-Bold';
  font-size: 14px;
  font-weight: bold;
  height: 18px;
  letter-spacing: 0px;
  line-height: 18px;
`;
const SubTitle = styled.Text`
  color: rgb(109, 117, 142);
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  font-weight: normal;
  height: 18px;
  letter-spacing: 0px;
  line-height: 18px;
`;

const UserInfoContainer = styled.View`
  flex-direction: row;
  padding-left: 20px;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const ButtonContainer = styled.View`
  position: absolute;
  bottom: 20px;
  left: 0px;
  right: 0px;
  width: 100%;
  padding-left: 20px;
  padding-right: 20px;
`;

const CheckIcon = styled.Image`
  height: 100px;
  width: 100px;
  top: -50px;
  position: absolute;
`;

const CheckIconContainer = styled.View`
  align-items: center;
`;

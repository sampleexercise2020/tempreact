import React from 'react';
import { storiesOf } from '@storybook/react-native';
import CheckoutModal from './CheckoutModal';

storiesOf('Components|Modal', module).add('Checkout Modal', () => (
  <CheckoutModal />
));

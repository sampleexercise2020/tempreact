import React from 'react';
import { storiesOf } from '@storybook/react-native';
import ProgressBar from './index';

storiesOf('Components/Progress', module)
  .add('Empty ProgressBar', () => <ProgressBar progressPercent={0} />)
  .add('Step 1', () => <ProgressBar progressPercent={33} />)
  .add('Step 2', () => <ProgressBar progressPercent={67} />)
  .add('Step 3', () => <ProgressBar progressPercent={100} />);

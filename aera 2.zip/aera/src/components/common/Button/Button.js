import React from 'react';
import { ActivityIndicator } from 'react-native';
import styled, { css } from 'styled-components/native';
import { useDebounce } from 'hooks/useDebounce';

const StyledButton = ({
  children,
  primary,
  onPress,
  disabled,
  secondary,
  error,
  allWhite,
  transparent,
  primaryV2,
  secondaryDisabled,
  debounce,
  testProperties,
  isLoading
}) => {
  const handleButtonPress = () => {
    useDebounce(onPress, 500);
  };

  return (
    <Button
      primary={primary}
      disabled={disabled}
      onPress={onPress}
      secondary={secondary}
      secondaryDisabled={secondaryDisabled}
      error={error}
      allWhite={allWhite}
      transparent={transparent}
      primaryV2={primaryV2}
    >
      {isLoading ? (
        <Loader>
          <ActivityIndicator size='small' />
        </Loader>
      ) : null}
      <Content
        isHidden={isLoading}
        allWhite={allWhite}
        primary={primary}
        disabled={disabled}
        error={error}
        transparent={transparent}
        primaryV2={primaryV2}
        secondaryDisabled={secondaryDisabled}
        {...testProperties}
      >
        {children}
      </Content>
    </Button>
  );
};

// TODO: Rätt rörigt här kan jag tycka. Om det kommer många fler stilar på knappar så behöver vi nog bygga om det här.

// const Borders = styled.View`
//   ${(props) =>
//     props.error &&
//     css`
//       height: 50px;
//       background-color: #f15b6080;
//       border-radius: 10px;
//     `}
// `;

const Loader = styled.View`
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  justify-content: center;
  align-items: center;
`;

const Content = styled.Text`
  text-align: center;
  font-family: 'TeshrinAR-Bold';
  font-size: 16px;
  width: 100%;
  line-height: 26px;
  font-weight: 600;
  ${(props) =>
    props.isHidden &&
    css`
      opacity: 0;
    `}
  color: ${(props) => props.theme.color.ctaDark};
  ${(props) =>
    props.primary &&
    css`
      color: white;
    `}
  ${(props) =>
    props.bold &&
    css`
      font-family: 'TeshrinAR-Bold';
      font-weight: 600;
    `}
  ${(props) =>
    props.disabled &&
    css`
      color: white;
    `}
  ${(props) =>
    props.secondary &&
    css`
      color: ${(props) => props.theme.color.primary.secondaryCTA};
    `}
  ${(props) =>
    props.error &&
    css`
      color: white;
    `}
  ${(props) =>
    props.transparent &&
    css`
      color: white;
    `}
  ${(props) =>
    props.secondaryDisabled &&
    css`
      color: #ced1d9;
    `}
  ${(props) =>
    props.primaryV2 &&
    css`
      color: white;
    `}
`;

const Button = styled.TouchableOpacity`
  background: white;
  padding: 10px;
  border-color: ${(props) => props.theme.color.primary.secondaryCTA};
  border-width: 1px;
  border-radius: 10px;
  height: 50px;
  ${(props) =>
    props.primary &&
    css`
      background: ${(props) => props.theme.color.primary.primaryCTA};
      border-width: 0;
    `}
  ${(props) =>
    props.disabled &&
    css`
      background: ${(props) => props.theme.color.disabled};
      border-color: ${(props) => props.theme.color.disabled};
    `}
  ${(props) =>
    props.secondary &&
    css`
      background: ${(props) => props.theme.color.primary.white};
      border-color: ${(props) => props.theme.color.primary.secondaryCTA};
    `}
  ${(props) =>
    props.allWhite &&
    css`
      background: ${(props) => props.theme.color.primary.white};
      border-color: ${(props) => props.theme.color.primary.white};
    `}
  ${(props) =>
    props.error &&
    css`
      background-color: #f15b60;
      border-width: 0;
    `}
  ${(props) =>
    props.transparent &&
    css`
      border-color: white;
      background-color: transparent;
    `}
  ${(props) =>
    props.primaryV2 &&
    css`
      background: #2c1e75;
    `}
  ${(props) =>
    props.secondaryDisabled &&
    css`
      background: ${(props) => props.theme.color.primary.white};
      border-color: #ced1d9;
    `}
`;

export default StyledButton;

import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

const AddButton = ({ text, backgroundColor, textColor, onPress, icon }) => {
  return (
    <Container backgroundColor={backgroundColor} onPress={onPress}>
      <Content>
        <PlusButton source={icon} />
        <CallToAction textColor={textColor}>{text}</CallToAction>
      </Content>
    </Container>
  );
};

AddButton.propTypes = {
  text: PropTypes.string,
  backgroundColor: PropTypes.string,
  textColor: PropTypes.string,
  onPress: PropTypes.func
};

const Container = styled.TouchableOpacity`
  justify-content: center;
  align-items: center;
  height: 32px;
  background: ${(props) =>
    props.backgroundColor ? props.backgroundColor : '#fbf2f3'};
  border-radius: 16px;
  padding: 6px 10px;
  margin-left: 22px;
`;

const Content = styled.View`
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;

const PlusButton = styled.Image`
  height: 16px;
  width: 16px;
`;
const CallToAction = styled.Text`
  width: 117px;
  height: 19px;
  color: ${(props) => (props.textColor ? props.textColor : '#210b4d')};
  font-size: 14px;
  font-family: 'OpenSans-Semibold';
  font-weight: 600;
  letter-spacing: 0;
  padding-left: 7px;
`;

export default AddButton;

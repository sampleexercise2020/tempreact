import React from 'react';
import { storiesOf } from '@storybook/react-native';
import ProfileHeader from './ProfileHeader';

storiesOf('Components|Header', module).add('ProfileHeader', () => (
  <ProfileHeader name='Anders Andersson' />
));

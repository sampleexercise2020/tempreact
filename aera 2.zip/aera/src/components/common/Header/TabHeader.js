import styled from 'styled-components/native';
import React from 'react';
import { testProperties } from '../../../helpers/testProperties';

const TabHeader = ({ text, testId, icon }) => {
  console.log('Tab Header Icon: ', icon);

  return (
    <Container>
      <InnerContainer>
        {icon && (
          <IconContainer>
            <Icon source={icon} resizeMode='contain' />
          </IconContainer>
        )}
        <Title
          numberOfLines={1}
          ellipsizeMode='tail'
          {...testProperties(`${testId}-header-id`)}
        >
          {text}
        </Title>
      </InnerContainer>
    </Container>
  );
};
const Container = styled.View`
  justify-content: center;
`;

const IconContainer = styled.View`
  background-color: rgba(255, 255, 255, 0.1);
  height: 44px;
  width: 44px;
  border-radius: 22px;
  margin-right: 15px;
  justify-content: center;
  align-items: center;
`;

const Icon = styled.Image`
  width: 24px;
  height: 24px;
`;

const InnerContainer = styled.View`
  flex-direction: row;
  align-items: center;
`;

const Title = styled.Text`
  color: rgb(255, 255, 255);
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 28px;
  font-weight: 900;
  height: 36px;
  letter-spacing: 0px;
  line-height: 36px;
`;

export default TabHeader;

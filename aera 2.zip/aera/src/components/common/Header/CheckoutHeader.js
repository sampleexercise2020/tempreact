import React from 'react';
import styled from 'styled-components/native';
import Avatar from '../../../modules/Discover/School/flows/Store/Start/components/Avatar';

const CheckoutHeader = ({ pageTitle, title, subtitle, image }) => {
  return (
    <Container>
      {/* <PageTitle>{pageTitle}</PageTitle> */}
      <Content>
        <Avatar image={image} />
        <TextContent>
          <Title>{title}</Title>
          <Subtitle>{subtitle}</Subtitle>
        </TextContent>
      </Content>
    </Container>
  );
};

export default CheckoutHeader;

const Container = styled.View`
  height: 138px;
  background-color: #2c1e75;
`;

const Content = styled.View`
  position: absolute;
  bottom: 0;
  margin-bottom: 15px;
  margin-left: 20px;
  flex-direction: row;
`;

const TextContent = styled.View`
  flex-direction: column;
  margin-left: 15px;
  justify-content: center;
`;

const Title = styled.Text`
  color: #ffffff;
  font-size: 14px;
  line-height: 18px;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
`;

const Subtitle = styled.Text`
  color: #ffffffb3;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  line-height: 18px;
  font-size: 14px;
`;

const PageTitle = styled.Text`
  text-align: center;
  margin-top: 15px;
  color: #ffffff;
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  line-height: 22px;
`;

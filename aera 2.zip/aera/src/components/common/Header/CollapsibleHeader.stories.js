import React from 'react';
import { View } from 'react-native';
import { storiesOf } from '@storybook/react-native';
import styled from 'styled-components';

import CollapsibleHeader from './CollapsibleHeader';
import ProfileImage from '../ProfileImage/ProfileImage';

storiesOf('Components|Header', module)
  .add('Collapsible - Standard', () => (
    <CollapsibleHeader
      title='Products'
      extendedHeight={300}
      collapsedHeight={100}
    >
      <View>
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
      </View>
    </CollapsibleHeader>
  ))
  .add('Collapsible - with Big Profile', () => (
    <CollapsibleHeader
      extendedHeight={300}
      collapsedHeight={100}
      title='Products'
      bigContent={
        <ProfileImage
          image='https://i.pravatar.cc/300'
          title='John Andersson'
          subtitle='Kindergarden 3A'
          editMode={true}
        />
      }
    >
      <View>
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
        <Item />
      </View>
    </CollapsibleHeader>
  ));

const Item = styled.View`
  height: 50px;
  border: 1px solid red;
`;

import React, { useState } from 'react';
import { Animated, Platform } from 'react-native';
import styled from 'styled-components';
import { getStatusBarHeight } from 'react-native-status-bar-height';
import DeviceInfo from 'react-native-device-info';

import NavigationBarHeader from './NavigationBarHeader';
import { css } from 'styled-components/native/dist/styled-components.native.esm';

// TODO: Put this in the category/product list screens: require('src/../../assets/icons/common/school-header-bg.png')

const CollapsibleHeader = ({
  children,
  bigContent: ProfileImage, //big component
  positionFromLeft,
  smallContent, //small component
  hasTitleBar, //needs to be true for left/right icons
  backgroundImage,
  extendedHeight, //max height
  collapsedHeight, //min height
  isCurved, //boolean
  titleBarIconLeft, //component
  titleBarIconRight, //component
  opacity,
  positionFromBottom, //= {40} int
  shouldScale,
  alignBigContentLeft,
  isHome,
  title // Title for the scroll list inside.
}) => {
  const statusBarHeight = getStatusBarHeight();
  const deviceHasNotch = DeviceInfo.hasNotch();
  const totalCollapsedHeight =
    Platform.OS === 'ios' ? collapsedHeight + statusBarHeight : collapsedHeight;

  const [heightOfHeader, setHeight] = useState(0);
  const [scrollY, setScrollY] = useState(new Animated.Value(0));

  const headerHeight = scrollY.interpolate({
    inputRange: [0, extendedHeight - totalCollapsedHeight],
    outputRange: [extendedHeight, totalCollapsedHeight],
    extrapolate: 'clamp'
  });
  const headerTitleOpacity = scrollY.interpolate({
    inputRange: [0, extendedHeight - totalCollapsedHeight],
    outputRange: [1, 0],
    extrapolate: 'clamp'
  });
  const heroTitleOpacity = scrollY.interpolate({
    inputRange: [0, extendedHeight - totalCollapsedHeight],
    outputRange: [0, 1],
    extrapolate: 'clamp'
  });
  const cornerRadius = scrollY.interpolate({
    inputRange: [0, extendedHeight - totalCollapsedHeight],
    outputRange: [50, 0],
    extrapolate: 'clamp'
  });
  headerHeight.addListener(({ value }) => setHeight(value));

  let transformOutputRange;
  let scaleOutputRangeEnd;

  const transformInputRange = deviceHasNotch ? 160 : 182;

  if (Platform.OS === 'android') {
    scaleOutputRangeEnd = 0.6;
    transformOutputRange = deviceHasNotch ? 105 : 90;
  } else {
    scaleOutputRangeEnd = 0.3;
    transformOutputRange = deviceHasNotch ? 105 : 110;
  }

  /**
   * This is to compensate for the extra padding on iOS devices, we should
   * probably find a solution that makes both Android and iOS the same.
   * @todo @Kevin or @Fabian
   */
  function getPlatformSpecificPaddingTop() {
    const extraPadding = 10;

    if (Platform.OS == 'android') {
      return extendedHeight + statusBarHeight + extraPadding;
    } else {
      return extendedHeight + extraPadding;
    }
  }

  return (
    <Container behavior='padding' enabled={Platform.OS !== 'android'}>
      <MakeStatusBarOpaque
        height={
          backgroundImage ? 0 : Platform.OS === 'android' ? 0 : statusBarHeight
        }
      />
      <Button disabled={true}>
        <HeaderContainer onPress height={headerHeight}>
          <Header
            height={headerHeight}
            style={{ borderBottomRightRadius: isCurved ? cornerRadius : 0 }}
          >
            <Background source={backgroundImage}>
              {hasTitleBar && (
                <NavigationContainer>
                  <NavigationBarHeader
                    deviceHasNotch={deviceHasNotch}
                    leftIcon={titleBarIconLeft}
                    rightIcon={titleBarIconRight}
                  >
                    <Animated.View style={{ opacity: heroTitleOpacity }}>
                      {smallContent}
                    </Animated.View>
                  </NavigationBarHeader>
                </NavigationContainer>
              )}
              <BigHeaderContainer
                isHome={isHome}
                alignBigContentLeft={alignBigContentLeft}
                style={{ bottom: positionFromBottom ? positionFromBottom : 20 }}
                positionFromLeft={positionFromLeft}
              >
                <Animated.View
                  style={{ opacity: opacity ? headerTitleOpacity : null }}
                >
                  {shouldScale ? (
                    <BigContent margin={10}>
                      {React.cloneElement(ProfileImage, {
                        heightOfHeader,
                        style: {
                          transform: [
                            {
                              translateY: scrollY.interpolate({
                                inputRange: [0, transformInputRange],
                                outputRange: [1, transformOutputRange],
                                extrapolate: 'clamp'
                              })
                            },
                            {
                              scaleX: scrollY.interpolate({
                                inputRange: [0, 130, 160],
                                outputRange: [1, 0.7, scaleOutputRangeEnd],
                                extrapolate: 'clamp'
                              })
                            },
                            {
                              scaleY: scrollY.interpolate({
                                inputRange: [0, 130, 160],
                                outputRange: [1, 0.7, scaleOutputRangeEnd],
                                extrapolate: 'clamp'
                              })
                            }
                          ]
                        }
                      })}
                    </BigContent>
                  ) : (
                    <BigContent>{ProfileImage}</BigContent>
                  )}
                </Animated.View>
              </BigHeaderContainer>
            </Background>
          </Header>
          {title ? (
            <TitleContainer>
              <Title>{title}</Title>
            </TitleContainer>
          ) : null}
        </HeaderContainer>
        {React.cloneElement(children, {
          onScroll: Animated.event([
            {
              nativeEvent: {
                contentOffset: {
                  y: scrollY
                }
              }
            }
          ]),
          scrollEventThrottle: 16,
          contentContainerStyle: {
            paddingTop: title
              ? getPlatformSpecificPaddingTop() + 30
              : getPlatformSpecificPaddingTop()
          }
        })}
      </Button>
    </Container>
  );
};

export default CollapsibleHeader;

const Container = styled.KeyboardAvoidingView`
  position: relative;
  flex: 1;
`;

const Button = styled.TouchableOpacity``;
const BigContent = styled(Animated.View)`
  ${(props) =>
    props.margin &&
    css`
      padding-bottom: ${props.margin};
    `}
`;

const HeaderContainer = styled(Animated.View)`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 100;
`;

const BigHeaderContainer = styled.View`
  position: absolute;
  
  align-self: ${(props) =>
    props.alignBigContentLeft ? 'flex-start' : 'center'};

  ${(props) =>
    props.positionFromLeft &&
    css`
      margin-left: ${props.positionFromLeft};
    `}
  ${(props) =>
    props.isHome &&
    css`
      left: 0;
      width: 100%;
    `}
  ${(props) =>
    !props.positionFromLeft &&
    css`
      align-self: center;
    `}
`;

const MakeStatusBarOpaque = styled.View`
  position: absolute;
  top: 0;
  left: 0;
  background: #402ca8;
  width: 100%;
  height: ${(props) => props.height};
  z-index: 101;
`;

const Header = styled(Animated.View)`
  position: relative;
  width: 100%;
  background: #402ca8;
  border-bottom-right-radius: ${(props) => (props.isCurved ? '50px' : '0px')};
  overflow: hidden;
`;

const Background = styled.ImageBackground`
  height: 100%;
  width: 100%;
`;

const TitleContainer = styled(Animated.View)`
  height: 60px;
  justify-content: center;
  background: white;
`;

const Title = styled.Text`
  padding-left: 30px;
  color: rgb(13, 25, 67);
  font-size: 32px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  letter-spacing: 0px;
  line-height: 40px;
`;

const NavigationContainer = styled.View`
  padding-top: 30px;
`;

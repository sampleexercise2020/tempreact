import styled from 'styled-components/native';
import React from 'react';
import CircleIndicator from '../CircleIndicator';
import Avatar from '../../../modules/Discover/School/flows/Store/Start/components/Avatar';
import { Dimensions } from 'react-native';

const ProfileHeader = ({ name, onPress, image }) => {
  const simpleArrowForward =
    '../../../../assets/icons/navigation/simple-arrow-forward-white.png';
  return (
    <Button onPress={onPress}>
      <Container>
        <Avatar name={name} image={image} />
        <TextContainer>
          <ProfileName>{name}</ProfileName>
          <SubTitle>Show Profile</SubTitle>
        </TextContainer>
        <ArrowIconContainer>
          <ArrowIcon
            resizeMode='contain'
            source={require(simpleArrowForward)}
          />
        </ArrowIconContainer>
      </Container>
    </Button>
  );
};

const Container = styled.View`
  flex-direction: row;
  background-color: #402ca8;
  width: ${Dimensions.get('window').width};
  padding-left: 20px;
  padding-right: 20px;
  align-items: center;
`;
const Button = styled.TouchableOpacity``;

const ArrowIconContainer = styled.View`
  /*padding-right: 20px;*/
  margin-right: auto;
  position: absolute;
  right: 20px;
  top: 16px;
`;
const ArrowIcon = styled.Image`
  height: 15px;
  width: 15px;
`;

const TextContainer = styled.View`
  margin-left: 10px;
`;
const ProfileName = styled.Text`
  color: rgb(255, 255, 255);
  font-family: 'OpenSans-Bold';
  font-size: 14px;
  font-weight: bold;
  height: 18px;
  letter-spacing: 0px;
  line-height: 18px;
`;
const SubTitle = styled.Text`
  color: rgb(255, 255, 255);
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  font-weight: normal;
  height: 18px;
  letter-spacing: 0px;
  line-height: 18px;
`;

export default ProfileHeader;

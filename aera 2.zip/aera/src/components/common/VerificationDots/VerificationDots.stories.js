import React from 'react';
import { storiesOf } from '@storybook/react-native';
import VerificationDots from './VerificationDots';

storiesOf('Components/VerificationDots', module)
  .add('No numbers', () => <VerificationDots />)
  .add('Verification Dots', () => (
    <VerificationDots values={['1', '2', '3', '4']} />
  ))
  .add('Two numbers', () => <VerificationDots values={['1', '2']} />);

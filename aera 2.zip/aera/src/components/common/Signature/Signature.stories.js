import React from 'react';
import { storiesOf } from '@storybook/react-native';

import Signature from './Signature';

storiesOf('Components|Signature', module).add('Basic', () => (
  <Signature text='Signature Required' />
));

import React from 'react';
import { render } from 'react-native-testing-library';
import Avatar from './Avatar';

describe('Avatar', () => {
  it('matches the snapshot', async () => {
    const { toJSON } = render(<Avatar />);
    expect(toJSON()).toMatchSnapshot();
  });
});

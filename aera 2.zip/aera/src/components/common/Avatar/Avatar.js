import React from 'react';
import styled from 'styled-components/native';
import UserAvatar from 'react-native-user-avatar';

const Avatar = ({
  isRemote,
  innerBorder,
  light,
  small,
  smallIcon,
  image,
  name,
  innerColor
}) => {
  const source = isRemote ? { uri: image } : image;
  return (
    <Container small={small}>
      {innerBorder ? (
        <PurpleStroke light={light} small={small}>
          <WhiteStroke innerColor={innerColor}>
            {image ? (
              <Img smallIcon={smallIcon} source={source} />
            ) : (
              <UserAvatarContainer>
                <UserAvatar
                  name={name ? name.toUpperCase() : 'Test Placeholder'}
                  size={small ? 35 : 45}
                  color='#4f2c94'
                />
              </UserAvatarContainer>
            )}
          </WhiteStroke>
        </PurpleStroke>
      ) : null}
      {!innerBorder ? (
        <PurpleStroke light={light} small={small}>
          {image ? (
            <Img smallIcon={smallIcon} source={source} />
          ) : (
            <UserAvatarContainer>
              <UserAvatar
                name={name ? name.toUpperCase() : 'Test Placeholder'}
                size={small ? 35 : 45}
                color='#4f2c94'
              />
            </UserAvatarContainer>
          )}
        </PurpleStroke>
      ) : null}
    </Container>
  );
};
const Container = styled.View`
  height: ${(props) => (props.small ? '35px' : '45px')};
  width: ${(props) => (props.small ? '35px' : '45px')};
  border-radius: 50px;
  justify-content: center;
  align-items: center;
  overflow: hidden;
`;

const PurpleStroke = styled.View`
  height: ${(props) => (props.small ? '32px' : '42px')};
  width: ${(props) => (props.small ? '32px' : '42px')};
  border-radius: 50px;
  border-width: 2.5px;
  border-color: ${(props) =>
    props.light ? 'rgb(207, 209, 216)' : 'rgb(62, 48, 164)'};
  justify-content: center;
  align-items: center;
  overflow: hidden;
  z-index: 102;
`;
const WhiteStroke = styled.View`
  height: ${(props) => (props.small ? '29.5px' : '39.5px')};
  width: ${(props) => (props.small ? '29.5px' : '39.5px')};
  border-radius: 50px;
  border-width: 2.5px;
  border-color: ${(props) => props.innerColor};
  justify-content: center;
  align-items: center;
  overflow: hidden;
  z-index: 101;
`;
const Img = styled.Image`
  height: ${(props) => (props.smallIcon ? '70%' : '110%')};
  width: ${(props) => (props.smallIcon ? '70%' : '110%')};
  padding: 2px;
  z-index: 100;
`;
const UserAvatarContainer = styled.View`
  height: ${(props) => (props.small ? '32px' : '42px')};
  width: ${(props) => (props.small ? '32px' : '42px')};
  justify-content: center;
  align-items: center;
  overflow: hidden;
  z-index: 100;
`;

export default Avatar;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import SimpleArrowListItem from './SimpleArrowListItem';

// TODO: Get notes working.

storiesOf('Components|List items', module).add(
  'Single text list item (arrow item)',
  () => <SimpleArrowListItem text='This is a list item with an arrow' />
);

import React from 'react';
import styled from 'styled-components/native';

//TODO: fixa borderfärgen till en variabel i theme ist för hårdkodat.
//TODO: fixa rätt font och rätt font storlek.

const SimpleArrowListItem = ({ onPress, text, icon }) => {
  return (
    <Container onPress={onPress}>
      {icon && (
        <Icon source={require('../../../../assets/icons/dummy_icon.png')} />
      )}
      <Title>{text}</Title>
      <Arrow
        resizeMode='contain'
        source={require('../../../../assets/icons/common/right-arrow.png')}
      />
    </Container>
  );
};

export default SimpleArrowListItem;

const Container = styled.TouchableOpacity`
  height: 53px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  padding: 0px 20px;
  background-color: #ffffff;
  overflow: visible;
`;

const Icon = styled.Image`
  height: 25px;
`;

const Arrow = styled.Image`
  height: 15px;
`;

const Title = styled.Text`
  color: ${(props) => props.theme.color.brandDark};
  font-size: 18px;
  font-family: 'OpenSans-SemiBold';
  font-weight: 600;
  letter-spacing: 0px;
  line-height: 26px;
`;

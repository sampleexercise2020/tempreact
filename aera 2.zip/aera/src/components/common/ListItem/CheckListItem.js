import React from 'react';
import styled from 'styled-components/native';
import RadioButton from 'components/common/RadioButton/RadioButton';

const CheckListItem = ({ itemName, selected, onPress }) => {
  return (
    <Container onPress={onPress}>
      <RadioButton checked={selected} />
      <ItemName>{itemName}</ItemName>
    </Container>
  );
};

export default CheckListItem;

const Container = styled.TouchableOpacity`
  flex-direction: row;
  align-items: center;
  padding-bottom: 20px;
`;

const ItemName = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  font-weight: bold;
  line-height: 22px;
  color: #0d1943;
  padding-left: 20px;
`;

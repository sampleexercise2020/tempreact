import React from 'react';
import styled from 'styled-components';
import { Headline } from 'components/common/Typography/';
import RadioButton from '../RadioButton/RadioButton';
import AddCardButton from '../../../modules/Discover/School/flows/Checkout/components/AddCardButton';

//TODO: fel tjocklek på texten
//TODO: fixa font
//TODO: fixa textfärger?

const CheckMarkIcon = require('src/../../assets/images/checkmark.png');
const forwardArrow = require('../../../../assets/icons/common/right-arrow.png');

const IconAndTextListItem = ({
  listItemText,
  imageUrl,
  border,
  icon,
  maskedPan,
  isDefault,
  selected,
  check,
  onPress,
  isButton,
  iconWidth,
  buttonOnPress,
  hideArrow
}) => {
  return (
    <Container border={border} onPress={onPress}>
      {icon ? (
        <IconContainer>
          {imageUrl && (
            <Icon
              iconWidth={iconWidth}
              resizeMode='contain'
              source={{ uri: imageUrl }}
            />
          )}
          {icon && (
            <Icon iconWidth={iconWidth} resizeMode='contain' source={icon} />
          )}
        </IconContainer>
      ) : null}
      <TextContainer>
        <Title>{listItemText}</Title>
        {maskedPan ? <MaskedPan>{maskedPan}</MaskedPan> : null}
      </TextContainer>
      {isDefault && (
        <DefaultCheck resizeMode='contain' source={CheckMarkIcon} />
      )}
      {check && { check } ? (
        <RadioContainer>
          <RadioButton checked={selected} />
        </RadioContainer>
      ) : isButton ? (
        <AddButtonContainer>
          <AddCardButton available onPress={buttonOnPress} />
        </AddButtonContainer>
      ) : hideArrow ? null : (
        <Arrow resizeMode='contain' source={forwardArrow} />
      )}
    </Container>
  );
};

export default IconAndTextListItem;

const Container = styled.TouchableOpacity`
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 14px 0;
  ${(props) =>
    props.border &&
    css`
      border-top-width: 1px;
      border-bottom-width: 1px;
      border-color: ${(props) => props.theme.color.misc.listItemDivider};
    `}
`;

const Title = styled(Headline)`
  color: #0d1943;
  font-size: 16px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
`;

const MaskedPan = styled(Headline)`
  color: #6d758e;
  font-size: 12px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
`;

const IconContainer = styled.View`
  height: 28px;
  width: 35px;
  margin-left: 20px;
  justify-content: center;
  align-items: center;
`;
const AddButtonContainer = styled.View`
  position: absolute;
  right: 20px;
`;

const Icon = styled.Image`
  flex: 1;
  height: undefined;
  width: ${(props) => (props.iconWidth ? props.iconWidth : '35px')};
`;

const Arrow = styled.Image`
  position: absolute;
  right: 0;
  height: 15px;
  margin-right: 20px;
`;

const TextContainer = styled.View`
  flex-direction: column;
  margin-left: 20px;
`;

const DefaultCheck = styled.Image`
  width: 14px;
  height: 14px;
  position: absolute;
  right: 0;
  margin-right: 60px;
`;

const RadioContainer = styled.View`
  position: absolute;
  right: 0;
`;

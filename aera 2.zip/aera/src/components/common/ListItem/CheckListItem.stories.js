import React from 'react';
import { storiesOf } from '@storybook/react-native';
import CheckListItem from './CheckListItem';

storiesOf('Components|List items', module).add('Checklist item', () => (
  <CheckListItem itemName='+23489234' />
));

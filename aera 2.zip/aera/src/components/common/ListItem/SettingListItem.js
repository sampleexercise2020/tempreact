import React from 'react';
import styled from 'styled-components/native';
import RadioButton from 'components/common/RadioButton/RadioButton';

const SettingListItem = ({ text, toggleValue, toggle }) => {
  return (
    <Container>
      <TextContainer>
        <ItemName>{text}</ItemName>
      </TextContainer>
      <Toggle
        onValueChange={toggle}
        value={toggleValue}
        trackColor={{ true: '#402ca8' }}
      />
    </Container>
  );
};

export default SettingListItem;

const Container = styled.View`
  flex-direction: row;
  height: 30px;
`;

const TextContainer = styled.View`
  flex: 1;
  justify-content: center;
`;

const ItemName = styled.Text`
  font-family: 'TeshrinAR-Bold';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
`;

const Toggle = styled.Switch``;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import IconAndTextListItem from './IconAndTextListItem';

// TODO: Get notes working.

const iconAmex = require('../../../../assets/icons/payment/Mobile-AmericanExpress.png');
const iconVisa = require('../../../../assets/icons/payment/Mobile-VISA.png');

storiesOf('Components|List items', module)
  .add('Icon and text', () => (
    <IconAndTextListItem
      icon={iconAmex}
      listItemText='American Express'
      maskedPan='**** **** **** 5236'
      isDefault={false}
    />
  ))
  .add('Icon and text (default)', () => (
    <IconAndTextListItem
      icon={iconVisa}
      listItemText='Visa'
      maskedPan='**** **** **** 4523'
      isDefault={true}
    />
  ))
  .add('Icon and text (check)', () => (
    <IconAndTextListItem
      icon={iconVisa}
      listItemText='Visa'
      maskedPan='**** **** **** 4523'
      check={true}
    />
  ))
  .add('Icon and text without mask', () => (
    <IconAndTextListItem
      icon={iconVisa}
      listItemText='Touch ID'
      isButton={true}
    />
  ));

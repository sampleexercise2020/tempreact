import { Text } from 'react-native';
import styled, { css } from 'styled-components/native';

// TODO: organisation? Oklart
// TODO: Add correct colors.
// TODO: Add correct font families!

export const Headline = styled(Text)`
  font-weight: bold;
  
  {/* FONT */}
  ${(props) =>
    props.teshrin &&
    css`
      font-family: Arial, Helvetica, sans-serif;
    `}

  ${(props) =>
    props.openSans &&
    css`
      font-family: Arial, Helvetica, sans-serif;
    `}

  {/* SIZE */}
  ${(props) =>
    props.h1 &&
    css`
      font-size: 48px;
      letter-spacing: -0.6px;
      line-height: 48px;
    `}

  ${(props) =>
    props.h2 &&
    css`
      font-size: 32px;
      line-height: 32px;
    `}

  ${(props) =>
    props.h3 &&
    css`
      font-size: 28px;
      line-height: 30px;
    `}

  ${(props) =>
    props.h4 &&
    css`
      font-size: 24px;
      line-height: 24px;
    `}
  ${(props) =>
    props.h5 &&
    css`
      font-size: 16px;
      line-height: 16px;
    `}

    ${(props) =>
      props.h6 &&
      css`
        font-size: 14px;
        line-height: 14px;
      `}

  {/* COLORS */}
  ${(props) =>
    props.black &&
    css`
      color: black;
    `}
  ${(props) =>
    props.white &&
    css`
      color: white;
    `}
  ${(props) =>
    props.primary &&
    css`
      color: ${(props) => props.theme.color.primary.primaryCTA};
    `}
  ${(props) =>
    props.brand &&
    css`
      color: ${(props) => props.theme.color.primary.primaryText};
    `}
  ${(props) =>
    props.cta &&
    css`
      color: ${(props) => props.theme.color.cta};
    `}
  ${(props) =>
    props.ctaDark &&
    css`
      color: ${(props) => props.theme.color.ctaDark};
    `}
`;

export const Regular = styled(Text)`
  font-size: 16px;
`;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import styled from 'styled-components/native';
import { Headline, Regular } from './index';

storiesOf('Components|Typography', module)
  .add('Fonts', () => (
    <React.Fragment>
      <Headline h2>Teshrin</Headline>
      <Spacer />
      <Headline h2>Open Sans</Headline>
    </React.Fragment>
  ))
  .add('Colors', () => (
    <React.Fragment>
      <Headline h2 black>
        Headline Black
      </Headline>
      <Spacer />
      <Headline h2 brand>
        Headline Brand
      </Headline>
      <Spacer />
      <Headline h2 cta>
        Headline CTA
      </Headline>
      <Spacer />
      <Headline h2 primary>
        Headline Primary
      </Headline>
      <Spacer />
      <Headline h2 ctaDark>
        Headline CTA Dark
      </Headline>
    </React.Fragment>
  ))
  .add('Headlines', () => (
    <React.Fragment>
      <Headline h1>Headline 48</Headline>
      <Spacer />
      <Headline h2>Headline 32</Headline>
      <Spacer />
      <Headline h3>Headline 28</Headline>
      <Spacer />
      <Headline h4>Headline 22</Headline>
      <Spacer />
      <Headline h5>Headline 32</Headline>
      <Spacer />
      <Headline h6>Headline 14</Headline>
    </React.Fragment>
  ))
  .add('Regular', () => (
    <React.Fragment>
      <Regular h1>Regular 16</Regular>
      <Spacer />
    </React.Fragment>
  ));

const Spacer = styled.View`
  height: 30px;
`;

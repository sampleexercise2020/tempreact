import React from 'react';
import { storiesOf } from '@storybook/react-native';
import RadioButton from './RadioButton';

storiesOf('Components/RadioButton', module).add('Radio button', () => (
  <RadioButton checked={true} />
));

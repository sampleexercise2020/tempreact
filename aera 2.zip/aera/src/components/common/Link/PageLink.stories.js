import React from 'react';
import { storiesOf } from '@storybook/react-native';
import PageLink from './PageLink';

// TODO: Get notes working.

storiesOf('Components|Links', module).add('Page link', () => (
  <PageLink
    linktext='Terms of use'
    onPress={() => console.log('on press works')}
  />
));

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import CircleIndicator from './index';

storiesOf('Components/Label', module).add('Circle indicator', () => (
  <CircleIndicator />
));

import React from 'react';
import { render, flushMicrotasksQueue } from 'test-utils';
import OfflineNotice from './OfflineNotice';

test('should be online by default', async () => {
  const { queryByTestId } = render(<OfflineNotice />);
  const Notice = queryByTestId('offline-notice');

  await flushMicrotasksQueue();

  expect(Notice).toBeNull();
});

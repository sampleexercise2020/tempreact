import React from 'react';
import { storiesOf } from '@storybook/react-native';
import styled from 'styled-components/native';
import SearchBar from './index';

storiesOf('Components/Search', module)
  .addDecorator((storyFn) => <Decorator>{storyFn()}</Decorator>)
  .add('Empty SearchBar', () => <SearchBar />)
  .add('With placeholder', () => <SearchBar placeholderText='Search school' />)
  .add('With value', () => (
    <SearchBar placeholderText='Search school' value='My school' />
  ));

const Decorator = styled.View`
  background-color: #efefef;
  padding: 20px;
  height: 100%;
  display: flex;
  justify-content: center;
`;

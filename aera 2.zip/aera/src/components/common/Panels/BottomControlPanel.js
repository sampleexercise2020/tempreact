import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

import Button from 'components/common/Button/Button';

// TODO: Add icons.

const CartControls = ({ text, actions }) => {
  return (
    <Container>
      <TextContainer children={text} />
      <Actions children={actions} />
    </Container>
  );
};

CartControls.propTypes = {};

const Container = styled.View`
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding: 0px 3px;
`;
const TextContainer = styled.View`
  flex-direction: row;
  margin-bottom: 12px;
`;

const Actions = styled.View`
  flex-direction: row;
`;

export default CartControls;

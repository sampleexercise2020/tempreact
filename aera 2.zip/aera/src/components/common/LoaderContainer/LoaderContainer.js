import React from 'react';
import { ActivityIndicator } from 'react-native';
import styled from 'styled-components/native';

const LoaderContainer = ({ children, isLoading }) => {
  return (
    <Container>
      {children && !isLoading ? (
        children
      ) : (
        <Loader>
          <ActivityIndicator size='large' />
        </Loader>
      )}
    </Container>
  );
};

const Loader = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
  padding: 20px 0;
`;

const Container = styled.View`
  flex: 1;
`;

export default LoaderContainer;

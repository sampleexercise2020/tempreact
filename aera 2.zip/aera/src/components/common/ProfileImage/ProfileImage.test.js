import React from 'react';
import { render } from 'test-utils';
import ProfileImage from './ProfileImage';

const mockData = {
  imageUri: 'https://mockimage.com/img.jpg'
};

describe('ProfileImage', () => {
  it('matches the snapshot', async () => {
    const { toJSON } = render(<ProfileImage image={mockData.imageUri} />);

    expect(toJSON()).toMatchSnapshot();
  });

  it('should have the correct image uri', async () => {
    const { getByTestId } = render(<ProfileImage image={mockData.imageUri} />);
    const Image = getByTestId('image');

    expect(Image.props.source.uri).toEqual(mockData.imageUri);
  });
});

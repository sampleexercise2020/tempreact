import React from 'react';
import styled from 'styled-components';
import { storiesOf } from '@storybook/react-native';
import CodeVerifier from './CodeVerifier';

storiesOf('Components/CodeVerifier', module).add('CVV', () => (
  <CodeVerifier length={3} onPress={() => alert('WOW!')}>
    <Title>Please enter your cards CVV number.</Title>
  </CodeVerifier>
));

const Title = styled.Text`
  width: 200px;
  color: rgb(13, 25, 67);
  font-size: 20px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  text-align: center;
  letter-spacing: 0px;
  line-height: 28px;
`;

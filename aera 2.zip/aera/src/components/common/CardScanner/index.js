import React, { Component } from 'react';
import { Text, TouchableOpacity } from 'react-native';
import { CardIOModule, CardIOUtilities } from 'react-native-awesome-card-io';
import { useStoreActions } from 'easy-peasy';
import SmallButton from '/components/common/Button/SmallButton';
import styled from 'styled-components/native';

const CameraIcon = require('../../../../assets/icons/common/camera.png');

const config = {
  useCardIOLogo: false,
  hideCardIOLogo: true,
  requireExpiry: true,
  requireCVV: false,
  scanExpiry: true,
  suppressManualEntry: true,
  CAN_READ_CARD_WITH_CAMERA: true
};

export default (CardScanner = () => {
  const saveCard = useStoreActions((actions) => actions.cards.saved);
  const isScanned = useStoreActions((actions) => actions.cards.isScanned);

  scanCard = () => {
    CardIOModule.scanCard(config)
      .then((card) => {
        const month =
          card.expiryMonth >= 10 ? card.expiryMonth : `0${card.expiryMonth}`;
        const year = Number(card.expiryYear.toString().slice(-2));
        const payload = {
          pan: card.cardNumber,
          expDate: `${month}/${year}`
        };
        isScanned();
        saveCard(payload);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <Container>
      <TouchableOpacity onPress={scanCard} style={{ flexDirection: 'row' }}>
        <Camera source={CameraIcon} />
        <Text
          style={{
            fontFamily: 'TeshrinAR-Bold',
            fontSize: 17,
            width: 100,
            color: '#4f2c94',
            marginLeft: 10
          }}
        >
          Scan Card
        </Text>
      </TouchableOpacity>
    </Container>
  );
});

const Container = styled.View`
  justify-content: center;
  align-items: center;
  height: 32px;
  border-radius: 16px;
  padding: 0px 10px;
  margin-left: 22px;
  padding-bottom: 10px;
`;

const Camera = styled.Image`
  width: 28px;
  height: 22px;
`;

import React from 'react';
import styled from 'styled-components/native';

const rakbankBranding = require('../../../../assets/images/splash-rakbank-branding.png');

const LoginFlowFooter = (props) => {
  return (
    <Footer>
      <Branding source={rakbankBranding} resizeMode='contain' />
    </Footer>
  );
};

export default LoginFlowFooter;

const Footer = styled.View`
  height: 30px;
  background-color: #130d32;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;

const Branding = styled.Image``;

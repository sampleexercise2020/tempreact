import React from 'react';
import { storiesOf } from '@storybook/react-native';
import LoginFlowFooter from './LoginFlowFooter';

storiesOf('Components|Footers', module).add('Login flow footer', () => (
  <LoginFlowFooter />
));

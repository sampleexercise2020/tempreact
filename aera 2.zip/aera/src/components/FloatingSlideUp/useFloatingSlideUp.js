import React, { useState, useCallback, useEffect } from 'react';
import { Navigation } from 'react-native-navigation';
import useFloating from 'hooks/useFloating';

export default (component, floatingState) => {
  return useFloating({
    component,
    componentId: 'FLOATING_SLIDE_UP_ID',
    componentName: 'FloatingSlideUp',
    interceptTouchOutside: true,
    floatingState
  });
};

import FloatingSlideUp from './FloatingSlideUp';
import useFloatingSlideUp from './useFloatingSlideUp';

export default FloatingSlideUp;

export { useFloatingSlideUp };

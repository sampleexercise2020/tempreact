import React from 'react';
import { storiesOf } from '@storybook/react-native';

import FloatingPanel from './FloatingPanel';

storiesOf('Examples|Floating panel', module).add('Basic', () => (
  <FloatingPanel />
));

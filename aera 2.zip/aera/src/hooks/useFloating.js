import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useActions } from 'easy-peasy';
import { Navigation } from 'react-native-navigation';

export default ({
  component,
  componentName,
  componentId,
  interceptTouchOutside = false
}) => {
  const [isOverlay, setIsOverlay] = useState(false);
  // const [isComponentMounted, setIsComponentMounted] = useState(false);
  const isComponentMounted = useRef(false);
  const setShowFloating = useActions(
    (actions) => actions.global.setShowFloating
  );

  const hideOverlay = () => {
    console.log('Is dismissing overlay:', componentId);
    Navigation.dismissOverlay(componentId);
    console.log('Did dismiss overlay:', componentId);
  };

  const showOverlay = () => {
    Navigation.showOverlay({
      component: {
        id: componentId,
        name: componentName,
        options: {
          overlay: {
            interceptTouchOutside
          }
        },
        passProps: {
          setIsOverlay,
          component
        }
      }
    });

    setShowFloating(true);
  };

  useEffect(() => {
    Navigation.events().registerComponentDidAppearListener((event) => {
      if (event.componentId == componentId) {
        console.log('Overlay did mount:', componentId);
        // setIsComponentMounted(true);
        isComponentMounted.current = true;
      }
    });

    Navigation.events().registerComponentDidDisappearListener((event) => {
      if (event.componentId == componentId) {
        console.log('Overlay did unmount:', componentId);
        isComponentMounted.current = false;
      }
    });
  }, []);

  useEffect(() => {
    console.log('isOverlay changed to:', isOverlay);
    if (isOverlay) {
      if (!isComponentMounted.current) {
        showOverlay();
      }
    } else {
      if (isComponentMounted.current) {
        console.log('Will hide overlay');
        hideOverlay();
      }
    }
  }, [isOverlay]);

  return setIsOverlay;
};

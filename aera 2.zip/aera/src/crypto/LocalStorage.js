import { AsyncStorage } from 'react-native';

export default class LocalStorage {
  // singleton instance
  static instance = null;
  static getInstance() {
    if (this.instance == null) {
      this.instance = new LocalStorage();
    }
    return this.instance;
  }

  // set symmetric key
  async setSymmetricKey(key, success, failure) {
    try {
      await AsyncStorage.setItem('SYM_KEY', key);
      success();
    } catch (error) {
      failure(error);
    }
  }

  // get symmetric key
  async getSymmetricKey(success, failure) {
    try {
      const value = await AsyncStorage.getItem('SYM_KEY');
      success(value);
    } catch (error) {
      failure(error);
    }
  }

  // set public key
  async setPublicKey(key, success, failure) {
    try {
      await AsyncStorage.setItem('PUB_KEY', key);
      success();
    } catch (error) {
      failure(error);
    }
  }

  // get public key
  async getPublicKey(success, failure) {
    try {
      const value = await AsyncStorage.getItem('PUB_KEY');
      success(value);
    } catch (error) {
      failure(error);
    }
  }

  // reset all ecryption keys
  removeCryptoKeys() {
    AsyncStorage.removeItem('SYM_KEY');
    AsyncStorage.removeItem('PUB_KEY');
  }
}

import HybridCrypto from './HybridCrypto';

export default class SecureAPI {
  /**
   * This method encrypts all request parameters with Hybrid Encryption and calls API.
   * It returns decrypted response text in success callback.
   * @param {*} url
   * URL of API
   * @param {*} method
   * Method of request.
   * @param {*} headers
   * Header for request.
   * @param {*} params
   * Request parameters of API
   * @param {*} success
   * Callback returns decrypted response of API
   * @param {*} failure
   * Callback retruns error message.
   */
  // request(url, method, headers, params, success, failure) {
  //   // Encrypt params
  //   HybridCrypto.encrypt(
  //     JSON.stringify(params),
  //     (encryptedPayload, encryptedSymKey) => {
  //       // update headers
  //       headers['x-sym-key'] = encryptedSymKey;
  //       headers['accept'] = '*/*';

  //       // call api
  //       fetch(url, {
  //         method: method,
  //         headers: headers,
  //         body: encryptedPayload
  //       })
  //         .then((response) => response.text())
  //         .then((text) => {
  //           // decrypt response
  //           HybridCrypto.decrypt(
  //             text,
  //             (decryptedPayload) => {
  //               success(decryptedPayload);
  //             },
  //             (error) => {
  //               failure('Unable to decrypt response.' + error);
  //             }
  //           );
  //         })
  //         .catch((error) => {
  //           console.error('Unable to request secure api. ' + error);
  //         });
  //     },
  //     (error) => {
  //       error('Unable to encrypt request parameters. ' + error);
  //     }
  //   );
  // }

  request(url, method, headers, params) {
    const promise = new Promise(function(resolve, reject) {
      HybridCrypto.encrypt(JSON.stringify(params))
        .then((encrypted) => {
          console.log('Ecrypted Params: ', JSON.stringify(encrypted));

          // update headers
          headers['x-sym-key'] = encrypted.encryptedSymKey;
          headers['accept'] = '*/*';

          // call api
          fetch(url, {
            method: method,
            headers: headers,
            body: encrypted.encryptedPayload
          })
            .then((response) => response.text())
            .then((text) => {
              console.log('Response Text: ' + text);
              // decrypt response
              HybridCrypto.decrypt(text)
                .then((decryptedResponse) => {
                  const decryptedData = JSON.parse(decryptedResponse.data);
                  const statusCode = decryptedData.status.code;
                  if (statusCode !== 'Y') {
                    reject(decryptedData.status);
                  } else {
                    resolve(decryptedData);
                  }
                })
                .catch((error) => {
                  reject(error);
                });
            })
            .catch((error) => {
              reject(error);
            });
        })
        .catch((error) => {
          reject(error);
        });
    });

    return promise;
  }
}

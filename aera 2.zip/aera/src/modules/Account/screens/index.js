import React from 'react';
import styled from 'styled-components/native';
import { Navigation } from 'react-native-navigation';
import { testProperties } from '../../../helpers/testProperties';

const AccountStartingPage = (props) => {
  Navigation.mergeOptions(props.componentId, {
    topBar: {
      title: {
        text: 'Account'
      }
    }
  });
  const navigateToMyProfile = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'Skiply.Account.Profile.Profile',
        options: {
          topBar: {
            title: {
              text: 'My Profile'
            }
          }
        }
      }
    });
  };
  const navigateToPaymentMethod = () => {
    Navigation.push(props.componentId, {
      component: {
        name: 'Skiply.Account.Payments.AvAvailableCards',
        options: {
          topBar: {
            title: {
              text: 'Payment methods'
            }
          }
        }
      }
    });
  };
  return (
    <Container {...testProperties('account-start-container-id')}>
      <Title {...testProperties('account-start-title-id')}>
        Account Page Starting Page
      </Title>
      <Button
        onPress={navigateToMyProfile}
        testProperties={testProperties('account-start-to-profile-button-id')}
      >
        <SubTitle>Go to my profile</SubTitle>
      </Button>
      <Button
        onPress={navigateToPaymentMethod}
        testProperties={testProperties(
          'account-start-to-paymentmethod-button-id'
        )}
      >
        <SubTitle>Payment method</SubTitle>
      </Button>
    </Container>
  );
};

export default AccountStartingPage;

const Container = styled.View`
  flex: 1;
`;

const SubTitle = styled.Text`
  padding: 50px;
  color: red;
`;
const Button = styled.TouchableOpacity``;

const Title = styled.Text`
  color: blue;
  font-size: 30px;
  padding-top: 100px;
  margin-left: 100px;
`;

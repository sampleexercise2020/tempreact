import React, { Fragment, useEffect } from 'react';
import { ActivityIndicator, FlatList, Text } from 'react-native';
import styled from 'styled-components/native';
import { useActions, useStore } from 'easy-peasy';
import { navigateTo } from 'navigation';
import IconAndTextListItem from 'components/common/ListItem/IconAndTextListItem';
import { ThinLine } from 'components/common/Dividers/Dividers';
import Button from 'components/common/Button/Button';
import { Navigation } from 'react-native-navigation';
import selectedCopy from '../../../../../../i18n/copy';
import { testProperties } from '../../../../../../helpers/testProperties';
import LoaderContainer from 'components/common/LoaderContainer';

const copy =
  selectedCopy.components.modules.Account.flows.Payments.AddMethod.components
    .AvailableCardsList;

const cardIcon = require('../../../../../../../assets/images/icon-credit-card-big.png');

const AvailableCardsList = (props) => {
  const navigateToAddNewMethod = () => {
    navigateTo('Skiply.Account.Payments.AddMethod', props.componentId);
  };
  const navigateToCard = (card) => {
    navigateTo('Skiply.Account.Payments.EditMethod', props.componentId, {
      card
    });
  };

  const cards = useStore((state) => state.cards);
  console.log('cards', cards);

  const fetchCards = useActions((actions) => {
    return actions.cards.fetchCards;
  });

  useEffect(() => {
    fetchCards();
  }, []);

  return (
    <LoaderContainer isLoading={cards.isLoading}>
      {cards.items.length > 0 ? (
        <Container>
          <ListContainer>
            <FlatList
              data={cards.items}
              keyExtractor={(item, id) => item.id}
              renderItem={({ item }) => (
                <IconAndTextListItem
                  listItemText={item.alias}
                  maskedPan={item.maskedPan}
                  imageUrl={item.imageUrl}
                  isDefault={item.isDefault}
                  onPress={() => {
                    navigateToCard(item);
                  }}
                />
              )}
              ItemSeparatorComponent={() => <ThinLine />}
            />
          </ListContainer>
          {cards.errorMessage.length > 0 ? (
            <Text>{cards.errorMessage}</Text>
          ) : null}
          {cards.items.length >= 5 && (
            <ErrorMessageContainer
              {...testProperties('available-card-list-error-message-container')}
            >
              <ErrorMessage>{copy.errorMessage}</ErrorMessage>
            </ErrorMessageContainer>
          )}
        </Container>
      ) : (
        <EmptyContainer>
          <EmptyIcon source={cardIcon} resizeMode='contain' />
          <EmptyText>No cards found</EmptyText>
          <EmptySubtitle>
            You haven't added any cards yet. Otherwise your cards will appear
            here.
          </EmptySubtitle>
        </EmptyContainer>
      )}
      <ButtonContainer>
        <Button
          onPress={navigateToAddNewMethod}
          secondary={cards.items.length < 5}
          error={cards.items.length >= 5}
          disabled={cards.items.length >= 5}
        >
          {copy.addNewCard}
        </Button>
      </ButtonContainer>
    </LoaderContainer>
  );
};

export default AvailableCardsList;

const Container = styled.View`
  flex: 1;
`;

const EmptyContainer = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
`;

const EmptyText = styled.Text`
  color: #0d1943;
  font-size: 16px;
  font-weight: bold;
  font-family: 'OpenSans-Bold';
  text-align: center;
  margin: 0 40px;
`;

const EmptySubtitle = styled.Text`
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  line-height: 18px;
  text-align: center;
  color: #0d1943;
  margin: 5px 40px 0 40px;
`;

const ListContainer = styled.View`
  flex: 1;
`;

const ErrorMessageContainer = styled.View`
  justify-content: center;
  align-items: center;
  margin: 0 60px 10px 60px;
`;

const ErrorMessage = styled.Text`
  color: #d9363b;
  text-align: center;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  font-size: 12px;
  line-height: 16px;
`;

const ButtonContainer = styled.View`
  margin: 0 20px;
`;

const EmptyIcon = styled.Image`
  height: 121px;
  width: 108px;
`;

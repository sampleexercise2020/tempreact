import React, { useState, useRef, useEffect } from 'react';
import { Platform, Alert } from 'react-native';
import { useActions, useStoreState } from 'easy-peasy';
import styled from 'styled-components/native';
import R from 'ramda';
import RadioButton from '/components/common/RadioButton/RadioButton';
import Button from '/components/common/Button/Button';
import FormInput from '/components/common/Input/FormInput';
import { Formik } from 'formik';
import * as yup from 'yup';
import selectedCopy from '../../../../../i18n/copy';
import { Navigation } from 'react-native-navigation';
import { testProperties } from '../../../../../helpers/testProperties';
import CardScanner from 'components/common/CardScanner';
import { useStoreActions } from 'easy-peasy';

const copy =
  selectedCopy.components.modules.Account.flows.Payments.AddMethod.index;

const AddCardSchema = yup.object().shape({
  name: yup
    .string()
    .required(copy.nameRequired)
    .matches(
      /^[a-zA-Z\s]+$/,
      'You cannot add numbers or special characters in cardholder name.'
    ),
  pan: yup
    .number()
    .required(copy.panRequired)
    .min(19, copy.panMin),
  expDate: yup
    .string()
    .ensure()
    .required(copy.panDateRequired)
    .test('test-name', 'Please enter a valid expiry date.', function(value) {
      console.log('value', value);
      if (value == undefined || value == '') {
        return true;
      } else {
        var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
        var matches = v.match(/\d{2,4}/g);
        var match = (matches && matches[0]) || '';
        var utc = parseInt(
          new Date()
            .toJSON()
            .slice(2, 4)
            .split('-')
            .join('/')
        );
        var parts = [];
        for (let i = 0; i < match.length; i += 2) {
          parts.push(match.substring(i, i + 2));
        }
        var month = parseInt(parts[0]);
        var year = parseInt(parts[1]);
        console.log('Value', value);
        console.log('Matches', matches);
        console.log('Month', month);
        console.log('Year', year);
        if (year === parts[1] && month + 1 > parts[0]) {
          return false;
        }
        if (month === 0 || value[0] >= 2 || parts[0] > 12) {
          return false;
        } else if (month <= 12 && year >= utc) {
          return true;
        } else {
          return false;
        }
      }
    }),
  alias: yup
    .string()
    .required('Please enter card nickname to continue.')
    .matches(
      /^[a-zA-Z0-9\s]+$/,
      'Only letters and numbers are allowed in nickname field.'
    ),
  isAmountChargedValidated: yup
    .bool()
    .oneOf([true], 'Please accept the terms to continue.')
});

const formatCardString = (value) => {
  var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
  var matches = v.match(/\d{4,16}/g);
  var match = (matches && matches[0]) || '';
  var parts = [];

  for (i = 0, len = match.length; i < len; i += 4) {
    parts.push(match.substring(i, i + 4));
  }

  if (parts.length) {
    return parts.join(' ');
  } else {
    return value;
  }
};

const formatExpiryDateString = (value) => {
  var v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
  var matches = v.match(/\d{2,4}/g);
  var match = (matches && matches[0]) || '';
  var parts = [];

  for (i = 0, len = match.length; i < len; i += 2) {
    parts.push(match.substring(i, i + 2));
  }

  if (parts.length) {
    return parts.join(' / ');
  } else {
    return value;
  }
};

const AddMethod = (props) => {
  const setShouldTakeATour = useStoreActions(
    ({ global }) => global.setShouldTakeATour
  );

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [navigationConstants, setNavigationConstants] = useState({});
  const cards = useStoreState((state) => state.cards.items);
  const isScanned = useStoreState((state) => state.cards.isScanned);
  const sessionExpire = useActions((actions) => actions.session.expire);
  const firstInput = useRef(null);
  const secondInput = useRef(null);
  const thirdInput = useRef(null);
  const fourthInput = useRef(null);
  const saveCard = useActions((actions) => actions.cards.save);

  useEffect(function componentDidMount() {
    getSetNavigationConstants();
  }, []);

  async function getSetNavigationConstants() {
    const constants = await Navigation.constants();
    setNavigationConstants(constants);
  }

  const handleSubmit = async ({
    name,
    alias,
    pan,
    isDefault,
    expDate,
    cvc
  }) => {
    setIsLoading(true);

    const expDateTuple = expDate
      .split('/')
      .map((item) => parseInt(item.trim()));

    const payload = {
      expMonth: expDateTuple[0],
      expYear: expDateTuple[1],
      name,
      pan,
      alias,
      default: isDefault
    };

    const response = await saveCard(payload);
    if (response.success) {
      await Navigation.pop(props.componentId);

      if (props.fromOnboarding) {
        setShouldTakeATour(true);
      }
    } else {
      if (response.errorCode === 'api.error.notAuthorized') {
        sessionExpire();
      } else {
        var message;
        if (response.message === 'Validation error in request data') {
          message =
            'The card details you have entered are invalid. Please re-enter valid card details.';
        } else if (response.message === 'expYear cannot be in the past;') {
          message =
            'The expiry date entered is in the past. Please enter a date in the future.';
        } else {
          message = response.message;
        }
        Alert.alert('Could not add card', message);
        setErrorMessage(response.message);
      }
    }

    setIsLoading(false);
  };

  return (
    <Formik
      initialValues={{
        name: '',
        pan: isScanned && !R.isEmpty(cards) ? cards[cards.length - 1].pan : '',
        expDate:
          isScanned && !R.isEmpty(cards) ? cards[cards.length - 1].expDate : '',
        alias: '',
        isDefault: cards.length > 0 ? false : true,
        isAmountChargedValidated: false
      }}
      onSubmit={handleSubmit}
      enableReinitialize
      validationSchema={AddCardSchema}
      validateOnBlur={false}
      validateOnChange={false}
    >
      {(props) => (
        <Container
          behavior='padding'
          enabled={Platform.OS !== 'android'}
          keyboardVerticalOffset={
            navigationConstants.topBarHeight +
            navigationConstants.statusBarHeight
          }
          {...testProperties('payments-add-method-container-id')}
        >
          <ScrollContainer keyboardShouldPersistTaps='never'>
            <ScrollContent>
              <CardScanner />
              <NickNameTitle>Enter Details</NickNameTitle>
              <FormContainer>
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label={copy.cardHolderName}
                  keyboardType='default'
                  value={props.values.name}
                  onChangeText={R.compose(
                    props.handleChange('name'),
                    (string) => string.replace(/[^a-zA-Z_ ]*$/i, '')
                  )}
                  onBlur={props.handleBlur('name')}
                  matches={/[a-zA-Z]+/}
                  maxLength={30}
                  testProperties={testProperties(
                    'payments-add-method-cardholder-name-id'
                  )}
                  returnKeyType='next'
                  onSubmitEditing={() => {
                    secondInput.current.focus();
                  }}
                  blurOnSubmit={false}
                />
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label={copy.cardNumber}
                  keyboardType='numeric'
                  returnKeyType='go'
                  maxLength={19}
                  onChangeText={(value) => {
                    if (/^[0-9\s]*$/.test(value)) {
                      props.setFieldValue('pan', formatCardString(value));
                    } else {
                      return;
                    }
                    const formattedValue = formatCardString(value);

                    if (formattedValue.length === 19) {
                      thirdInput.current.focus();
                    }
                  }}
                  onBlur={props.handleBlur('pan')}
                  value={props.values.pan}
                  testProperties={testProperties('payments-add-method-pan-id')}
                  innerRef={secondInput}
                />
                <FormInput
                  numberOfLines={1}
                  placeholder='MM / YY'
                  logo={false}
                  label={copy.cardExpiryDate}
                  keyboardType='numeric'
                  returnKeyType='go'
                  maxLength={7}
                  value={props.values.expDate}
                  onChangeText={(value) => {
                    const formattedValue = formatExpiryDateString(value);
                    props.setFieldValue(
                      'expDate',
                      formatExpiryDateString(value)
                    );

                    if (formattedValue.length === 7) {
                      fourthInput.current.focus();
                    }
                  }}
                  onBlur={props.handleBlur('expDate')}
                  testProperties={testProperties('payments-add-method-date-id')}
                  innerRef={thirdInput}
                />
              </FormContainer>
              <NickNameTitle>{copy.nickNameTitle}</NickNameTitle>
              <FormContainerNickName>
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label={copy.cardNickname}
                  keyboardType='default'
                  returnKeyType='go'
                  maxLength={15}
                  value={props.values.alias}
                  onChangeText={props.handleChange('alias')}
                  onBlur={props.handleBlur('alias')}
                  testProperties={testProperties(
                    'payments-add-method-nickname-id'
                  )}
                  innerRef={fourthInput}
                />
              </FormContainerNickName>
              <RadioContainer
                onPress={() =>
                  props.setFieldValue('isDefault', !props.values.isDefault)
                }
                testProperties={testProperties(
                  'payments-add-method-is-default-button-id'
                )}
              >
                <RadioButton
                  checked={props.values.isDefault}
                  buttonType='checkbox'
                />
                <RadioText>{copy.default}</RadioText>
              </RadioContainer>
              <RadioContainer
                onPress={() =>
                  props.setFieldValue(
                    'isAmountChargedValidated',
                    !props.values.isAmountChargedValidated
                  )
                }
                testProperties={testProperties(
                  'payments-add-method-agree-to-add-card-button-id'
                )}
              >
                <RadioButton
                  checked={props.values.isAmountChargedValidated}
                  buttonType='checkbox'
                />
                <RadioText>
                  To validate your card, an amount of up to AED 0.10 will be
                  charged which would be automatically refunded.
                </RadioText>
              </RadioContainer>
            </ScrollContent>
          </ScrollContainer>
          <ButtonContainer
            elevation={5}
            style={{
              shadowColor: '#000',
              shadowOffset: {
                width: 0,
                height: 7
              },
              shadowOpacity: 0.43,
              shadowRadius: 9.51,

              elevation: 15
            }}
          >
            <ErrorMessageContainer
              {...testProperties('add-method-error-message-container')}
            >
              {props.errors.name && (
                <ErrorMessage>{props.errors.name}</ErrorMessage>
              )}
              {props.errors.pan && (
                <ErrorMessage>{props.errors.pan}</ErrorMessage>
              )}
              {props.errors.expDate && (
                <ErrorMessage>{props.errors.expDate}</ErrorMessage>
              )}
              {props.errors.alias && (
                <ErrorMessage>{props.errors.alias}</ErrorMessage>
              )}
              {props.errors.isAmountChargedValidated && (
                <ErrorMessage>
                  {props.errors.isAmountChargedValidated}
                </ErrorMessage>
              )}
            </ErrorMessageContainer>
            <Button
              primary={!isLoading}
              disabled={isLoading}
              isLoading={isLoading}
              onPress={props.handleSubmit}
              testProperties={testProperties(
                'payments-add-method-handle-submit-button-id'
              )}
            >
              {copy.Save}
            </Button>
          </ButtonContainer>
        </Container>
      )}
    </Formik>
  );
};

export default AddMethod;

const Container = styled.KeyboardAvoidingView`
  flex: 1;
`;

const ScrollContainer = styled.ScrollView`
  flex: 1;
`;

const ScrollContent = styled.View`
  padding: 20px 0;
`;

const RadioContainer = styled.TouchableOpacity`
  display: flex;
  flex-direction: row;
  margin: 0 20px 20px 20px;
  align-items: center;
  border: 1px solid transparent;
`;

const RadioText = styled.Text`
  margin: 0 20px;
  color: #36235e;
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
`;

const FormContainer = styled.View`
  margin: 0px 20px 20px 20px;
  background-color: #f5f5f7;
  padding: 15px;
  padding-bottom: 5px;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
`;

const FormContainerNickName = styled.View`
  margin: 0px 20px 20px 20px;
  background-color: #f5f5f7;
  padding: 15px;
  padding-bottom: 5px;
  border-radius: 4px;
`;

const NickNameTitle = styled.Text`
  margin-bottom: 20px;
  margin-left: 20px;
  margin-top: 10px;
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  font-weight: bold;
  color: #0d1943;
`;

const ErrorMessageContainer = styled.View`
  justify-content: center;
  align-items: center;
  padding-bottom: 10px;
`;

const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  font-weight: normal;
  margin-bottom: 5px;
`;

const ButtonContainer = styled.View`
  padding: 10px 20px 20px;
  background: #ffffff;
`;

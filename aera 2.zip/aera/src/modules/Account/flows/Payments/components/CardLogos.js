import React from 'react';
import styled from 'styled-components/native';

//TODO: ändra så att man kan byta ut loggorna, just nu bara som boolean angående payment buttons.

const CardLogos = ({ image, right }) => {
  return (
    <Container>
      <Logos source={image} right={right} />
    </Container>
  );
};

export default CardLogos;

const Container = styled.View`
  position: absolute;
  margin-right: 18px;
  right: ${(props) => (props.right ? 10 : 0)};
`;

const Logos = styled.Image`
  right: ${(props) => (props.right ? 10 : 0)};
`;

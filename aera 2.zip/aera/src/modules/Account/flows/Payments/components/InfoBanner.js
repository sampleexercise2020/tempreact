import React from 'react';
import styled from 'styled-components/native';
import CardLogos from './CardLogos';

//TODO: ändra så att man kan byta ut loggorna, just nu bara som boolean angående payment buttons.

const InfoBanner = ({ label }) => {
  return (
    <Container>
      <Label>{label}</Label>
      <CardLogos
        right={true}
        image={require('../../../../../../assets/icons/payment/card-logos.png')}
      />
    </Container>
  );
};

export default InfoBanner;

const Container = styled.View`
  margin-left: 20px;
  margin-top: 20px;
  margin-right: 20px;
  padding-top: 13px;
  padding-bottom: 13px;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
  background-color: #edeef1;
  display: flex;
  flex-direction: row;
  align-items: center;
`;

const Label = styled.Text`
  margin-left: 15px;
  color: ${(props) => props.theme.color.brandDark};
  font-weight: bold;
`;

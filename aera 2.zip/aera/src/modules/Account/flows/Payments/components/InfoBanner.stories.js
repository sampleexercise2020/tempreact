import React from 'react';
import { storiesOf } from '@storybook/react-native';
import InfoBanner from './InfoBanner';
import en from '../../../../../i18n/en';

storiesOf('Components|InfoBanner', module).add('Info banner', () => (
  <InfoBanner
    label={
      en.components.modules.Account.flows.Payments.AddMethod.components
        .InfoBannerStories
    }
  />
));

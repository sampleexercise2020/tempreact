export const TermsAndConditionList = [
  {
    key: '1',
    title: 'Changes to these Terms and Conditions',
    body: `RAKBANK reserves the right to change, amend or update these Terms and Conditions at any time and at its sole discretion and shall endeavor to notify you of such changes. If you continue to use the Application after such changes to these Terms and Conditions, you will be deemed to have unconditionally agreed to the amended Terms and Conditions.`
  },
  {
    key: '2',
    title: 'Continuance of Terms',
    body: `These Terms and Conditions, as amended, will remain in full force and effect while you use the Application. Even after you have deleted the Application or RAKBANK has terminated or suspended the license granted to you below, the balance of these Terms and Conditions will remain binding on you. RAKBANK reserves the right to amend or change the Application or its content in any way or suspend, terminate or withdraw the Application or your use of the Application at any time at its sole discretion and without having to assign any reason.`
  },
  {
    key: '3',
    title: 'Privacy',
    body: `RAKBANK recognizes the importance of respecting the privacy of those who visit its websites and use its applications. The RAKBANK Privacy Policy (https://rakbank.ae/wps/portal/footer/privacy-policy) provides a description of how RAKBANK collects, uses, shares and protects personal information of its users, as well as the choices and access rights users have in regards to such personal information in connection with Skiply. You are advised to carefully review the Privacy Policy.`
  },
  {
    key: '4',
    title: 'Setting up Your Skiply Account',
    body: `You may register for Skiply by providing RAKBANK with the information set forth on the Skiply registration pages, including a valid email address and mobile phone number, sign-in message, and password. You may then store payment information (card nickname, cardholder name, card number, expiration date, and security code), billing information and other information for your credit or debit cards (each a “Card”) for card-on-file payment via Skiply along with other information indicated on the Skiply registration page. All of the information for your Card and related information are collectively referred to as your “Payment Information”.`
  },
  {
    key: '5',
    title: 'Protecting Your Information',
    body: `You are responsible for keeping your Skiply password secure and for all activities that occur through Skiply, including the activities of others and regardless of whether such activities are authorized. You agree to immediately notify RAKBANK of any breach or unauthorized use of your Skiply account. RAKBANK reserves the right to require you to change your password(s) if RAKBANK believes your password(s) is no longer secure. Neither RAKBANK nor its agents will be liable for any loss or damages of any kind that may arise as a result of the unauthorized use of your Skiply account or any Payment Information, either with or without your knowledge; however, you shall be liable for any losses incurred by RAKBANK or another party due to someone else using your Skiply account or Payment Information.`
  },
  {
    key: '6',
    title: 'Updating Your Information',
    body: `You are solely responsible for maintaining up-to-date and accurate information pertaining to your Skiply Account, including without limitation all Payment Information. RAKBANK DOES NOT REPRESENT OR WARRANT THE AUTHENTICITY, VALIDITY, ACCURACY OR COMPLETENESS OF THE PAYMENT INFORMATION RAKBANK TRANSMITS ON YOUR BEHALF.`
  },
  {
    key: '7',
    title: 'Purchases',
    body: `Skiply is an application through which you may pay, order and purchase products or services through your browser and/or your mobile device from Skiply Merchants for collection or delivery from a physical location. When you make a payment within Skiply, your purchase becomes non-reversible by you and RAKBANK will transmit your selected Payment Information from your Skiply account to the Skiply Merchant from which you are making your purchase. After the Skiply Merchant receives your Payment Information, it will submit the transaction for processing. Each transaction is a contractual relationship directly between you and the Skiply Merchant and is non-refundable by RAKBANK. RAKBANK is not involved in processing your transaction and has no liability to you with respect to such transaction or the Skiply Merchant. RAKBANK is not responsible for the products or services that may be offered or obtained through Skiply or for the accuracy, completeness, or reliability of any information obtained through Skiply with respect to such products, services or the Skiply Merchant.`
  },
  {
    key: '8',
    title: 'Representation and Warranty',
    body: `RAKBANK DOES NOT REPRESENT OR WARRANT THAT THE DESCRIPTIONS OR TERMS AND CONDITIONS OF PRODUCTS OR SERVICES OFFERED BY A SKIPLY MERCHANT FOR PURCHASE THROUGH SKIPLY ARE ACCURATE OR COMPLETE.`
  },
  {
    key: '9',
    title: 'Payment',
    body: `By using Skiply to purchase products or services from a Skiply Merchant, you hereby authorize RAKBANK to charge the payment instrument you selected to use for that transaction (“Payment Instrument”). This charge will appear on your Payment Instrument’s statement identified as a charge by the Skiply Merchant. You may receive a digital transaction receipt from the Skiply Merchant, which will be accessible through Skiply on your mobile device; provided however, that RAKBANK is under no obligation to provide you with a receipt or other written confirmation in connection with charges made through Skiply.`
  },
  {
    key: '10',
    title: 'Use of Your Payment Information',
    body: `You are solely responsible for ensuring your use of Skiply complies with the terms and conditions that govern your Cards that you store in and use through your Skiply account. You also are responsible for all charges and/or debits to your Cards that result from transactions made using your Payment Information transmitted by Skiply, and any fees that the issuers of your Cards may charge in connection with such transactions. You are solely responsible for reporting and paying any applicable taxes arising from transactions originated using your Payment Information transmitted by Skiply and you shall be liable to comply with any and all applicable tax laws in connection therewith.Any and all questions or issues regarding any of your Cards should be directed to the bank or financial institution that issued your Card. TO THE EXTENT THE CARDS ARE NOT ISSUED BY RAKBANK, RAKBANK MAKES NO REPRESENTATIONS THAT YOUR CARDS ARE VALID OR IN GOOD STANDING OR THAT THE PARTIES WHO ISSUED YOUR CARDS WILL APPROVE OR HONOR YOUR REQUESTED TRANSACTIONS.`
  },
  {
    key: '11',
    title: 'Resolution of Transaction Issues',
    body: `If you have any concerns with respect to any transaction made using Skiply, you must contact the Skiply Merchant with which you entered into that transaction.`
  },
  {
    key: '12',
    title: 'Modifications to Skiply',
    body: `While RAKBANK currently makes Skiply available free of charge, RAKBANK may in the future charge for Skiply (or additional features or functionality) at any time, in its sole discretion. RAKBANK may also discontinue, modify or change Skiply, or RAKBANK’s services and systems at any time and at its sole discretion. Such changes may require you to update your Payment Information or other information related to your Skiply account in order to continue using Skiply. RAKBANK will have no liability or obligation whatsoever to you with regard to any modifications or changes it makes to Skiply or RAKBANK’s services or systems.`
  },
  {
    key: '13',
    title: 'Intellectual Property Ownership',
    body: `The Application is licensed to you in accordance with these Terms and Conditions, not sold. Except for the limited license granted under these Terms and Conditions, RAKBANK and its licensors retain all right, title and interest in and to the Application and all proprietary rights in the Application and all content set forth therein, including copyrights, patents, trademarks and trade secret rights.`
  },
  {
    key: '14',
    title: 'Grant of License',
    body: `So long as you comply with these Terms and Conditions, RAKBANK grants you a limited, nonexclusive, as-is, revocable, non-transferable license, without right of sublicense, to use the object code version of the Application solely for the purpose of making payments and purchases from Skiply Merchants.`
  },
  {
    key: '15',
    title: 'Limitations On License',
    body: `The license granted to you under these Terms and Conditions is restricted as follows:`,
    withList: [
      {
        key: '(a)',
        body:
          'Limitations on Use and Misuse: You may not gain access to or use (including, without limitation, copy or distribute) RAKBANK’s services or systems or the Application other than as permitted hereunder, or damage, disrupt, or impede the operation of RAKBANK’s services or systems.'
      },
      {
        key: '(b)',
        body:
          'Limitations on Reverse Engineering and Modification: Except as expressly permitted by these Terms and Conditions, you may not reverse engineer, decompile, disassemble, modify or create works derivative of the Application or any content set forth therein.'
      },
      {
        key: '(c)',
        body:
          'Sublicense, Rental and Third Party Use: You may not assign, sub-license, rent, timeshare, loan, lease or otherwise transfer the Application, your Skiply account, or directly or indirectly permit any third party to use or copy the Application or your Skiply account.'
      },
      {
        key: '(d)',
        body:
          'Proprietary Notices: You may not remove any proprietary notices (e.g., copyright or trade mark notices) from the Application.'
      },
      {
        key: '(e)',
        body:
          'Use in Accordance with Documentation: All use of the Application must be in accordance with its then current documentation.'
      }
    ]
  },
  {
    key: '16',
    title: 'Compliance with Applicable Laws',
    body: `You are solely responsible for ensuring your use of the Application is in compliance with all applicable laws, rules and regulations. Capacity. You must be lawfully able to enter into contracts. You are solely responsible for evaluating and selecting the goods and services which you order and purchase using the Application. All such goods and services are sold or licensed or provided solely by the Skiply Merchant who offers the relevant goods and/or services for sale or affiliates, agents or sub-contractors of such Skiply Merchant, not RAKBANK, under such terms and conditions as determined by such vendors and, to the fullest extent permitted by law, RAKBANK has no liability whatsoever in connection with such goods or services.`
  },
  {
    key: '17',
    title: 'Personal Information',
    body: `To the extent you use the Application to provide personal information or data about yourself or other individuals (for example, your child), as may be requested by the Skiply Merchant offering the goods and/or services in connection with which such information is being requested, you must be able to lawfully (a) provide such information and data, and (b) consent to its processing and usage by RAKBANK for any purpose whatsoever including for marketing related activities and by the Skiply Merchant in connection with such goods and/or services (including, for the avoidance of doubt, RAKBANK providing or making such information and data available to the Skiply Merchant for such purposes). You are solely responsible for the information and data you provide through the Application. All such information and data will be provided to the Skiply Merchant offering the relevant goods and/or services in connection with which such information or data is being requested, and will be used by that Skiply Merchant or by the affiliates, agents or sub-contractors of that Skiply Merchant, under such terms and conditions as determined by such vendors and, to the fullest extent permitted by law, RAKBANK has no liability whatsoever in connection with the use of such information and data by such Skiply Merchant or the affiliates, agents or sub-contractors of such Skiply Merchant.`
  },
  {
    key: '18',
    title: 'Termination',
    body: `Termination: Your right and license to use the Application will automatically terminate in the event you breach these Terms and Conditions. RAKBANK reserves the right to immediately suspend, terminate or withdraw the Application or your use of the Application at any time at its sole discretion without notice and without having to assign any reason.`
  },
  {
    key: '19',
    title: 'Location-Enabled Features',
    body: `Certain location-enabled functionality and information may be made available in the Application. You must exercise your own judgment as to the adequacy and appropriateness of the information. To the extent permitted by law, all location-based information is provided entirely "as is" without warranties of any kind.`
  },
  {
    key: '20',
    title: 'Warranty Disclaimer',
    body: `The Application and all content therein is made available to you by RAKBANK on an "as available", "as is" basis. RAKBANK makes no representations or warranties, express or implied, whatsoever with respect to the availability, performance, security, characteristics or operation of the Application.`
  },
  {
    key: '21',
    title: 'Third Parties',
    body: `Your wireless carrier, the manufacturer and retailer of your mobile device, the developer of the operating system for your mobile device, and the operator of any application store or similar service through which you obtain the Application (collectively, the "Third Parties") do not own and are not responsible for the Application. You acknowledge and agree that: (i) the Third Parties have no responsibility whatsoever to furnish any maintenance and support services with respect to the Application; (ii) in the event of any failure of the Application to conform to any applicable warranty, you may notify the Third Parties and the Third Parties will refund the purchase price (if any) you paid for the Application; (iii) to the maximum extent permitted by applicable law, the Third Parties will have no other warranty obligation whatsoever with respect to the Application, and the Third Parties are not be responsibility for any other claims, losses, liabilities, damages, costs or expenses attributable to any failure to conform to any warranty; (iv) the Third Parties are not responsible for addressing any claims that you or any third party make relating to the Application or your possession and/or use of the Application including: (A) product liability claims; (B) any claim that the Application fails to conform to any applicable legal or regulatory requirement; and (C) claims arising under consumer protection or similar legislation; (v) the Third Parties will have no responsibility whatsoever for the investigation, defense, settlement or discharge of any third party claim that the Application infringes that third party's intellectual property rights; (vi) you will comply with any relevant third party terms of agreement when using the Application; and (vii) the Third Parties and their subsidiaries are third party beneficiaries of these. Terms and Conditions and each of the Third Parties will have the right (and will be deemed to have accepted the right) as a third party beneficiary to enforce these Terms and Conditions against you.`
  },
  {
    key: '22',
    title: 'Third Party Content',
    body: `The Application may contain third party content ("Third Party Content") and links to third party sites (“Third Party Sites”) that are completely independent of the Application and not owned or controlled by RAKBANK. Third Party Content and links to Third Party Sites are included solely for the convenience of users and do not constitute any approval, endorsement or warranty by RAKBANK. RAKBANK is not responsible for the content, security, operation, or use of any Third Party Content or Third Party Sites, or the products or services that may be offered or obtained through them or for the accuracy, completeness, or reliability of any information obtained from any Third Party Content or Third Party Sites. When you click on a link to a Third Party Site, you will leave the services controlled by RAKBANK. Any personal information you submit after you leave the Application will not be collected or controlled by RAKBANK. It will be subject to the privacy notice or terms of use applicable to the Third Party Site. It is your responsibility to review those policies before submitted your information to the Third Party Site and you provide your information at your own risk. You expressly relieve RAKBANK from any and all loss, damages or other liabilities you incur as a result of your ACCESS TO OR use of any THIRD PARTY SITE.`
  },
  {
    key: '23',
    title: 'Sanctions',
    body: `RAKBANK at all times will comply with UN, EU, US, UKHMT, UAE and Arab league (“Sanctions Authority”) sanctions. You represent and warrant that: (i) you are not located in a country that is subject to an embargo, or that has been designated by any Sanctions Authority as a "terrorist supporting" country; and (ii) you are not listed on any list of prohibited or restricted parties issued by any Sanctions Authority.`
  },
  {
    key: '24',
    title: 'Contacts',
    body: `RAKBANK is solely responsible for addressing any questions, comments or claims relating to the Application and your use of the Application. If you have any comments, questions or complaints relating to the Application, please contact us by sending an e-mail to: contactus@skiply.ae`
  },
  {
    key: '25',
    title: 'Limitation Of Liability',
    body: `To the fullest extent permitted by law, in no event will RAKBANK or its suppliers/licensors be liable to you or any third party for any special, incidental, consequential, punitive, or indirect damages (whether in contract, tort (including negligence), or otherwise) or any lost profits, lost data or business interruption, arising in connection with the use or inability to use the Application, even if RAKBANK has been advised of the possibility of such damages.RAKBANK will not be responsible or liable (whether in contract or otherwise) for any (i) interruption of business; (ii) access delays to, access interruptions to, suspension of or discontinuation of the Application; (iii) data non-delivery, mis-delivery, corruption, destruction or other modification; (iv) use or misuse of personal information or data by any Skiply Merchant; (v) loss or damages of any sort incurred as a result of dealings with the Application; (vi) viruses, system failures or malfunctions which may occur in connection with your use of the Application; (vi) any inaccuracies or omissions in content; or (viii) events beyond RAKBANK's reasonable control; andyou are solely responsible for your use of the Application and RAKBANK will not be liable for any loss or damage you incur which is caused by your use of the Application in breach of these Terms and Conditions or due to your fault or negligence.`
  },
  {
    key: '26',
    title: 'Governing Law and Jurisdiction',
    body: `These Terms and Conditions shall be governed by and construed in accordance with the Federal laws of the United Arab Emirates as applied by the Courts of the Emirate of Dubai, as applicable from time to time. You and RAKBANK hereby irrevocably submit to the exclusive jurisdiction of the courts in the United Arab Emirates to hear and determine any suit, action or proceeding and to settle any disputes which may arise out of or in connection with these Terms and Conditions, its performance or subject matter.`
  },
  {
    key: '27',
    title: 'General',
    body: `These Terms and Conditions constitute the entire understanding and agreement between RAKBANK and you with respect to the transactions contemplated in these Terms and Conditions and supersedes all prior or contemporaneous oral or written communications with respect to the subject matter of these Terms and Conditions. In the event any provision of these Terms and Conditions is found invalid or unenforceable pursuant to judicial decree, the remainder of these Terms and Conditions will remain valid and enforceable according to its terms. Any failure by RAKBANK to strictly enforce any provision of these Terms and Conditions will not operate as a waiver of that provision or any subsequent breach of that provision. The disclaimers and limitations of liability will survive any termination or expiration of your right to use the Application.`
  }
];

import React, { useEffect } from 'react';
import { Linking } from 'react-native';
import styled from 'styled-components/native';
import Button from 'components/common/Button/Button';

const Contact = ({ componentId }) => {
  function openEmail() {
    Linking.openURL('mailto:contactus@skiply.ae').catch((err) =>
      console.error('An error occurred', err)
    );
  }

  return (
    <Container>
      <Title>
        We are here to simplify your life. Facing any issue with Skiply? We're
        eager to help.
      </Title>
      <Title>
        Please get in touch with us on the below id and we will try and resolve
        your concerns as soon as we can.
      </Title>
      <EmailText>contactus@skiply.ae</EmailText>
      <Button primary onPress={openEmail}>
        Go to e-mail
      </Button>
    </Container>
  );
};

export default Contact;

const Container = styled.View`
  flex: 1;
  margin: 20px;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Regular';
  text-align: center;
  margin: 30px 30px 10px 30px;
`;

const EmailText = styled.Text`
  margin: 5px 30px 50px 30px;
  text-align: center;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
`;

import React from 'react';
import styled from 'styled-components/native';
import { PolicyParagraphs } from './PolicyParagraphs';

const PolicyList = ({ key, title, body }) => (
  <PolicyItem>
    <TitleContainer>
      <Number>{key}.</Number>
      <ParagraphHeader>{title}</ParagraphHeader>
    </TitleContainer>
    <PolicyBody>
      <Paragraph>{body}</Paragraph>
    </PolicyBody>
  </PolicyItem>
);

const Policy = () => {
  return (
    <Container>
      <PolicyWrapper>{PolicyParagraphs.map(PolicyList)}</PolicyWrapper>
    </Container>
  );
};

export default Policy;

const Container = styled.ScrollView`
  flex: 1;
`;

const PolicyWrapper = styled.View`
  padding: 30px 20px 20px 20px;
`;

const PolicyItem = styled.View`
  margin-bottom: 20px;
`;

const PolicyBody = styled.View``;

const Paragraph = styled.Text`
  padding-left: 20px;
`;

const ParagraphHeader = styled.Text`
  font-family: TeshrinAR-Bold;
`;

const Number = styled.Text`
  font-family: TeshrinAR-Bold;
  width: 20px;
  flex-direction: row;
`;

const TitleContainer = styled.View`
  flex-direction: row;
  margin-bottom: 3px;
  padding-right: 20px;
`;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import ChangePassword from './ChangePassword/';
import Account from './Account/';
import EditProfile from './EditProfile/';
import Profile from './Profile/';

// TODO: Get notes working.

storiesOf('Modules|Account/Profile', module)
  .add('Change Password', () => <ChangePassword />)
  .add('Account', () => <Account />)
  .add('EditProfile', () => <EditProfile />)
  .add('Profile', () => <Profile />);

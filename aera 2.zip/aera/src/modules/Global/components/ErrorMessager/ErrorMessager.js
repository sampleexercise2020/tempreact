import React from 'react';
import styled from 'styled-components/native';
import Button from 'components/common/Button/Button';
import { popToRoot } from 'navigation';

const ErrorMessager = (props) => {
  function navigateToHome() {
    popToRoot(props.componentId);
  }

  return (
    <Container>
      <ContentWrapper>
        <Content>
          <Title>Something went wrong</Title>
          <Body>Our developers have been notified.</Body>
        </Content>
      </ContentWrapper>
      <Footer>
        <Button onPress={navigateToHome} secondary>
          Start over
        </Button>
      </Footer>
    </Container>
  );
};

const Container = styled.View`
  flex: 1;
  justify-content: space-between;
`;

const ContentWrapper = styled.View`
  margin-bottom: 20px;
  justify-content: center;
  align-items: center;
  flex-grow: 1;
`;

const Content = styled.View`
  margin-bottom: 20px;
`;

const Footer = styled.View`
  width: 100%;
  padding: 0 20px 20px;
`;

const Title = styled.Text`
  color: rgb(13, 25, 67);
  font-size: 24px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  letter-spacing: 0px;
  line-height: 40px;
  margin-bottom: 4px;
`;

const Body = styled.Text`
  color: rgb(13, 25, 67);
  font-size: 12px;
  font-family: OpenSans-SemiBold;
  font-weight: 600;
  text-align: center;
  letter-spacing: 0px;
  line-height: 16px;
  padding: 0 20px;
`;

export default ErrorMessager;

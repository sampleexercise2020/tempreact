import React, { useState, useEffect } from 'react';
import { TouchableOpacity, Text } from 'react-native';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components/native';
import { Headline } from 'components/common/Typography';
import R from 'ramda';

import ListItem from './ListItem';

const SchoolList = ({ sections, title, sendDataToParent }) => {
  const [selected, setSelected] = useState(null);

  const checkSelected = (item) => {
    return item === selected;
  };

  useEffect(() => {
    sendDataToParent(selected);
  }, [selected]);

  const StickyHeader = ({ section }) => {
    if (section.type == 'listHeader') {
      return (
        <ListHeader>
          <Headline h5>{section.title}</Headline>
        </ListHeader>
      );
    } else if (section.type == 'sectionHeader') {
      return (
        <SectionHeaderContainer>
          <SectionHeader>
            <Text>{section.title}</Text>
          </SectionHeader>
        </SectionHeaderContainer>
      );
    }
  };

  const renderItem = ({ item }) => {
    return (
      <TouchableOpacity key={item.id} onPress={() => setSelected(item)}>
        <ListItem
          title={item.name}
          address={item.outlets ? item.outlets[0].address : item.address}
          checked={checkSelected(item)}
          imageUrl={item.icon}
        />
      </TouchableOpacity>
    );
  };

  return (
    <Container>
      <List
        sections={sections}
        renderItem={renderItem}
        renderSectionHeader={StickyHeader}
        keyExtractor={(item) => item.id}
      />
    </Container>
  );
};

SchoolList.propTypes = {
  title: PropTypes.string.isRequired,
  sections: PropTypes.array.isRequired
};

const Container = styled.View`
  flex: 1;
`;

const ListHeader = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin: 0 20px 12px;
  background-color: #ffffff;
  padding-bottom: 6px;
  margin-bottom: 6px;
  padding-top: 20px;
`;

const List = styled.SectionList`
  margin-bottom: 0px;
`;

const SectionHeaderContainer = styled.View`
  padding: 6px 20px 0;
`;

const SectionHeader = styled.View`
  justify-content: center;
  align-items: center;
  background: rgb(245, 245, 247);
  height: 20px;
  border-radius: 2px;
  font-size: 12px;
`;

export default SchoolList;

import VerifyStudent from './VerifyStudent';

export default VerifyStudent;

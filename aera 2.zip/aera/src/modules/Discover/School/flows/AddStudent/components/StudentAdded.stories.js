import React from 'react';
import { storiesOf } from '@storybook/react-native';
import StudentAdded from './StudentAdded';

storiesOf('Modules|Discover/School/AddStudent', module).add(
  'Student Added',
  () => <StudentAdded studentFirstname='Sarah' />
);

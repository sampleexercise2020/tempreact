import React from 'react';
import { storiesOf } from '@storybook/react-native';
import NotCorrectStudent from './NotCorrectStudent';

storiesOf('Modules|Discover/School/AddStudent', module).add(
  'Not correct student',
  () => <NotCorrectStudent />
);

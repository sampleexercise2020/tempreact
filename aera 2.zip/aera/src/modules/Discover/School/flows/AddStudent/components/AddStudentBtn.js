import React from 'react';
import styled, { css } from 'styled-components/native';

import selectedCopy from '../../../../../../i18n/copy';

const copy =
  selectedCopy.components.modules.Discover.School.flows.AddStudent.components
    .AddStudentBtn;

const PlusIcon = require('src/../../assets/images/picker_plus.png');

const AddStudentBtn = ({ onPress }) => {
  return (
    <Container onPress={onPress}>
      <ImgContainer>
        <Increment source={PlusIcon} />
      </ImgContainer>
      <AddBtnText>{copy.addStudent}</AddBtnText>
    </Container>
  );
};

const Container = styled.TouchableOpacity`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin-top: 5px;
  margin-bottom: 35px;
`;

const AddBtnText = styled.Text`
  color: rgb(64, 44, 168);
  font-family: OpenSans-SemiBold;
  font-size: 14px;
`;

const ImgContainer = styled.View`
  background-color: #f5f5f7;
  height: 30px;
  width: 30px;
  margin-right: 10px;
  border-radius: 15px;
  justify-content: center;
  align-items: center;
`;

const Increment = styled.Image`
  height: 14px;
  width: 14px;
`;

export default AddStudentBtn;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import AddStudentManually from './AddStudentManually';
import FindStudentById from './FindStudentById';
import SearchSchool from './SearchSchool';
import StudentFound from './StudentFound';
import StudentResults from './StudentResults';

// TODO: Get notes working.

storiesOf('Modules|Discover/School/AddStudent', module)
  .add('Add Student Manually', () => <AddStudentManually />)
  .add('Find Student By Id', () => <FindStudentById />)
  .add('Search School', () => <SearchSchool />)
  .add('Student Found', () => <StudentFound />);

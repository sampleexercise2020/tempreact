import React from 'react';
import { View, Text } from 'react-native';
import styled, { css } from 'styled-components/native';
import { testProperties } from '../../../../../../helpers/testProperties';

const StudentFound = (props) => {
  return (
    <View {...testProperties('discover-studentfound-view-id')}>
      <Text>Student Found Screen</Text>
    </View>
  );
};

export default StudentFound;

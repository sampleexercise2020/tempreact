import React from 'react';
import styled from 'styled-components/native';

const Avatar = ({ small, image }) => {
  return (
    <Container small={small}>
      <WhiteStroke small={small}>
        <Img source={image} />
      </WhiteStroke>
    </Container>
  );
};

export default Avatar;

const Container = styled.View`
  height: ${(props) => (props.small ? '36px' : '44px')};
  width: ${(props) => (props.small ? '36px' : '44px')};
  border-radius: 50px;
  border-width: 2px;
  border-color: #e7e7e7;
  justify-content: center;
  align-items: center;
  overflow: hidden;
`;
const WhiteStroke = styled.View`
  height: ${(props) => (props.small ? '32px' : '40px')};
  width: ${(props) => (props.small ? '32px' : '40px')};
  border-radius: 50px;
  border-width: 2.5px;
  border-color: white;
  justify-content: center;
  align-items: center;
  overflow: hidden;
`;
const Img = styled.Image`
  width: 100%;
  height: 100%;
`;

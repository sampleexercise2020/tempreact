import React from 'react';
import { storiesOf } from '@storybook/react-native';
import SchoolHeader from './SchoolHeader';

storiesOf('Modules|Discover/School/AddStudent', module).add(
  'School Header',
  () => (
    <SchoolHeader
      schoolName='Brilliant Int School'
      schoolAddress='152 adress, Dubai'
    />
  )
);

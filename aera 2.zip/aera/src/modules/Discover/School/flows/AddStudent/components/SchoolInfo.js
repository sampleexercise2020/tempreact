import React from 'react';
import { useStore, useActions } from 'easy-peasy';
import Avatar from 'components/common/Avatar/Avatar';
import styled from 'styled-components/native';

const SchoolInfo = ({}) => {
  const school = useStore((state) => state.merchant.data.outlets[0]);
  const schoolName = useStore((state) => state.merchant.data.name);
  const schoolIcon = useStore((state) => state.merchant.data.icon);

  console.log('School ICon: ', schoolIcon);

  return (
    <Container>
      <Avatar
        isRemote={true}
        image={schoolIcon}
        smallIcon
        light
        name={schoolName}
      />
      <Information>
        <Name>{schoolName}</Name>
        <Address numberOfLines={2}>{school.address}</Address>
      </Information>
    </Container>
  );
};

export default SchoolInfo;

const Container = styled.View`
  flex-direction: row;
`;
const Information = styled.View`
  flex-direction: column;
  margin-left: 14px;
  justify-content: center;
  padding-right: 14px;
  border: 1px solid transparent;
`;
const Name = styled.Text`
  color: rgb(13, 25, 67);
  font-size: 14px;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  letter-spacing: 0px;
  line-height: 18px;
`;
const Address = styled.Text`
  color: rgb(109, 117, 142);
  font-size: 14px;
  font-family: OpenSans-Regular;
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 18px;
`;

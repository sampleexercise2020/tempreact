import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

import Button from 'components/common/Button/Button';
import { addCommaSeparator } from 'helpers/addCommaSeparator';

// TODO: Add icons.

const ProductControls = ({
  price,
  currency,
  addToCartAction,
  payNowAction,
  hidePanel
}) => {
  return (
    <Container>
      <TextContainer>
        <Total>Total: </Total>
        <Price>
          {currency} {addCommaSeparator(price)}
        </Price>
      </TextContainer>
      <Actions>
        <AddToCart>
          <Button
            primary
            bold
            onPress={() => {
              console.log('Closing panels?');
              hidePanel();
              addToCartAction();
            }}
          >
            Add to cart
          </Button>
        </AddToCart>
        <Pay>
          <Button
            bold
            onPress={() => {
              // FIXME:
              // When clicked before panel animation is done, an error occurs:
              // _onEventListener (not all the times)
              hidePanel();
              payNowAction();
            }}
          >
            Pay Now
          </Button>
        </Pay>
      </Actions>
    </Container>
  );
};

ProductControls.propTypes = {};

const Container = styled.View`
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding: 0px 3px;
`;
const TextContainer = styled.View`
  flex-direction: row;
  margin-bottom: 12px;
`;

const Total = styled.Text`
  color: rgb(13, 133, 123);
  font-size: 18px;
  font-family: 'TeshrinAR+LT-Regular';
  font-weight: normal;
  text-align: center;
  letter-spacing: 0px;
`;
const Price = styled.Text`
  color: rgb(13, 133, 123);
  font-size: 18px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: bold;
  text-align: center;
  letter-spacing: 0px;
`;

const Actions = styled.View`
  flex-direction: row;
`;
const AddToCart = styled.View`
  flex-grow: 1;
  padding: 0px 3px;
`;
const Pay = styled.View`
  flex-grow: 1;
  padding: 0px 3px;
`;

export default ProductControls;

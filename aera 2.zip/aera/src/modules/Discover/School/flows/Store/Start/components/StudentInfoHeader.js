import React from 'react';
import { useStore, useActions } from 'easy-peasy';
import { useStoreState, useStoreActions } from 'easy-peasy';
import Avatar from './Avatar';
import styled from 'styled-components/native';
import NavigationButton from 'components/common/TopBar/NavigationButton';
import R from 'ramda';
import { navigateTo } from 'navigation';

const editButton = require('../../../../../../../../assets/icons/common/edit-white.png');

const StudentInfoHeader = ({ student, showSchool, onPress, hasButton }) => {
  return (
    <Container>
      <Avatar
        image={student && student.image}
        name={student && `${student.firstName} ${student.lastName}`}
      />
      <Information>
        <Name>
          {student && student.firstName} {student && student.lastName}
        </Name>
        {showSchool ? (
          <Grade>{student && student.schoolName}</Grade>
        ) : (
          <Grade>
            {student && student.grade} {student && student.class}
          </Grade>
        )}
      </Information>
      {hasButton && <NavigationButton icon={editButton} onPress={onPress} />}
    </Container>
  );
};

export default StudentInfoHeader;

const Container = styled.View`
  flex-direction: row;
  justify-content: center;
  height: 50px;
`;
const Information = styled.View`
  flex-direction: column;
  margin-left: 14px;
  justify-content: center;
  flex: 1;
`;
const Name = styled.Text`
  color: rgb(255, 255, 255);
  font-size: 14px;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  letter-spacing: 0px;
  line-height: 18px;
`;
const Grade = styled.Text`
  color: rgb(255, 255, 255);
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 18px;
`;

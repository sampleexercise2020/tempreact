import React from 'react';
import { storiesOf } from '@storybook/react-native';

import Date from './Date';

storiesOf('Modules|Discover/School/Store/Components/Product/Date', module).add(
  'Basic',
  () => <Date date='Monday, 21 April, 2018' />
);

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import { action, configureActions } from '@storybook/addon-actions';

import OptionsList from './OptionsList';

const mockData = [
  { id: '132312', checked: false, title: 'Annual', price: 4000 },
  {
    id: '1sd12',
    title: 'Grade 5',
    price: 120
  },
  {
    id: 'asd12',
    title: 'Term 2',
    price: 99
  },
  {
    id: '1312',
    title: 'Term 53',
    price: 4000
  }
];
storiesOf(
  'Modules|Discover/School/Store/Components/Product/Option List',
  module
)
  .add('Single Choice', () => (
    <OptionsList title='Single Choice' list={mockData} type='single' />
  ))
  .add('Multi choice', () => (
    <OptionsList
      title='Multi Choice'
      list={mockData}
      type='multi'
      buttonType='checkbox'
    />
  ))
  .add('Multi choice with maximum 3 options', () => (
    <OptionsList
      title='Multi Choice'
      list={mockData}
      type='multi'
      buttonType='checkbox'
      max={3}
    />
  ));

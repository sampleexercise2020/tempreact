import React from 'react';
import Avatar from './Avatar';
import styled from 'styled-components/native';

const NavigationStudentHeader = ({ name, schoolAddress, image }) => {
  return (
    <Container>
      <Avatar image={image} small name={name} />
    </Container>
  );
};

export default NavigationStudentHeader;

const Container = styled.View`
  flex-direction: row;
  justify-content: center;
`;

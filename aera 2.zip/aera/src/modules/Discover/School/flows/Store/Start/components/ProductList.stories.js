import React, { useEffect } from 'react';
import { storiesOf } from '@storybook/react-native';
import { action, configureActions } from '@storybook/addon-actions';
import ProductList from './ProductList';

storiesOf('Modules|Discover/School/Store/Components/Category', module).add(
  'Product List',
  () => <ProductList categoryId={488509} />
);

import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

import Signature from 'components/common/Signature/Signature';

import selectedCopy from '../../../../../../../i18n/copy';

const copy =
  selectedCopy.components.modules.Discover.School.flows.Store.Start.components
    .ListItemProduct;

const ListItemProduct = ({
  title,
  shortDesc,
  image,
  requiresSignature,
  inCart
}) => {
  return (
    <Container>
      <TextContainer>
        <Title numberOfLines={1} ellipsizeMode='tail'>
          {title}
        </Title>
        <Description numberOfLines={1} ellipsizeMode='tail'>
          {shortDesc}
        </Description>
        <ViewOptions>{copy.viewOptions}</ViewOptions>
        {requiresSignature ? <Signature text={copy.signatureRequired} /> : null}
      </TextContainer>
      <ImageContainer>
        <Border>
          <Img source={{ uri: image }} />
        </Border>
      </ImageContainer>
      {inCart ? <InCartIndicator /> : null}
    </Container>
  );
};

ListItemProduct.propTypes = {
  title: PropTypes.string.isRequired,
  shortDesc: PropTypes.string.isRequired,
  image: PropTypes.string,
  requiresSignature: PropTypes.bool,
  inCart: PropTypes.bool
};

const Container = styled.View`
  position: relative;
  flex-direction: row;
  padding: 15px 20px;
  width: 100%;
  justify-content: space-between;
`;

const TextContainer = styled.View`
  flex: 1;
`;
const ImageContainer = styled.View`
  margin-left: 10px;
`;
const Border = styled.View`
  border-top-left-radius: 11px;
  border-bottom-right-radius: 11px;
  overflow: hidden;
`;

const Title = styled.Text`
  color: rgb(13, 25, 67);
  font-size: 20px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  letter-spacing: 0px;
  line-height: 28px;
  height: 28px;
`;

const Description = styled.Text`
  color: rgb(109, 117, 142);
  font-size: 16px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 22px;
  height: 22px;
  margin-bottom: 14px;
`;

const ViewOptions = styled.Text`
  height: 16px;
  color: rgb(13, 129, 119);
  font-size: 12px;
  font-family: 'OpenSans-Semibold';
  font-weight: 600;
  letter-spacing: 0px;
  line-height: 16px;
  margin-bottom: 10px;
`;

const Img = styled.Image`
  width: 80px;
  height: 80px;
  background: rebeccapurple;
  border-top-left-radius: 11px;
  border-bottom-right-radius: 11px;
  overflow: hidden;
`;

const InCartIndicator = styled.View`
  position: absolute;
  top: 0px;
  left: 0px;
  width: 4px;
  height: 28px;
  background: #0d8177;
`;

export default ListItemProduct;

import React from 'react';
import { View, Text } from 'react-native';
import styled, { css } from 'styled-components/native';
import { testProperties } from '../../../../../../helpers/testProperties';

const Confirmation = (props) => {
  return (
    <View {...testProperties('discover-store-confirmation-view-id')}>
      <Text>Confirmation Payment Store</Text>
    </View>
  );
};

export default Confirmation;

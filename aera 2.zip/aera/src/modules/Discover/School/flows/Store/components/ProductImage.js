import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

const ProductImage = ({ source }) => {
  return (
    <Container>
      <Img
        source={{
          uri: source
        }}
      />
    </Container>
  );
};

Date.propTypes = {};

const Container = styled.View`
  height: 224px;
  width: 100%;
  border-bottom-right-radius: 40px;
  overflow: hidden;
`;

const Img = styled.Image`
  width: 100%;
  height: 100%;
`;

export default ProductImage;

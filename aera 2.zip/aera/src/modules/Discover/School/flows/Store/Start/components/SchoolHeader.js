import React from 'react';
import styled from 'styled-components/native';

const SchoolHeader = ({ schoolName, schoolAddress }) => {
  return (
    <Container>
      <TextContainer>
        <SchoolName numberOfLines={1}>
          {schoolName ? schoolName : 'N/A'}
        </SchoolName>
        <SchoolAddress numberOfLines={1}>
          {schoolAddress ? schoolAddress : 'N/A'}
        </SchoolAddress>
      </TextContainer>
    </Container>
  );
};

export default SchoolHeader;

const Container = styled.View`
  display: flex;
  flex-direction: row;
  align-items: center;
  margin-bottom: 25px;
`;

const TextContainer = styled.View`
  flex-direction: column;
  max-width: 235px;
`;

const SchoolName = styled.Text`
  color: rgb(255, 255, 255);
  font-size: 20px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  letter-spacing: 0px;
  line-height: 28px;
`;

const SchoolAddress = styled.Text`
  color: rgb(255, 255, 255);
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 18px;
`;

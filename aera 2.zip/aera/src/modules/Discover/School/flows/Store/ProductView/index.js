import React, { useState, useEffect } from 'react';
import { StyleSheet, ScrollView, Platform, Text, Alert } from 'react-native';
import { Navigation } from 'react-native-navigation';
import { navigateTo } from 'navigation';
import styled from 'styled-components/native';
import CartControls from '../components/CartControls';
import LinearGradient from 'react-native-linear-gradient';
import {
  useStore,
  useActions,
  useStoreActions,
  useStoreState
} from 'easy-peasy';
import { ProductViewDivider } from 'components/common/Dividers/Dividers';
import { useFloatingBottom } from 'components/FloatingBottom';
import ProductText from '../components/ProductText';
import OptionsList from '../components/OptionsList';
import VariantList from '../components/VariantList';
import FormInput from '/components/common/Input/FormInput';
import QuantityPicker from '../components/QuantityPicker';
import Date from '../components/Date';
import ProductImage from '../components/ProductImage';
import BottomControlPanel from 'components/common/Panels/BottomControlPanel';
import Button from 'components/common/Button/Button';
import LoaderWithOverlay from 'components/common/LoaderWithOverlay';
import { testProperties } from 'helpers/testProperties';
import { addCommaSeparator } from 'helpers/addCommaSeparator';

const store = {
  currentProduct: ({ currentProduct }) => currentProduct,
  isSavingCartItem: ({ cart }) => cart.isSaving,
  addToCart: ({ currentProduct }) => currentProduct.addToCart,
  selectedVariantId: ({ currentProduct }) => currentProduct.variantId
};

const FloatingProductControls = ({ componentId, student, hasConsentForm }) => {
  const currentProduct = useStore(store.currentProduct);
  const currency = useStoreState((state) => state.merchant.currency);
  const isSavingCartItem = useStore(store.isSavingCartItem);
  const addToCartAction = useStoreActions(store.addToCart);
  const selectedVariantId = useStoreState(store.selectedVariantId);
  const [errorMessage, setErrorMessage] = useState('');

  function navigateToConsentForm(isPayNow) {
    navigateTo('Skiply.Store.Consent.Form', componentId, { student, isPayNow });
  }

  const navigateToCheckout = () => {
    return navigateTo('Skiply.Store.Checkout', componentId, { student });
  };

  function addToCart(cb) {
    return async function(isPayNow) {
      if (hasConsentForm) {
        if (
          currentProduct != undefined &&
          currentProduct.selectedOptions.length != 0
        ) {
          const customField = currentProduct.selectedOptions[0].options[0];
          if (
            customField.name === 'Enter Amount' &&
            customField.paymentAdjust == 0
          ) {
            Alert.alert(
              'Sorry!',
              'You cannot add zero value product to cart. Please select appropriate option.',
              [
                {
                  text: 'OK',
                  onPress: () => {}
                }
              ]
            );
            return;
          }
        }
        navigateToConsentForm(isPayNow);
      } else {
        console.log('Current Product =' + JSON.stringify(currentProduct));
        if (
          currentProduct != undefined &&
          currentProduct.selectedOptions.length != 0
        ) {
          const customField = currentProduct.selectedOptions[0].options[0];
          if (
            customField.name === 'Enter Amount' &&
            customField.paymentAdjust == 0
          ) {
            Alert.alert(
              'Sorry!',
              'You cannot add zero value product to cart. Please select appropriate option.',
              [
                {
                  text: 'OK',
                  onPress: () => {}
                }
              ]
            );
            return;
          }
        }
        setErrorMessage('');
        const response = await addToCartAction();

        if (response.status == 200) {
          cb();
        } else {
          if (response.message == 'Validation error in request data') {
            setErrorMessage('Please select one of the options to add in cart.');
          } else {
            setErrorMessage(response.message);
          }
        }
      }
    };
  }

  function popToList() {
    Navigation.pop(componentId);
  }

  const payNow = async () => {
    await addToCart(navigateToCheckout)({ isPayNow: true });
  };

  const addToCartHandler = async () => {
    await addToCart(popToList)({ isPayNow: false });
  };

  return (
    <PlaceAtBottom
      elevation={5}
      style={{
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 7
        },
        shadowOpacity: 0.43,
        shadowRadius: 9.51,

        elevation: 15
      }}
    >
      <BottomControlPanel
        {...testProperties('discover-store-productview-bottompanel-id')}
        text={
          <>
            <Total>Total: </Total>
            <Price>
              {' '}
              {currency} {addCommaSeparator(currentProduct.totalPrice)}
            </Price>
          </>
        }
        actions={
          <ActionsContainer>
            {errorMessage ? (
              <ErrorContainer>{errorMessage}</ErrorContainer>
            ) : null}
            <Actions>
              <Pay>
                <Button
                  testProperties={testProperties(
                    'discover-store-productview-actions-button-id'
                  )}
                  primary={!isSavingCartItem && selectedVariantId}
                  disabled={isSavingCartItem || !selectedVariantId}
                  error={errorMessage}
                  bold
                  onPress={addToCartHandler}
                >
                  Add to cart
                </Button>
              </Pay>
              <Pay>
                <Button
                  testProperties={testProperties(
                    'discover-store-productview-cancel-button-id'
                  )}
                  bold
                  onPress={payNow}
                >
                  Pay now
                </Button>
              </Pay>
            </Actions>
          </ActionsContainer>
        }
      />
    </PlaceAtBottom>
  );
};

const ProductView = ({
  category,
  setIsScrolledToTop,
  componentId,
  student
}) => {
  const currentProduct = useStore((state) => state.currentProduct);
  const isSavingCartItem = useStore(store.isSavingCartItem);
  const product = currentProduct.data;
  const singleVariantPricing = currentProduct.singleVariantPricing;

  const setSingleVariantProductDetails = useActions(
    ({ currentProduct }) => currentProduct.setSingleVariantProductDetails
  );

  const updatePurchaseNote = useStoreActions(
    (actions) => actions.currentProduct.updatePurchaseNote
  );

  const handleSingleVariantProduct = (id, price) => {
    setSingleVariantProductDetails({ id, price });
  };

  return (
    product && (
      <Container
        {...testProperties('discover-store-productview-main-container-id')}
        behavior='padding'
        enabled={Platform.OS !== 'android'}
      >
        {isSavingCartItem && <LoaderWithOverlay />}
        <ScrollView
          contentContainerStyle={styles.contentContainer}
          onScrollEndDrag={setIsScrolledToTop}
        >
          <ProductImage source={product.mediumImageUrl} />
          <ProductTopDivider />
          <ProductText
            {...testProperties('discover-store-productview-producttext-id')}
            title={product.name}
            category={category}
            shortDesc={product.smallDescription}
            longDesc={product.description}
            signature={product.form}
            signed={false}
            price={singleVariantPricing}
            product={product}
            signNowPress={() =>
              navigateTo('Skiply.Store.Consent.Form', componentId, { student })
            }
          />
          <ProductViewDivider />
          {product.variants.length > 1 ? (
            <React.Fragment key={product.variants[0].sku}>
              <VariantList
                {...testProperties('discover-store-productview-variantlist-id')}
                title={product.variants[0].variantDetails.variantLabel}
                list={product.variants}
                type='single'
                isRequired={true}
              />
              <ProductViewDivider />
            </React.Fragment>
          ) : (
            handleSingleVariantProduct(
              product.variants[0].id,
              product.variants[0].amountMinorUnits
            )
          )}
          {product.optionSets.map((list, index) => (
            <React.Fragment key={list.name}>
              <OptionsList
                {...testProperties(
                  `discover-store-productview-optionslist-${list.name}-id`
                )}
                title={list.label}
                list={list.options}
                type={list.maxSelected > 1 ? 'multi' : 'single'}
                buttonType={list.buttonType}
                min={list.minSelected}
                max={list.maxSelected}
                internalName={list.name}
                index={index}
              />
              <ProductViewDivider />
            </React.Fragment>
          ))}
          {product.allowPurchaseNote && (
            <>
              <Header>
                <Title>Delivery Address</Title>
              </Header>
              <FormContainer>
                <FormInput
                  numberOfLines={1}
                  a
                  logo={false}
                  label='Enter your address'
                  keyboardType='default'
                  returnKeyType='go'
                  maxLength={200}
                  onChangeText={(e) => updatePurchaseNote(e)}
                />
              </FormContainer>
            </>
          )}
        </ScrollView>
        <FloatingProductControls
          hasConsentForm={product.form}
          student={student}
          componentId={componentId}
        />
      </Container>
    )
  );
};

const Container = styled.KeyboardAvoidingView`
  flex: 1;
`;

const ProductTopDivider = styled.View`
  height: 30px;
`;

const PlaceAtBottom = styled.View`
  width: 100%;
  padding: 10px 20px 30px;
  background: white;
`;

const Total = styled.Text`
  color: rgb(13, 133, 123);
  font-size: 16px;
  font-family: 'TeshrinAR+LT-Regular';
  font-weight: normal;
  text-align: center;
  letter-spacing: 0px;
`;

const Price = styled.Text`
  color: rgb(13, 133, 123);
  font-size: 16px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: bold;
  text-align: center;
  letter-spacing: 0px;
`;

const Actions = styled.View`
  margin: 0 -5px;
  flex-grow: 1;
  flex-direction: row;
`;

const ActionsContainer = styled.View`
  flex: 1;
`;

const Pay = styled.View`
  flex-grow: 1;
  padding: 0 5px;
`;

const ErrorContainer = styled.Text`
  color: red;
  text-align: center;
  margin-bottom: 10px;
`;

const styles = StyleSheet.create({
  contentContainer: {
    overflow: 'hidden'
  }
});

const FormContainer = styled.View`
  background-color: #f5f5f7;
  border-radius: 4px;
  padding: 15px 15px 10px 15px;
  margin: 10px 20px;
`;

const Header = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin: 0 20px;
`;

const Title = styled.Text`
  color: #36235e;
  font-size: 20px;
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  letter-spacing: 0;
`;

export default ProductView;

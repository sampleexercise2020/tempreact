import React, { useState, useEffect } from 'react';
import { Alert, View, Text, TouchableWithoutFeedback } from 'react-native';
import { useStoreState } from 'easy-peasy';
import PropTypes from 'prop-types';
import styled, { css } from 'styled-components/native';

import Signature from 'components/common/Signature/Signature';
import { addCommaSeparator } from 'helpers/addCommaSeparator';

const ProductText = (props) => {
  const {
    title,
    category,
    shortDesc,
    longDesc,
    price,
    signature,
    signed
  } = props;
  const [readMore, setReadMore] = useState(false);

  const currency = useStoreState((state) => state.merchant.currency);

  return (
    <Container>
      <Category>{category}</Category>
      <Name>{title}</Name>
      {price ? (
        <Price>
          {currency} {addCommaSeparator(price)}
        </Price>
      ) : null}
      {signed === false ? (
        signature && signature.formRequiresSignature ? (
          <SignatureContainer>
            <Signature text='Signature required' />
          </SignatureContainer>
        ) : null
      ) : signature && signature.formRequiresSignature ? (
        <SignatureContainer>
          <Signature signed={true} text='Signature attached' />
        </SignatureContainer>
      ) : null}
      {shortDesc ? <ShortDescription>{shortDesc}</ShortDescription> : null}
      {longDesc ? (
        <TouchableWithoutFeedback
          onPress={() => {
            setReadMore(!readMore);
          }}
        >
          <LongDescription>
            {longDesc.length > 250 && readMore === false
              ? longDesc.substring(0, 250)
              : longDesc}
            {longDesc.length > 250 ? (
              readMore == false ? (
                <More> more...</More>
              ) : (
                <More> less...</More>
              )
            ) : null}
          </LongDescription>
        </TouchableWithoutFeedback>
      ) : null}
    </Container>
  );
};

ProductText.propTypes = {
  title: PropTypes.string.isRequired,
  price: PropTypes.number,
  signature: PropTypes.bool,
  category: PropTypes.string.isRequired,
  shortDesc: PropTypes.string,
  longDesc: PropTypes.string
};

const Container = styled.View`
  flex: 1;
  margin: auto 25px;
`;
const Category = styled.Text`
  opacity: 0.6;
  font-size: 16px;
  font-family: OpenSans-Regular;
  font-weight: normal;
  letter-spacing: 0;
  height: 22px;
`;
const Name = styled.Text`
  color: #30224d;
  font-size: 28px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  letter-spacing: 0px;
  line-height: 30px;
  padding: 6px 0px;
`;

const LongDescription = styled.Text`
  color: rgba(51, 51, 51, 0.8);
  font-size: 16px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  letter-spacing: -0.2px;
  line-height: 24px;
  padding-top: 6px;
`;

const ShortDescription = styled(LongDescription)`
  padding: 6px 0;
`;

const More = styled.Text`
  color: blue;
`;

const Price = styled.Text`
  color: #0d857b;
  font-size: 24px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  letter-spacing: 0;
`;

const SignatureContainer = styled.View`
  position: relative;
  flex-direction: row;
  justify-content: space-between;
  padding-top: 13px;
  margin: 20px 0;
`;

const SignNow = styled.TouchableOpacity`
  padding: 6px 8.5px;
  background: rgb(13, 133, 123);
  border-radius: 4px;
  justify-content: center;
  align-items: center;
`;

const SignNowText = styled.Text`
  color: rgb(255, 255, 255);
  font-size: 14px;
  font-family: 'OpenSans-SemiBold';
  font-weight: 600;
  text-align: center;
  letter-spacing: 0px;
  line-height: 18px;
`;

export default ProductText;

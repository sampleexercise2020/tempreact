import React, { Component } from 'react';
import { Navigation } from 'react-native-navigation';
import styled from 'styled-components';
import Button from 'components/common/Button/Button';
import { useStoreState, useStoreActions, useActions } from 'easy-peasy';
import { StyleSheet, Animated } from 'react-native';
import SignatureCapture from 'react-native-signature-capture';
import { popTo } from 'navigation';
import SignProductView from './components/SignProductView';
import TopIndicationBar from './components/TopIndicationBar';
import { testProperties } from 'helpers/testProperties';
import { navigateTo } from 'navigation';

const icon = require('../../../../../../../assets/images/sign-here-icon.png');

class Sign extends Component {
  constructor(props) {
    super(props);
    this.animation = new Animated.Value(1);

    this.state = {
      showText: true,
      isEmpty: true,
      isSavingForm: false,
      errorMessage: ''
    };
  }

  componentDidMount() {
    setTimeout(() => {
      this.setState({ showText: false });
    }, 2000);

    Animated.timing(this.animation, { toValue: 0, duration: 1300 }).start();
  }

  saveSign() {
    this.refs['sign'].saveImage();
  }

  resetSign() {
    this.refs['sign'].resetImage();
    this.setState({ isEmpty: true });
  }

  async _onSaveEvent(result) {
    this.setState({ isSavingForm: true });
    const formElements = this.props.formElements.map((formElement) => {
      if (formElement.type == 'Signature') {
        return {
          id: formElement.id,
          value: result.encoded
        };
      } else {
        return {
          id: formElement.id,
          value: formElement.value
        };
      }
    });

    const payload = {
      beneficiaryId: this.props.beneficiaryId,
      formId: this.props.formId,
      formElements
    };

    console.log('PAYLOAD:', this.props);

    const response = await this.props.saveConsentFormAction(payload);

    if (response.status == 200) {
      this.addToCart();
    } else if (response.status === 401 || response.status === 403) {
      this.props.sessionExpire();
    } else {
      this.setState({ errorMessage: response.message });
    }
  }

  navigateToCheckout() {
    navigateTo('Skiply.Store.Checkout', this.props.componentId, {
      student: this.props.student
    });
  }

  async addToCart() {
    const response = await this.props.addToCartAction();

    if (response.status === 200 && this.props.isPayNow) {
      this.navigateToCheckout();
    } else if (response.status == 200) {
      this.popToList();
    } else if (response.status === 401 || response.status === 403) {
      this.props.sessionExpire();
    } else {
      this.setState({ errorMessage: response.message });
    }
  }

  popToList() {
    Navigation.popTo(this.props.productListComponentId);
  }

  _onDragEvent() {
    this.setState({ isEmpty: false });
  }

  render() {
    return (
      <>
        <TopIndicationBar steps={2} activeStep={2} />
        <Container {...testProperties('discover-store-sign-sign-container-id')}>
          <SignProductView
            {...testProperties('discover-store-sign-sign-signproductview-id')}
            productName={this.props.productName}
            shortDesc={this.props.productDescription}
            price={this.props.productTotalPrice}
            productImg={this.props.productImageUrl}
          />
          <SignatureContainer>
            {this.state.showText ? (
              <Animated.View style={{ opacity: this.animation }}>
                <SignIconContainer>
                  <SignText>Sign here please</SignText>
                  <SignIcon source={icon} resizeMode='contain' />
                </SignIconContainer>
              </Animated.View>
            ) : (
              <SignatureCapture
                {...testProperties(
                  'discover-store-sign-sign-signaturecapture-id'
                )}
                style={styles.signatureBox}
                ref='sign'
                onSaveEvent={this._onSaveEvent.bind(this)}
                onDragEvent={this._onDragEvent.bind(this)}
                saveImageFileInExtStorage={false}
                showNativeButtons={false}
                showTitleLabel={false}
                viewMode={'portrait'}
                showBorder={false}
              />
            )}
          </SignatureContainer>
          <Container>
            {this.state.errorMessage ? (
              <ErrorContainer>{this.state.errorMessage}</ErrorContainer>
            ) : null}
            <BtnsContainer>
              <LeftBtn>
                <Button
                  {...testProperties(
                    'discover-store-sign-sign-clear-button-id'
                  )}
                  secondaryDisabled={this.state.isEmpty}
                  secondary={!this.state.isEmpty}
                  onPress={this.resetSign.bind(this)}
                >
                  Clear
                </Button>
              </LeftBtn>
              <RightBtn>
                <Button
                  {...testProperties('discover-store-sign-sign-done-button-id')}
                  disabled={this.state.isEmpty || this.state.isSavingForm}
                  isLoading={this.state.isSavingForm}
                  primary={!this.state.isEmpty}
                  onPress={this.saveSign.bind(this)}
                >
                  Done
                </Button>
              </RightBtn>
            </BtnsContainer>
          </Container>
        </Container>
      </>
    );
  }
}

const store = {
  currentProduct: ({ currentProduct }) => currentProduct.data,
  saveConsentForm: ({ currentProduct }) => currentProduct.saveConsentForm,
  productTotalPrice: ({ currentProduct }) => currentProduct.totalPrice,
  addToCart: ({ currentProduct }) => currentProduct.addToCart,
  productListComponentId: ({ currentProduct }) =>
    currentProduct.productListComponentId
};

const Wrapper = ({
  formElements,
  beneficiaryId,
  formId,
  isPayNow,
  student,
  componentId
}) => {
  const saveConsentFormAction = useStoreActions(store.saveConsentForm);
  const addToCartAction = useStoreActions(store.addToCart);
  const currentProduct = useStoreState(store.currentProduct);
  const productTotalPrice = useStoreState(store.productTotalPrice);
  const productName = currentProduct.name;
  const productDescription = currentProduct.smallDescription;
  const productImageUrl = currentProduct.mediumImageUrl;
  const productListComponentId = useStoreState(store.productListComponentId);
  const sessionExpire = useActions((actions) => actions.session.expire);

  return (
    <Sign
      currentProduct={currentProduct}
      productName={productName}
      productDescription={productDescription}
      productImageUrl={productImageUrl}
      productTotalPrice={productTotalPrice}
      formElements={formElements}
      beneficiaryId={beneficiaryId}
      formId={formId}
      productListComponentId={productListComponentId}
      saveConsentFormAction={saveConsentFormAction}
      addToCartAction={addToCartAction}
      sessionExpire={sessionExpire}
      isPayNow={isPayNow}
      student={student}
      componentId={componentId}
    />
  );
};

export default Wrapper;

const styles = StyleSheet.create({
  signatureBox: {
    flex: 1,
    borderWidth: 1,
    height: 200,
    backgroundColor: 'white'
  }
});

const Container = styled.View`
  flex: 1;
  margin: 0 20px;
`;

const Inner = styled.View`
  flex: 1;
`;

const BtnsContainer = styled.View`
  flex-direction: row;
  justify-content: space-between;
  margin-bottom: 20px;
`;

const LeftBtn = styled.View`
  width: 50%;
  padding-right: 5px;
`;

const RightBtn = styled.View`
  width: 50%;
  padding-left: 5px;
`;

const SignIcon = styled.Image`
  height: 50px;
  width: 65px;
`;

const SignText = styled.Text`
  margin-bottom: 15px;
  font-family: 'OpenSans-Bold';
  color: #6d758e;
  font-size: 14px;
  font-weight: bold;
`;

const SignatureContainer = styled.View`
  background-color: #ffffff;
  border: 20px solid #f5f5f7;
  border-radius: 4px;
  flex: 1;
  padding: 20px;
  margin-bottom: 20px;
  height: 333px;
`;

const SignIconContainer = styled.View`
  height: 100%;
  background-color: #ffffff;
  justify-content: center;
  align-items: center;
`;

const ErrorContainer = styled.Text`
  color: red;
  text-align: center;
  margin-bottom: 10px;
`;

import React from 'react';
import { storiesOf } from '@storybook/react-native';

import CategoryList from './CategoryList';

storiesOf('Modules|Discover/School/Store/Components/Category', module).add(
  'Category List',
  () => <CategoryList title='Test' categoryId={387943} />
);

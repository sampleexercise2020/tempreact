import React from 'react';
import { Text } from 'react-native';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { useState, useActions } from 'easy-peasy';

import Signature from 'components/common/Signature/Signature';
import { addCommaSeparator } from 'helpers/addCommaSeparator';

const CloseIcon = require('src/../../assets/images/close.png');
const CartIcon = require('src/../../assets/images/edit_grey.png');

const CartItem = ({
  currency,
  price,
  title,
  image,
  requiresSignature,
  signed,
  quantity,
  id,
  onPress,
  removeFromCart
}) => {
  console.log('Cart item ID:', id);
  return (
    <>
      <Container onPress={onPress}>
        <ImageContainer>
          <Border>
            <Img source={{ uri: image }} />
          </Border>
        </ImageContainer>
        <TextContainer>
          <Price numberOfLines={1} ellipsizeMode='tail'>
            {currency} {addCommaSeparator(price)}
          </Price>
          <Title numberOfLines={1} ellipsizeMode='tail'>
            {title}
          </Title>
          <QuantityView>
            <Quantity>QTY: {quantity}</Quantity>
            <EditImage source={CartIcon} />
          </QuantityView>
        </TextContainer>
        <CloseButton onPress={() => removeFromCart(id)}>
          <CloseImage resizeMode='contain' source={CloseIcon} />
        </CloseButton>
      </Container>
      {signed === false ? (
        requiresSignature ? (
          <SignatureContainer>
            <Signature text='Signature required' />
            <SignNow>
              <SignNowText>Sign now</SignNowText>
            </SignNow>
          </SignatureContainer>
        ) : null
      ) : requiresSignature ? (
        <SignatureContainer>
          <Signature signed={true} text='Signature attached' />
        </SignatureContainer>
      ) : null}
    </>
  );
};

const Container = styled.TouchableOpacity`
  position: relative;
  flex-direction: row;
  justify-content: space-between;
`;

const TextContainer = styled.View`
  flex: 1;
`;
const ImageContainer = styled.View`
  margin: 0 20px;
`;
const Border = styled.View`
  border-top-left-radius: 11px;
  border-bottom-right-radius: 11px;
  overflow: hidden;
`;

const Price = styled.Text`
  color: rgb(13, 25, 67);
  font-size: 20px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  letter-spacing: 0px;
  line-height: 28px;
  height: 28px;
`;

const Title = styled.Text`
  color: rgb(13, 25, 67);
  font-size: 16px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 22px;
  padding-bottom: 18px;
`;

const Quantity = styled.Text`
  color: rgb(109, 117, 142);
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 18px;
`;
const SignNowText = styled.Text`
  color: rgb(255, 255, 255);
  font-size: 14px;
  font-family: 'OpenSans-SemiBold';
  font-weight: 600;
  text-align: center;
  letter-spacing: 0px;
  line-height: 18px;
`;

const Img = styled.Image`
  width: 80px;
  height: 80px;
  background: rebeccapurple;
  border-top-left-radius: 11px;
  border-bottom-right-radius: 11px;
  overflow: hidden;
`;

const SignatureContainer = styled.View`
  position: relative;
  flex-direction: row;
  justify-content: space-between;
  padding-top: 13px;
  margin: 0 20px;
`;

const SignNow = styled.TouchableOpacity`
  padding: 6px 8.5px;
  background: rgb(13, 133, 123);
  border-radius: 4px;
  justify-content: center;
  align-items: center;
`;

const CloseButton = styled.TouchableOpacity`
  width: 40px;
  height: 14px;
  margin-right: 20px;
  padding: 16px;
  justify-content: flex-end;
  align-items: flex-start;
`;

const CloseImage = styled.Image`
  height: 16px;
  width: 16px;
`;

const QuantityView = styled.View`
  flex-direction: row;
`;

const EditImage = styled.Image`
  height: 21px;
  width: 21px;
  padding-left: 40px;
  resize-mode: contain;
`;

export default CartItem;

import React, { useState, useCallback } from 'react';
import { Alert } from 'react-native';
import { useStore, useActions } from 'easy-peasy';
import { ActivityIndicator } from 'react-native';
import styled, { css } from 'styled-components/native';
import StudentInfoHeader from '../Start/components/StudentInfoHeader';
import SchoolHeader from '../Start/components/SchoolHeader';
import CartControls from '../components/CartControls';
import CartItem from './components/CartItem';
import { navigateTo, popToPrevious, dismissOverlay } from 'navigation';
import { CartItemSeparator } from 'components/common/Dividers/Dividers';
import LoaderContainer from 'components/common/LoaderContainer';
import { testProperties } from 'helpers/testProperties';

const ContinueToCheckout = ({ buttonTitle, student, componentId, cart }) => {
  const navigateToCheckout = () => {
    return navigateTo('Skiply.Store.Checkout', componentId, { student });
  };

  return (
    <PlaceAtBottom
      elevation={5}
      style={{
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 7
        },
        shadowOpacity: 0.43,
        shadowRadius: 9.51,
        elevation: 15
      }}
    >
      <CartControls
        {...testProperties('discover-store-shoppingcart-cartcontrols-id')}
        price={cart.amountMinorUnits / 100}
        currency={cart.currency}
        vat={cart.taxAmount / 100}
        payNowAction={navigateToCheckout}
        buttonTitle='Check out'
      />
    </PlaceAtBottom>
  );
};

const ShoppingCart = ({ componentId }) => {
  const cart = useStore((state) => state.cart);
  const students = useStore((state) => state.student.lists.saved);
  const deleteFromCart = useActions((actions) => actions.cart.deleteCartItem);
  const clearCart = useActions((actions) => actions.cart.clearCart);
  const setIsEditingCurrentProduct = useActions(
    ({ currentProduct }) => currentProduct.setIsEditing
  );
  const [isLoadingProduct, setIsLoadingProduct] = useState(false);

  // const storeBeneficiaryId = useStore((state) => state.student.beneficiaryId);
  const selectCurrentProduct = useActions(
    (actions) => actions.currentProduct.selectCurrentProduct
  );

  const beneficiaryId =
    cart.carts && cart.carts[0] && cart.carts[0].cartItems[0].beneficiaryId;

  const getStudent = () => {
    return students.find(
      ({ mcBeneficiaryId }) => mcBeneficiaryId == beneficiaryId
    );
  };

  const showProduct = async (cartItem) => {
    setIsLoadingProduct(true);
    setIsEditingCurrentProduct(true);
    await selectCurrentProduct({ ...cartItem, type: 'cartItem' });
    await navigateTo('Skiply.Store.Product', componentId, {
      isEditing: true
    });
    setIsLoadingProduct(false);
  };

  const removeFromCart = useCallback(
    async (id) => {
      const isLastCartItem =
        cart.carts[0] && cart.carts[0].cartItems.length == 1;

      if (isLastCartItem) {
        clearCart();
        popToPrevious(componentId);
      }

      const response = await deleteFromCart(id);

      if (response.status !== 200) {
        Alert.alert('Cart item deletetion failed', response.message);
      }
    },
    [cart]
  );

  const openRemoveFromCartPrompt = useCallback(
    (id) => {
      Alert.alert('Do you want to delete the item?', ``, [
        {
          text: 'Cancel',
          style: 'cancel'
        },
        ,
        {
          text: 'Yes',
          onPress: () => removeFromCart(id)
        }
      ]);
    },
    [cart]
  );

  return (
    <Container {...testProperties('discover-store-shoppingcart-container-id')}>
      <Inner>
        <Content>
          <Header>
            <StudentInfoHeader
              {...testProperties(
                'discover-store-shoppingcart-studentheader-id'
              )}
              student={getStudent()}
              showSchool={true}
            />
          </Header>
          <Products
            {...testProperties('discover-store-shoppingcart-products-id')}
          >
            <LoaderContainer isLoading={isLoadingProduct}>
              {cart &&
                cart.carts[0] &&
                cart.carts[0].cartItems.map((item) => (
                  <React.Fragment key={item.id}>
                    <CartItem
                      {...testProperties(
                        `discover-store-shoppingcart-products-cartitem-${
                          item.id
                        }-id`
                      )}
                      currency={item.currency}
                      price={item.totalAmount / 100}
                      title={item.productName}
                      quantity={item.quantity}
                      removeFromCart={openRemoveFromCartPrompt}
                      onPress={() => {
                        showProduct(item);
                      }}
                      image={item.imageUrl}
                      requiresSignature={false}
                      id={item.id}
                    />
                    <CartItemSeparator />
                  </React.Fragment>
                ))}
            </LoaderContainer>
          </Products>
        </Content>
      </Inner>
      {cart.carts && cart.carts[0] && (
        <ContinueToCheckout
          {...testProperties(
            'discover-store-shoppingcart-continuetocheckout-id'
          )}
          componentId={componentId}
          student={getStudent()}
          cart={cart.carts[0]}
        />
      )}
    </Container>
  );
};

export default ShoppingCart;

const Container = styled.View`
  flex: 1;
  height: 100%;
`;

const Content = styled.View`
  flex: 1;
  height: 100%;
`;

const Inner = styled.View`
  flex-grow: 1;
  flex: 1;
  height: 100%;
`;

const Header = styled.View`
  height: 74px;
  background: #2c1e75;
  justify-content: center;
  padding-left: 20px;
`;
const PlaceAtBottom = styled.View`
  padding: 10px 20px 30px;
  background: white;
`;

const Products = styled.ScrollView`
  padding: 20px 0px;
  flex: 1;
  flex-grow: 1;
  height: 100%;
`;

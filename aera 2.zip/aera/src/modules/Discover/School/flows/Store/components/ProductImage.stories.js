import React from 'react';
import { storiesOf } from '@storybook/react-native';

import ProductImage from './ProductImage';

storiesOf('Modules|Discover/School/Store/Components/Product/', module).add(
  'Product Image',
  () => <ProductImage />
);

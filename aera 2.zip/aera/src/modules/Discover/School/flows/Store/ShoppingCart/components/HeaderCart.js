import React from 'react';
import styled from 'styled-components/native';
import { useStoreState } from 'easy-peasy';
import { navigateTo } from 'navigation';

const HeaderCart = ({ componentId }) => {
  const carts = useStoreState((state) => state.cart.carts);
  const cart = carts[0];
  const cartIcon = require('src/../../assets/icons/common/cart-white.png');
  const numberOfItemsInCart = cart && cart.cartItems && cart.cartItems.length;
  const navigateToCart = () => {
    console.log('navigate to cart from id:', componentId);
    navigateTo('Skiply.Store.Cart', componentId);
  };

  return cart ? (
    <Container>
      <Button onPress={navigateToCart}>
        <CartIcon source={cartIcon} />
        <CartNumberWrapper>
          <CartText>{numberOfItemsInCart}</CartText>
        </CartNumberWrapper>
      </Button>
    </Container>
  ) : (
    <Nothing />
  );
};

const Container = styled.View`
  position: absolute;
  top: -25;
  right: 0;
`;

const Button = styled.TouchableOpacity`
  display: flex;
  flex-direction: row;
  align-items: center;
  align-self: center;
`;

const CartIcon = styled.Image`
  height: 22px;
  width: 22px;
  margin-top: 15px;
`;

const CartText = styled.Text`
  color: #fff;
  font-size: 12px;
  font-family: 'OpenSans-Semibold';
  font-weight: 600;
  letter-spacing: 0;
`;

const CartNumberWrapper = styled.View`
  background-color: #0d857b;
  height: 20px;
  width: 20px;
  border-radius: 10px;
  justify-content: center;
  align-items: center;
  margin-bottom: 15px;
  margin-right: 3px;
`;

const Nothing = styled.View``;

export default HeaderCart;

import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

const Date = ({ date }) => {
  return (
    <Container>
      <Title>Date</Title>
      <DateText>{date}</DateText>
    </Container>
  );
};

Date.propTypes = {};

const Title = styled.Text`
  width: 47px;
  height: 31px;
  color: rgb(54, 35, 94);
  font-size: 20px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  letter-spacing: 0px;
`;

const Container = styled.View`
  justify-content: center;
  flex-direction: column;
  height: 56px;
  margin: auto 25px;
`;

const DateText = styled.Text`
  color: #36235e;
  font-size: 16px;
  font-family: 'OpenSans-Regular';
  letter-spacing: -0.2px;
  line-height: 20px;
`;

export default Date;

import React from 'react';
import { storiesOf } from '@storybook/react-native';

import CartItem from './CartItem';

const mockData = {
  price: 'School Uniform',
  shortDesc: 'Short Description'
};

storiesOf(
  'Modules|Discover/School/Store/Components/Product/List Item - Cart Item',
  module
)
  .add('Basic', () => (
    <CartItem price={mockData.price} shortDesc={mockData.shortDesc} />
  ))
  .add('Long Name', () => (
    <CartItem
      price='This is a very long product name that continues for eternity'
      shortDesc={mockData.shortDesc}
    />
  ))
  .add('With Image', () => (
    <CartItem
      price={mockData.price}
      shortDesc={mockData.shortDesc}
      image='https://placekitten.com/300/300'
      requiresSignature={false}
      inCart={false}
    />
  ));

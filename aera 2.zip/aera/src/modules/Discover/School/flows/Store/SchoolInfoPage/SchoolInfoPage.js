import React from 'react';
import styled from 'styled-components/native';

const emailIcon = require('../../../../../../../assets/images/email.png');
const phoneIcon = require('../../../../../../../assets/images/phone.png');
const addressIcon = require('../../../../../../../assets/images/location.png');

const SchoolInfoPage = ({ merchant }) => {
  console.log('MERCHAAANTTT:::', merchant);
  return (
    <Container>
      <HeaderContainer>
        <Border>
          <SchoolImg source={{ uri: merchant.data.outlets[0].iconUrl }} />
        </Border>
        <SchoolTitle numberOfLines={1}>
          {merchant.data.outlets[0].name}
        </SchoolTitle>
      </HeaderContainer>
      <ScrollContainer>
        <ContactInformationContainer>
          {/* FIXME: uncomment this line as soon as we get email from the api */}
          {/* <InfoItem>
            <IconBackground>
              <InfoItemIcon source={emailIcon} />
            </IconBackground>
            <InfoItemText numberOfLines={1}>-</InfoItemText>
          </InfoItem> */}
          <InfoItem>
            <IconBackground>
              <InfoItemIcon source={phoneIcon} />
            </IconBackground>
            <InfoItemText numberOfLines={1}>
              {merchant.data.outlets[0].phone
                ? merchant.data.outlets[0].phone
                : '-'}
            </InfoItemText>
          </InfoItem>
          <InfoItem>
            <IconBackground>
              <InfoItemIcon source={addressIcon} />
            </IconBackground>
            <InfoItemText numberOfLines={2}>
              {merchant.data.outlets[0].address
                ? merchant.data.outlets[0].address
                : '-'}
            </InfoItemText>
          </InfoItem>
        </ContactInformationContainer>
        {/* <BorderSeparator /> */}
        {/* <Description>
          Placeholder.
        </Description> */}
      </ScrollContainer>
    </Container>
  );
};

export default SchoolInfoPage;

const Container = styled.View``;

const ScrollContainer = styled.ScrollView``;

const InfoItem = styled.View`
  flex-direction: row;
  margin-bottom: 20px;
  align-items: center;
`;

const InfoItemIcon = styled.Image`
  height: 13px;
  width: 13px;
`;

const IconBackground = styled.View`
  height: 30px;
  width: 30px;
  border-radius: 15px;
  background-color: #f5f5f7;
  justify-content: center;
  align-items: center;
`;

const InfoItemText = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  line-height: 18px;
  color: #0d1943;
  margin-left: 20px;
`;

const ContactInformationContainer = styled.View`
  flex-direction: column;
  margin: 30px 20px 20px 20px;
`;

const HeaderContainer = styled.View`
  height: 270px;
  background-color: #402ca8;
  border-bottom-right-radius: 40px;
  align-items: center;
  justify-content: center;
  padding-top: 40px;
`;

const SchoolImg = styled.Image`
  height: 120px;
  width: 120px;
  border-radius: 60px;
  border-width: 2px;
  border-color: #402ca8;
`;

const Border = styled.View`
  border-width: 2px;
  border-color: rgba(250, 250, 250, 0.8);
  height: 126px;
  width: 126px;
  justify-content: center;
  align-items: center;
  border-radius: 62px;
`;

const SchoolTitle = styled.Text`
  font-family: 'OpenSans-Bold';
  color: #ffffff;
  font-size: 18px;
  font-weight: bold;
  text-align: center;
  line-height: 26px;
  margin: 10px 60px 0 60px;
`;

const BorderSeparator = styled.View`
  border-bottom-width: 1px;
  border-bottom-color: #edeef1;
  margin: 0 20px 30px 20px;
`;

const Description = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
  margin: 0 20px 40px 20px;
`;

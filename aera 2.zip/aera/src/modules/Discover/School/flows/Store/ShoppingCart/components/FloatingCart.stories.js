// import React from 'react';
// import { storiesOf } from '@storybook/react-native';

// import FloatingCart from './FloatingCart';

// storiesOf('Modules|Discover/School/Store/Components/Category', module).add(
//   'Floating Cart',
//   () => <FloatingCart title='Test' categoryId={387943} />
// );

import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { useStore, useActions } from 'easy-peasy';
import { navigateTo } from 'navigation';
import CheckoutHeader from '../../../../../components/common/Header/CheckoutHeader';
import CheckoutItem from './components/CheckoutItem';
import AvailableCardsCO from './components/AvailableCardsCO';
import CartControls from '../Store/components/CartControls';
import selectedCopy from '../../../../../i18n/copy';
import { testProperties } from '../../../../../helpers/testProperties';
import R from 'ramda';

const copy = selectedCopy.components.modules.Account.flows.Checkout.index;

/**
 * TODO:
 * Should be refractored so that we do now have more then one component per file.
 * Teo Jul 8, 2019
 */
const MakePayment = ({ cart, componentId, selectedCardIndex, disabled }) => {
  const cards = useStore((state) => state.cards.items);

  const navigateToVerifyCvc = async () => {
    navigateTo('Skiply.Store.VerifyCvc', componentId, {
      card: cards[selectedCardIndex]
    });
  };

  return (
    <PlaceAtBottom
      elevation={5}
      style={{
        shadowColor: '#000',
        shadowOffset: {
          width: 0,
          height: 7
        },
        shadowOpacity: 0.43,
        shadowRadius: 9.51,

        elevation: 15
      }}
    >
      <CartControls
        {...testProperties('discover-checkout-cartcontrol-id')}
        price={cart.amountMinorUnits / 100}
        currency={cart.currency}
        vat={cart.cartTotalTax / 100}
        buttonTitle={copy.CartControls}
        payNowAction={async () => {
          navigateToVerifyCvc();
        }}
        disabled={cards.length > 0 && !disabled ? false : true}
      />
    </PlaceAtBottom>
  );
};

const CheckoutPage = ({ componentId, student }) => {
  const cards = useStore((state) => state.cards.items);
  const cart = useStore((state) => state.cart);
  const selectedCardState = useState(null);
  const [selectedCardIndex, setSelectedCardState] = selectedCardState;

  useEffect(() => {
    setSelectedCardState(R.findIndex(R.propEq('isDefault', true))(cards));
  }, [cards]);

  const navigateToAddNewMethod = () => {
    navigateTo('Skiply.Account.Payments.AddMethod', componentId);
  };

  return (
    <Container {...testProperties('discover-checkout-container-id')}>
      <FlexContainer>
        <InnerContainer>
          <CheckoutHeader
            {...testProperties('discover-checkout-checkout-header-id')}
            pageTitle={copy.CheckoutHeader}
            title={`${student.firstName} ${student.lastName}`}
            subtitle={student.schoolName || 'Undefined school name'}
            image={student.image}
          />
          {cart.carts.length > 0 ? (
            <CartItems
              {...testProperties('discover-checkout-cartitems-id')}
              scrollEnabled={false}
              data={cart.carts[0].cartItems}
              renderItem={({ item }) => (
                <CheckoutItem
                  productTitle={item.productName}
                  amount={item.totalAmount / 100}
                  currency={cart.carts[0].currency}
                />
              )}
              ItemSeparatorComponent={() => <Separator />}
            />
          ) : null}
          <AvailableCardsCO
            {...testProperties('discover-checkout-availablecardsco-id')}
            title={copy.AvailableCardsCO}
            selectedCardState={selectedCardState}
            navigateToAddNewMethod={navigateToAddNewMethod}
          />
        </InnerContainer>
      </FlexContainer>
      {cart.carts && cart.carts[0] && (
        <MakePayment
          {...testProperties('discover-checkout-makepayment-id')}
          componentId={componentId}
          selectedCardIndex={selectedCardIndex}
          cart={cart.carts[0]}
          disabled={
            cards.length > 0 &&
            (selectedCardIndex === 0 || selectedCardIndex > 0)
              ? false
              : true
          }
        />
      )}
    </Container>
  );
};

export default CheckoutPage;

const PlaceAtBottom = styled.View`
  width: 100%;
  padding: 10px 20px 30px;
  background: white;
`;

const Container = styled.View`
  flex: 1;
`;

const InnerContainer = styled.View``;

const FlexContainer = styled.ScrollView``;

const CartItems = styled.FlatList`
  padding-top: 30px;
`;

const Separator = styled.View`
  margin-top: 10px;
`;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import ReceiptTimeStamp from './ReceiptTimeStamp';

storiesOf('Modules|Discover/School/Checkout/components', module).add(
  'Timestamp',
  () => <ReceiptTimeStamp timestamp='2019-05-02' orderRef='REF #8934-234-234' />
);

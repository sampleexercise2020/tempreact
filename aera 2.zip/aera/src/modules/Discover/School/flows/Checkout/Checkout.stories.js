import React from 'react';
import { storiesOf } from '@storybook/react-native';
import CheckoutPage from './index';
import CardCVV from './CVV';

const mockCard = {
  backgroundColor: '#909090',
  isDefault: false,
  maskedPan: '**** **** **** 2234',
  cardHolderName: 'Ivar Stolpe',
  imageUrl: null,
  alias: 'Ivars',
  id: '570021',
  isExpired: false,
  type: 'Unknown'
};

storiesOf('Modules|Discover/School/Checkout', module)
  .add('Checkout page', () => <CheckoutPage />)
  .add('CVV Verification Page', () => <CardCVV card={mockCard} />);

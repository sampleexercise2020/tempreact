import React, { useState, useEffect } from 'react';
import { Alert } from 'react-native';
import styled from 'styled-components/native';
import * as yup from 'yup'; // for everything
import FormInput from 'components/common/Input/FormInput';
import Button from 'components/common/Button/Button';
import {
  useStoreActions,
  useStoreState,
  useActions,
  useStore
} from 'easy-peasy';
import { testProperties } from 'helpers/testProperties';
import { Navigation } from 'react-native-navigation';

let emailSchema = yup.object().shape({
  email: yup
    .string()
    .email()
    .required()
});

const EmailReceipt = (props) => {
  const userEmail = useStore((state) => state.profile.data.emailAddress);

  const [email, setEmail] = useState(userEmail);
  const [valid, setValid] = useState(false);

  const receipt = useStore((state) => state.receipts.singleReceipt);
  const isLoading = useStore((state) => state.receipts.isLoadingSendingReceipt);
  const sendEmailReceipt = useActions((actions) => {
    return actions.receipts.sendEmailReceipt;
  });
  const setLoadingSendingReceiptToDefault = useActions((actions) => {
    return actions.receipts.setLoadingSendingReceiptToDefault;
  });
  const sessionExpire = useActions((actions) => actions.session.expire);

  const checkValidity = async () => {
    const validity = await emailSchema.isValid({
      email: email
    });
    validity ? setValid(true) : setValid(false);
    console.log(validity);
  };

  const sendReceipt = async () => {
    let id = receipt.id;
    const response = await sendEmailReceipt({ id: id, email: email });
    console.log('Receipt Response: ', response);
    console.log('Receipts Send Email Response: ', response);

    if (response.status == 200) {
      Alert.alert(
        'Success!',
        'We have sent receipt on registered email address.'
      );
      Navigation.pop(props.componentId);
    } else if (response.status === 401 || response.status == 403) {
      sessionExpire();
    } else {
      Alert.alert(
        'Send Receipt Failure',
        'Unable to send receipt, please try again.'
      );
    }
  };

  const cancelClicked = async () => {
    Navigation.pop(props.componentId);
  };

  useEffect(() => {
    setLoadingSendingReceiptToDefault(false);
    checkValidity();
  }, [email]);

  return (
    <Container {...testProperties('send-receipt-container-id')}>
      <InnerContainer>
        <Title {...testProperties('send-receipt-title-id')}>
          Enter receipient e-mail address
        </Title>
        <FormContainer>
          <FormInput
            testProperties={testProperties('send-receipt-email-input-id')}
            numberOfLines={1}
            logo={false}
            label='E-mail address'
            keyboardType='email-address'
            returnKeyType='go'
            value={email}
            autoCapitalize={'none'}
            onChangeText={(text) => setEmail(text)}
          />
        </FormContainer>
      </InnerContainer>
      <ButtonContainer>
        <Button
          testProperties={testProperties('send-receipt-nextstep-button-id')}
          disabled={!valid || isLoading}
          primary={valid}
          onPress={sendReceipt}
          isLoading={isLoading}
        >
          Send
        </Button>
      </ButtonContainer>
      <ButtonContainer>
        <Button
          testProperties={testProperties('receipt-email-cancel-button-id')}
          secondary
          onPress={() => cancelClicked()}
        >
          Cancel
        </Button>
      </ButtonContainer>
    </Container>
  );
};

export default EmailReceipt;

const Container = styled.View`
  margin: 0 20px 20px 20px;
  flex: 1;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  line-height: 22px;
  padding: 25px 20px;
  text-align: center;
  color: #0d1943;
`;

const FormContainer = styled.View`
  background-color: #f5f5f7;
  border-radius: 4px;
  padding: 10px 15px 5px 15px;
`;

const ErrorContainer = styled.View``;

const ErrorText = styled.Text``;

const ButtonContainer = styled.View`
  margin-bottom: 10px;
`;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import MySkiplyPoints from './MySkiplyPoints';

storiesOf('Modules|Promotions', module)
  .add('No card', () => <MySkiplyPoints noRAKCard={true} showAddBtn={true} />)
  .add('Has card', () => (
    <MySkiplyPoints
      noRAKCard={false}
      appliedForCardInfo={true}
      showAddBtn={true}
    />
  ))
  .add('Has points', () => (
    <MySkiplyPoints
      noRAKCard={false}
      appliedForCardInfo={false}
      hasPoints={true}
      showAddBtn={false}
    />
  ));

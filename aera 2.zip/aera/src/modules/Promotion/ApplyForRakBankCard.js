import React, { useState } from 'react';
import styled from 'styled-components/native';
import RakBankCardCarousel from './components/RakBankCardCarousel';
import Button from '../../components/common/Button/Button';
import { testProperties } from '../../helpers/testProperties';
import { navigateTo } from 'navigation';

//TODO: ha ett kryss istället för back-knapp

const cardsList = [
  {
    cardType: 'FC Barcelona Platinum Credit Card',
    productCode: 'MCBPC',
    cardImg: require('../../../assets/images/rak_card_barca.png'),
    cardDesc: [
      { id: 1, text: 'Earn RAKBANKBarcaRewards' },
      { id: 2, text: 'Special offers on football coaching' },
      { id: 3, text: 'Win all-inclusive packages to Barcelona' }
    ],
    id: 0
  },
  {
    cardType: 'Air Arabia Platinum Credit Card',
    productCode: 'MCBAA',
    cardImg: require('../../../assets/images/rak_card_air.png'),
    cardDesc: [
      {
        id: 1,
        text:
          'Unmatched Air Rewards without any cap. 1.75 Air rewards per AED 5 at www.airarabia.com'
      },
      {
        id: 2,
        text: 'Get up to 2 return tickets to any Air Arabia destination'
      },
      {
        id: 3,
        text: 'Complimentary lounge access for cardholder at 25+ Airport lounge'
      }
    ],
    id: 1
  },
  {
    cardType: 'World Credit Card',
    productCode: 'MRBWORLD',
    cardImg: require('../../../assets/images/rak_card_world.png'),
    cardDesc: [
      {
        id: 1,
        text:
          'Up to 10% Cashback on Travel, Supermarkets & Hotel Dining and up to 50% Cashback on Cinemas'
      },
      {
        id: 2,
        text:
          'Up to 5% Cashback on all International and 3% Cashback on domestic spends'
      },
      {
        id: 3,
        text: 'Complimentary lounge access to more than 900+ airport lounges'
      }
    ],
    id: 2
  }
];

const ApplyForRakBankCard = ({ componentId }) => {
  const [selectedCard, setSelectedCard] = useState(0);

  const navigateToApplyCardFormPage = () => {
    navigateTo('Skiply.Promotion.ApplyForCardForm', componentId, {
      card: cardsList[selectedCard]
    });
  };

  return (
    <>
      <Container {...testProperties('apply-for-rakbank-card-container-id')}>
        <TopContent>
          <Title {...testProperties('apply-for-rakbank-card-title-id')}>
            Select a card
          </Title>
          <Subtitle {...testProperties('apply-for-rakbank-card-subtitle-id')}>
            Find the credit card that fits your lifestyle.
          </Subtitle>
        </TopContent>
        <RakBankCardCarousel
          setSelectedCard={setSelectedCard}
          cardsList={cardsList}
        />
      </Container>
      <ButtonContainer>
        <Button
          onPress={navigateToApplyCardFormPage}
          primary
          {...testProperties('apply-for-rakbank-card-button-id')}
        >
          Select this card
        </Button>
      </ButtonContainer>
    </>
  );
};

export default ApplyForRakBankCard;

const Container = styled.ScrollView`
  flex: 1;
`;

const TopContent = styled.View`
  margin: 0 40px 40px 40px;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 20px;
  font-weight: 900;
  text-align: center;
  line-height: 28px;
  color: #0d1943;
  margin-top: 35px;
  margin-bottom: 20px;
`;

const Subtitle = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  text-align: center;
  color: #0d1943;
`;

const ButtonContainer = styled.View`
  margin: 0 20px 20px 20px;
`;

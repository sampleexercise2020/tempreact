import React from 'react';
import styled from 'styled-components/native';
import { Navigation } from 'react-native-navigation';
import { navigateTo } from 'navigation';

const editIcon = require('../../../../assets/images/edit_pen_dark.png');

const CardselectedItem = ({ componentId, card }) => {
  return (
    <Container>
      <CardImg source={card.cardImg} />
      <CardType>{card.cardType}</CardType>
      <EditCardButton onPress={() => Navigation.pop(componentId)}>
        <EditCardIcon source={editIcon} />
      </EditCardButton>
    </Container>
  );
};

export default CardselectedItem;

const Container = styled.View`
  margin-bottom: 40px;
  align-items: center;
  justify-content: center;
  flex-direction: row;
  height: 24px;
`;

const CardType = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  line-height: 18px;
  text-align: center;
  color: #0d1943;
`;

const CardImg = styled.Image`
  height: 24px;
  width: 40px;
  margin-right: 10px;
`;

const EditCardButton = styled.TouchableOpacity`
  margin-left: 15px;
`;

const EditCardIcon = styled.Image`
  height: 13px;
  width: 13px;
`;

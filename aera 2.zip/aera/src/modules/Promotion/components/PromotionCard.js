import React from 'react';
import styled from 'styled-components/native';
import TextLink from '../../../components/common/Link/TextLink';
import { Navigation } from 'react-native-navigation';
import { navigateTo } from 'navigation';
import { testProperties } from 'helpers/testProperties';

//TODO: fixa test id för promotion card

const PromotionCard = ({ componentId }) => {
  const navigateToApplyForRakBankCard = () => {
    navigateTo('Skiply.Promotion.ApplyForRakBankCard', componentId);
  };

  return (
    <Container {...testProperties('promotion-card-container-id')}>
      <TopContainer>
        <TextWrapper>
          <Title {...testProperties('promotion-card-title-id')}>
            Apply for a RAKBANK card
          </Title>
          <Subtitle {...testProperties('promotion-card-subtitle-id')}>
            Earn special rewards and bonuses using one of our featured cards.
          </Subtitle>
        </TextWrapper>
      </TopContainer>
      <BottomContainer
        onPress={() => navigateToApplyForRakBankCard()}
        {...testProperties('promotion-card-button-id')}
      >
        <TextLink
          marginLeft={20}
          linktext='Apply now'
          onPress={() => navigateToApplyForRakBankCard()}
          white
          {...testProperties('promotion-card-link-id')}
        />
      </BottomContainer>
    </Container>
  );
};

export default PromotionCard;

const Container = styled.View`
  margin: 0 20px;
  height: 160px;
  border-top-left-radius: 40px;
  border-bottom-right-radius: 40px;
  margin-bottom: 30px;
  box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.08);
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 18px;
  font-weight: 900;
  line-height: 24px;
  color: #ffffff;
`;

const Subtitle = styled.Text`
  color: #ffffff;
  font-family: 'OpenSans-Regular';
  font-size: 14px;
  line-height: 18px;
`;

const TopContainer = styled.View`
  background-color: #13b9ab;
  height: 110px;
  border-top-left-radius: 40px;
  align-items: center;
  flex-direction: row;
`;

const TextWrapper = styled.View`
  flex-direction: column;
  margin: 2px 15px 0 15px;
`;

const BottomContainer = styled.TouchableOpacity`
  flex: 1;
  align-items: center;
  flex-direction: row;
  overflow: hidden;
  border-bottom-right-radius: 40px;
  background-color: #0d8177;
`;

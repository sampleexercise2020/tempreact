import React from 'react';
import styled from 'styled-components/native';

const SPlogo = require('../../../../assets/images/skiply_pts.png');

const PointsHeader = (props) => {
  return (
    <>
      <Container>
        <Logo source={SPlogo} />
        <HeaderText>My Skiply Points</HeaderText>
        <PointAmount>2 200 pts</PointAmount>
      </Container>
      <PointsContainer>
        <LeftTextContainer>
          <LeftText>Used points</LeftText>
          <LeftText>Money Saved</LeftText>
        </LeftTextContainer>
        <RightTextContainer>
          <RightText>200 pts</RightText>
          <RightText>AED 850</RightText>
        </RightTextContainer>
      </PointsContainer>
    </>
  );
};

export default PointsHeader;

const Container = styled.View`
  height: 215px;
  background-color: #fff1e2;
  justify-content: center;
  align-items: center;
`;

const Logo = styled.Image`
  height: 45px;
  width: 47px;
`;

const HeaderText = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  text-align: center;
  color: #2c1e75;
  margin-top: 10px;
`;

const PointAmount = styled.Text`
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  font-size: 32px;
  line-height: 40px;
  color: #2c1e75;
`;

const PointsContainer = styled.View`
  background-color: #2c1e75;
  height: 94px;
  width: 100%;
  border-bottom-right-radius: 40px;
  flex-direction: row;
  align-items: center;
`;

const LeftTextContainer = styled.View`
  left: 20px;
`;

const LeftText = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #ffffff;
`;

const RightTextContainer = styled.View`
  position: absolute;
  right: 20px;
`;

const RightText = styled.Text`
  font-family: 'OpenSans-Bold';
  font-weight: bold;
  font-size: 16px;
  line-height: 22px;
  color: #ffffff;
`;

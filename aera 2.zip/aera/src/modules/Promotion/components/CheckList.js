import React from 'react';
import styled from 'styled-components/native';

const checkIcon = require('../../../../assets/icons/common/purple-check.png');

const array = [
  {
    message:
      'Use any credit card from RAKBANK to earn cashback on every purchase.',
    id: 1
  },
  { message: 'Use Skiply Points to pay for products in the app.', id: 2 },
  {
    message:
      'Access RAKBANK for promotions and offers from a wide range of parthers.',
    id: 3
  }
];

const CheckList = (props) => {
  return (
    <Container>
      {array.map((item) => (
        <ListItem>
          <CheckMark source={checkIcon} />
          <ItemText>{item.message}</ItemText>
        </ListItem>
      ))}
    </Container>
  );
};

export default CheckList;

const Container = styled.View`
  margin: 0 20px;
  margin-bottom: 30px;
`;

const ItemText = styled.Text`
  font-family: 'OpenSans-Regular';
  color: #2c1e75;
  font-size: 14px;
  line-height: 18px;
  margin-left: 10px;
  flex-wrap: wrap;
  flex: 1;
`;

const CheckMark = styled.Image`
  height: 11px;
  width: 14px;
`;

const ListItem = styled.View`
  flex-direction: row;
  margin-top: 20px;
`;

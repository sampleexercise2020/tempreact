import React from 'react';
import styled from 'styled-components/native';

const array = [{ id: 1 }];

const Accordion = (props) => {
  return (
    <Container>
      <Title>FAQ</Title>
    </Container>
  );
};

export default Accordion;

const Container = styled.View`
  border: 1px solid red;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  font-weight: bold;
  line-height: 22px;
  padding-left: 20px;
  color: #0d1943;
`;

import React from 'react';
import styled from 'styled-components/native';

const SPlogo = require('../../../../assets/images/skiply_pts.png');

const LogoHeader = (props) => {
  return (
    <Container>
      <Logo source={SPlogo} />
      <HeaderText>Skiply Points</HeaderText>
    </Container>
  );
};

export default LogoHeader;

const Container = styled.View`
  height: 180px;
  background-color: #fff1e2;
  border-bottom-right-radius: 40px;
  justify-content: center;
  align-items: center;
`;

const Logo = styled.Image`
  height: 45px;
  width: 47px;
`;

const HeaderText = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 28px;
  line-height: 36px;
  text-align: center;
  color: #2c1e75;
`;

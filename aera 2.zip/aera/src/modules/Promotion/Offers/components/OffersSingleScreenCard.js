import React from 'react';
import styled from 'styled-components/native';
import { navigateTo } from 'navigation';
import ContentCardWithOnpress from '../../components/ContentCardWithOnpress';

// const cardsIcon = require('../../../../../assets/images/offers-card.png');
// const arrowicon = require('../../../../../assets/icons/common/forward-arrow.png');

const navigateToApplyForRAKBANKCardFlow = (componentId) => {
  navigateTo('Skiply.Promotion.ApplyForRakBankCard', componentId);
};

const card = {
  id: 3,
  title: 'Apply for a RAKBANK card',
  //categoryTitle: 'Special offers',
  onPressActivated: false,
  cardBackgroundColor: '#b99cec',
  backgroundLinkColor: '#8a72b3',
  linktext: 'Apply now',
  secondSubtitle:
    'Earn special rewards and bonuses using one of our featured cards.',
  footerLinkVisible: true,
  containerHeight: 260,
  contentCardIcon: require('../../../../../assets/images/offers-card.png'),
  linkOnPress: navigateToApplyForRAKBANKCardFlow
};

const OffersSingleScreenCard = ({ componentId }) => {
  return (
    <Container>
      <ContentCardWithOnpress
        key={card.id}
        backgroundLinkColor={card.backgroundLinkColor}
        linktext={card.linktext}
        imageBackgroundImg={card.imageBackgroundImg}
        title={card.title}
        categoryTitle={card.categoryTitle}
        footerLinkVisible={card.footerLinkVisible}
        cardBackgroundColor={card.cardBackgroundColor}
        secondSubtitle={card.secondSubtitle}
        contentCardIcon={card.contentCardIcon}
        containerHeight={card.containerHeight}
        linkOnPress={card.linkOnPress}
        componentId={componentId}
      />
    </Container>
  );
};

export default OffersSingleScreenCard;

const Container = styled.View`
  margin: 30px 0 30px -20px;
`;

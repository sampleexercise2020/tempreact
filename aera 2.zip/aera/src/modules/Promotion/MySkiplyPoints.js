import React from 'react';
import styled from 'styled-components/native';
import LogoHeader from './components/LogoHeader';
import CheckList from './components/CheckList';
import Button from 'components/common/Button/Button';
import AboutSP from './components/AboutSP';
import Accordion from './components/Accordion';
import InfoBox from './components/InfoBox';
import PointsHeader from './components/PointsHeader';
import { Navigation } from 'react-native-navigation';
import { navigateTo } from 'navigation';
import { testProperties } from '../../helpers/testProperties';

const MySkiplyPoints = ({
  noRAKCard,
  appliedForCardInfo,
  hasPoints,
  showAddBtn,
  componentId
}) => {
  console.log('Props: ', noRAKCard);

  Navigation.mergeOptions(componentId, {
    topBar: {
      visible: true,
      statusBar: {
        backgroundColor: 'rgb(255, 241, 226);',
        style: 'dark'
      }
    }
  });

  const navigateToApplyForRakBankCard = () => {
    navigateTo('Skiply.Promotion.ApplyForRakBankCard', componentId);
  };

  return (
    <Container {...testProperties('promotion-myskiplypointspage-container-id')}>
      {(noRAKCard || appliedForCardInfo) && (
        <LogoHeader
          {...testProperties('promotion-myskiplypoints-logoheader-id')}
        />
      )}
      {hasPoints && (
        <PointsHeader
          {...testProperties('promotion-myskiplypoints-pointsheader-id')}
        />
      )}
      <Title {...testProperties('promotion-myskiplypoints-title-id')}>
        Start earning Skiply Points
      </Title>
      <CheckList />
      {showAddBtn && (
        <ButtonsContainer>
          <Button
            testProperties={testProperties(
              'promotion-myskiplypoints-addcard-button-id'
            )}
            primaryV2
            onPress={() =>
              navigateTo('Skiply.Account.Payments.AddMethod', componentId)
            }
          >
            Add credit card
          </Button>
          {noRAKCard && (
            <>
              <NoRAKText>No RAKBANK credit card</NoRAKText>
              <Button
                testProperties={testProperties(
                  'promotion-myskiplypoints-applyforcard-button-id'
                )}
                secondary
                onPress={() => navigateToApplyForRakBankCard()}
              >
                Apply for credit card
              </Button>
            </>
          )}
          {appliedForCardInfo && (
            <InfoBox
              boxText='Thank you for applying. RAKBANK will contact you shortly to finalize
        your application.'
            />
          )}
        </ButtonsContainer>
      )}
      <Border />
      <AboutSP />
      <Accordion />
    </Container>
  );
};

export default MySkiplyPoints;

const Container = styled.ScrollView``;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  font-weight: bold;
  line-height: 22px;
  text-align: center;
  color: #2c1e75;
  margin-top: 30px;
  margin-bottom: 10px;
`;

const ButtonsContainer = styled.View`
  margin: 0 20px 30px 20px;
`;

const NoRAKText = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  line-height: 16px;
  text-align: center;
  color: #2c1e75;
  margin-bottom: 10px;
  margin-top: 30px;
`;

const Border = styled.View`
  border-bottom-width: 1px;
  border-color: #edeef1;
`;

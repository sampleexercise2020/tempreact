import React, { useState, useEffect } from 'react';
import { ActivityIndicator, Alert } from 'react-native';
import styled from 'styled-components/native';
import FormInput from '/components/common/Input/FormInput';
import Button from '../../components/common/Button/Button';
import CardselectedItem from './components/CardSelectedListItem';
import { Formik } from 'formik';
import R from 'ramda';
import * as yup from 'yup';
import CountryCodeForm from '../LoginAndSignup/flows/Signup/components/CountryCodeForm';
import { useStore, useActions } from 'easy-peasy';
import { Navigation } from 'react-native-navigation';
import { testProperties } from '../../helpers/testProperties';
import firebase from 'react-native-firebase';

//TODO: ha ett kryss istället för back-knapp eventuellt
//TODO: efternamnet står det null på, gör till tom sträng ist.

let ApplyForRAKBANKCardSchema = yup.object().shape({
  emailAddress: yup
    .string()
    .email('Must be a valid e-mail.')
    .required('An e-mail is required.'),
  name: yup
    .string()
    .required('Please enter your name to continue.')
    .max(39, 'Max 40 characters')
    .matches(
      /^[a-zA-Z \-']+$/,
      'Invalid name due to the number or special character used.'
    ),
  phoneNumber: yup
    .number()
    .required('Please enter your mobile number to continue.')
    .min(9, 'Your phone number has to contain a minimum of 9 digits.')
    .moreThan(0, 'Your phone number cannot start with 0.')
});

const ApplyForCardForm = ({ componentId, card }) => {
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const userId = useStore((state) => state.profile.data.emailAddress);
  const phoneNumber = useStore((state) => state.profile.data.phoneNumber);
  const firstName = useStore((state) => state.profile.data.firstName);
  const lastName = useStore((state) => state.profile.data.lastName);
  const phoneNumberCountryCode = useStore(
    (state) => state.profile.data.phoneNumberCountryCode
  );

  const [countryCode, setCountryCode] = useState('+' + phoneNumberCountryCode);
  // const isLoading = useStore((state) => state.promotion.isLoading);

  const postCardApplication = useActions(
    (actions) => actions.promotion.postCardApplication
  );

  const handleSubmit = async ({ name, phoneNumber, emailAddress }) => {
    setIsLoading(true);

    const names = name.split(' ').map((item) => item.trim());

    const response = await postCardApplication({
      userId: emailAddress,
      emailId: emailAddress,
      productCode: card.productCode,
      contactPersonMobileNo: phoneNumber,
      contactPersonMobileNoCode: countryCode.slice(1),
      mobileNumber: phoneNumber,
      mobileNoCode: countryCode.slice(1),
      firstName: names[0],
      lastName: names[1]
    });

    if (response.status == 200) {
      firebase.analytics().logEvent('applying_for_card');
      Navigation.popToRoot(componentId);
      Alert.alert(
        'Thank you!',
        'A RAKBANK representative will get back to you within 24 hours.'
      );
    } else {
      Alert.alert('Oops', 'Something went wrong, please try again later.');
    }

    setIsLoading(false);
  };

  return (
    <Formik
      initialValues={{
        name: firstName + ' ' + (lastName || ''),
        phoneNumber: phoneNumber,
        phoneNumberCountryCode: phoneNumberCountryCode,
        emailAddress: userId
      }}
      onSubmit={handleSubmit}
      enableReinitialize
      validationSchema={ApplyForRAKBANKCardSchema}
    >
      {(props) => (
        <>
          <Container
            {...testProperties('apply-for-rakbank-card-form-container-id')}
          >
            <InnerContainer>
              <Title
                {...testProperties('apply-for-rakbank-card-form-title-id')}
              >
                Confirm contact details
              </Title>
              <Subtitle
                {...testProperties('apply-for-rakbank-card-form-subtitle-id')}
              >
                RAKBANK will get in touch within a day or two to complete your
                application.
              </Subtitle>
              <CardselectedItem componentId={componentId} card={card} />
              <FormContainer
                {...testProperties(
                  'apply-for-rakbank-card-form-form-container-id'
                )}
              >
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label='Name'
                  keyboardType='default'
                  returnKeyType='go'
                  maxLength={40}
                  value={props.values.name}
                  onChangeText={props.handleChange('name')}
                  autoCapitalize={'none'}
                  error={props.errors.name}
                  {...testProperties(
                    'apply-for-rakbank-card-form-input-name-id'
                  )}
                />
                <FormInput
                  numberOfLines={1}
                  logo={false}
                  label='Email'
                  keyboardType='email-address'
                  returnKeyType='go'
                  maxLength={40}
                  value={props.values.emailAddress}
                  onChangeText={props.handleChange('emailAddress')}
                  autoCapitalize={'none'}
                  error={props.errors.emailAddress}
                  {...testProperties(
                    'apply-for-rakbank-card-form-input-email-id'
                  )}
                />
              </FormContainer>
              <CountryCodeContainer>
                <CountryCodeForm
                  numberOfLines={1}
                  logo={false}
                  label='Phone Number'
                  keyboardType='numeric'
                  returnKeyType='go'
                  matches={/^((?!(0))[0-9])/}
                  onChangeText={props.handleChange('phoneNumber')}
                  onBlur={props.handleBlur('phoneNumber')}
                  value={props.values.phoneNumber}
                  setCountryCode={setCountryCode}
                  error={props.errors.phoneNumber}
                  {...testProperties(
                    'apply-for-rakbank-card-form-input-phone-id'
                  )}
                  defaultCountryCode={countryCode}
                />
              </CountryCodeContainer>
            </InnerContainer>
            {isLoading && <ActivityIndicator size='large' />}
          </Container>
          <ErrorMessageContainer
            {...testProperties('sign-up-error-message-container-id')}
          >
            {props.errors.name && (
              <ErrorMessage>{props.errors.name}</ErrorMessage>
            )}
            {props.errors.emailAddress && (
              <ErrorMessage>{props.errors.emailAddress}</ErrorMessage>
            )}
            {props.errors.phoneNumber && (
              <ErrorMessage>{props.errors.phoneNumber}</ErrorMessage>
            )}
          </ErrorMessageContainer>
          <ButtonContainer
            {...testProperties(
              'apply-for-rakbank-card-form-button-container-id'
            )}
          >
            <Button
              onPress={props.handleSubmit}
              isLoading={isLoading}
              disabled={isLoading || !R.isEmpty(props.errors)}
              primary={!isLoading}
              {...testProperties('apply-for-rakbank-card-form-button-id')}
            >
              Confirm and contact me
            </Button>
          </ButtonContainer>
        </>
      )}
    </Formik>
  );
};

export default ApplyForCardForm;

const Container = styled.ScrollView`
  flex: 1;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 20px;
  font-weight: 900;
  line-height: 28px;
  text-align: center;
  color: #0d1943;
  margin: 35px 40px 20px 40px;
`;

const Subtitle = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  line-height: 22px;
  color: #0d1943;
  margin: 0 40px 40px 40px;
  text-align: center;
`;

const FormContainer = styled.View`
  background-color: #f5f5f7;
  padding: 15px 15px 5px 15px;
  margin: 0 20px;
  border-radius: 4px;
`;

const ButtonContainer = styled.View`
  margin: 20px 20px 20px 20px;
`;

const CountryCodeContainer = styled.View`
  background-color: #f5f5f7;
  padding: 15px 15px 15px 15px;
  margin: 20px 20px 0 20px;
  border-radius: 4px;
`;

const ErrorMessageContainer = styled.View`
  justify-content: center;
  align-items: center;
  margin-bottom: 10px;
  min-height: 10px;
`;

const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  line-height: 22px;
  font-weight: normal;
`;

import React from 'react';
import { Dimensions } from 'react-native';
import styled from 'styled-components/native';

const screenWidth = Dimensions.get('window').width;
const placeholderPhone = require('../../../../../../assets/images/placeholder-phone.png');

const SingleSlide = ({
  backgroundColor,
  title,
  subtitle,
  screenWidth,
  image
}) => {
  return (
    <Container backgroundColor={backgroundColor} screenWidth={screenWidth}>
      <InnerContainer>
        <TextContainer>
          <Title numberOfLines={3}>{title}</Title>
          <Subtitle numberOfLines={4}>{subtitle}</Subtitle>
        </TextContainer>
        <PicContainer>
          <Picture source={image} resizeMode='contain' />
        </PicContainer>
      </InnerContainer>
    </Container>
  );
};

export default SingleSlide;

const Container = styled.View`
  background-color: ${(props) => props.backgroundColor};
  width: ${() => screenWidth};
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const TextContainer = styled.View`
  margin-bottom: 20px;
  align-items: center;
  padding-top: 20px;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 28px;
  color: #ffffff;
  margin: 80px 30px 10px 30px;
  text-align: center;
  padding: 0 20px;
  font-weight: 900;
  line-height: 28px;
`;

const Subtitle = styled.Text`
  margin: 0 30px 40px 30px;
  font-family: 'OpenSans-Bold';
  color: #ffffff;
  text-align: center;
  line-height: 18px;
  font-size: 14px;
`;

const PicContainer = styled.View`
  justify-content: center;
  align-items: center;
  flex-grow: 1;
  flex: 1;
  height: 100%;
  padding-bottom: 64px;
`;

const Picture = styled.Image`
  width: 100%;
  height: 100%;
  flex-shrink: 1;
  box-shadow: 2px 2px 5px #262626;
`;

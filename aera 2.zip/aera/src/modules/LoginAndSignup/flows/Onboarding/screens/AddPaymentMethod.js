import React from 'react';
import { navigateTo } from 'navigation';
import Button from 'components/common/Button/Button';
import styled from 'styled-components/native';
import { root } from 'navigation/root';
import { Navigation } from 'react-native-navigation';
import { useStoreActions } from 'easy-peasy';

const cardIcon = require('../../../../../../assets/icons/common/card-icon-white.png');

const AddPaymentMethod = (props) => {
  const setShouldTakeATour = useStoreActions(
    ({ global }) => global.setShouldTakeATour
  );

  return (
    <Container>
      <IconContainer>
        <Icon source={cardIcon} />
      </IconContainer>
      <Title>Let's add a payment method</Title>
      <Subtitle>
        Add a credit card to your profile and you will be set to pay in seconds
      </Subtitle>
      <ButtonsContainer>
        <Button
          primary
          onPress={async () => {
            await Navigation.setRoot({ root });

            navigateTo('Skiply.Account.Payments.AddMethod', 'Skiply.Home', {
              fromOnboarding: true
            });
          }}
        >
          Yes, please
        </Button>
        <DismissButton
          onPress={() => {
            setShouldTakeATour(true);
            Navigation.setRoot({ root });
          }}
        >
          <DismissText>Not now</DismissText>
        </DismissButton>
      </ButtonsContainer>
    </Container>
  );
};

export default AddPaymentMethod;

const Container = styled.View`
  flex: 1;
  margin: 0 20px;
`;

const IconContainer = styled.View`
  height: 90px;
  width: 90px;
  border-radius: 45px;
  background-color: #402ca8;
  align-self: center;
  margin: 60px 40px 30px 40px;
  align-items: center;
  justify-content: center;
`;

const Icon = styled.Image`
  height: 30px;
  width: 40px;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  text-align: center;
  color: #0d1943;
  font-size: 28px;
  line-height: 36px;
  font-weight: 900;
  margin: 0 40px 20px 40px;
`;

const Subtitle = styled.Text`
  font-family: 'OpenSans-SemiBold';
  text-align: center;
  color: #0d1943;
  font-size: 14px;
  font-weight: 600;
  line-height: 22px;
  margin: 0 40px;
`;

const DismissButton = styled.TouchableOpacity`
  margin-top: 20px;
`;

const DismissText = styled.Text`
  font-family: 'OpenSans-SemiBold';
  font-size: 14px;
  font-weight: 600;
  line-height: 18px;
  color: #402ca8;
  text-align: center;
`;

const ButtonsContainer = styled.View`
  justify-content: flex-end;
  flex: 1;
  margin-bottom: 35px;
`;

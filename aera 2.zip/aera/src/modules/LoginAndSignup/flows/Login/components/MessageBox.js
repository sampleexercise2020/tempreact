import React from 'react';
import styled, { css } from 'styled-components/native';

const MessageBox = ({ error, regular, message }) => {
  return (
    <Container>
      <Title error={error} regular={regular}>
        {message}
      </Title>
    </Container>
  );
};

export default MessageBox;

const Container = styled.View`
  min-height: 50px;
  justify-content: center;
  align-items: center;
  margin: 10px 0;
`;

const Title = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  line-height: 22px;
  padding: 0 20px;
  ${(props) =>
    props.error &&
    css`
      color: #d9363b;
    `}
  ${(props) =>
    props.regular &&
    css`
      color: #0d1943;
    `}
`;

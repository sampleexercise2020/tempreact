import React, { useState } from 'react';
import styled from 'styled-components/native';
import FormInput from 'components/common/Input/FormInput';
import FormMessage from './FormMessage';
import Button from 'components/common/Button/Button';

const EnterPasswordForm = ({ title, subtitle, formMessage, buttonText }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(true);

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  return (
    <Container>
      <InnerContainer>
        <Title>{title}</Title>
        <Subtitle>{subtitle}</Subtitle>
        <FormContainer>
          <FormInput
            numberOfLines={1}
            logo={false}
            label='Password'
            keyboardType='default'
            returnKeyType='go'
            toggleShowPassword={toggleShowPassword}
            secureTextEntry={showPassword}
            showPW={true}
            showPWText='Show'
            value={password}
            onChangeText={(text) => setPassword(text)}
          />
        </FormContainer>
        <FormMessage message={formMessage} />
      </InnerContainer>
      <Button disabled onPress={() => handleLogin()}>
        {buttonText}
      </Button>
    </Container>
  );
};

export default EnterPasswordForm;

const Container = styled.View`
  flex: 1;
  margin: 0 20px 20px 20px;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  color: #0d1943;
  margin-top: 60px;
  line-height: 22px;
`;

const Subtitle = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 16px;
  color: #0d1943;
  line-height: 22px;
  text-align: center;
`;

const FormContainer = styled.View`
  height: 80px;
  background-color: #f5f5f7;
  border-radius: 4px;
  padding: 15px;
  margin-top: 40px;
`;

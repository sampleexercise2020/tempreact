import React from 'react';
import EnterPassWordForm from './components/EnterPasswordForm';
import selectedCopy from '../../../../i18n/copy';
import { testProperties } from '../../../../helpers/testProperties';

const copy =
  selectedCopy.components.modules.LoginAndSignup.flows.Login.SessionExpired;

const userName = 'john.andersson@gmail.com';

const SessionExpired = (props) => {
  return (
    <EnterPassWordForm
      {...testProperties('login-sessionexpired-form-id')}
      title={copy.title}
      subtitle={`${copy.subtitleStart} ${userName} ${copy.subtitleEnd}`}
      formMessage={copy.minPassword}
      buttonText={copy.next}
    />
  );
};

export default SessionExpired;

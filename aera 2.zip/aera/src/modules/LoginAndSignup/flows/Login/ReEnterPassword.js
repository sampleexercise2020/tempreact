import React from 'react';
import EnterPassWordForm from './components/EnterPasswordForm';

import selectedCopy from '../../../../i18n/copy';
import { testProperties } from '../../../../helpers/testProperties';

const copy =
  selectedCopy.components.modules.LoginAndSignup.flows.Login.ReEnterPassword;

const ReEnterPassword = (props) => {
  return (
    <EnterPassWordForm
      {...testProperties('login-reenterpassword-form-id')}
      title={copy.title}
      subtitle={copy.subtitle}
      formMessage={copy.minPassword}
      buttonText={copy.login}
    />
  );
};

export default ReEnterPassword;

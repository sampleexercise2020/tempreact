import React from 'react';
import styled from 'styled-components/native';
import LoginFlowFooter from 'components/common/Footers/LoginFlowFooter';
import selectedCopy from '../../../../i18n/copy';
import { testProperties } from '../../../../helpers/testProperties';

const copy = selectedCopy.components.modules.LoginAndSignup.flows.Splash.index;

const skiplyLogo = require('../../../../../assets/icons/common/skiply-white-logo-medium.png');

const Splash = (props) => {
  return (
    <Container {...testProperties('signup-splashscreen-container-id')}>
      <InnerContainer>
        <LogoContainer>
          <Logo
            {...testProperties('signup-splashscreen-logo-id')}
            source={skiplyLogo}
          />
        </LogoContainer>
        <TextContainer>
          <Title {...testProperties('signup-splashscreen-title-id')}>
            {copy.title}
          </Title>
        </TextContainer>
      </InnerContainer>
      <LoginFlowFooter />
    </Container>
  );
};

export default Splash;

const Container = styled.View`
  flex: 1;
  background-color: #402ca8;
`;

const InnerContainer = styled.View`
  flex: 1;
  align-items: center;
`;

const LogoContainer = styled.View`
  height: 200px;
  width: 275px;
  background-color: #5341b0;
  margin-top: 160px;
  border-bottom-right-radius: 40px;
  border-top-left-radius: 40px;
  justify-content: center;
  align-items: center;
`;

const Logo = styled.Image``;

const TextContainer = styled.View`
  width: 280px;
  margin-top: 20px;
  padding: 0 50px;
`;

const Title = styled.Text`
  font-family: 'TeshrinAR+LT-Heavy';
  color: #ffffff;
  font-size: 20px;
  line-height: 28px;
  text-align: center;
`;

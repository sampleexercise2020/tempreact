import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Splash from './index';

storiesOf('Modules|LoginAndSignup/Splash', module).add('Splash screen', () => (
  <Splash />
));

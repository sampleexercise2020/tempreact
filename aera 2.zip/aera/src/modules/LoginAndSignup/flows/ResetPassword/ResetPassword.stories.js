import React from 'react';
import { storiesOf } from '@storybook/react-native';
import NewPassword from './NewPassword/NewPassword';
import ResetPassword from './ResetPassword/ResetPassword';
import VerifyReset from './VerifyReset/VerifyReset';
import Modal from '../../../../components/common/Modal/FullScreenModal';
import VerificationCode from './VerificationCode/VerificationCode';

// TODO: Get notes working.

storiesOf('Modules|LoginAndSignup/ResetPassword', module)
  .add('Reset Password', () => (
    <ResetPassword title='Enter your e-mail to be able to reset password' />
  ))
  .add('Verify reset', () => (
    <VerifyReset title='How do you want to vertify and reset your password?' />
  ))
  .add('Code sent modal', () => (
    <Modal
      text='A verification code has been sent to +46 123 456 789'
      cancelText='Back'
      onPressCancel={() => console.log('on press back')}
      onPressPrimaryButton={console.log('on press primaryyy')}
      buttonText='Enter code'
    />
  ))
  .add('Verification code (enter)', () => <VerificationCode />)
  .add('New Password', () => <NewPassword title='Enter your new password' />)
  .add('new pw set modal', () => (
    <Modal
      text='Your new password is now saved.'
      cancelText='Close'
      onPressCancel={() => console.log('on press back')}
      onPressPrimaryButton={console.log('on press primaryyy')}
      buttonText='Login'
    />
  ));

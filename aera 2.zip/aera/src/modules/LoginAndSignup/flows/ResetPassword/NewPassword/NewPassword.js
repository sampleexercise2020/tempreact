import React, { useState } from 'react';
import { Text } from 'react-native';
import styled from 'styled-components/native';
import FormInput from '../../../../../components/common/Input/FormInput';
import Button from 'components/common/Button/Button';
import { testProperties } from '../../../../../helpers/testProperties';

const NewPassword = ({ title }) => {
  const [showPassword, setShowPassword] = useState(true);
  const [password, setPassword] = useState('qwerty1234');

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  return (
    <Container {...testProperties('newpassword-newpasswordform-container-id')}>
      <InnerContainer>
        <Text>reset pw</Text>
        <Title {...testProperties('newpassword-title-id')}> {title}</Title>
        <FormContainer>
          <FormInput
            testProperties={testProperties('newpassword-password-input-id')}
            numberOfLines={1}
            logo={false}
            label='Password'
            keyboardType='default'
            returnKeyType='go'
            toggleShowPassword={toggleShowPassword}
            secureTextEntry={showPassword}
            showPW={true}
            showPWText='Show'
            value={password}
            onChangeText={(text) => setPassword(text)}
          />
        </FormContainer>
        <GuideTip>Min. 8 characters</GuideTip>
      </InnerContainer>
      <Button
        testProperties={testProperties('newpassword-nextstep-button-id')}
        disabled
        onPress={() => console.log('next step')}
      >
        Next
      </Button>
    </Container>
  );
};

export default NewPassword;

const Container = styled.View`
  margin: 0 20px 20px 20px;
  flex: 1;
`;

const InnerContainer = styled.View`
  flex: 1;
`;

const Title = styled.Text`
  font-family: 'OpenSans-Bold';
  font-size: 16px;
  line-height: 22px;
  padding: 60px 40px;
  text-align: center;
  color: #0d1943;
`;

const FormContainer = styled.View`
  background-color: #f5f5f7;
  border-radius: 4px;
  padding: 15px 15px 5px 15px;
`;

const GuideTip = styled.Text`
  font-family: 'OpenSans-Regular';
  font-size: 12px;
  color: #2c79de;
  margin-left: 20px;
  margin-top: 1px;
`;

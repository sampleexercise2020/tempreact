import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Carousel from './Carousel';

storiesOf('Modules|LoginAndSignup/Landing', module).add('Carousel', () => (
  <Carousel />
));

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Landing from './index';

storiesOf('Modules|LoginAndSignup/Landing', module).add(
  'Landing screen',
  () => <Landing />
);

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import SignupForm from './Form/SignupForm';

// TODO: Get notes working.

storiesOf('Modules|LoginAndSignup/Signup', module).add('Signup Form', () => (
  <SignupForm />
));

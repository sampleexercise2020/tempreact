import React, { useEffect, useState } from 'react';
import { AsyncStorage, Alert, Linking, Text } from 'react-native';
import styled from 'styled-components/native';
import FormInput from 'components/common/Input/FormInput';
import { Navigation } from 'react-native-navigation';
import Button from 'components/common/Button/Button';
import { navigateTo } from 'navigation';
import CountryCodeForm from '../components/CountryCodeForm';
import RadioButton from '../../../../../components/common/RadioButton/RadioButton';
import { Formik } from 'formik';
import * as yup from 'yup';
import { root } from 'navigation/root';
import { useActions, useStoreActions, useStore } from 'easy-peasy';
import selectedCopy from '../../../../../i18n/copy';
import { testProperties } from '../../../../../helpers/testProperties';
import BiometricManager from '../../../../../biometric/BiometricManager';
import firebase from 'react-native-firebase';

const copy =
  selectedCopy.components.modules.LoginAndSignup.flows.Signup.Form.SignupForm;

const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

let SignupSchema = yup.object().shape({
  phoneNumber: yup
    .string()
    .required('Please enter your mobile number to continue.')
    .min(9, 'Your phone number has to contain a minimum of 9 digits.')
    .matches(phoneRegExp, 'Phone number can only contain numbers.'),
  emailAddress: yup
    .string()
    .email('Please enter a valid email id.')
    .required('Please enter your email id to continue.')
    .matches(
      /^[^{<>()[\]\\+,;:\%#^\s@\}"$&§!@-]+@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z0-9]+\.)+[a-zA-Z]{2,}))$/,
      "You can only use letters, numbers, period ('.') and underscore ('_') in your email."
    ),
  name: yup
    .string()
    .required('Please enter your name to continue.')
    .matches(
      /^[a-zA-Z \-']+$/,
      'Invalid name due to the number or special character used.'
    ),
  password: yup
    .string()
    .required('Please enter your password to continue.')
    .min(8, 'Your password must have at least 8 characters.')
    .max(16, 'Your password cannot have more than 16 characters.')
    .matches(
      /^(?=.*?[A-Z])(?=(.*[a-z]){1,})(?=(.*[\d]){1,})(?=(.*[\W]){1,})(?!.*\s).{8,}$/,
      'Your password should contain alphabets, numbers and at least one special character and one capital letter.'
    ),
  terms: yup
    .boolean()
    .oneOf([true], 'Please accept terms and conditions to continue.')
});

const SignupForm = ({ componentId }) => {
  const [isSigningUp, setIsSigningUp] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const signup = useActions((actions) => actions.session.signup);
  const [countryCode, setCountryCode] = useState('+971');
  const fetchProfile = useStoreActions(({ profile }) => profile.fetch);
  const setAccessToken = useStoreActions((actions) => actions.session.setToken);
  const setAuthorization = useStoreActions(
    (actions) => actions.session.setAuthorization
  );

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleSubmit = async ({
    name,
    areaCode,
    phoneNumber,
    emailAddress,
    password
  }) => {
    setIsSigningUp(true);

    const names = name.split(' ').map((item) => item.trim());

    let payload = {
      firstName: names[0],
      emailAddress,
      password: password,
      phoneNumber: parseInt(phoneNumber),
      lastName: names[1] || '',
      countryOfResidence: 'AE',
      automaticEmailReceipts: false,
      phoneNumberCountryCode: parseInt(countryCode)
    };
    const response = await signup(payload);

    if (response.success) {
      firebase.analytics().logEvent('sign_up');
      setAccessToken(response.data.userAccessToken);
      setAuthorization(response.data.authorization);
      const bm = BiometricManager.showEnableOptionsFor(emailAddress, password);

      await bm
        .then((response) => {
          console.log('Biometric Response: ', response);
        })
        .catch((error) => {
          console.log('Biometric Error: ', error);
        });

      await AsyncStorage.setItem('ONBOARDING_DONE', 'false');

      await fetchProfileAndNavigateToOnboarding();
    } else {
      var errorMessage;
      if (response.message == 'Email already exists.') {
        errorMessage =
          'The user is already registered with us. Please login with your email id and password.';
      } else {
        errorMessage = response.message;
      }
      Alert.alert('Sign up failed', errorMessage);

      setIsSigningUp(false);
    }
  };

  const fetchProfileAndNavigateToOnboarding = async () => {
    const profileResponse = await fetchProfile();
    if (profileResponse.status == 200) {
      console.log('Response: ', profileResponse);
      firebase.analytics().setUserId(profileResponse.data.id);
      firebase.analytics().logEvent('login');
      navigateTo('Skiply.WelcomeOnboard', componentId);
    } else {
      setErrorMessage(profileResponse.message);
      setIsSigningUp(false);
    }
  };

  const navigateToHome = async () => {
    Navigation.setRoot({ root });
  };

  const removeEmojisFromInputField = (string = '') => {
    const regex = /\uD83C\uDFF4(?:\uDB40\uDC67\uDB40\uDC62(?:\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDB40\uDC77\uDB40\uDC6C\uDB40\uDC73|\uDB40\uDC73\uDB40\uDC63\uDB40\uDC74)\uDB40\uDC7F|\u200D\u2620\uFE0F)|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC68(?:\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D)?\uD83D\uDC68|(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67]))|\uD83D\uDC66\u200D\uD83D\uDC66|\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDB0-\uDDB3])|(?:\uD83C[\uDFFB-\uDFFF])\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDB0-\uDDB3]))|\uD83D\uDC69\u200D(?:\u2764\uFE0F\u200D(?:\uD83D\uDC8B\u200D(?:\uD83D[\uDC68\uDC69])|\uD83D[\uDC68\uDC69])|\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDB0-\uDDB3])|\uD83D\uDC69\u200D\uD83D\uDC66\u200D\uD83D\uDC66|(?:\uD83D\uDC41\uFE0F\u200D\uD83D\uDDE8|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2695\u2696\u2708]|\uD83D\uDC68(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2695\u2696\u2708]|\u200D[\u2695\u2696\u2708])|(?:(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)\uFE0F|\uD83D\uDC6F|\uD83E[\uDD3C\uDDDE\uDDDF])\u200D[\u2640\u2642]|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDD6-\uDDDD])(?:(?:\uD83C[\uDFFB-\uDFFF])\u200D[\u2640\u2642]|\u200D[\u2640\u2642])|\uD83D\uDC69\u200D[\u2695\u2696\u2708])\uFE0F|\uD83D\uDC69\u200D\uD83D\uDC67\u200D(?:\uD83D[\uDC66\uDC67])|\uD83D\uDC69\u200D\uD83D\uDC69\u200D(?:\uD83D[\uDC66\uDC67])|\uD83D\uDC68(?:\u200D(?:(?:\uD83D[\uDC68\uDC69])\u200D(?:\uD83D[\uDC66\uDC67])|\uD83D[\uDC66\uDC67])|\uD83C[\uDFFB-\uDFFF])|\uD83C\uDFF3\uFE0F\u200D\uD83C\uDF08|\uD83D\uDC69\u200D\uD83D\uDC67|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])\u200D(?:\uD83C[\uDF3E\uDF73\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E[\uDDB0-\uDDB3])|\uD83D\uDC69\u200D\uD83D\uDC66|\uD83C\uDDF6\uD83C\uDDE6|\uD83C\uDDFD\uD83C\uDDF0|\uD83C\uDDF4\uD83C\uDDF2|\uD83D\uDC69(?:\uD83C[\uDFFB-\uDFFF])|\uD83C\uDDED(?:\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA])|\uD83C\uDDEC(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE])|\uD83C\uDDEA(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA])|\uD83C\uDDE8(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF5\uDDF7\uDDFA-\uDDFF])|\uD83C\uDDF2(?:\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF])|\uD83C\uDDF3(?:\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF])|\uD83C\uDDFC(?:\uD83C[\uDDEB\uDDF8])|\uD83C\uDDFA(?:\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF])|\uD83C\uDDF0(?:\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF])|\uD83C\uDDEF(?:\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5])|\uD83C\uDDF8(?:\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF])|\uD83C\uDDEE(?:\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9])|\uD83C\uDDFF(?:\uD83C[\uDDE6\uDDF2\uDDFC])|\uD83C\uDDEB(?:\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7])|\uD83C\uDDF5(?:\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE])|\uD83C\uDDE9(?:\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF])|\uD83C\uDDF9(?:\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF])|\uD83C\uDDE7(?:\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF])|[#\*0-9]\uFE0F\u20E3|\uD83C\uDDF1(?:\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE])|\uD83C\uDDE6(?:\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF])|\uD83C\uDDF7(?:\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC])|\uD83C\uDDFB(?:\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA])|\uD83C\uDDFE(?:\uD83C[\uDDEA\uDDF9])|(?:\uD83C[\uDFC3\uDFC4\uDFCA]|\uD83D[\uDC6E\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4-\uDEB6]|\uD83E[\uDD26\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDD6-\uDDDD])(?:\uD83C[\uDFFB-\uDFFF])|(?:\u26F9|\uD83C[\uDFCB\uDFCC]|\uD83D\uDD75)(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u261D\u270A-\u270D]|\uD83C[\uDF85\uDFC2\uDFC7]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC70\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDCAA\uDD74\uDD7A\uDD90\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC]|\uD83E[\uDD18-\uDD1C\uDD1E\uDD1F\uDD30-\uDD36\uDDB5\uDDB6\uDDD1-\uDDD5])(?:\uD83C[\uDFFB-\uDFFF])|(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDEEB\uDEEC\uDEF4-\uDEF9]|\uD83E[\uDD10-\uDD3A\uDD3C-\uDD3E\uDD40-\uDD45\uDD47-\uDD70\uDD73-\uDD76\uDD7A\uDD7C-\uDDA2\uDDB0-\uDDB9\uDDC0-\uDDC2\uDDD0-\uDDFF])|(?:[#*0-9\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23E9-\u23F3\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB-\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u261D\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692-\u2697\u2699\u269B\u269C\u26A0\u26A1\u26AA\u26AB\u26B0\u26B1\u26BD\u26BE\u26C4\u26C5\u26C8\u26CE\u26CF\u26D1\u26D3\u26D4\u26E9\u26EA\u26F0-\u26F5\u26F7-\u26FA\u26FD\u2702\u2705\u2708-\u270D\u270F\u2712\u2714\u2716\u271D\u2721\u2728\u2733\u2734\u2744\u2747\u274C\u274E\u2753-\u2755\u2757\u2763\u2764\u2795-\u2797\u27A1\u27B0\u27BF\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55\u3030\u303D\u3297\u3299]|\uD83C[\uDC04\uDCCF\uDD70\uDD71\uDD7E\uDD7F\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE02\uDE1A\uDE2F\uDE32-\uDE3A\uDE50\uDE51\uDF00-\uDF21\uDF24-\uDF93\uDF96\uDF97\uDF99-\uDF9B\uDF9E-\uDFF0\uDFF3-\uDFF5\uDFF7-\uDFFF]|\uD83D[\uDC00-\uDCFD\uDCFF-\uDD3D\uDD49-\uDD4E\uDD50-\uDD67\uDD6F\uDD70\uDD73-\uDD7A\uDD87\uDD8A-\uDD8D\uDD90\uDD95\uDD96\uDDA4\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA-\uDE4F\uDE80-\uDEC5\uDECB-\uDED2\uDEE0-\uDEE5\uDEE9\uDEEB\uDEEC\uDEF0\uDEF3-\uDEF9]|\uD83E[\uDD10-\uDD3A\uDD3C-\uDD3E\uDD40-\uDD45\uDD47-\uDD70\uDD73-\uDD76\uDD7A\uDD7C-\uDDA2\uDDB0-\uDDB9\uDDC0-\uDDC2\uDDD0-\uDDFF])\uFE0F|(?:[\u261D\u26F9\u270A-\u270D]|\uD83C[\uDF85\uDFC2-\uDFC4\uDFC7\uDFCA-\uDFCC]|\uD83D[\uDC42\uDC43\uDC46-\uDC50\uDC66-\uDC69\uDC6E\uDC70-\uDC78\uDC7C\uDC81-\uDC83\uDC85-\uDC87\uDCAA\uDD74\uDD75\uDD7A\uDD90\uDD95\uDD96\uDE45-\uDE47\uDE4B-\uDE4F\uDEA3\uDEB4-\uDEB6\uDEC0\uDECC]|\uD83E[\uDD18-\uDD1C\uDD1E\uDD1F\uDD26\uDD30-\uDD39\uDD3D\uDD3E\uDDB5\uDDB6\uDDB8\uDDB9\uDDD1-\uDDDD])/g;

    return string.replace(regex, '');
  };

  const removeFirstZeroFromInputField = (string = '') => {
    const regex = /^0$/;

    return string.replace(regex, '');
  };

  function navigateToTerms() {
    navigateTo('Skiply.Account.About.Terms', componentId);
  }

  function navigateToPrivacyPolicy() {
    navigateTo('Skiply.Account.About.Policy', componentId);
  }

  return (
    <Formik
      initialValues={{
        name: '',
        phoneNumber: '',
        emailAddress: '',
        password: '',
        terms: false
      }}
      onSubmit={handleSubmit}
      enableReinitialize
      validationSchema={SignupSchema}
    >
      {(props) => (
        <Container
          {...testProperties('signup-signupform-container-id')}
          keyboardDismissMode={'on-drag'}
        >
          <ScrollContainer>
            <ScrollContent>
              <FormContainer>
                <CountryCodeForm
                  content-desc='signup-phone-input-id'
                  {...testProperties('signup-phone-input-id')}
                  numberOfLines={1}
                  logo={false}
                  label='Phone Number'
                  keyboardType='numeric'
                  returnKeyType='go'
                  maxLength={10}
                  onChangeText={props.handleChange('phoneNumber')}
                  onBlur={props.setFieldTouched}
                  fieldName='phoneNumber'
                  value={removeFirstZeroFromInputField(
                    props.values.phoneNumber
                  )}
                  setCountryCode={setCountryCode}
                  defaultCountryCode={countryCode}
                />
              </FormContainer>
              <Margin />
              <FormContainer>
                <FormInput
                  content-desc='signup-email-input-id'
                  {...testProperties('signup-email-input-id')}
                  numberOfLines={1}
                  //placeholder='add email'
                  logo={false}
                  label='E-mail'
                  keyboardType='email-address'
                  returnKeyType='go'
                  maxLength={40}
                  value={props.values.emailAddress}
                  onChangeText={props.handleChange('emailAddress')}
                  onBlur={props.setFieldTouched}
                  autoCapitalize={'none'}
                  fieldName='emailAddress'
                />
                <FormInput
                  content-desc='signup-name-input-id'
                  {...testProperties('signup-name-input-id')}
                  numberOfLines={1}
                  //placeholder='add name'
                  logo={false}
                  label='Name'
                  keyboardType='default'
                  returnKeyType='go'
                  matches={/[a-zA-Z]+/}
                  maxLength={30}
                  value={props.values.name}
                  onChangeText={props.handleChange('name')}
                  onBlur={props.setFieldTouched}
                  fieldName='name'
                />
                <FormInput
                  content-desc='signup-password-input-id'
                  {...testProperties('signup-password-input-id')}
                  numberOfLines={1}
                  //placeholder='add password'
                  logo={false}
                  label='Password'
                  keyboardType='default'
                  returnKeyType='go'
                  minLength={8}
                  matches={/[a-zA-Z-0-9]+/}
                  toggleShowPassword={toggleShowPassword}
                  secureTextEntry={showPassword}
                  showPW={true}
                  showPWText={showPassword ? 'Show' : 'Hide'}
                  value={removeEmojisFromInputField(props.values.password)}
                  onChangeText={props.handleChange('password')}
                  onBlur={props.setFieldTouched}
                  autoCapitalize={'none'}
                  fieldName='password'
                />
              </FormContainer>

              {/* <FormMessage
            message='Min. 8 characters'
            {...testProperties('min-char-info-box-id')}
          /> */}

              <RadioContainer
                onPress={() =>
                  props.setFieldValue('terms', !props.values.terms)
                }
                {...testProperties('signup-submit-button-id')}
              >
                <RadioButton
                  checked={props.values.terms}
                  buttonType='checkbox'
                  {...testProperties('signup-agree-terms-and-con-button-id')}
                />
                <RadioText>
                  <TermsText>
                    By signing up, you confirm that you agree to our
                    <TextLink
                      onPress={navigateToTerms}
                      {...testProperties('terms-text-link-id')}
                    >
                      {' '}
                      Terms of use{' '}
                    </TextLink>
                    and have read and understood our
                    <TextLink
                      onPress={() =>
                        Linking.openURL(
                          'https://rakbank.ae/wps/portal/footer/privacy-policy'
                        )
                      }
                      {...testProperties('privacy-policy-text-link-id')}
                    >
                      {' '}
                      Privacy Policy
                    </TextLink>
                    .
                  </TermsText>
                </RadioText>
              </RadioContainer>
            </ScrollContent>
          </ScrollContainer>
          <ButtonContainer
            elevation={5}
            style={{
              shadowColor: '#000',
              shadowOffset: {
                width: 0,
                height: 7
              },
              shadowOpacity: 0.43,
              shadowRadius: 9.51,

              elevation: 15
            }}
          >
            <ErrorMessageContainer
              {...testProperties('sign-up-error-message-container-id')}
            >
              {props.errors.name && props.touched.name && (
                <ErrorMessage {...testProperties('error-message-name-id')}>
                  {props.errors.name}
                </ErrorMessage>
              )}
              {props.errors.phoneNumber && props.touched.phoneNumber && (
                <ErrorMessage {...testProperties('error-message-phone-id')}>
                  {props.errors.phoneNumber}
                </ErrorMessage>
              )}

              {props.errors.emailAddress && props.touched.emailAddress && (
                <ErrorMessage {...testProperties('error-message-email-id')}>
                  {props.errors.emailAddress}
                </ErrorMessage>
              )}

              {props.errors.password && props.touched.password && (
                <ErrorMessage {...testProperties('error-message-password-id')}>
                  {props.errors.password}
                </ErrorMessage>
              )}
              {props.errors.terms && props.touched.terms && (
                <ErrorMessage {...testProperties('error-message-email-id')}>
                  {props.errors.terms}
                </ErrorMessage>
              )}
            </ErrorMessageContainer>
            <Button
              testProperties={testProperties('signup-submit-button-id')}
              onPress={props.handleSubmit}
              isLoading={isSigningUp}
              disabled={!props.isValid || isSigningUp}
              primary={props.isValid && !isSigningUp}
            >
              Create account
            </Button>
          </ButtonContainer>
        </Container>
      )}
    </Formik>
  );
};

export default SignupForm;

const Container = styled.View`
  flex: 1;
`;

const ScrollContainer = styled.ScrollView``;

const ScrollContent = styled.View`
  padding: 40px 20px;
`;

const Margin = styled.View`
  margin-bottom: 20px;
`;

const RadioContainer = styled.TouchableOpacity`
  flex-direction: row;
  align-items: center;
  margin: 20px 0;
`;

const RadioText = styled.View`
  margin: 0px 20px;
  color: #36235e;
  font-size: 14px;
  font-family: 'OpenSans-Regular';
  font-weight: normal;
  flex-direction: row;
`;

const TermsText = styled.Text`
  color: rgb(109, 117, 142);
  font-family: OpenSans-Regular;
  font-size: 12px;
  font-weight: normal;
  letter-spacing: 0px;
  line-height: 16px;
  flex-wrap: wrap;
`;

const FormContainer = styled.View`
  background-color: #f5f5f7;
  border-radius: 4px;
  padding: 15px 15px 15px 15px;
`;

const ErrorMessageContainer = styled.View`
  justify-content: center;
  align-items: center;
  padding-bottom: 10px;
`;

const ErrorMessage = styled.Text`
  text-align: center;
  font-family: 'OpenSans-Regular';
  color: #d9363b;
  font-size: 12px;
  font-weight: normal;
  margin-bottom: 5px;
`;

const TextLink = styled.Text`
  color: rgb(64, 44, 168);
  font-family: OpenSans-Regular;
  text-decoration: underline;
  font-size: 12px;
  font-weight: normal;
  line-height: 16px;
`;

const ButtonContainer = styled.View`
  padding: 10px 20px 20px;
  background: #ffffff;
`;

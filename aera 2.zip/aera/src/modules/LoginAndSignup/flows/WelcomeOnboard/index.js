import React, { useEffect, useState } from 'react';
import { Animated, Easing } from 'react-native';
import styled from 'styled-components/native';
import LoginFlowFooter from 'components/common/Footers/LoginFlowFooter';
import selectedCopy from '../../../../i18n/copy';
import { testProperties } from '../../../../helpers/testProperties';
import { navigateTo } from 'navigation';

const copy =
  selectedCopy.components.modules.LoginAndSignup.flows.WelcomeOnboard;

const checkMarkBigWhite = require('../../../../../assets/icons/common/checkMarkBigWhite.png');

const WelcomeOnboard = ({ componentId }) => {
  const [scaleAnimation, setScaleAnimation] = useState(new Animated.Value(0));

  useEffect(function AnimateContent() {
    Animated.timing(
      // Animate over time
      scaleAnimation, // The animated value to drive
      {
        useNativeDriver: true,
        toValue: 1, // Animate to opacity: 1 (opaque)
        duration: 1000, // Make it take a while,
        easing: Easing.quad
      }
    ).start();
    const timer = setTimeout(() => {
      navigateTo('Skiply.Onboarding.AddPaymentMethod', componentId);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <Container {...testProperties('signup-welcome-onboard-container-id')}>
      <InnerContainer
        style={{
          transform: [
            {
              scaleX: scaleAnimation
            },
            {
              scaleY: scaleAnimation
            }
          ]
        }}
      >
        <LogoContainer>
          <Image source={checkMarkBigWhite} />
        </LogoContainer>
        <WelcomeMessage>{copy.message}</WelcomeMessage>
      </InnerContainer>
    </Container>
  );
};

export default WelcomeOnboard;

const Container = styled.View`
  flex: 1;
  background-color: white;
`;

const InnerContainer = styled(Animated.View)`
  flex: 1;
  align-items: center;
  justify-content: center;
`;

const LogoContainer = styled.View`
  width: 90px;
  height: 90px;
  background: rgb(64, 44, 168);
  border-top-left-radius: 40px;
  border-bottom-right-radius: 40px;
  margin-bottom: 40px;
  align-items: center;
  justify-content: center;
`;

const Image = styled.Image`
  height: 30px;
  width: 33px;
`;

const WelcomeMessage = styled.Text`
  color: rgb(13, 25, 67);
  font-size: 28px;
  font-family: 'TeshrinAR+LT-Heavy';
  font-weight: 900;
  text-align: center;
  line-height: 36px;
`;

import React from 'react';
import { storiesOf } from '@storybook/react-native';
import SchoolsEduCard from './SchoolsEduCard';

// TODO: Get notes working.

storiesOf('Modules|Home/Content Cards/Schools and Education Card', module)
  .add('Schools and Education Card', () => <SchoolsEduCard />)
  .add('Schools and Education Card - Pending', () => (
    <SchoolsEduCard pending />
  ));

import React from 'react';
import styled from 'styled-components/native';
import { testProperties } from '../../../helpers/testProperties';

const background = require('../../../../assets/backgrounds/contentcardbg.png');

const ContentCard = (props) => {
  return (
    <Container {...testProperties('content-content-card-container-id')}>
      <Background source={background} />
      <InnerContainer
        {...testProperties('content-content-card-imagebackground-id')}
      >
        <SubHeader {...testProperties('content-content-card-subtitle-id')}>
          Welcome to Skiply
        </SubHeader>
        <MarginFirst />
        <Header {...testProperties('content-content-card-title-id')}>
          Let’s skip the line
        </Header>
        <MarginSecond />
        <Paragraph {...testProperties('content-content-card-paragraph-id')}>
          We are on a mission to make waiting in line to order or pay a thing of
          the past.
        </Paragraph>
      </InnerContainer>
    </Container>
  );
};

export default ContentCard;

const Container = styled.View`
  height: 260px;
  overflow: hidden;
  margin: 15px 20px;
  background-color: blue;
  border-top-left-radius: 40px;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 40px;
  border-bottom-left-radius: 4px;
`;
const InnerContainer = styled.View`
  margin: 40px 20px 0 20px;
`;

const SubHeader = styled.Text`
  color: rgb(255, 255, 255);
  font-family: OpenSans-Regular;
  font-size: 12px;
`;
const Header = styled.Text`
  color: rgb(255, 255, 255);
  font-family: 'TeshrinAR+LT-Heavy';
  font-size: 20px;
  font-weight: 900;
`;
const Paragraph = styled.Text`
  color: rgb(255, 255, 255);
  font-family: OpenSans-Regular;
  font-size: 12px;
`;

const Background = styled.Image`
  position: absolute;
  width: 100%;
  width: 100%;
  top: 0;
  left: 0;
`;

const MarginFirst = styled.View`
  margin-bottom: 5px;
`;
const MarginSecond = styled.View`
  margin-bottom: 20px;
`;

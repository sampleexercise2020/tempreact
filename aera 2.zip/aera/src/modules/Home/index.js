import React, { useEffect, useState, useRef } from 'react';
import { Animated, ActivityIndicator, Dimensions, Text } from 'react-native';
import SchoolPaymentCard from './components/SchoolPaymentCard';
import CompleteProfileBtn from './components/CompleteProfileBtn';
import TabHeader from 'components/common/Header/TabHeader';
import HeaderCart from '../Discover/School/flows/Store/ShoppingCart/components/HeaderCart';
import styled from 'styled-components/native';
import { navigateTo, showOverlay, popToRoot } from 'navigation';
import {
  useStore,
  useActions,
  useStoreActions,
  useStoreState
} from 'easy-peasy';
import SchoolsEduCard from './components/SchoolsEduCard';
import R from 'ramda';
import CollapsibleHeader from '../../components/common/Header/CollapsibleHeader';
import selectedCopy from 'src/../i18n/copy';
import ContentCardWithOnpress from '../Promotion/components/ContentCardWithOnpress';
import CircleIndicator from 'components/common/CircleIndicator/index';
import { testProperties } from '../../helpers/testProperties';
import { AsyncStorage } from 'react-native';

const copy = selectedCopy.components.common.Header.HomeWelcomeHeader;

const contentCardList = [
  {
    imageBackgroundImg: require('../../../assets/images/landing-school2-big.png'),
    id: 1,
    title: "Let's skip the line",
    categoryTitle: '',
    onPressActivated: false,
    secondSubtitle: 'Parents in UAE are already skipping the line.'
  },
  {
    imageBackgroundImg: require('../../../assets/images/landing-boy2-big.png'),
    id: 3,
    title: "Let's skip the line",
    onPressActivated: false,
    categoryTitle: '',
    secondSubtitle:
      'We collaborate with more than 20 schools for cashless payments, adding more happiness each day.'
  },
  {
    cardBackgroundColor: '#402ca8',
    id: 2,
    title: 'Convenient meets secure',
    secondSubtitle:
      'For us innovation with bank-level security comes natural. Because we are a bank.',
    contentCardIcon: require('../../../assets/images/security.png'),
    onPressActivated: false,
    smallIcon: true
  }
];

const navigateToOffers = (componentId) => {
  navigateTo('Skiply.Promotion.Offers.OffersCategoriesScreen', componentId);
};

const offerContentCard = {
  id: 3,
  title: 'RAKBANK card offers',
  onPressActivated: false,
  cardBackgroundColor: '#f15b60',
  backgroundLinkColor: '#c0484c',
  linktext: 'Check all offers',
  secondSubtitle:
    'Spending is now even more rewarding with RAKBANK Credit, Debit and Prepaid Cards.',
  footerLinkVisible: true,
  containerHeight: 260,
  contentCardIcon: require('../../../assets/images/dark-gift.png'),
  linkOnPress: navigateToOffers
};


const Home = ({ componentId }) => {
  const firstName = useStore((state) => state.profile.data.firstName);
  const userPhoneNumber = useStore((state) => state.profile.data.phoneNumber);
  const student = useStore((state) => state.student);
  const cards = useStore((state) => state.cards.items);
  const savedStudents = student.lists.saved;
  const receipts = useStore((state) => state.receipts.results);
  const fetchCarts = useActions((actions) => actions.cart.fetch);
  const fetchStudentProfiles = useActions(
    (actions) => actions.student.fetchStudentProfiles
  );
  const handleBiometricLoading = useStoreActions(
    ({ session }) => session.handleBiometricLoading
  );
  const shouldTakeATour = useStoreState(({ global }) => global.shouldTakeATour);
  const setShouldTakeATour = useStoreActions(
    ({ global }) => global.setShouldTakeATour
  );
  const fetchReceipts = useActions((actions) => {
    return actions.receipts.fetch;
  });

  const scrollView = useRef();
  const [scrollIndex, setScrollIndex] = useState(0);
  const screenWidth = Dimensions.get('window').width;

  const handleScroll = (e) => {
    const offset = e.nativeEvent.contentOffset.x;
    const index = Math.ceil(offset / screenWidth);

    setScrollIndex(index);
  };

  useEffect(() => {
    fetchStudentProfiles();
    fetchCarts();
    handleBiometricLoading(false);
    fetchReceipts();
  }, []);

  useEffect(() => {
    if (shouldTakeATour) {
      handleOnboarding();
    }
  }, [shouldTakeATour]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (scrollIndex < 2) {
        scrollView.current.scrollTo({ x: screenWidth * (scrollIndex + 1) });
        setScrollIndex((index) => index + 1);
      } else {
        scrollView.current.scrollTo({ x: 0 });
        setScrollIndex((_) => 0);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, [scrollIndex]);

  function navigateToHome() {
    popToRoot(componentId);
  }

  async function handleOnboarding() {
    const isOnboardingDone =
      (await AsyncStorage.getItem('ONBOARDING_DONE')) == 'true';

    setShouldTakeATour(false);

    if (!isOnboardingDone) {
      await AsyncStorage.setItem('ONBOARDING_DONE', 'true');
      setTimeout(() => {
        navigateTo('Skiply.Onboarding.Slider', componentId, {
          onClose: navigateToHome
        });
      }, 1500);
    }
  }

  function navigateToHome() {
    popToRoot(componentId);
  }

  return (
    <CollapsibleHeader
      {...testProperties('home-welcomeheader-header-id')}
      extendedHeight={134}
      collapsedHeight={0}
      isCurved={true}
      alignBigContentLeft={true}
      isHome={true}
      bigContent={
        <HeaderContent>
          <Left>
            <TabHeader
              text={copy.welcome + ' ' + firstName}
              testId={'home-welcomeheader'}
            />
          </Left>
          <Right>
            <HeaderCart componentId={componentId} />
          </Right>
        </HeaderContent>
      }
    >
      <Container as={Animated.ScrollView}>
        <CarouselWrapper {...testProperties('home-promo-card-container-id')}>
          <ContentCardCarouselContainer
            ref={scrollView}
            horizontal
            showsHorizontalScrollIndicator={false}
            snapToAlignment='center'
            decelerationRate='fast'
            snapToInterval={screenWidth}
            onMomentumScrollEnd={handleScroll}
            {...testProperties('home-promo-carousel-container-id')}
          >
            {contentCardList.map((item) => (
              <ContentCardWithOnpress
                key={item.id}
                backgroundLinkColor={item.backgroundLinkColor}
                linktext={item.linktext}
                imageBackgroundImg={item.imageBackgroundImg}
                title={item.title}
                categoryTitle={item.categoryTitle}
                footerLinkVisible={item.footerLinkVisible}
                cardBackgroundColor={item.cardBackgroundColor}
                secondSubtitle={item.secondSubtitle}
                contentCardIcon={item.contentCardIcon}
                componentId={componentId}
                smallIcon={item.smallIcon}
              />
            ))}
          </ContentCardCarouselContainer>
        </CarouselWrapper>
        <ContentCardCarouselCircleIndicatorWrapper>
          {contentCardList.map((item, i) => (
            <CircleIndicator
              key={item.id}
              darkActive={i === scrollIndex}
              dark
            />
          ))}
        </ContentCardCarouselCircleIndicatorWrapper>
        {receipts.length > 0 ? (
          <LatestActivityContainer>
            <Title {...testProperties('home-complete-profile-header-title-id')}>
              Latest activity
            </Title>
            <CompleteProfileBtn
              onPress={() =>
                navigateTo('Skiply.Purchases.Receipt', componentId, {
                  receipt: receipts[0]
                })
              }
              btnText='Your latest activity'
              image={require('src/../../assets/icons/common/card-wbg.png')}
            />
          </LatestActivityContainer>
        ) : null}
        {student.isLoading ? (
          <LoadingContainer>
            <ActivityIndicator size='large' />
          </LoadingContainer>
        ) : R.isEmpty(savedStudents) ? (
          <SchoolPaymentCard
            {...testProperties('home-schoolpaymentcard-id')}
            componentId={componentId}
          />
        ) : (
          <SchoolsEduCard
            {...testProperties('home-schoolseducard-id')}
            componentId={componentId}
          />
        )}
        {(userPhoneNumber && userPhoneNumber.length < 2) || cards.length < 1 ? (
          <CompleteProfileContainer>
            <Title {...testProperties('home-complete-profile-header-title-id')}>
              Complete profile
            </Title>
            {userPhoneNumber && userPhoneNumber.length < 2 ? (
              <CompleteProfileBtn
                onPress={() =>
                  navigateTo('Skiply.Account.Profile.EditProfile', componentId)
                }
                image='src/../../../../assets/icons/common/profile.png'
                btnText='Add profile information'
                image={require('src/../../assets/icons/common/profile-wbg.png')}
              />
            ) : null}
            {cards.length < 1 ? (
              <CompleteProfileBtn
                onPress={() =>
                  navigateTo('Skiply.Account.Payments.AddMethod', componentId)
                }
                btnText='Setup payment method'
                image={require('src/../../assets/icons/common/card-wbg.png')}
              />
            ) : null}
          </CompleteProfileContainer>
        ) : null}
        {/* offers content card */}
        <OffersCardContainer>
          <ContentCardWithOnpress
            key={offerContentCard.id}
            backgroundLinkColor={offerContentCard.backgroundLinkColor}
            linktext={offerContentCard.linktext}
            imageBackgroundImg={offerContentCard.imageBackgroundImg}
            title={offerContentCard.title}
            categoryTitle={offerContentCard.categoryTitle}
            footerLinkVisible={offerContentCard.footerLinkVisible}
            cardBackgroundColor={offerContentCard.cardBackgroundColor}
            secondSubtitle={offerContentCard.secondSubtitle}
            contentCardIcon={offerContentCard.contentCardIcon}
            containerHeight={offerContentCard.containerHeight}
            linkOnPress={offerContentCard.linkOnPress}
            componentId={componentId}
          />
        </OffersCardContainer>
        {/* offers content card */}
      </Container>
    </CollapsibleHeader>
  );
};

export default Home;

const Container = styled.ScrollView`
  height: 100%;
`;

const LoadingContainer = styled.View`
  margin: 20px 0;
`;
const CompleteProfileContainer = styled.View`
  margin-bottom: 20px;
`;
const Title = styled.Text`
  color: rgb(13, 25, 67);
  font-family: OpenSans-Bold;
  font-size: 16px;
  font-weight: bold;
  margin: 10px 0 15px 20px;
  box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.08);
`;

const ContentCardCarouselContainer = styled.ScrollView``;

const ContentCardCarouselCircleIndicatorWrapper = styled.View`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin: 15px 0;
`;

const CarouselWrapper = styled.View`
  flex: 1;
`;

const OffersCardContainer = styled.View`
  margin-bottom: 40px;
`;

const LatestActivityContainer = styled.View`
  margin-bottom: 20px;
`;

const HeaderContent = styled.View`
  flex-direction: row;
  padding: 0 20px;
  width: 100%;
  position: relative;
`;
const Left = styled.View`
  flex-grow: 1;
  justify-content: center;
`;
const Right = styled.View``;

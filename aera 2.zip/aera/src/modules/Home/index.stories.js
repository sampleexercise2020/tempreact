import React from 'react';
import { storiesOf } from '@storybook/react-native';
import Home from './index';

// TODO: Get notes working.

storiesOf('Modules|Home', module).add('Home Page Logged in', () => <Home />);

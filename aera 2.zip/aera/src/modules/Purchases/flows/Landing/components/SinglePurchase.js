import React from 'react';
import styled from 'styled-components/native';
import Button from 'components/common/Button/Button';
import SchoolHeader from '../../../../Discover/School/flows/AddStudent/components/SchoolHeader';
import selectedCopy from '../../../../../i18n/copy';

const copy =
  selectedCopy.components.modules.Purchases.flows.Landing.components
    .SinglePurchase;

const SinglePurchase = ({
  date,
  refNumber,
  schoolName,
  schoolAddress,
  onPress
}) => {
  return (
    <Container>
      <SchoolHeader
        bgTransparent
        schoolName={schoolName}
        schoolAddress={schoolAddress}
        hideArrow={true}
      />
      <InnerContainer>
        <Date>{date}</Date>
        <RefNumber>
          {copy.ref} #{refNumber}
        </RefNumber>
        <Button primary onPress={onPress}>
          {copy.viewReceipt}
        </Button>
      </InnerContainer>
    </Container>
  );
};

export default SinglePurchase;

const Container = styled.View`
  background: rgb(245, 245, 247);
  flex-wrap: wrap;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 40px;
  border-top-left-radius: 40px;
  border-top-right-radius: 4px;
  margin-bottom: 30px;
`;

const InnerContainer = styled.View`
  margin: 0 20px 30px 20px;
`;

const Date = styled.Text`
  margin-top: -3px;
  font-size: 12px;
  font-family: 'OpenSans-Regular';
  color: rgb(109, 117, 142);
`;

const RefNumber = styled.Text`
  color: rgb(13, 25, 67);
  font-family: OpenSans-Regular;
  font-size: 16px;
  font-weight: normal;
  margin-bottom: 20px;
`;

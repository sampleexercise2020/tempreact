import React from 'react';
import { storiesOf } from '@storybook/react-native';
import SinglePurchase from './SinglePurchase';

storiesOf('Modules|Purchases/SinglePurchase', module).add(
  'SinglePurchase',
  () => (
    <SinglePurchase
      schoolName='Brilliant Int School'
      schoolAddress='152 Adress, Dubai'
      date='2019-05-02'
      refNumber='8934-234-234'
    />
  )
);

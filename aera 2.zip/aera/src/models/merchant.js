import { action, thunk } from 'easy-peasy';
import axios from 'axios';
import { API_URL, API_KEY } from 'components/../config';
import amendResponseObject from 'helpers/amendResponseObject';

const Merchant = {
  data: null,
  currency: '',
  // name: 'Skiply School of Excellence DSO',
  // id: null,
  // image:
  //   'https://testmssbucket.s3-eu-west-1.amazonaws.com/SkiplySchoolofExcellence/56ad1935-bbc8-4741-aafd-8c76a201d776.png',
  // address: 'Silicon Oasis, Dubai, UAE',
  id: '514336',
  customFields: [],
  isLoading: false,
  errorMessage: '',

  // actions
  setData: action((state, payload) => {
    state.data = payload;
  }),
  setCurrency: action((state, payload) => {
    state.currency = payload;
  }),
  setCustomFields: action((state, payload) => {
    state.customFields = payload;
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),

  // thunks
  fetch: thunk(async (actions, payload, { getStoreState }) => {
    const state = getStoreState();
    const endpoint = API_URL + 'skiply-schprod/schools/' + payload;

    const response = axios({
      method: 'get',
      url: endpoint,
      headers: {
        'X-Auth-Token': state.session.token,
        Authorization: state.session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        console.log('Merchant fetch success response', response);
        actions.setData(response.data);
        actions.setCurrency(response.data.defaultCurrency);
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Merchant fetch error response:', response);
        return response;
      });

    return response;
  }),

  fetchCustomFields: thunk(async (actions, payload, { getStoreState }) => {
    const state = getStoreState();
    const endpoint =
      API_URL +
      'skiply-studregister/beneficiarycustomfields/' +
      state.merchant.data.id;

    actions.setIsLoading(true);

    const response = await axios({
      method: 'get',
      url: endpoint,
      headers: {
        'X-Auth-Token': state.session.token,
        Authorization: state.session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        const customFields = response.data.list;
        console.log('Custom fields success response');
        actions.setCustomFields(customFields);
        return response;
      })
      .catch((error) => {
        const response = amendResponseObject(error.response);
        console.log('Custom fields error response :', response);
        actions.setErrorMessage(response.message);
        return response;
      });

    actions.setIsLoading(false);

    return response;
  }),

  fetchCustomFieldsEditStudent: thunk(
    async (actions, payload, { getStoreState }) => {
      const state = getStoreState();
      console.log('request for fetch custoime field merchant id is ', payload);
      const endpoint =
        API_URL + 'skiply-studregister/beneficiarycustomfields/' + payload;

      actions.setIsLoading(true);

      const response = await axios({
        method: 'get',
        url: endpoint,
        headers: {
          'X-Auth-Token': state.session.token,
          Authorization: state.session.authorization,
          apikey: API_KEY
        }
      })
        .then(amendResponseObject)
        .then((response) => {
          const customFields = response.data.list;
          console.log('Custom fields success response');
          actions.setCustomFields(customFields);
          return response;
        })
        .catch((error) => {
          const response = amendResponseObject(error.response);
          console.log('Custom fields error response :', response);
          actions.setErrorMessage(response.message);
          return response;
        });

      actions.setIsLoading(false);

      return response;
    }
  )
};

export default Merchant;

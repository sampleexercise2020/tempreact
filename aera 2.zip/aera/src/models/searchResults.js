import { action, thunk } from 'easy-peasy';
import axios from 'axios';
import { API_URL, API_KEY } from 'components/../config';
import amendResponseObject from 'helpers/amendResponseObject';

// This store contains the search results from the Discovery screen

const SearchResults = {
  results: [],
  locationResults: [],
  isLoading: false,
  errorMessage: '',
  componentId: null,

  // actions
  setComponentId: action((state, payload) => {
    state.componentId = payload;
  }),
  searched: action((state, payload) => {
    state.results = payload;
  }),
  searchedLocation: action((state, payload) => {
    console.log('Location search payload: ', payload);
    state.locationResults = payload;
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),

  // thunks
  // Takes nothing, queryString or lat and long
  search: thunk(async (actions, payload = {}, { getStoreState }) => {
    actions.setIsLoading(true);

    const queryParams = {
      latitude: payload.latitude,
      longitude: payload.longitude,
      queryString: payload.queryString
    };

    const endpoint = `${API_URL}skiply-schprod/schools/query`;
    const response = await axios({
      cancelToken: payload.call.token,
      method: 'get',
      url: endpoint,
      params: queryParams,
      headers: {
        'X-Auth-Token': getStoreState().session.token,
        Authorization: getStoreState().session.authorization,
        apikey: API_KEY
      }
    })
      .then(amendResponseObject)
      .then((response) => {
        const schools = response.data.list;

        console.log('School search successresponse');

        if (payload.latitude) {
          actions.searchedLocation(schools);
        } else {
          actions.searched(schools);
        }

        return response;
      })
      .catch((error) => {
        const isCancelled = axios.isCancel(error);
        let response = amendResponseObject(error.response, isCancelled);

        console.log('School search error response: ', response);

        return response;
      });

    return response;
  })
};

export default SearchResults;

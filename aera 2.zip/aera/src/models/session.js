import { Alert } from 'react-native';
import { action, thunk } from 'easy-peasy';
import axios from 'axios';
import { API_URL, API_KEY } from 'components/../config';
import { reset } from 'store';
import SecureAPI from '../crypto/SecureAPI';
import amendResponseObject from 'helpers/amendResponseObject';

import { Navigation } from 'react-native-navigation';
import { root, loginRoot } from '../navigation/root';

const Session = {
  emailAddress: '',
  password: '',
  token: '',

  // Reset and Update Password
  otpToken: '',
  otpPin: '',
  existingQkrUser: false,
  isLoading: false,
  errorMessage: '',
  resetPasswordFetchDetails: '',
  isBiometricLoading: false,

  // actions
  setErrorMessage: action((state, payload) => {
    state.errorMessage = payload;
  }),
  setEmailAddress: action((state, payload) => {
    state.emailAddress = payload;
  }),
  setPassword: action((state, payload) => {
    state.password = payload;
  }),
  setIsLoading: action((state, payload) => {
    state.isLoading = payload;
  }),
  setToken: action((state, payload) => {
    state.token = payload;
  }),
  removeToken: action((state, payload) => {
    console.log('Removing token!');
    state.token = null;
  }),
  setOtpToken: action((state, payload) => {
    state.otpToken = payload;
  }),
  setExistingQkrUser: action((state, payload) => {
    state.existingQkrUser = payload;
  }),
  setResetPasswordFetchDetails: action((state, payload) => {
    state.resetPasswordFetchDetails = payload;
  }),
  clearPasswordResetData: action((state, _payload) => {
    state.resetPasswordFetchDetails = '';
    state.otpToken = '';
  }),
  setAuthorization: action((state, payload) => {
    state.authorization = payload;
  }),
  handleBiometricLoading: action((state, payload) => {
    state.isBiometricLoading = payload;
  }),
  expireSession: action((state, payload) => {
    actions.expire();
  }),

  // thunks
  fetch: thunk(async (actions) => {
    const endpoint = API_URL + 'skiply-userprofile/login';

    actions.setIsLoading(true);

    const data = await axios({
      method: 'get',
      url: endpoint
    })
      .then((response) => {
        return response.clear.body;
      })
      .catch((error) => actions.setErrorMessage(error.response.code));
    actions.setToken(data.accessToken.token);
    actions.setIsLoading(false);
  }),
  login: thunk(async (actions, payload) => {
    const endpoint = API_URL + 'skiply-auth/login';
    let headers = {
      'Content-Type': 'application/json',
      apikey: API_KEY
    };
    let api = new SecureAPI();
    const response = await api
      .request(endpoint, 'POST', headers, payload)
      .then((response) => {
        actions.setPassword(payload.password);
        actions.setEmailAddress(payload.emailAddress);
        return {
          success: true,
          data: response.body
        };
      })
      .catch((error) => {
        console.log('Login error:', error);
        if (error.code !== 'Y') {
          return {
            success: false,
            message: error.message,
            errorCode: error.errorCode
          };
        } else {
          return {
            success: false,
            message: error
          };
        }
      });

    return response;
  }),
  signup: thunk(async (actions, payload, { dispatch }) => {
    const endpoint = API_URL + 'skiply-auth/profile';
    let headers = {
      'Content-Type': 'application/json',
      apikey: API_KEY
    };
    let api = new SecureAPI();

    console.log('Sign up payload: ', payload);

    const response = await api
      .request(endpoint, 'POST', headers, payload)
      .then((response) => {
        actions.setPassword(payload.password);
        actions.setEmailAddress(payload.emailAddress);
        return {
          success: true,
          data: response.body
        };
      })
      .catch((error) => {
        console.log('Error:', error);
        if (error.code !== 'Y') {
          return {
            success: false,
            message: error.message,
            errorCode: error.errorCode
          };
        } else {
          return {
            success: false,
            message: error
          };
        }
      });

    return response;
  }),
  verifyOtp: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-auth/verifyOTP';
    let headers = {
      'Content-Type': 'application/json',
      apikey: API_KEY
    };
    const data = await axios({
      method: 'post',
      data: {
        countryCode: payload.countryCode,
        errorMessage: payload.errorMessage,
        otp: payload.errorMessage,
        otpToken: getStoreState().session.otpToken,
        verifierType: 'What is this?',
        verifierValue: 'What is this?'
      },
      url: endpoint,
      headers: headers
    })
      .then((response) => {
        return response.data.body;
      })
      .catch((error) => {
        console.log(error.response);
      });
  }),
  updatePassword: thunk(async (actions, payload, { getStoreState }) => {
    const endpoint = API_URL + 'skiply-userprofile/updatePassword';
    let headers = {
      'Content-Type': 'application/json',
      apikey: API_KEY
    };
    actions.setIsLoading(true);
    actions.setErrorMessage(null);

    const data = await axios({
      method: 'post',
      data: {
        emailAddress: getStoreState().session.emailAddress,
        existingUser: true,
        newPassword: payload,
        otpToken: getStoreState().session.otpToken
      },
      url: endpoint,
      headers: headers
    })
      .then((response) => {
        return response.data.body;
      })
      .catch((error) => {
        console.log(error.response);
        actions.setErrorMessage('Error Placeholder');
      });
    actions.setIsLoading(false);
  }),
  resendOtp: thunk(async (actions, payload, { getStoreState }) => {
    let endpoint = '';

    console.log('Resend OTP Payload: ', payload);

    if (getStoreState().session.existingQkrUser) {
      endpoint = API_URL + 'skiply-auth/resendOTP';
    } else {
      endpoint = API_URL + 'skiply-auth/resendotpcustom';
    }

    console.log('OtpToken: ', getStoreState().session.otpToken);

    let headers = {
      'Content-Type': 'application/json',
      apikey: API_KEY
    };

    const data = await axios({
      method: 'post',
      data: {
        otpToken: getStoreState().session.otpToken,
        emailAddress: getStoreState().session.emailAddress,
        ...payload
      },
      url: endpoint,
      headers: headers
    })
      .then((response) => {
        console.log('Reset OTP success', response);
        console.log('Status: ', response.data.status.code);
        actions.setOtpToken(response.data.body.otpToken);
        return response.data.status.code;
      })
      .catch((error) => {
        console.error('Reset OTP error:', error);
        console.log('Error message: ', error.response.data.status.message);
        return error.response.data.status.message;
      });

    console.log('Resend OTP Data: ', data);

    return data;
  }),
  logout: thunk(async (actions) => {
    console.log('Logging out!');
    actions.removeToken();
    reset();
  }),
  resetPassword: thunk(async (actions, payload) => {
    const endpoint = API_URL + 'skiply-auth/';
    const fetchDetailsEndpoint =
      endpoint + 'forgotpassword/fetchdetails/' + payload;
    let headers = {
      'Content-Type': 'application/json',
      apikey: API_KEY
    };

    actions.setIsLoading(true);
    actions.setErrorMessage(null);
    actions.clearPasswordResetData();
    actions.setEmailAddress(payload);

    const response = await axios({
      method: 'get',
      url: fetchDetailsEndpoint,
      headers: headers
    })
      .then((response) => {
        console.log('Success: Fetched Details for Password Reset Flow');
        actions.setResetPasswordFetchDetails(response.data.body);
        return response.status;
      })
      .catch((error) => {
        console.log(
          'Fail: Fetched Details not working: ',
          error.response.data.status.message
        );
        try {
          if (error.response.data.status.message == 'invalid email address') {
            actions.setErrorMessage(
              'The email ID is not registered on Skiply.\nPlease sign up and login.'
            );
          } else {
            actions.setErrorMessage(error.response.data.status.message);
          }
        } catch (error) {
          actions.setErrorMessage('Failed to fetch details');
        }
      });
    actions.setIsLoading(false);
    return response;
  }),
  forgotpassword: thunk(async (actions, payload) => {
    const endpoint = API_URL + 'skiply-auth/';
    const resetPasswordEndpoint = endpoint + 'forgotpassword/' + payload;

    actions.setIsLoading(true);
    actions.setExistingQkrUser(true);

    let headers = {
      'Content-Type': 'application/json',
      apikey: API_KEY
    };

    const response = await axios({
      method: 'get',
      url: resetPasswordEndpoint,
      headers: headers
    })
      .then((response) => {
        console.log(
          'Success: Initiated forgot password for existingqkruser',
          response.data.body.otpToken
        );
        actions.setOtpToken(response.data.body.otpToken);
        return response.status;
      })
      .catch((error) => {
        console.log(
          'Fail:forgot password for existingqkruser: ',
          error.response.data.status.message
        );
        try {
          actions.setErrorMessage(error.response.data.status.message);
        } catch (error) {
          actions.setErrorMessage('Failed to set token');
        }
      });
    actions.setIsLoading(false);

    return response;
  }),
  forgotPasswordCustom: thunk(
    async (actions, payload, { getStoreState, dispatch }) => {
      const endpoint = API_URL + 'skiply-auth/forgotpasswordcustom';

      actions.setIsLoading(true);
      actions.setExistingQkrUser(false);

      let headers = {
        'Content-Type': 'application/json',
        apikey: API_KEY
      };

      const response = await axios({
        method: 'post',
        data: payload,
        url: endpoint,
        headers: headers
      })
        .then((response) => {
          console.log(
            'Success: Send Phone Number',
            response.data.body.otpToken
          );
          actions.setOtpToken(response.data.body.otpToken);
          return response.status;
        })
        .catch((error) => {
          console.log(
            'Fail: Could not send phone number successfully: ',
            error.response.data.status.message
          );
          actions.setErrorMessage(error.response.data.status.message);
        });

      actions.setIsLoading(false);
      return response;
    }
  ),
  verifyOtpCustom: thunk(
    async (actions, payload, { getStoreState, dispatch }) => {
      const endpoint = API_URL + 'skiply-auth/' + 'verifyotpcustom';

      actions.setIsLoading(true);

      let headers = {
        'Content-Type': 'application/json',
        apikey: API_KEY
      };

      const response = await axios({
        method: 'post',
        data: payload,
        url: endpoint,
        headers: headers
      })
        .then((response) => {
          if (response.data.body.success) {
            actions.setAuthorization(response.data.body.authorization);
            return response.data.body.success;
          } else {
            return response.data.body.success;
          }
        })
        .catch((error) => {
          console.log(
            'Fail: DID NOT VERIFY: ',
            error.response.data.status.message
          );
          actions.setErrorMessage(error.response.data.status.message);
        });

      actions.setIsLoading(false);
      return response;
    }
  ),
  expire: thunk(async (actions, payload, { dispatch }) => {
    setTimeout(() => {
      dispatch.cart.setIsFloatingCart(false);
    }, 200);

    Alert.alert(
      'Session Expired',
      'Your session has expired. Please login again.',
      [
        {
          text: 'OK',
          onPress: () => {
            actions.logout().then(() => {
              Navigation.setRoot({ root: loginRoot })
                .then(console.log)
                .catch(console.log);
            });
          }
        }
      ]
    );
  })
};

export default Session;

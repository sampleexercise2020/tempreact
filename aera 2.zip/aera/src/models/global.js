import { action, thunk } from 'easy-peasy';
import axios from 'axios';

const Global = {
  showFloating: false,
  didInitialize: false,
  shouldTakeATour: false,

  // actions
  setShowFloating: action((state, payload) => {
    state.showFloating = payload;
  }),
  setDidInitialize: action((state, payload) => {
    state.didInitialize = payload;
  }),
  setShouldTakeATour: action((state, payload) => {
    state.shouldTakeATour = payload;
  })
};

export default Global;

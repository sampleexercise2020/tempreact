const convertDate = (unixDate) => {
  let date = new Date(unixDate);
  let month = date.getUTCMonth() + 1;
  month.length == 1 ? (month = '0' + month) : null; //months from 1-12
  let day = date.getUTCDate();
  day.length == 1 ? (day = '0' + day) : null;
  let year = date.getUTCFullYear();

  return day + '-' + month + '-' + year;
};

export default convertDate;

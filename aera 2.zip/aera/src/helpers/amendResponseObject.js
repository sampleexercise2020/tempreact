const getResponseStatus = (response, isCancelled) => {
  if (isCancelled) {
    return 'cancelled';
  } else {
    return response && response.status;
  }
};

const amendResponseObject = (response, isCancelled = false) => {
  if (response) {
    return {
      status: getResponseStatus(response, isCancelled),
      message: response.data.status ? response.data.status.message : '',
      data: response.data && response.data.body
    };
  } else {
    return {
      status: getResponseStatus(response, isCancelled),
      message: response && response.data && response.data.status,
      data: null
    };
  }
};

export default amendResponseObject;

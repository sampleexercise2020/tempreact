import { Platform } from 'react-native';

export function testProperties(id) {
  if (Platform.OS === 'ios') {
    return { testID: `test-${id}` };
  } else {
    return { accessibilityLabel: `test-${id}` };
  }
}

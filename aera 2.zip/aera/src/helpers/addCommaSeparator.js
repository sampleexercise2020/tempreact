export const addCommaSeparator = (numb) =>
  numb
    .toString()
    .split('')
    .reduceRight((acc, item) => {
      let [firstEleme = '', ...rest] = acc;
      return firstEleme.length && firstEleme.length % 3 === 0
        ? [item, ...acc]
        : [item + firstEleme, ...rest];
    }, [])
    .join(',');

export default {
  color: {
    // TODO: Naming convention needs to be a bit better here.
    brand: '#675391',
    brandDark: '#36235E',
    primary: '#0D857B',
    cta: '#1E5EAF',
    ctaDark: '#16216A',
    notice: 'rgba(232, 181, 184, 0.16)', // --> #E8B5B8 with 16% opacity.
    warning: '#F15B60',
    disabled: '#CECECE',
    listItemDivider: 'rgba(151,151,151, 0.2)',
    inputBorderColor: '#979797',
    //------------------------------

    //NEW NAME CONVENTIONS:
    primary: {
      primaryCTA: '#0D857B', //buttons
      secondaryCTA: '#4f2c94', //links & prices
      primaryText: '#30224d', //page headlines
      bulkText: '#333333', //text
      white: '#ffffff',
      warning: '#d9363b',
      link: '#402ca8'
    },
    secondary: {
      green: '#45ba9d',
      lightGreen: '#29cca3',
      pink: '#e8b5b8',
      lightPink: '#fff5f5',
      lightPurple: '#ebe6f5',
      red: '#f15b60',
      grey: '#6d758e'
    },
    misc: {
      disabled: '#CECECE',
      listItemDivider: 'rgba(151,151,151, 0.2)',
      borderColor: '#979797',
      notice: 'rgba(232, 181, 184, 0.16)' // --> #E8B5B8 with 16% opacity.
    }
  }
};

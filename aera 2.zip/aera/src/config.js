// export const API_URL = 'http://skiply.43f4db4de0f64f8b8de9.southindia.aksapp.io/';

export const API_URL = 'https://qa.skiply.ae/';

export const API_URL_PROMOTIONS = 'https://revamp.rakbank.ae/api/';

export const API_KEY = 'UmFrVXNlclNlY3JldEtleQ';

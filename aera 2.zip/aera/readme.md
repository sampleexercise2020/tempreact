#Skiply
This project was created with `react-native init` - [More info](https://facebook.github.io/react-native/blog/2017/03/13/introducing-create-react-native-app)

##Table of contents

- [Overview](#overview)
  - [Purpose](#purpose)
- [Prerequisites](#prerequisites)
- [Setting up](#setting-up)
- [Start up](#start-up)
- [Creating](#creating)
- [Components](#components)
  - [Commented code](#commented-code)
- [State management](#state-management)
- [API](#api)
- [Styling](#styling)
  - [Storybook](#storybook)
- [Built with](#built-with)
- [Branches](#branches)
  - [Branch examples](#branch-examples)
- [Testing](#testing)
- [Authors](#authors)

## Overview

Skiply is an app built with React Native. The project started in March 2019 and is continually updated with the help of technologies such as React Native and Git.

###Purpose
The purpose of this app is to make it easier to transfer money in a safe way. This includes schools, restaurants and other venues. You simply find the item you want to purchase and make a quick transfer - and you are all done!

## Prerequisites

The following programs should be installed on your machine:

- [Node](https://nodejs.org) (version 10.15.0 or newer)
- [Yarn](https://yarnpkg.com)
- [Git](https://git-scm.com/)

You should also note that you will in some cases need:

- [XCode](https://developer.apple.com/xcode/) (for iOS development)
  **and/or**
- [Android Studio](https://developer.android.com/studio) (for Android development)

## Setting up

First clone the repository.

Run `yarn install` or `npm install` to install the dependencies used in this project.

We use [CocoaPods](https://cocoapods.org/) for installing native iOS libraries:

```
cd ios
pod install
```

In some cases, where the Cocoa Pods aren't working, use this command:

`pod deintegrate`

Then return to the `ios` folder and try to `pod install` again.

## Start up

**Start server:**

```elixir
yarn start-server # or npm run start-server
```

This will start up the development server on your local environment, either in Android Studio _(Android)_ or in XCode _(iOS)_. This process requires that you press the "play"-button in either Android Studio or XCode.

---

**Run device simulators:**

Please note that using these commands below does not require the `yarn start-server` command.

```elixir
yarn run-ios
#or
yarn run-android
```

---

**Start Storybook:**

```
yarn storybook
```

This will start the Storybook server on [localhost:7007](http://localhost:7007). You can control the Storybook both on the simulator and any connected devices from this site. No stories will show up unless either a simulator or device is running. Running simulator and device at the same time will result in bugs. In order for stories to show up Storybook must be run before running a simulator/device.

After running Storybook and getting the simulator going you need to refresh the simulator for it to update to the latest changes.

## Creating

When creating new components or files, make sure they are placed in the intended folder and always check that you are working in a tidy and organized fashion. This includes deleting files/folders that are not in use. We work this way to keep the project manageable for everybody involved.

**Rules:**

- Folders - are named in `lowercase`, example: `folder`

- Files - are named in `camel case` with the addition that the first letter is capitalized, example: `FileName.js`. Please note that it does **not** follow the standard rule of camel casing where we would write `fileName`.

- Name the folder appropriately and create sub folders and files in this folder if needed. This will make it easier to follow and manage in the future but also makes the project more organized. Please note that sub folders follow the same rule and should be written in `lowercase`.

- Make sure that you don't use unnecessary symbols or other characters that disrupts the rules of naming folders and files. Make sure you try to follow this standard.

## Components

Screens are found in the `modules` folder and that in turn has sub folders with the different sections names, for example `modules/home/` will have all the screens that involves the home tab.

Other components that are used in the project that aren't in the `modules` folder, will be created in the `components` folder. The rule of thumb is to create folders named the same as the screen folder that the components belong to.

For example if you have screens in `modules/home/`, and need to create special components that will be used in either of the home screens - you will need to create a folder structure as follows: `components/home/`. We use this standard for everyone to understand where the components belong.

---

It's important to note that we try to break up everything into as small pieces/components as possible. So don't be afraid to keep each component lightweight and relevant. It makes the project easier to handle for everyone involved and is much easier to understand by everyone. With that being said - it's also important to see if the component can be made re-usable in most cases.

### Commented code

Since the start of the project, we have tried to live by the rule:

> Well written code is self-explanatory.

Therefor you shall follow the same rules for writing easy to understand code. However, you should make sure to comment your code if you feel like it's necessary. A general rule of thumb is that we try to make sure the code is as comprehendable as possible for all parties involved in this project.

We also live by the **_"boy scout rule"_** - where we try to leave the code a little better than when we found it.

## State management (It's Easy Peasy)

State management is handled using [Easy Peasy](https://github.com/ctrlplusb/easy-peasy), which adds an abastraction layer on top of [Redux](https://redux.js.org/). Examples can be seen in the Storybook as well as the `Examples` folder.

## API

The API and Swagger documentation are available [here](http://skiply.43f4db4de0f64f8b8de9.southindia.aksapp.io/).

**TEMPORARY:**

Some API endpoints need an X-Auth-Token. This can be generated in wallet by sending a request to
the `"/wallet/cards/usersession/create"` endpoint. This will be a common service once the Login Micro Service is up and running.

Please click on the links that will take you to the right API endpoint.

- [Wallet](http://skiply.43f4db4de0f64f8b8de9.southindia.aksapp.io/skiply-wallet/swagger-ui.html)
- [Schools & Products](http://skiply.43f4db4de0f64f8b8de9.southindia.aksapp.io/skiply-schprod/swagger-ui.html)
- [Transactions](http://skiply.43f4db4de0f64f8b8de9.southindia.aksapp.io/skiply-payment/swagger-ui.html)
- [Cart](http://skiply.43f4db4de0f64f8b8de9.southindia.aksapp.io/skiply-cart/swagger-ui.html#/card-controller/getSessionUsingGET)

## Styling

**Quick FAQ:**

- Styling is done by using - [Styled Components](https://www.styled-components.com/docs/basics).
- Global styling (such as colors) are defined in a theme file in the root folder and can be used in each component by for example writing: `${(props) => props.theme.color.primary};`.
- All styling will be added on a component based level.
- To avoid repetiton - deconstructing the styles object is something to be done when working in this project.

**All of the statements above will be shown in an example below.**

---

**Example of a Styled Component in the app:**

```js
import React from 'react';
import styled from 'styled-components/native';

const SCExample = ({ title, onPress }) => {
  return (
    <Container onPress={onPress}>
      <Title>{title}</Title>
    </Container>
  );
};

export default SCExample;

/*As you might notice, the styling in the React Native part of styled components is done the exact same way as on the web.
The only difference is that we use Native based components such as (in this example) TouchableOpacity and Text.*/
const Container = styled.TouchableOpacity`
  height: 50px;
`;

const Title = styled.Text`
  color: rgb(64, 44, 168);
  font-size: 12px;
`;
```

---

To keep a uniform structure, we use **[Prettier](https://prettier.io/)**. You can see our config for our .rc-file below.

```js
{
  "printWidth": 80,
  "tabWidth": 2,
  "semi": true,
  "singleQuote": true,
  "jsxSingleQuote": true,
  "trailingComma": "none",
  "bracketSpacing": true,
  "jsxBracketSameLine": false,
  "arrowParens": "always"
}
```

We also use [Husky](https://github.com/typicode/husky) for creating Git hooks. On commit - all files that are not according to our standard, will be formatted correctly.

## Storybook

To use storybook, you must create a `filename.stories.js` file - containing the component you want to show in Storybook.

An example of a `stories.js` file:

```js
import React from 'react';
import { storiesOf } from '@storybook/react-native';
import CheckoutHeader from './CheckoutHeader';

storiesOf('Components|Header', module).add(
  'Checkout header - standard ',
  () => (
    <CheckoutHeader
      pageTitle='Checkout'
      title='Sara Andersson'
      subtitle='Brilliant Int School'
    />
  )
);
```

Then, as previously mentioned, you must start the Storybook server:

```
yarn storybook
```

This will start the Storybook server on [localhost:7007](http://localhost:7007).

After running Storybook and getting the simulator going you need to refresh the simulator for it to update to the latest changes.

## Built with

Technologies used to create this project:

- [React Native](https://facebook.github.io/react-native/blog/2017/03/13/introducing-create-react-native-app) (**not** created with Expo)
- [React Native FB SDK](https://github.com/facebook/react-native-fbsdk)
- [React Native Google Signin](https://github.com/react-native-community/react-native-google-signin)
- [React Native Biometrics](https://github.com/SelfLender/react-native-biometrics)
- [React Native Linear Gradient](https://github.com/react-native-community/react-native-linear-gradient)
- [React Native Signature Capture](https://github.com/RepairShopr/react-native-signature-capture)
- [React Native Navigation](https://github.com/wix/react-native-navigation)
- [React Native Awesome Card IO (OBS: Currently not in use.)](https://github.com/Kerumen/react-native-awesome-card-io)
- [React Native Calendar Events](https://github.com/wmcmahan/react-native-calendar-events)
- [React Native Sliding Up Panel](https://github.com/octopitus/rn-sliding-up-panel)
- [Easy Peasy](https://github.com/ctrlplusb/easy-peasy)
- [Storybook](https://storybook.js.org/)
- [Styled Components](https://www.styled-components.com)

## Branches

When developing we use several different branches in order to keep track of what we are all doing. The feature branches will be named after the Jira-tickets that are found in Citrix.

### Branch examples

Please make sure that you are always working in the intended branch so that it doesn't bring confusion to the other team members of the project.

---

####master branch

The `master branch` is mainly used for development. Where we push code that works and does not bug with any part of the app. Please make sure to keep it this way for a clean work process for everyone involved in the production.

####feature branch (named after the epics)##

A `feature branch` should be created whenever you are going to working on something big or a feature that is in the app. We usually create our feature branches named after the epics we are working on. This makes it possible for several people to work on the same feature branch/epic and not disturb one another because they are creating ticket branches which they will merge into the feature branch.

**Example:**

`feature/user-management`

####ticket branch (named after specific tickets)
When working on a special ticket found in Jira, please name it after that ticket name to let the team know exactly which feature you are working on. When you are done with that specific ticket, you should merge in into the feature branch of the epic you are working on, as mentioned above.

**Example:**

`skiply-14-login-flow`.

---

## Testing

Tests are run with Jest and individual components are tested with Enzyme when component functionality tests are required.

Jest takes "snapshots" of components which are commited to the repository. These snapshots are tested against the real component snapshot.

If the component changes somehow, tests will fail since the snapshot won't match anymore, therefore, run the tests with `yarn test:u` in order to take new snapshots of the components.

```sh
# Run unit tests
yarn test

# Run unit tests and update snapshots
yarn test:u

# Run unit tests with coverage report
yarn test:coverage
```

## Authors

Contributors to the project:

- Marigona Haxha
- Fabian Rios
- Kevin Åberg Kultalahti
- Sebastian Wittek

package ae.rakbank.skiply;

import com.BV.LinearGradient.LinearGradientPackage;
import com.appdynamics.eum.reactnative.ReactNativeAppdynamicsPackage;
import com.cardio.RNCardIOPackage;
import com.facebook.CallbackManager;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.ReactPackage;
import com.facebook.react.shell.MainReactPackage;
import com.facebook.reactnative.androidsdk.FBSDKPackage;
import com.gantix.JailMonkey.JailMonkeyPackage;
import com.google.firebase.FirebaseApp;
import com.imagepicker.ImagePickerPackage;
import com.learnium.RNDeviceInfo.RNDeviceInfo;
import com.reactnativecommunity.asyncstorage.AsyncStoragePackage;
import com.reactnativenavigation.NavigationApplication;
import com.reactnativenavigation.react.NavigationReactNativeHost;
import com.reactnativenavigation.react.ReactGateway;
import com.rnbiometrics.ReactNativeBiometricsPackage;
import com.rnfingerprint.FingerprintAuthPackage;
import com.rssignaturecapture.RSSignatureCapturePackage;
import com.vonovak.AddCalendarEventPackage;

import org.devio.rn.splashscreen.SplashScreenReactPackage;

import java.util.Arrays;
import java.util.List;

import co.apptailor.googlesignin.RNGoogleSigninPackage;
import io.invertase.firebase.RNFirebasePackage;
import io.invertase.firebase.analytics.RNFirebaseAnalyticsPackage;
import io.invertase.firebase.messaging.RNFirebaseMessagingPackage;
import io.invertase.firebase.notifications.RNFirebaseNotificationsPackage;
import io.invertase.firebase.fabric.crashlytics.RNFirebaseCrashlyticsPackage; 


public class MainApplication extends NavigationApplication {

     private static CallbackManager mCallbackManager =
     CallbackManager.Factory.create();

     protected static CallbackManager getCallbackManager() {
     return mCallbackManager;
     }

    private final ReactNativeHost mReactNativeHost = new ReactNativeHost(this) {
        @Override
        public boolean getUseDeveloperSupport() {
            return BuildConfig.DEBUG;
        }

        @Override
        protected List<ReactPackage> getPackages() {
            return Arrays.<ReactPackage>asList(
                new MainReactPackage(),
                new SplashScreenReactPackage(),
                new AsyncStoragePackage(),
                new JailMonkeyPackage(),
                new AddCalendarEventPackage(),
                new RNFirebasePackage(),
                new RNFirebaseAnalyticsPackage(),
                new RNFirebaseMessagingPackage(),
                new RNFirebaseNotificationsPackage(),
                new RNGoogleSigninPackage(),
                new JailMonkeyPackage(),
                new FingerprintAuthPackage(),
                new ReactNativeAppdynamicsPackage(),
                new RNDeviceInfo(),
                new RSSignatureCapturePackage(),
                new LinearGradientPackage(),
                new FBSDKPackage(mCallbackManager),
                new ReactNativeBiometricsPackage(),
                new RNFirebaseCrashlyticsPackage()
            );
        }

        @Override
        protected String getJSMainModuleName() {
            return "index";
        }
    };

    @Override
    protected ReactGateway createReactGateway() {
        ReactNativeHost host = new NavigationReactNativeHost(this, isDebug(), createAdditionalReactPackages()) {

            @Override
            protected String getJSMainModuleName() {
                return "index";
            }

        };
        return new ReactGateway(this, isDebug(), host);
    }

    @Override
    public boolean isDebug() {
        return BuildConfig.DEBUG;
    }

    protected List<ReactPackage> getPackages() {
        return Arrays.<ReactPackage>asList(new RSSignatureCapturePackage(), new LinearGradientPackage(),
        new LinearGradientPackage(), new RNDeviceInfo(), new RNCardIOPackage(), new SplashScreenReactPackage(),
         new FBSDKPackage(mCallbackManager), new ReactNativeBiometricsPackage(), new RNFirebasePackage(),
         new RNFirebaseMessagingPackage(), new RNFirebaseNotificationsPackage(), new ReactNativeAppdynamicsPackage(),
         new RNFirebaseAnalyticsPackage(), new ImagePickerPackage(), new FingerprintAuthPackage(), new JailMonkeyPackage(),
         new RNFirebaseCrashlyticsPackage());
    }

    @Override
    public List<ReactPackage> createAdditionalReactPackages() {
        return getPackages();
    }


    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(this);
    }
}